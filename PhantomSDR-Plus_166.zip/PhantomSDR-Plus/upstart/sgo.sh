#!/bin/bash
date >> /home/sv1btl/logwebsdr.txt
echo "Starting the initialization script of the PhantomSdr Server" >> /home/sv1btl/logwebsdr.txt
#echo "Starting the initialization script of the PhantomSdr Server"
echo " " >> /home/sv1btl/logwebsdr.txt
sleep 1
#ps ax | grep webs | grep -v 64-1 | grep sdr > /home/sv1btl/logwebsdr.flag
ps ax | grep spectrumserver | grep -v grep | grep -v color > /home/sv1btl/logwebsdr.flag
sleep 1

if ! [ -s /home/sv1btl/logwebsdr.flag ]; then
   sleep 1
#   /home/sv1btl/dongle
###spectrumserver -T 0 -m 504 -e 2 -g 8 -G 0,1,24,8 -f 4049920  -s 7999880  -  > ~/PhantomSDR-Plus/rtl.fifo &
/home/sv1btl/xgo.sh
else
   echo "PhantomSdr is running so no action needed"

fi

sleep 3

while [ true ]; do
#  sleep 1
#  ps ax | grep webs | grep -v 64-1 | grep sdr > /home/sv1btl/logwebsdr.flag
  ps ax | grep spectrumserver | grep -v grep | grep -v color > /home/sv1btl/logwebsdr.flag
  sleep 1
  if ! [ -s /home/sv1btl/logwebsdr.flag ]; then
   echo "PhantomSdr Server stopped"
   date >> /home/sv1btl/logwebsdr.txt
   echo "PhantomSdr Server Broken" >> /home/sv1btl/logwebsdr.txt
#   echo " " >> /home/sv1btl/logwebsdr.txt
   sleep 1
   echo "Starting the PhantomSdr Server" >> /home/sv1btl/logwebsdr.txt
   echo "Starting the PhantomSdr Server"
   echo " " >> /home/sv1btl/logwebsdr.txt

/home/sv1btl/xgo.sh
  else
   echo "PhantomSdr Server is running" > /dev/null
  fi
  sleep 3

done   

