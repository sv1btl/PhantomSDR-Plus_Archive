#!/bin/bash
/home/panos/fkill
sleep 1
/home/panos/check-go &

