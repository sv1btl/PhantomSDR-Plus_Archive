#!/bin/bash
echo "Starting the initialization script of the PhantomSdr Server"
#sudo 
#####killall -s 9 check-go
#sudo 
#sudo 
killall -s 9 spectrumserver
killall -s 9 rx_sdr
killall -s 9 miri_sdr
#sudo 
killall -s 9 rx888_stream
#sleep 2
killall -s 9 sdrplay_apiService > /dev/null
#sleep 3
killall -s 9 sdrplay_apiService > /dev/null
#sleep 3

# Turn USB powersaving off
#echo on | sudo tee /sys/bus/usb/devices/*/power/control > /dev/null
#echo on | sudo tee /sys/bus/usb/devices/*/power/control > /dev/null
#echo -1 | sudo tee /sys/module/usbcore/parameters/autosuspend > /dev/null

#service sdrplay restart
#sudo systemctl restart sdrplay
###########~/PhantomSDR-Plus/sdrplay_apiService &

# mkfifo ~/PhantomSDR-Plus/rtl.fifo
if test -e ~/PhantomSDR-Plus/rtl.fifo; then
 echo fifo alredy exists
else
 echo creating fifo...
 mkfifo ~/PhantomSDR-Plus/rtl.fifo
fi
cd ~/PhantomSDR-Plus

# sleep 2

#~/rx_tools/rx_sdr -f 4067000 -s 10000000 -d driver=sdrplay -F CS16 - | ./build/spectrumserver --config config-rsp1a.toml &
#  > /dev/null 2>&1 &  ## 5067000
# -d 4
## gia ton proto server ### miri_sdr -T 0 -m 504 -e 2 -g 0 -G 0,1,24,18 -f 128548060  -s 8499850  -  > ~/PhantomSDR-Plus/rtl.fifo &
# Me xamili ebaisthisia gia kentrarisma # miri_sdr -T 0 -m 504 -e 2 -g 0 -G 0,0,24,10 -f 25000000  -s 10000000  -  > ~/PhantomSDR-Plus/rtl.fifo &
#miri_sdr -T 0 -m 504 -e 2 -g 0 -G 1,1,24,24 -f 105000550  -s 10000000  -  > ~/PhantomSDR-Plus/rtl.fifo &
#miri_sdr -T 0 -m 504 -e 2 -g 0 -G 1,1,24,24 -f 105000550  -s 10000000  -  > ~/PhantomSDR-Plus/rtl.fifo &

## mexri 4-8-25 # miri_sdr -T 0 -m 504 -e 2 -g 0 -G 1,1,24,20 -f 25000060  -s 10000000  -  > ~/PhantomSDR-Plus/rtl.fifo &

#miri_sdr -T 0 -m 504 -e 2 -g 0 -G 0,0,24,18 -f 26049925  -s 8999800  -  > ~/PhantomSDR-Plus/rtl.fifo &
# miri_sdr -T 0 -m 504 -e 2 -g 8 -G 0,0,24,5 -f 4049925  -s 7999880  -  > ~/PhantomSDR-Plus/rtl.fifo &
### strogylemeno ## miri_sdr -T 0 -m 504 -e 2 -g 8 -G 0,1,24,8 -f 4050000  -s 8000000  -  > ~/PhantomSDR-Plus/rtl.fifo &

#### ~/rx_tools/rx_sdr -f 4067000 -s 8000000 -d driver=sdrplay -F CS16 - > ~/PhantomSDR-Plus/rtl.fifo &

~/PhantomSDR-Plus/rx888_stream/target/release/rx888_stream -f ~/PhantomSDR-Plus/rx888_stream/SDDC_FX3.img -s 22000000 -g 55 -m low --pga -r -d -o - > ~/PhantomSDR-Plus/rtl.fifo &

sleep 5
~/PhantomSDR-Plus/build/spectrumserver --config ~/PhantomSDR-Plus/config-rx888mk2.toml < ~/PhantomSDR-Plus/rtl.fifo &
##### ~/PhantomSDR-Plus/build/spectrumserver --config ~/PhantomSDR-Plus/config-rsp1a.toml < ~/PhantomSDR-Plus/rtl.fifo &
#####sleep 5
#####~/check-go &
#exit



