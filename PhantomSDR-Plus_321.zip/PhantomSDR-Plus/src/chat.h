// chat.h
#ifndef CHAT_H
#define CHAT_H

#include "client.h"
#include <atomic>
#include <string>
#include <mutex>
#include <unordered_map>
#include <deque>
#include <set>

class ChatClient : public Client {
public:
    ChatClient(connection_hdl hdl, PacketSender& sender);

    void send_event(std::string& event);

    virtual void on_chat_message(connection_hdl sender_hdl, std::string& user_id, std::string& message);
    virtual void store_chat_message(const std::string& message);
    virtual void on_close_chat(connection_hdl hdl);
    virtual void on_open_chat(connection_hdl hdl);

    std::string get_or_generate_username(const std::string& user_id);
    std::string get_chat_history_as_string();

    static std::set<connection_hdl, std::owner_less<connection_hdl>>& get_chat_connections();

    // BUG FIX (DEADLOCK): Previously the destructor acquired chat_connections_mtx
    // unconditionally.  If on_close_chat (or any code path that holds the mutex
    // on the same thread) ever triggers the final release of a ChatClient
    // shared_ptr, the destructor would try to re-acquire a non-recursive mutex
    // it already owns → deadlock.
    //
    // Fix: use an atomic "already removed" flag so the erase is attempted at
    // most once, and both the destructor and on_close_chat use the same helper.
    // The flag also eliminates the no-op double-erase that occurred when
    // on_close_chat fired before the destructor ran.
    virtual ~ChatClient() {
        remove_from_connections();
    }

private:
    // Ensures chat_connections.erase(hdl) happens exactly once, safely.
    // Called from both on_close_chat and the destructor.
    void remove_from_connections();

    // Set to true as soon as this client is removed from chat_connections.
    // Prevents a second mutex acquisition + erase in the destructor when
    // on_close_chat has already cleaned up (normal close path), and prevents
    // a deadlock when both paths race to acquire chat_connections_mtx.
    std::atomic<bool> removed_from_chat_{false};

    static std::set<connection_hdl, std::owner_less<connection_hdl>> chat_connections;
    static std::mutex chat_connections_mtx;
    static std::unordered_map<std::string, std::string> user_id_to_name;
    static std::deque<std::string> chat_messages_history;
    static const std::set<std::string> blocked_usernames;
    static const std::set<std::string> blocked_words;
    static bool is_history_loaded;

    void load_chat_history();
    void save_chat_history();
    bool is_valid_username(const std::string& username);
    std::string filter_message(const std::string& message);
};

#endif
