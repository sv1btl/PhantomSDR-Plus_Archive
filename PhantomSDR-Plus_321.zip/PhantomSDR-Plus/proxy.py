#!/usr/bin/env python3
"""
PhantomSDR-Plus Reverse Proxy
==============================
Reads all configuration from admin_config.json (written by setup_admin.sh):

  proxy_port   → port this proxy listens on
  port         → admin panel internal port
  public_port  → spectrumserver port

Routes:
  /admin*  → Admin panel  (localhost:{port})
  /*       → Spectrumserver (localhost:{public_port})

Run: python3 proxy.py
"""

import asyncio
import sys
import json
from pathlib import Path

try:
    import aiohttp
    from aiohttp import web, ClientSession, ClientTimeout, WSMsgType
except ImportError:
    print("[ERROR] aiohttp is not installed. Run:", file=sys.stderr)
    print("        pip3 install aiohttp --break-system-packages", file=sys.stderr)
    sys.exit(1)

# ── Load configuration from admin_config.json ─────────────────────────────────
_cfg_path = Path(__file__).parent / "admin_config.json"
try:
    with open(_cfg_path) as _f:
        _cfg = json.load(_f)
except FileNotFoundError:
    print(f"[ERROR] admin_config.json not found at {_cfg_path}", file=sys.stderr)
    print("        Run setup_admin.sh first.", file=sys.stderr)
    sys.exit(1)
except json.JSONDecodeError as _e:
    print(f"[ERROR] admin_config.json is invalid JSON: {_e}", file=sys.stderr)
    sys.exit(1)

for _key in ("port", "public_port", "proxy_port"):
    if _key not in _cfg:
        print(f"[ERROR] Missing '{_key}' in admin_config.json.", file=sys.stderr)
        print("        Re-run setup_admin.sh to reconfigure.", file=sys.stderr)
        sys.exit(1)

LISTEN_HOST    = "0.0.0.0"
LISTEN_PORT    = int(_cfg["proxy_port"])
ADMIN_UPSTREAM = f"http://127.0.0.1:{int(_cfg['port'])}"
SDR_UPSTREAM   = f"http://127.0.0.1:{int(_cfg['public_port'])}"

# ─────────────────────────────────────────────────────────────────────────────

async def proxy_request(request: web.Request, upstream: str) -> web.StreamResponse:
    url = upstream + str(request.rel_url)
    headers = {k: v for k, v in request.headers.items()
               if k.lower() not in ("host", "content-length", "accept-encoding")}
    headers["Accept-Encoding"]   = "identity"
    headers["X-Forwarded-For"]   = request.remote or ""
    headers["X-Forwarded-Host"]  = request.headers.get("Host", "")
    headers["X-Forwarded-Proto"] = "http"
    headers["X-Forwarded-Port"]  = str(LISTEN_PORT)
    try:
        timeout = ClientTimeout(total=60)
        async with ClientSession(timeout=timeout) as session:
            body = await request.read()
            async with session.request(
                method=request.method,
                url=url,
                headers=headers,
                data=body,
                allow_redirects=False,
                ssl=False,
            ) as resp:
                response = web.StreamResponse(
                    status=resp.status,
                    headers={k: v for k, v in resp.headers.items()
                             if k.lower() not in ("transfer-encoding", "connection")},
                )
                await response.prepare(request)
                async for chunk in resp.content.iter_chunked(8192):
                    await response.write(chunk)
                await response.write_eof()
                return response
    except aiohttp.ClientConnectorError:
        target = "Admin panel" if upstream == ADMIN_UPSTREAM else "Spectrumserver"
        return web.Response(
            status=502,
            text=f"502 Bad Gateway — {target} is not running on {upstream}",
        )
    except Exception as e:
        return web.Response(status=500, text=f"Proxy error: {e}")


async def proxy_websocket(request: web.Request, upstream: str) -> web.WebSocketResponse:
    """Forward WebSocket connections (needed for spectrumserver)."""
    ws_client = web.WebSocketResponse()
    await ws_client.prepare(request)

    ws_url = upstream.replace("http://", "ws://") + str(request.rel_url)
    headers = {k: v for k, v in request.headers.items()
               if k.lower() not in ("host", "upgrade", "connection",
                                     "sec-websocket-key", "sec-websocket-version")}
    try:
        async with ClientSession() as session:
            async with session.ws_connect(ws_url, headers=headers) as ws_upstream:
                async def forward_up():
                    async for msg in ws_client:
                        if msg.type == WSMsgType.TEXT:
                            await ws_upstream.send_str(msg.data)
                        elif msg.type == WSMsgType.BINARY:
                            await ws_upstream.send_bytes(msg.data)
                        elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                            break

                async def forward_down():
                    async for msg in ws_upstream:
                        if msg.type == WSMsgType.TEXT:
                            await ws_client.send_str(msg.data)
                        elif msg.type == WSMsgType.BINARY:
                            await ws_client.send_bytes(msg.data)
                        elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                            break

                task_up   = asyncio.ensure_future(forward_up())
                task_down = asyncio.ensure_future(forward_down())
                done, pending = await asyncio.wait(
                    {task_up, task_down},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass
    except Exception:
        pass

    if not ws_client.closed:
        await ws_client.close()
    return ws_client


async def handle(request: web.Request) -> web.StreamResponse:
    path = request.path
    if path.startswith("/admin"):
        upstream = ADMIN_UPSTREAM
    else:
        upstream = SDR_UPSTREAM
    if request.headers.get("Upgrade", "").lower() == "websocket":
        return await proxy_websocket(request, upstream)
    return await proxy_request(request, upstream)


async def main():
    app = web.Application()
    app.router.add_route("*", "/{path_info:.*}", handle)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, LISTEN_HOST, LISTEN_PORT)
    await site.start()

    admin_port = int(_cfg["port"])
    sdr_port   = int(_cfg["public_port"])
    print(f"╔══════════════════════════════════════════════════════╗")
    print(f"║  PhantomSDR-Plus Reverse Proxy                       ║")
    print(f"║  Listening : http://0.0.0.0:{LISTEN_PORT:<5}                ║")
    print(f"║  /admin*   → Admin panel  (localhost:{admin_port:<5})        ║")
    print(f"║  /*        → SDR server   (localhost:{sdr_port:<5})        ║")
    print(f"╚══════════════════════════════════════════════════════╝")

    await asyncio.Event().wait()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[stopped]")
