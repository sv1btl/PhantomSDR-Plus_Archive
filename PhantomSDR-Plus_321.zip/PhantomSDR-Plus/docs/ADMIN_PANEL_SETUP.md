# PhantomSDR-Plus Admin Panel — Setup Guide

> ⚠️ **Security notice:** Keep this admin panel on your home network or behind a VPN. Public exposure of port 3000 is not recommended without proper authentication hardening.

---

## Overview

The admin panel is a web interface for managing your PhantomSDR-Plus station. It consists of two Python services:

| Service | File | Role |
|---|---|---|
| Admin panel | `admin_server.py` | Flask web app, listens on port 3000 (internal) |
| Reverse proxy | `proxy.py` | Optional — exposes both the SDR and the admin panel on a single public port |

---

## What the admin panel gives you

- **Dashboard** — live server status, CPU/RAM, top processes, recent log output, terminal
- **Config Editor** — view, edit and save any `.toml`, `.sh`, `.json`, `.h`, `.cpp` file in your installation
- **Log Viewer** — tail any log file in real time
- **Markers** — view and edit frequency markers
- **Chat History** — view or clear the WebSDR chat log
- **Users** — live list of connected listeners with their tuned frequency, mode, duration and a ⚡ Kick button
- **Settings** — change admin password, SDR base directory, process name, public port

---

## Requirements

- PhantomSDR-Plus already installed and running
- Python 3.8+
- `pip3 install flask psutil aiohttp --break-system-packages`

---

## Step 1 — Files

Place these four files inside your PhantomSDR-Plus directory:

```
admin_server.py
manage_admin.sh
setup_admin.sh
proxy.py          ← optional, needed for single-port access
```

Make the shell scripts executable:

```bash
chmod +x setup_admin.sh manage_admin.sh
```

---

## Step 2 — Run the setup script

```bash
./setup_admin.sh
```

The script will:
1. Check that Python 3 is installed
2. Install `flask`, `psutil` and `aiohttp` via pip
3. Grant `ss` the `cap_net_admin` capability (required for the Kick Users feature)
4. Ask for the admin panel port (default: **3000**)
5. Write `admin_config.json` with your settings
6. Offer to install a systemd service for auto-start on boot

After setup, open your browser:
```
http://YOUR_SERVER_IP:3000/admin
```
Default password: **`admin`**

> ⚠️ **Change the password immediately** — go to Settings on first login. A first-run wizard will guide you through setting the SDR directory, process name, public port and a new password.

---

## Step 3 — Start / Stop / Restart

Use `manage_admin.sh` to control both the admin panel and the proxy together:

```bash
./manage_admin.sh start      # start admin panel (and proxy if present)
./manage_admin.sh stop       # stop both
./manage_admin.sh restart    # restart both
./manage_admin.sh status     # show running status and PIDs
```

If you installed the systemd service during setup:

```bash
sudo systemctl start   phantomsdr-admin
sudo systemctl stop    phantomsdr-admin
sudo systemctl restart phantomsdr-admin
sudo systemctl status  phantomsdr-admin
sudo journalctl -u phantomsdr-admin -f   # live logs
```

---

## Step 4 — Open firewall port

If accessing from outside your local network:

```bash
sudo ufw allow 3000    # for direct access to admin panel
# or
sudo ufw allow 9000    # if using proxy.py (see below)
```

---

## Step 5 — Kick Users feature

The Kick button on the Users page uses `ss -K` which requires a Linux capability. The setup script applies this automatically, but if you skipped it:

```bash
sudo setcap cap_net_admin+ep $(which ss)
# Verify:
getcap $(which ss)    # should show: cap_net_admin=ep
```

---

## proxy.py — what it is and when you need it

`proxy.py` is an optional **reverse proxy** that puts both the SDR server and the admin panel on a **single public port**. Without it:

- SDR server is at `http://YOUR_IP:9001`
- Admin panel is at `http://YOUR_IP:3000/admin` (separate port)

With proxy.py running on port 9000:

- SDR server is at `http://YOUR_IP:9000`
- Admin panel is at `http://YOUR_IP:9000/admin`

The proxy routes all `/admin*` requests to the admin panel and everything else to spectrumserver.

### How to configure proxy.py

Open `proxy.py` and edit the four constants near the top:

```python
LISTEN_HOST = "0.0.0.0"   # bind address (0.0.0.0 = all interfaces)
LISTEN_PORT = 9000         # the single public port you expose
ADMIN_UPSTREAM = "http://127.0.0.1:3000"   # must match your admin panel port
SDR_UPSTREAM   = "http://127.0.0.1:8900"   # must match your spectrumserver port
```

Then restart:

```bash
./manage_admin.sh restart
```

### How to change the admin panel internal port

The admin panel defaults to port **3000**. To change it, set the `ADMIN_PORT` environment variable before starting, or edit `admin_config.json`:

```bash
ADMIN_PORT=9000 python3 admin_server.py
```

Then update `ADMIN_UPSTREAM` in `proxy.py` to match:

```python
ADMIN_UPSTREAM = "http://127.0.0.1:9000"
```

### How to change the public proxy port

Edit `LISTEN_PORT` in `proxy.py` and open the new port in your firewall:

```bash
sudo ufw allow 9100   # example new port
```

---

## Useful manual commands

```bash
# Start admin panel manually (no manage_admin.sh)
python3 ~/PhantomSDR-Plus/admin_server.py &

# Kill the admin panel
pkill -f admin_server.py

# Kill the proxy
pkill -f proxy.py

# Free a port that is stuck in use
sudo fuser -k 3000/tcp

# Check what is listening on a port
ss -tlnp | grep 3000
```

---

## Log files

| File | Contents |
|---|---|
| `admin.log` | Admin panel output |
| `proxy.log` | Proxy output |
| `logwebsdr.txt` | Main SDR server log |
| `rade.log` | RADE/FreeDV sidecar log |

---

## Access summary

| Setup | SDR | Admin panel |
|---|---|---|
| Without proxy | `http://YOUR_IP:8900` | `http://YOUR_IP:3000/admin` |
| With proxy (default) | `http://YOUR_IP:9000` | `http://YOUR_IP:9000/admin` |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Admin panel not starting | Check `admin.log` — usually a missing Python package |
| Proxy not starting | Run `python3 -c "import aiohttp"` — if it fails, `pip3 install aiohttp --break-system-packages` |
| Kick button says "no connections" | Check `getcap $(which ss)` — run `sudo setcap cap_net_admin+ep $(which ss)` |
| Status always shows OFFLINE | Go to Settings → SDR Process Name — set it to the exact process name shown by `ps -eo comm,args \| grep -v grep` |
| Users page shows no data | Verify `/users` endpoint works: `curl http://127.0.0.1:8900/users` |
| External browser gets NetworkError | Ensure proxy.py is running: `./manage_admin.sh status` |
