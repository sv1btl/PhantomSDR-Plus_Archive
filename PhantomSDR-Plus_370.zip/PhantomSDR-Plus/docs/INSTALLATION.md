# PhantomSDR-Plus Installation Guide for System Operators

This comprehensive guide will walk you through installing and configuring PhantomSDR-Plus on your server.

---

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Pre-Installation Preparation](#pre-installation-preparation)
3. [Installing PhantomSDR-Plus](#installing-phantomsdr-plus) — the installer, and [what it does](#what-the-installer-does)
4. [Autorun Spot Reporter (FT8/FT4/WSPR)](#autorun-spot-reporter-ft8ft4wspr)
5. [Configuration](#configuration)
6. [SDR Device-Specific Setup](#sdr-device-specific-setup)
7. [Testing and Verification](#testing-and-verification)
8. [Setting Up Autostart](#setting-up-autostart)
9. [CPU Thermal Protection](#cpu-thermal-protection)
10. [Troubleshooting](#troubleshooting)

**Reference only — the installer already does all of this for you.** Read these sections when you are on a distribution none of the installers covers, or when you need to repair one piece by hand:

- [Installing Dependencies](#installing-dependencies)
- [Installing Node.js and npm](#installing-nodejs-and-npm)
- [Installing OpenCL](#installing-opencl-optional-but-recommended)
- [Building by hand](#building-by-hand-reference)
- [Installing Opus Audio Codec](#installing-opus-audio-codec)

---

## System Requirements

### Supported Operating Systems

**Primary (Recommended):**
- Ubuntu 24.04 LTS (x86_64) (recommended)
- Ubuntu 22.04 LTS (Jammy) — use `install_ubuntu22.sh`
- Debian 12 (Bookworm) and Debian 13 (Trixie)

**Alternative:**
- Fedora (latest stable release)
- Arch Linux (rolling)
- openSUSE Tumbleweed (not Leap — see the note further down)

### Hardware Requirements

**Minimum Configuration:**
- CPU: Dual-core processor (2+ GHz)
- RAM: 4 GB
- Storage: 10 GB free space
- Network: 100 Mbps connection

**Recommended Configuration:**
- CPU: Quad-core or better (Ryzen 5 2600, Intel i5-6500T or better)
- RAM: 8 GB or more
- Storage: 20 GB+ SSD
- GPU: AMD/NVIDIA with OpenCL support (highly recommended)
- Network: 1 Gbps connection

**High-Performance Configuration:**
- CPU: 6+ cores (Ryzen 7, Intel i7 or better)
- RAM: 16 GB or more
- Storage: NVMe SSD
- GPU: Dedicated GPU with OpenCL/CUDA support
- Network: 1 Gbps or better

---

## Pre-Installation Preparation

### 1. Update Your System

```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade -y
sudo reboot

# Fedora
sudo dnf update -y
sudo reboot
```

### 2. Verify Ubuntu Version

```bash
lsb_release -a
```

**Expected output should show:** Ubuntu 24.04 LTS

### 3. Check Available Disk Space

```bash
df -h
```

Ensure you have at least 10 GB free in your home directory.

### 4. Check CPU Information

```bash
lscpu
```

Note the number of cores/threads for configuration optimization.

---

## Installing Dependencies

> [!IMPORTANT]
> **You do not need this section for a normal installation.** `./install.sh` — or the installer for your distribution — does all of it for you; see [What the installer does](#what-the-installer-does). What follows is a reference for a manual setup, for a distribution none of the installers covers, or for repairing one piece by hand.


### Ubuntu 24.04 LTS

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  git \
  psmisc \
  wget \
  curl
```

### Fedora

```bash
sudo dnf install -y \
  g++ \
  meson \
  cmake \
  fftw3-devel \
  websocketpp-devel \
  flac-devel \
  zlib-devel \
  boost-devel \
  libzstd-devel \
  opus-devel \
  liquid-dsp-devel \
  git \
  psmisc \
  wget \
  curl
```

### Verify Installation

```bash
# Check if key dependencies are installed
pkg-config --modversion fftw3
cmake --version
meson --version
```

---

## Installing Node.js and npm

> [!IMPORTANT]
> **You do not need this section for a normal installation.** `./install.sh` — or the installer for your distribution — does all of it for you; see [What the installer does](#what-the-installer-does). What follows is a reference for a manual setup, for a distribution none of the installers covers, or for repairing one piece by hand.


PhantomSDR-Plus requires Node.js for building the frontend. We'll use NVM (Node Version Manager) for installation.

### 1. Install NVM

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
```

### 2. Load NVM

**IMPORTANT:** Close and reopen your terminal, or run:

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

### 3. Verify NVM Installation

```bash
nvm --version
```

Expected output: `0.40.4` or similar

### 4. Install Node.js

```bash
# Install Node.js 22 - the version every install script requires
nvm install 22

# Make it the default, so systemd units and cron see it too
nvm alias default 22

# Verify installation
node --version
npm --version
```

### 5. Optional: Install Additional Node Versions

```bash
# Install latest version
nvm install node

# Install specific version (if needed)
nvm install 22.22.3

# List installed versions
nvm list

# Use specific version
nvm use 22
```

---

## Installing OpenCL (Optional but Recommended)

> [!IMPORTANT]
> **You do not need this section for a normal installation.** `./install.sh` — or the installer for your distribution — does all of it for you; see [What the installer does](#what-the-installer-does). What follows is a reference for a manual setup, for a distribution none of the installers covers, or for repairing one piece by hand.


OpenCL dramatically improves performance by offloading FFT calculations to the GPU. This section covers Intel integrated graphics. For AMD/NVIDIA GPUs, refer to manufacturer documentation.

### Intel CPU with Integrated Graphics

#### 1. Install Base OpenCL Components

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  libclfft-dev \
  ocl-icd-opencl-dev \
  clinfo
```

#### 2. Download Intel Compute Runtime

```bash
mkdir -p ~/neo
cd ~/neo

wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
```

#### 3. Install Intel OpenCL Runtime

```bash
sudo dpkg -i *.deb
```

If dependency errors occur:

```bash
sudo apt --fix-broken install
```

#### 4. Install OpenCL ICD Loader

```bash
sudo apt update
sudo apt install intel-opencl-icd
```

If errors occur:

```bash
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
```

#### 5. Verify OpenCL Installation

```bash
sudo clinfo
```

You should see information about your OpenCL platform and devices. Look for:
- Number of platforms: 1 (or more)
- Platform name: Intel(R) OpenCL (or similar)
- Device type: GPU or CPU

#### 6. Reboot

```bash
sudo reboot
```

### AMD GPU OpenCL

For AMD GPUs, install ROCm:

```bash
# Add ROCm repository
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list

# Install ROCm
sudo apt update
sudo apt install rocm-opencl rocm-clinfo

# Add user to video group
sudo usermod -a -G video $USER

# Reboot
sudo reboot

# Verify
clinfo
```

### NVIDIA GPU OpenCL

For NVIDIA GPUs, install CUDA:

```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-525

# Install CUDA toolkit
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt update
sudo apt install cuda

# Reboot
sudo reboot

# Verify
nvidia-smi
clinfo
```

---

## Installing PhantomSDR-Plus

### Clone the Repository, Make Scripts Executable, Run the Installer

```bash
cd ~
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```

**⚠️ IMPORTANT:** After the installer completes, **restart your terminal** before continuing — the newly installed Node.js and Rust are not on your `PATH` until you do.

Use the script that matches your system. They do the same work and ask the same questions; only the package manager differs:

| System | Script |
|---|---|
| Ubuntu 24.04, Debian 13 (Trixie) | `./install.sh` |
| Ubuntu 22.04 (Jammy) | `./install_ubuntu22.sh` |
| Debian 12 (Bookworm) | `./install-Deb12.sh` |
| Fedora | `./install_fedora.sh` |
| Arch | `./install_arch.sh` |
| openSUSE Tumbleweed | `./install_opensuse.sh` |

> **Ubuntu 22.04 has its own installer.** `install_ubuntu22.sh` is `install.sh` with three Jammy-specific changes. It sets `DEBIAN_FRONTEND=noninteractive`, so the `tzdata` that arrives with `python3-matplotlib` cannot stop the run to ask for your time zone — and then swallow the answer meant for the next question. It calls `install_rade_ubuntu22.sh` directly, because Jammy's `python3-websockets` is 10.1 and RADE needs 11.0 or newer. And it installs OpenCL in a single step, since `intel-opencl-icd`, `mesa-opencl-icd` and `pocl-opencl-icd` are all in Jammy's own repositories, so the per-distribution menu `install.sh` needs does not apply. No newer compiler is involved: the stock GCC 11.4 accepts `-std=c++23` and builds the backend, Boost 1.74 and all, so do not install `gcc-12` for this. Start the wrong one of the two and it will notice and offer to hand over.

> **Ubuntu 26.04 (Resolute) and Arch build, but have not been run on air.** Both ship a Boost newer than 1.87, which removed the `io_service` API that the vendored websocketpp 0.8.2 was written against. The patched headers the installer copies in bridge that gap (`io_context`, `executor_work_guard`, `boost::asio::post`, the modern resolver), and a clean install has been verified end to end in containers on Boost 1.90 and 1.91. That proves the server compiles and starts — not that it serves a receiver for hours. Treat both as untested in production until someone reports back.

> **openSUSE means Tumbleweed.** That is where `install_opensuse.sh` is verified. Leap 15.6 does not work: its repositories carry no `liquid-dsp-devel` at all, which the backend needs, and Boost is only available under versioned package names. Supporting Leap would mean adding third-party OBS repositories, so it is out of scope for now.

### What the installer does

Nothing has to be prepared by hand first — no dependency list to paste, no Node.js to fetch, no OpenCL packages to hunt down. The run is interactive from beginning to end, so do not leave it unattended, and allow anywhere from about twenty minutes to well over an hour depending on the machine and on how many extras you keep.

| # | Step | What you are asked |
|---|---|---|
| 1 | Detects the distribution and installs every build dependency (compiler, meson/ninja, FFTW, Boost, FLAC, Opus, liquid-dsp, zlib/zstd, libcurl …) | nothing |
| 2 | Installs Node.js 22 through nvm if the system Node is missing or too old | nothing |
| 3 | Builds the backend with meson | nothing |
| 4 | Builds the driver for your receiver — RX888 MkII / RX888, RTL-SDR (Blog V4 asked separately), SDRplay, or none. Picking the RX888 **also installs the udev rules**, so the server never needs `sudo` for the device | which SDR you have |
| 5 | Opens `frontend/site_information.json` in your editor | your callsign, locator, hardware, antenna — **do not skip this** |
| 6 | Installs the frontend dependencies and builds the desktop and `/mobile` pages | nothing |
| 7 | Installs OpenCL, choosing the provider from the hardware it finds (Intel / AMD / NVIDIA GPU, or the x86 CPU runtime). If there is no OpenCL-capable device it says so and moves on | confirm, default yes |
| 8 | Installs the **admin panel**, the **FreeDV RADE V1 decoder** and the **statistics server** — all three by default | confirm each, default yes; each has its own questions |
| 9 | Patches the two websocketpp headers that websdr.org registration needs | nothing |
| 10 | Runs `recompile.sh` as its last action, so everything is built from the patched sources | `[3] Both backend and frontend` → starting variant → `[1] build-all.sh` |

After a reboot the RX888 udev rules and any OpenCL driver are fully in effect; the installer tells you when a reboot or a re-login is needed.

When it sets up the admin panel, the installer offers to install the two systemd units as well, and **strongly recommends** accepting: the CPU over-temperature guard runs inside the panel, so without them a reboot or a crash leaves the machine unprotected. The offer is skipped automatically where systemd is not running (containers, WSL1, OpenRC) — see the [Admin Panel guide](ADMIN_PANEL_SETUP.md#step-3--start--stop--restart).

Each extra is a normal script you can also run on its own at any time — `./setup_admin.sh` ([manual](ADMIN_PANEL_SETUP.md)), `./install_rade.sh` ([manual](RADE_README.md)), `./install-stats-server.sh` ([manual](sdr-stats/README.md)) and `./setup-rx888-udev.sh` — they are exactly what the installer calls.

### Building by hand (reference)

> [!IMPORTANT]
> **You do not need this section for a normal installation.** `./install.sh` — or the installer for your distribution — does all of it for you; see [What the installer does](#what-the-installer-does). What follows is a reference for a manual setup, for a distribution none of the installers covers, or for repairing one piece by hand.

Should you ever have to build without the installer — a distribution none of the scripts covers, or repairing a half-finished build:

#### Build the Backend

```bash
# Clean any previous builds, Configure build with optimization, Compile
rm -rf build
meson setup build --buildtype=release --optimization=3
meson compile -C build

# Verify binary was created
ls -lh build/spectrumserver
```

#### Build the Frontend

```bash
cd frontend

# Install dependencies, Fix any vulnerabilities, Build the frontend
npm install
npm audit fix
npm run build

# Return to project root
cd ..
```

### Verify Installation

```bash
# Check if binary exists
ls -lh build/spectrumserver

# Check if frontend was built
ls -lh frontend/dist/

# List important files
ls -lh *.sh *.toml
```

---

## Installing Opus Audio Codec

> [!IMPORTANT]
> **You do not need this section for a normal installation.** `./install.sh` — or the installer for your distribution — does all of it for you; see [What the installer does](#what-the-installer-does). What follows is a reference for a manual setup, for a distribution none of the installers covers, or for repairing one piece by hand.


Opus provides better audio quality and lower latency compared to FLAC.

### 1. Install libopus System Library

```bash
sudo apt-get update
sudo apt-get install -y libopus0 libopus-dev
```

### 2. Install Opus Decoder for Frontend

```bash
cd PhantomSDR-Plus/frontend

# Install npm dependencies if not already done, Install Opus WASM decoder, Fix any vulnerabilities, Rebuild frontend
npm install
npm install @wasm-audio-decoders/opus-ml
npm audit fix
npm run build

# Return to project root
cd ..
```

### 3. Verify Opus Installation

```bash
# Check if Opus system library is installed
pkg-config --modversion opus

# Check if Opus npm package is installed
cd frontend
npm list @wasm-audio-decoders/opus-ml
cd ..
```

---

## Autorun Spot Reporter (FT8/FT4/WSPR)

PhantomSDR-Plus ships an optional **autorun spot reporter** (in the `autorun/` directory). It decodes FT8/FT4/WSPR server-side straight off the receiver and uploads spots to the reporting networks:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

It is controlled entirely from the **admin panel → "Spot Reporting"** tab, and **reporting is OFF by default** — nothing is transmitted or uploaded until you enable it there. The decoder runs as a separate Node.js daemon and taps the receiver's audio locally, so it adds no extra RF hardware.

### Requirements

| Requirement | Notes |
|-------------|-------|
| **Node.js 22+** | Same runtime the frontend build already needs — installed in the [Node.js step](#installing-nodejs-and-npm). |
| **`ws` + `cbor-x` npm packages** | Resolved through `autorun/node_modules`, a symlink to the frontend's `node_modules` (both packages are declared in `frontend/package.json`). |
| **`util-linux`** (`taskset`) | The admin "Start" button pins the daemon to the E-cores with `taskset`. Present on virtually every distro; the installers add it explicitly. |
| **Callsign + grid** | Read from `frontend/site_information.json` (`siteSysop` / `siteGridSquare`) unless overridden in the admin tab. Spots are uploaded under this callsign. |

> ⚠️ **Report only what you actually receive.** Spots are uploaded to public networks under your callsign — only enable bands/modes your receiver genuinely hears, and use your correct grid square.

### Automatic installation

`install.sh` (and the per-distro variants: `install_ubuntu22.sh`, `install-Deb12.sh`, `install_arch.sh`, `install_fedora.sh`, `install_opensuse.sh`) handle everything for you: they install Node.js 22 and `util-linux`, run the frontend `npm install`, and then create the `autorun/node_modules` symlink automatically. No extra steps are required — the feature is ready as soon as `install.sh` finishes.

### Manual installation

> [!NOTE]
> The installer already does this for you: it creates the symlink and installs `util-linux`. Use the steps below only to repair an installation by hand.

If you installed manually (Option B), create the symlink yourself after the frontend `npm install` so the daemon can resolve its dependencies:

```bash
cd ~/PhantomSDR-Plus

# 1. Frontend deps must be installed first (ws + cbor-x live there)
cd frontend && npm install && cd ..

# 2. Link the autorun daemon to the frontend's node_modules
ln -sfn ../frontend/node_modules autorun/node_modules

# 3. Ensure taskset is available (Debian/Ubuntu shown; use your package manager)
sudo apt install -y util-linux
```

> **Note:** `autorun/node_modules` is git-ignored, so a fresh `git clone` never contains it — the symlink must be (re)created after every clean checkout. The installers do this for you; the command above is only for manual setups.

### Verifying

```bash
# The symlink should point at ../frontend/node_modules
ls -l autorun/node_modules

# ws + cbor-x must resolve
ls -d frontend/node_modules/ws frontend/node_modules/cbor-x

# taskset must be on PATH
command -v taskset
```

Then open the admin panel, go to the **Spot Reporting** tab, set your identity, tick the bands/modes to decode, enable the destination(s), and press **Start**. A "📶 REPORTING" badge appears on the main waterfall whenever reporting is active. (PSK Reporter uploads batch every 5 minutes and wsprnet every 2 minutes, so a freshly started daemon shows "0 sent" for the first few minutes — that is normal.)

Two different counters are then shown, and it is easy to mistake one for the other. The **SPOTS UPLOADED PER DECODER** tiles count only the current run, so Stop/Start resets them to zero; the number beside each band/mode checkbox is that slot's **all-time** total, kept in `autorun-totals.json` so it survives restarts. See the [Admin Panel guide](ADMIN_PANEL_SETUP.md) for both, and for the **Graphs** page that plots CPU frequency, load, temperature and users online over the last 15 minutes to 24 hours.

> **If your machine runs hot**, the panel also carries a [Thermal Guard](ADMIN_PANEL_SETUP.md#thermal-guard) that stops the server when the CPU reaches a dangerous temperature and restarts it once cool. It derives its thresholds from your own CPU's critical trip point, so there is nothing to calculate, and it works whatever start/stop method you use. It is installed with the panel but starts in log-only mode: it records what it *would* have done and changes nothing until you enable it in Settings. Continuous decoding keeps a CPU busy around the clock, so it is worth reading the CRASH tab after a week of autorun to see how close your machine actually gets.

> **Server port is auto-detected.** The daemon taps spectrumserver's own `[server] port` directly (loopback + token, bypassing the proxy). It reads that port from the config file the running spectrumserver was launched with, so it works on any port with no configuration — the `[autorun] tap backend: …` line in `autorun.log` shows what it resolved. If your server wasn't running when the daemon started, or you use an unusual setup, pin it in `autorun.json`:
> ```json
> "server": { "host": "127.0.0.1", "port": 9002 }
> ```
> A wrong port shows up as `504` / `tap closed 1006` in `autorun.log` with `decodes` stuck at 0.

---

## Configuration

### 1. Choose Your Configuration File

Select the appropriate config file for your SDR:

- `config-rtl.toml` - RTL-SDR dongles
- `config-rsp1a.toml` - SDRplay RSP1A
- `config-airspyhf.toml` - Airspy HF+ Discovery
- `config-rx888mk2.toml` - RX888 MK2
- `config.example.hackrf.toml` - HackRF One

For this example, we'll use RTL-SDR.

### 2. Edit Configuration File

```bash
nano config-rtl.toml
```

#### Key Settings to Configure

```toml
[server]
port = 9002                      # Web interface port (or everything else)
html_root = "frontend/dist/"     # Frontend location
otherusers = 1                   # Show other users (1=yes, 0=no)
threads = 2                      # Number of server threads

[websdr]
register_online = true           # Register on sdr-list.xyz (true/false)
name = "Your WebSDR Name"        # Display name
antenna = "Your Antenna Type"    # e.g., "Vertical", "Loop", "Dipole"
grid_locator = "AB12cd"          # Your Maidenhead grid square
hostname = "your.domain.com"     # Your domain or IP address

[input]
sps = 2048000                    # Sample rate (adjust for your coverage)
fft_size = 131072                # FFT size (higher = better resolution)
brightness_offset = -10          # Waterfall brightness adjustment
frequency = 145000000            # Base frequency in Hz (145 MHz for 2m)
signal = "iq"                    # "iq" for complex, "real" for real sampling
fft_threads = 2                  # FFT processing threads
accelerator = "opencl"           # "none", "cuda", or "opencl"
audio_sps = 12000                # Audio sample rate (keep at 12000)
audio_compression = "opus"       # "flac" or "opus"
smeter_offset = -2               # S-meter calibration
waterfall_size = 1024            # Waterfall FFT size
waterfall_compression = "zstd"   # Waterfall compression

[input.driver]
name = "stdin"                   # Input driver
format = "u8"                    # Sample format for RTL-SDR

[input.defaults]
frequency = 145500000            # Default tuning frequency
modulation = "FM"                # Default modulation mode
```

#### Sample Rate Guidelines

| Coverage | Sample Rate | FFT Size |
|----------|-------------|----------|
| 2 MHz | 2048000 | 131072 |
| 3.2 MHz | 3200000 | 131072 |
| 10 MHz | 10000000 | 1048576 |
| 30 MHz | 30000000 | 2097152 |
| 60 MHz | 60000000 | 8388608 |

### 3. Configure Site Information

```bash
nano frontend/site-information.json
```

Edit the following fields:

```json
{
  "siteSysop": "YourCallsign",
  "siteSysopEmailAddress": "your@email.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "Your City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Computer specifications",
  "siteSoftware": "PhantomSDR-Plus v3.7.0",
  "siteReceiver": "Your SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional information",
  "siteIP": "http://your.domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

**IARU Regions:**
- **1**: Europe, Africa, Middle East, Northern Asia
- **2**: Americas (North, Central, South), Caribbean
- **3**: Asia-Pacific, Oceania

### 4. Customize Frequency Markers (Optional)

```bash
nano markers.json
```

Add your favorite frequencies, repeaters, and broadcast stations.

### 5. Edit Start Script

```bash
nano start-rtl.sh
```

The start script is a self-contained launcher + watchdog. Edit only the **RECEIVER CONFIGURATION** block near the top so the receiver arguments match your setup:

```bash
# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═══
RX_LABEL="RTL-SDR"
RX_COMM="rtl_sdr"                       # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rtl.toml"    # your .toml
FIFO="$PHANTOMDIR/rtl.fifo"
RX_ARGS="${RX_ARGS:--f 145000000 -s 2048000 -}"   # receiver args (edit these)
```

Parameters inside `RX_ARGS`:
- `-f 145000000`: Center frequency (145 MHz)
- `-s 2048000`: Sample rate (2.048 MSPS)

`CONFIG` points at your `.toml`. You do **not** need to edit anything else in the script — the start/restart/watchdog/logging logic is generic. You can also override the receiver args at launch without editing the file: `RX_ARGS="-f 145000000 -s 2048000 -" ./start-rtl.sh` (`RX888_ARGS` for `start-rx888mk2.sh`).

---

## SDR Device-Specific Setup

### RTL-SDR

#### Install RTL-SDR Tools

```bash
sudo apt install -y rtl-sdr
```

#### Test RTL-SDR

```bash
rtl_test
```

Press Ctrl+C to stop. You should see sample rate information.

#### Edit Configuration

```bash
nano config-rtl.toml
```

Common settings for RTL-SDR:
```toml
sps = 2048000
frequency = 145000000
signal = "iq"
format = "u8"
```

### SDRplay RSP1A

#### Install SoapySDR and SDRplay Support

```bash
# Install SoapySDR
sudo apt install -y soapysdr-tools

# Download SDRplay API
cd ~/Downloads
wget https://www.sdrplay.com/software/SDRplay_RSP_API-Linux-3.07.1.run
chmod +x SDRplay_RSP_API-Linux-3.07.1.run
sudo ./SDRplay_RSP_API-Linux-3.07.1.run

# Install SoapySDRPlay
git clone https://github.com/pothosware/SoapySDRPlay.git
cd SoapySDRPlay
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig
```

#### Test SDRplay

```bash
SoapySDRUtil --find="driver=sdrplay"
```

#### Additional Instructions

See the included file: `instractions-for-rsp1a`

### Airspy HF+

#### Install Airspy Tools

```bash
sudo apt install -y airspy
```

#### Test Airspy

```bash
airspy_info
```

#### Additional Instructions

See the included file: `instractions-for-airspy`

### RX888 MK2

#### Install RX888 Tools

```bash
# Install rx_tools
git clone https://github.com/rxseger/rx_tools.git
cd rx_tools
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig

# Install RX888 firmware and support
# Follow manufacturer instructions
```

#### Run rx888_stream Without sudo (udev rules)

By default the RX-888's Cypress FX3 USB device is only accessible to root, so `rx888_stream` would need `sudo`. Run the bundled helper once to install udev rules and add yourself to the `plugdev` group:

```bash
./setup-rx888-udev.sh          # re-runs itself with sudo automatically
```

It writes `/etc/udev/rules.d/99-rx888.rules` for all three Cypress FX3 product ids (`04b4:00f1`/`00f3` bootloader and `04b4:8613` firmware-loaded), reloads udev, and creates a stable `/dev/rx888` symlink. **Log out and back in** (for the group change) and **replug the device** once, then `rx888_stream` — and the `start-rx888mk2.sh` launcher — run without `sudo`. It is idempotent, so it's safe to re-run. To set up a different account: `RX888_USER=<name> ./setup-rx888-udev.sh`.

#### Edit Configuration

```bash
nano config-rx888mk2.toml
```

Common settings for RX888:
```toml
sps = 60000000
frequency = 0
signal = "real"
format = "s16"
fft_size = 8388608
```

### HackRF One

#### Install HackRF Tools

```bash
sudo apt install -y hackrf
```

#### Test HackRF

```bash
hackrf_info
```

---

## Testing and Verification

### 1. Test Run

```bash
# For RTL-SDR
./start-rtl.sh
```

This starts the server **in the background** (it detaches and returns immediately) and begins logging to `logwebsdr.txt`.

### 2. Check for Errors

The script logs its progress to `logwebsdr.txt` — watch it live:

```bash
tail -f logwebsdr.txt
```

Look for:
- ✅ `Starting the initialization script of the PhantomSDR Server`
- ✅ `<receiver> running (PID …)`
- ✅ `Server started normally`
- ❌ `Server … FAILED …` or `ERROR: receiver binary '…' not found` (fix the receiver args/`.toml`, or install the receiver tool, then re-run the start script)

### 3. Access Web Interface

Open your browser to:
```
http://localhost:9002
```

(Replace port number with your configured port)

### 4. Verify Functionality

- Waterfall should be displaying
- Audio should play when clicking on signals
- S-meter should respond to signals
- User count should show "1"

### 5. Test from Another Device

From another computer on your network:
```
http://YOUR_SERVER_IP:9002
```

### 6. Check Resource Usage

```bash
# Monitor CPU usage
htop

# Monitor GPU usage (if OpenCL/CUDA enabled)
nvidia-smi  # For NVIDIA
radeontop   # For AMD

# Monitor network usage
iftop
```

### 7. Stop the Server

The server runs in the background under a watchdog, so **Ctrl+C won't stop it** (and the watchdog would just restart it). Use the shared stop script, which works for any receiver — it stops the watchdog first, then the receiver and `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## Setting Up Autostart

### Using systemd (Recommended)

#### 1. Create Service File

```bash
sudo nano /etc/systemd/system/phantomsdr.service
```

Add the following content (adjust paths and user):

```ini
[Unit]
Description=PhantomSDR-Plus WebSDR Server
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/PhantomSDR-Plus
# Run the watchdog in the FOREGROUND (note the --watchdog flag) so systemd can
# track it. Do NOT use the plain "./start-rtl.sh" here — that form detaches into
# the background and exits, which systemd would treat as the service stopping.
ExecStart=/home/youruser/PhantomSDR-Plus/start-rtl.sh --watchdog
ExecStop=/home/youruser/PhantomSDR-Plus/stop-websdr.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

> The `--watchdog` process already auto-restarts the receiver/`spectrumserver` on its own; `Restart=always` is just a backstop for the rare case the watchdog itself exits. Because systemd supervises the server here, you can use `systemctl start/stop/restart` and `journalctl -u phantomsdr -f` in place of running the scripts by hand.

#### 2. Enable and Start Service

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable phantomsdr.service

# Start service now
sudo systemctl start phantomsdr.service

# Check status
sudo systemctl status phantomsdr.service
```

#### 3. Manage Service

```bash
# Start
sudo systemctl start phantomsdr

# Stop
sudo systemctl stop phantomsdr

# Restart
sudo systemctl restart phantomsdr

# View logs
sudo journalctl -u phantomsdr -f
```

### Using Screen (Alternative)

> Usually unnecessary: `./start-rtl.sh` already detaches into the background (via `setsid`) and keeps running after you log out, with its own watchdog. Screen is only handy if you specifically want an interactive session to run the foreground `./start-rtl.sh --watchdog` form.

#### 1. Install Screen

```bash
sudo apt install -y screen
```

#### 2. Start in Screen Session

```bash
screen -S phantomsdr
./start-rtl.sh
```

Press Ctrl+A, then D to detach.

#### 3. Reattach to Session

```bash
screen -r phantomsdr
```

---

## CPU Thermal Protection

> 📖 **Full manual: [THERMAL_GUARD.md](THERMAL_GUARD.md)** — the four modes and what a sysop must do for each, the standalone systemd service, enabling the throttle stage without root, testing and troubleshooting.

PhantomSDR-Plus ships a guard that stops the server if the CPU reaches a dangerous temperature and starts it again once it has cooled. It derives its thresholds from the critical trip point your own CPU publishes, so there is nothing to calculate, and it works whatever start/stop method you use.

**If you run the admin panel, you already have it** — it runs inside the panel and is configured on its Settings page. See the [Admin Panel guide](ADMIN_PANEL_SETUP.md#thermal-guard). The rest of this section is for installations **without** the panel.

### 1. Check what the guard sees on your machine

```bash
cd ~/PhantomSDR-Plus
python3 thermal_guard.py --once
```

```
sensor     : hwmon:coretemp
temperature: 58.0 C
crit       : 100.0 C
mode       : log
thresholds : warn 88.0  throttle 92.0  stop 95.0  resume 75.0 (C)
cpufreq    : not writable — throttle stage disabled
```

Only real CPU-die sensors are used (`coretemp`, `k10temp`, `zenpower`, `cpu_thermal`); `acpitz` and unlabelled thermal zones are ignored on purpose, because they often report a case or board temperature tens of degrees below the CPU. If this prints `sensor : NONE`, that machine cannot be protected — common on a VPS or inside a container — and the guard will stay inactive rather than pretend.

Nothing needs to be installed for this: `thermal_guard.py` uses only the Python standard library.

### 2. Configure it

The guard reads `admin_config.json` next to `thermal_guard.py`. Create it if you do not have one — with no panel installed you will not. The minimum useful file:

```json
{
  "sdr_process_name": "spectrumserver",
  "stop_script":  "stop-websdr.sh",
  "start_script": "start-rx888mk2.sh",
  "thermal_mode": "stop+restart"
}
```

- `thermal_mode` — `log` (record only, the default), `throttle`, `stop`, or `stop+restart`. **This is the one you must set**, because the guard ships inert: left alone it only writes what it *would* have done. You can also pass it on the command line as `--mode stop+restart`, which overrides the file — so if you are happy with every other default you need no config file at all.
- `stop_script` / `start_script` — how the guard stops and starts your server. Without a stop script it falls back to `SIGTERM`, then `SIGKILL` after 10 seconds, on `sdr_process_name`. Without a start script it stops but never restarts.
- Thresholds and timings can be set here too, with the same key names the panel uses — the full table is in the [Admin Panel guide](ADMIN_PANEL_SETUP.md#thermal-guard).

> **If systemd supervises your SDR server**, point `stop_script` at a small wrapper that runs `systemctl stop your-unit` rather than letting the guard signal the process directly. The guard will win either way — while the CPU is too hot it re-issues the stop every 2 seconds, so anything that revives the server is undone — but a clean stop beats a fight every two seconds.

### 3. Run it as a service

The repository includes a ready-made unit, `thermal-guard.service`. Edit `User=` and the two paths in it, then:

```bash
sudo cp thermal-guard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now thermal-guard
systemctl status thermal-guard
```

`User=` must be an account allowed to run your start/stop scripts — normally the same user that runs the SDR server. **A guard running as a user that cannot stop the server leaves you unprotected while looking protected.**

To arm the guard from the unit instead of the config file, add `--mode` to `ExecStart`:

```ini
ExecStart=/usr/bin/python3 -u /home/sysop/PhantomSDR-Plus/thermal_guard.py --mode stop+restart
```

To run it without systemd:

```bash
cd ~/PhantomSDR-Plus
nohup python3 -u thermal_guard.py --mode stop+restart >> thermal.log 2>&1 &
```

`python3 thermal_guard.py --help` lists every option, including `--config` for a config file somewhere other than beside the script.

### 4. Watch it, then trust it

Everything the guard does is written to `crash.log` in the PhantomSDR-Plus directory, one event per line:

```
[THERMAL] warn: 89.0C (warn=88.0 crit=100.0) sustained 31s
[THERMAL] STOPPED server: 96.0C sustained 62s (stop=95.0 crit=100.0) — Started stop-websdr.sh
[THERMAL] lockout: process reappeared at 94.0C — re-stopped [3 time(s) so far]
[THERMAL] recovered: 74.0C held below 75.0 — lockout cleared
```

```bash
grep THERMAL crash.log
```

Leave `thermal_mode` at `"log"` for a week first and read that file after your heavy moments — a full rebuild, a hot afternoon. If nothing appears, your machine never came close. Then set the mode to `stop`.

Before relying on it, prove the whole path once by adding a fake reading above your stop threshold:

```json
"thermal_test_temp": 97
```

The guard treats it as real, so warn → stop → lockout → recover → restart all run on demand. Remove the line (or set it to `null`) to return to the real sensor. With the mode at `stop` this really does stop the server and disconnect your listeners, so do it when nobody is on — or run the test at `log`, where it shows what *would* have happened without touching anything.

---

## Troubleshooting

### Build Errors

#### Dependency Issues

```bash
# Ubuntu: Install missing dependencies
sudo apt install --fix-broken

# Fedora: Install missing dependencies
sudo dnf install <package-name>
```

#### Meson Configuration Fails

```bash
# Clean and reconfigure
rm -rf build
meson setup build --buildtype=release
```

#### The backend built but there is no web page

The symptom is an installation that looks like it mostly worked: `build/spectrumserver` exists, the server starts, and the browser gets nothing — because `frontend/dist/` was never produced. Look back through the installer output for:

```
[vite-plugin-top-level-await] missing field `type`
    at Compiler.printSync (node_modules/@swc/core/index.js:257:29)
error during build:
   ❌ Failed: Default
```

`vite-plugin-top-level-await` asks for `@swc/core` `^1.12.14`, so a fresh `npm install` resolves 1.16.0, whose `printSync()` rejects the syntax tree the plugin gives it. It has nothing to do with your distribution — every installer now pins the working version, and so does `frontend/package.json`. A machine installed before that pin was added keeps working until its `node_modules` is deleted, which is why this appears out of nowhere on a reinstall.

If you are repairing an older checkout by hand:

```bash
cd frontend
npm pkg set 'overrides.@swc/core=1.15.33'
npm install
./build-all.sh
```

### Runtime Errors

#### Port Already in Use

```bash
# Find process using port
sudo lsof -i :9002

# Kill process
sudo kill -9 <PID>
```

#### Permission Denied for SDR

```bash
# Add user to plugdev group
sudo usermod -a -G plugdev $USER

# Reload groups (or log out and back in)
newgrp plugdev
```

For an **RX-888 MkII** this isn't enough on its own — the Cypress FX3 device also needs udev rules. Run the bundled helper (installs the rules *and* adds you to `plugdev`), then log out/in and replug the device:

```bash
./setup-rx888-udev.sh
```

#### Audio Issues

```bash
# Try different codec
# Edit config file and change:
audio_compression = "flac"  # or "opus"

# Rebuild
cd frontend && npm run build && cd ..
```

### OpenCL Issues

#### clinfo Shows No Devices

```bash
# Verify drivers are loaded
sudo clinfo

# Check OpenCL ICD files
ls /etc/OpenCL/vendors/

# Reinstall drivers (Intel example)
sudo apt remove --purge intel-opencl-icd
sudo apt install intel-opencl-icd
```

#### Performance Not Improved

```bash
# Verify OpenCL is enabled in config
accelerator = "opencl"

# Try different device
# Add to config file:
[input.opencl]
device_id = 0  # Try 0, 1, 2, etc.
```

### Network Issues

#### Can't Access from Other Devices

```bash
# Check firewall
sudo ufw status
sudo ufw allow 9002/tcp

# Or disable firewall temporarily for testing
sudo ufw disable
```

#### High Latency

```bash
# Reduce waterfall size in config
waterfall_size = 512

# Increase buffer size
buffer_size = 16384

# Use Opus instead of FLAC
audio_compression = "opus"
```

### SDR Device Issues

#### RTL-SDR Not Found

```bash
# Check if device is recognized
lsusb | grep Realtek

# Test with rtl_test
rtl_test

# Try blacklisting DVB-T drivers
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo rmmod dvb_usb_rtl28xxu
```

#### SDRplay Not Found

```bash
# Check API installation
systemctl status sdrplay

# Restart API
sudo systemctl restart sdrplay

# Test with SoapySDR
SoapySDRUtil --find
```

---

## Performance Optimization

### CPU Optimization

```toml
# Adjust thread counts based on CPU cores
[server]
threads = 4  # Set to number of cores

[input]
fft_threads = 4  # Set to number of cores
```

### Memory Optimization

```toml
# Reduce memory usage
[input]
waterfall_size = 512  # Lower value = less memory
fft_size = 65536      # Lower value = less memory
```

### Network Optimization

```toml
# Optimize for limited bandwidth
[input]
audio_compression = "opus"  # More efficient than FLAC
waterfall_compression = "zstd"  # Efficient compression
```

---

## Updating PhantomSDR-Plus

### Manual Update

```bash
cd PhantomSDR-Plus

# Backup your configuration
cp config-rtl.toml config-rtl.toml.backup
cp frontend/site-information.json frontend/site-information.json.backup

# Pull latest changes
git pull origin main
git submodule update --init --recursive

# Rebuild
meson compile -C build
cd frontend && npm install && npm run build && cd ..
```

### Automatic Update Script

Create `update.sh`:

```bash
#!/bin/bash
cd ~/PhantomSDR-Plus
./stop-websdr.sh
git pull origin main
git submodule update --init --recursive
meson compile -C build
cd frontend && npm install && npm run build && cd ..
./start-rtl.sh
```

---

## Backup and Restore

### Files to Backup

- Configuration files: `*.toml`
- Site information: `frontend/site-information.json`
- Markers: `markers.json`
- Custom scripts: `start-*.sh`, `stop-*.sh`
- Chat history: `chat_history.txt`
- Background image: `frontend/src/assets/background.jpg`

### Backup Command

```bash
cd ~/PhantomSDR-Plus
tar -czf phantomsdr-backup-$(date +%Y%m%d).tar.gz \
  *.toml \
  *.sh \
  markers.json \
  chat_history.txt \
  frontend/site-information.json \
  frontend/src/assets/background.jpg
```

### Restore Command

```bash
tar -xzf phantomsdr-backup-YYYYMMDD.tar.gz
```

---

## Security Considerations

### Firewall Configuration

```bash
# Allow only necessary ports
sudo ufw allow 9002/tcp
sudo ufw enable
```

### Reverse Proxy (Optional)

Consider using nginx or Apache as a reverse proxy for:
- SSL/TLS encryption
- Domain name mapping
- Load balancing
- Access control

### User Limits

Edit `config.toml`:
```toml
[server]
max_users = 100  # Limit concurrent users
```

---

## Getting Help

### Resources

- **Documentation**: This guide, README.md, USER_GUIDE.md
- **GitHub Issues**: https://github.com/sv1btl/PhantomSDR-Plus/issues
- **Live Demo**: http://phantomsdr.no-ip.org:8900/

### Reporting Issues

When reporting issues, include:
1. Operating system and version
2. SDR device model
3. Configuration file contents
4. Error messages
5. System resource usage (CPU, RAM, GPU)

### Community Support

- Check existing GitHub issues before creating new ones
- Provide detailed information about your setup
- Include logs and error messages
- Be patient and respectful

---

## Appendix A: Complete Dependency List

### Ubuntu 24.04 Package List

```
build-essential
cmake
pkg-config
meson
libfftw3-dev
libwebsocketpp-dev
libflac++-dev
zlib1g-dev
libzstd-dev
libboost-all-dev
libopus-dev
libliquid-dev
git
util-linux (taskset — for the autorun spot reporter)
psmisc
wget
curl
rtl-sdr (for RTL-SDR)
airspy (for Airspy)
hackrf (for HackRF)
libclfft-dev (for OpenCL)
ocl-icd-opencl-dev (for OpenCL)
clinfo (for OpenCL)
```

---

## Appendix B: Configuration Examples

### Example 1: RTL-SDR for VHF/UHF

```toml
[input]
sps = 2048000
frequency = 145000000
signal = "iq"

[input.driver]
format = "u8"

[input.defaults]
frequency = 145500000
modulation = "FM"
```

### Example 2: RX888 for HF (0-30 MHz)

```toml
[input]
sps = 60000000
frequency = 0
signal = "real"
fft_size = 8388608

[input.driver]
format = "s16"

[input.defaults]
frequency = 7100000
modulation = "LSB"
```

### Example 3: HackRF for Wideband FM

```toml
[input]
sps = 10000000
frequency = 100900000
signal = "iq"

[input.driver]
format = "s8"

[input.defaults]
frequency = 100900000
modulation = "WBFM"
```

---

**Installation complete! You should now have a fully functional PhantomSDR-Plus server.**

**73 de SV1BTL & SV2AMK**
