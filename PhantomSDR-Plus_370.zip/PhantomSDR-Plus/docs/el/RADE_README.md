# Ψηφιακή φωνή RADE v1 για το PhantomSDR-Plus

Το **RADE** (Radio AutoencoDEr) είναι ο κορυφαίος τρόπος ψηφιακής φωνής HF του FreeDV. Χρησιμοποιεί έναν υβριδικό συνδυασμό μηχανικής μάθησης / DSP (τον νευρωνικό κωδικοποιητή φωνής FARGAN) για να προσφέρει ομιλία υψηλής ποιότητας στα HF με SNR έως και −2 dB, σε εύρος ζώνης RF μόλις 1500 Hz — στενότερο από ένα σήμα SSB.

Το έγγραφο αυτό καλύπτει την πλήρη ενσωμάτωση της λήψης RADE v1 στο PhantomSDR-Plus, που υλοποιείται ως sidecar σε Python (`rade_helper.py`) και γεφυρώνει τον περιηγητή με την αλυσίδα αποκωδικοποίησης `radae_rxe.py` + `lpcnet_demo`.

## Η εγκατάσταση — ο σύντομος δρόμος

```bash
cd ~/PhantomSDR-Plus
./install_rade.sh
```

Αυτή είναι όλη η εγκατάσταση. Το script εγκαθιστά τα πακέτα συστήματος μέσω όποιου διαχειριστή πακέτων έχει το μηχάνημα (apt, pacman, dnf ή zypper), καταφεύγει στο pip για ό,τι δεν έχει η διανομή, αναβαθμίζει το `websockets` αν η έκδοση της διανομής είναι παλαιότερη από την 11.0 που χρειάζεται το sidecar, κλωνοποιεί και χτίζει το radae, ελέγχει τα βάρη του μοντέλου, ξαναχτίζει το frontend και ξεκινά το sidecar. Στο Ubuntu 22.04 παραδίδει τη σκυτάλη στο `install_rade_ubuntu22.sh`. Το `./install.sh` προσφέρεται να το τρέξει στο πλαίσιο της κανονικής εγκατάστασης, οπότε σε ένα φρέσκο μηχάνημα το RADE υπάρχει ήδη.

**Όλα, από το [Πριν την εγκατάσταση](#πριν-την-εγκατάσταση--απαιτήσεις-συστήματος) έως το [Βήμα 6](#βήμα-6--εγκατάσταση-του-σεναρίου-ελέγχου-radesh), περιγράφουν όσα κάνει για εσάς αυτό το script.** Διαβάστε τα αν θέλετε να καταλάβετε την αλυσίδα, αν είστε σε σύστημα που δεν καλύπτει το script, ή αν επισκευάζετε ένα βήμα με το χέρι. Οι ενότητες μετά το Βήμα 6 — θύρα, χρήση στον browser, μεταβλητές περιβάλλοντος, αντιμετώπιση προβλημάτων και μέτρηση ταυτόχρονων χρηστών — ισχύουν για κάθε εγκατάσταση.

- **[Χειροκίνητη εγκατάσταση σε Linux](RADE_General_INSTALL_MANUAL_LINUX.md)** - ο δρόμος με το χέρι, βήμα βήμα
- **[Χειροκίνητη εγκατάσταση σε Pi / Debian Bookworm (ARM64)](RADE_Pi_INSTALL_MANUAL.md)** - ο δρόμος με το χέρι σε ARM

---

## Πίνακας περιεχομένων

1. [Πώς λειτουργεί](#πώς-λειτουργεί)
2. [Επισκόπηση αρχιτεκτονικής](#επισκόπηση-αρχιτεκτονικής)
3. [RADEL έναντι RADEU](#radel-έναντι-radeu)
4. [Πριν την εγκατάσταση — απαιτήσεις συστήματος](#πριν-την-εγκατάσταση--απαιτήσεις-συστήματος)
5. [Βήμα 1 — Κλωνοποίηση και μεταγλώττιση του αποθετηρίου radae](#βήμα-1--κλωνοποίηση-και-μεταγλώττιση-του-αποθετηρίου-radae)
6. [Βήμα 2 — Εγκατάσταση εξαρτήσεων Python](#βήμα-2--εγκατάσταση-εξαρτήσεων-python)
7. [Βήμα 3 — Επαλήθευση της αλυσίδας αποκωδικοποίησης](#βήμα-3--επαλήθευση-της-αλυσίδας-αποκωδικοποίησης)
8. [Βήμα 4 — Τοποθέτηση των διορθωμένων αρχείων](#βήμα-4--τοποθέτηση-των-διορθωμένων-αρχείων)
9. [Βήμα 5 — Μεταγλώττιση του frontend](#βήμα-5--μεταγλώττιση-του-frontend)
10. [Βήμα 6 — Εγκατάσταση του σεναρίου ελέγχου rade.sh](#βήμα-6--εγκατάσταση-του-σεναρίου-ελέγχου-radesh)
11. [Βήμα 7 — Άνοιγμα της θύρας 8074](#βήμα-7--άνοιγμα-της-θύρας-8074)
12. [Βήμα 8 — Εκκίνηση του διακομιστή](#βήμα-8--εκκίνηση-του-διακομιστή)
13. [Βήμα 9 — Χειροκίνητη εκκίνηση του RADE](#βήμα-9--χειροκίνητη-εκκίνηση-του-rade)
14. [Βήμα 10 — Χρήση του RADE στον περιηγητή](#βήμα-10--χρήση-του-rade-στον-περιηγητή)
15. [Επαλήθευση και αποσφαλμάτωση](#επαλήθευση-και-αποσφαλμάτωση)
16. [Μεταβλητές περιβάλλοντος](#μεταβλητές-περιβάλλοντος)
17. [Αρχεία που άλλαξαν](#αρχεία-που-άλλαξαν)
18. [Σύνοψη ροής σήματος](#σύνοψη-ροής-σήματος)
19. [Αντιμετώπιση προβλημάτων](#αντιμετώπιση-προβλημάτων)
20. [Μέτρηση ταυτοχρονίας στο δικό σας υλικό](#μέτρηση-ταυτοχρονίας-στο-δικό-σας-υλικό)
21. [Ενημέρωση του RADE v1](#ενημέρωση-του-rade-v1)

---

## Πώς λειτουργεί

Το RADE v1 δεν μπορεί να εκτελεστεί στον περιηγητή — απαιτεί PyTorch και τον νευρωνικό κωδικοποιητή φωνής FARGAN, που είναι υπερβολικά μεγάλα για WASM. Η λύση είναι μια διεργασία sidecar σε Python (`rade_helper.py`) που εκτελείται στον ίδιο διακομιστή με το PhantomSDR-Plus.

> **Σημαντικό:** το `freedv_rx` του αποθετηρίου codec2 **δεν** υποστηρίζει RADEV1. Η αλυσίδα αποκωδικοποίησης RADE βρίσκεται εξ ολοκλήρου στο ξεχωριστό αποθετήριο `radae` του David Rowe (VK5DGR). Μην επιχειρήσετε να χρησιμοποιήσετε το `freedv_rx` του codec2 για RADE.

Όταν επιλέγετε RADE στον περιηγητή:

1. Το frontend θέτει την υποκείμενη αποδιαμόρφωση σε USB ή LSB — ο διακομιστής C++ αποδιαμορφώνει κανονικά το σήμα SSB.
2. Το ακατέργαστο αποδιαμορφωμένο PCM λαμβάνεται στο `audio.js` **πριν** από οποιαδήποτε σίγαση ή πύλη squelch — το `radae_rxe.py` χρειάζεται συνεχή είσοδο για να διατηρεί τον συγχρονισμό πλαισίων.
3. Κάθε τμήμα PCM συμπληρώνεται με μηδενικά από πραγματικό f32 σε μιγαδικό f32 (πραγματικό + 0.0 φανταστικό) — αυτό αναμένει το `radae_rxe.py` στην τυπική είσοδο.
4. Ο sidecar διοχετεύει αυτά τα δείγματα στο `radae_rxe.py`, το οποίο παράγει χαρακτηριστικά κωδικοποιητή φωνής.
5. Το `lpcnet_demo -fargan-synthesis` μετατρέπει τα χαρακτηριστικά σε ομιλία s16 στα 16000 Hz.
6. Ο sidecar μετατρέπει s16 → f32 και τα στέλνει πίσω στον περιηγητή ως δυαδικά πλαίσια WebSocket.
7. Ο περιηγητής αναπαράγει την αποκωδικοποιημένη ομιλία μέσω του Web Audio API στα 16000 Hz.

Ο διακομιστής C++ (`spectrumserver.cpp`) δεν τροποποιείται καθόλου.

---

## Επισκόπηση αρχιτεκτονικής

```
┌────────────────────────────────────────────────────────────────────┐
│  Browser                                                           │
│                                                                    │
│  Decoder → "RADE v1 — RADEL (LSB)" / "RADEU (USB)"               │
│       │                                                            │
│  audio.js ── demod cmd (LSB/USB) ──────────► C++ spectrumserver   │
│       │                                              │             │
│       │  raw SSB PCM @ audioOutputSps ◄─────────────┘             │
│       │  (tapped before mute gate, zero-padded to complex f32)     │
│       │                                                            │
│       │  binary WebSocket ──► ws://host:8074                       │
│       ▼                                                            │
├────────────────────────────────────────────────────────────────────┤
│  rade_helper.py  (port 8074)                                       │
│                                                                    │
│  resample to 8000 Hz if needed                                     │
│  zero-pad real f32 → complex f32 pairs                             │
│       │ stdin pipe                                                  │
│       ▼                                                            │
│  radae_rxe.py  --model_name model19_check3/.../checkpoint_100.pth  │
│       │ stdout pipe (vocoder features f32)                         │
│       ▼                                                            │
│  lpcnet_demo  -fargan-synthesis  -  -                              │
│       │ stdout (s16 PCM @ 16000 Hz)                                │
│       │ converted → f32 by sidecar                                 │
│       │ binary WebSocket frames ──► browser                        │
│       ▼                                                            │
├────────────────────────────────────────────────────────────────────┤
│  Browser                                                           │
│                                                                    │
│  _radePlayPCM() → AudioContext.createBuffer(16000 Hz) → speaker   │
└────────────────────────────────────────────────────────────────────┘
```

---

## RADEL έναντι RADEU

Το RADE v1 μεταδίδεται πάντα μέσω SSB. Κατά σύμβαση:

| Τρόπος | Πλευρική ζώνη | Χρήση στις μπάντες                       |
|--------|----------------|------------------------------------------|
| RADEL  | LSB            | 160 m, 80 m, 40 m  (≤ 10 MHz)           |
| RADEU  | USB            | 20 m, 17 m, 15 m, 12 m, 10 m (> 10 MHz) |

---

## Προϋποθέσεις

| Απαίτηση | Έκδοση | Σημειώσεις |
|---|---|---|
| PhantomSDR-Plus | οποιαδήποτε | με frontend Vite/Svelte |
| Linux | Ubuntu 24.04+ / Debian Bookworm+ | δοκιμασμένο |
| Python | 3.8+ | για τα `rade_helper.py` και `radae_rxe.py` |
| αποθετήριο radae | τελευταίο master | παρέχει τα `radae_rxe.py` και `lpcnet_demo` |
| cmake | 3.10+ | για μεταγλώττιση του `lpcnet_demo` από το radae |
| PyTorch | 2.0+ | απαιτείται από το `radae_rxe.py` |
| Node.js | 16+ | για το `npm run build` |
| websockets (Python) | 10–16+ | `pip3 install websockets` — υποστηρίζονται όλες οι εκδόσεις |
| matplotlib | οποιαδήποτε | απαιτείται από το `radae_rxe.py` κατά την εισαγωγή |
| numpy | 1.23+ | απαιτείται· επιτρέπει επίσης την επαναδειγματοληψία |
| scipy | οποιαδήποτε | προαιρετικό, επιτρέπει ακριβή επαναδειγματοληψία |

---

## Πριν την εγκατάσταση — απαιτήσεις συστήματος

Πριν κλωνοποιήσετε το αποθετήριο PhantomSDR-Plus ή μεταγλωττίσετε οτιδήποτε, εγκαταστήστε όλες τις εξαρτήσεις επιπέδου συστήματος στον διακομιστή Ubuntu/Debian.

### Πακέτα συστήματος

```bash
sudo apt update
sudo apt install -y \
    build-essential cmake git \
    python3 python3-pip \
    nodejs npm \
    aplay alsa-utils
```

### Node.js (αν η έκδοση του συστήματος είναι πολύ παλιά — απαιτείται 22+)

```bash
node --version   # check current version
# If below 22.x - via nvm, not NodeSource: deb.nodesource.com now
# answers HTTP 403 on every repository path.
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
nvm install 22 && nvm use 22 && nvm alias default 22
```

### Πακέτα Python

```bash
pip3 install websockets matplotlib torch numpy scipy
```

> **Σημείωση για την έκδοση του websockets:** υποστηρίζεται οποιαδήποτε έκδοση από 10.x έως 16.x+. Το `rade_helper.py` εντοπίζει αυτόματα την έκδοση του API.

### Επαλήθευση των πακέτων Python

```bash
python3 -c "import websockets, matplotlib, torch, numpy, scipy; print('All OK')"
```

---

## Βήμα 1 — Κλωνοποίηση και μεταγλώττιση του αποθετηρίου radae

Ο αποκωδικοποιητής RADE **δεν** αποτελεί μέρος του codec2. Βρίσκεται σε ξεχωριστό αποθετήριο και πρέπει να μεταγλωττιστεί από τον πηγαίο κώδικα ώστε να προκύψει το εκτελέσιμο `lpcnet_demo`.

```bash
# 1a. Install build dependencies
sudo apt install build-essential cmake git python3-pip

# 1b. Clone the radae repository
git clone https://github.com/drowe67/radae.git ~/radae
cd ~/radae

# 1c. Build (produces lpcnet_demo and other binaries)
mkdir build && cd build
cmake ..
make -j$(nproc)

# 1d. Verify lpcnet_demo was built
ls -la ~/radae/build/src/lpcnet_demo
```

Θα πρέπει να δείτε το `lpcnet_demo` στο `~/radae/build/src/lpcnet_demo`.

Τα **προεκπαιδευμένα βάρη του μοντέλου** περιλαμβάνονται ήδη στο αποθετήριο:

```bash
# Verify model19_check3 weights are present (this is the correct model)
ls ~/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
```

---

## Βήμα 2 — Εγκατάσταση εξαρτήσεων Python

```bash
# Required
pip3 install websockets matplotlib torch numpy

# Recommended (enables accurate resampling when audioOutputSps > 8000)
pip3 install scipy
```

> **Γιατί matplotlib;** Το `radae_rxe.py` εισάγει το matplotlib στην αρχή του αρχείου ακόμη κι όταν δεν παράγονται γραφήματα. Πρέπει να είναι εγκατεστημένο, αλλιώς το σενάριο αποτυγχάνει αμέσως με `ModuleNotFoundError: No module named 'matplotlib'`.

> **Γιατί torch;** Το `radae_rxe.py` χρησιμοποιεί PyTorch για τη συμπερασματολογία του νευρωνικού κωδικοποιητή φωνής.

---

## Βήμα 3 — Επαλήθευση της αλυσίδας αποκωδικοποίησης

Πριν συνδέσετε τα πάντα μεταξύ τους, επαληθεύστε ότι η πλήρης αλυσίδα λειτουργεί αυτόνομα. Το βήμα αυτό παράγει ένα δοκιμαστικό σήμα RADE από ένα αρχείο WAV και το αποκωδικοποιεί στα ηχεία.

```bash
cd ~/radae

# Step 3a — Generate a RADE-encoded test signal
# Note: --auxdata is required for model19_check3 when using inference.sh
./inference.sh model19_check3/checkpoints/checkpoint_epoch_100.pth \
    wav/brian_g8sez.wav /dev/null \
    --rate_Fs --pilots --pilot_eq --eq_ls --cp 0.004 \
    --write_rx rx.f32 --auxdata
```

Περιμένετε να ολοκληρωθεί. Εμφανίζει στατιστικά που τελειώνουν με:
```
loss: 0.741 Auxdata BER: 0.012
```

Έπειτα αποκωδικοποιήστε και αναπαράγετε:

```bash
# Step 3b — Decode and play
cat rx.f32 \
    | python3 radae_rxe.py --model_name model19_check3/checkpoints/checkpoint_epoch_100.pth \
    | ./build/src/lpcnet_demo -fargan-synthesis - - \
    | aplay -f S16_LE -r 16000
```

Θα πρέπει να ακούσετε φωνή. Η έξοδος δείχνει την απόκτηση συγχρονισμού:
```
  1 state: search     ...
  5 state: sync       ... SNRdB:  4.03 uw_err: 0
Playing raw data 'stdin' : Signed 16 bit Little Endian, Rate 16000 Hz, Mono
```

Τα μηνύματα `underrun!!!` σε αυτή τη δοκιμή εκτός σύνδεσης είναι αναμενόμενα — το `radae_rxe.py` επεξεργάζεται πιο αργά από την είσοδο/έξοδο του αρχείου. **Δεν** εμφανίζονται σε ζωντανή λήψη, γιατί ο περιηγητής τροφοδοτεί τον ήχο σε πραγματικό χρόνο.

> **Βασικά σημεία για το `radae_rxe.py`:**
> - Η διαδρομή του μοντέλου δίνεται ως `--model_name <διαδρομή>`, **όχι** ως θεσιακό όρισμα
> - Το `--auxdata` είναι **ενεργό εξ ορισμού** — μην το περνάτε ως σημαία
> - Χρησιμοποιήστε το `--noauxdata` μόνο αν χρειάζεται να το απενεργοποιήσετε

```bash
# Step 3c — Verify the sidecar starts correctly
python3 ~/PhantomSDR-Plus/rade_helper.py
```

Αναμενόμενη έξοδος (χωρίς γραμμές WARNING):
```
[RADE] helper starting on ws://0.0.0.0:8074
[RADE] radae_rx.py    : /home/sv1btl/radae/radae_rxe.py
[RADE] model          : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
[RADE] lpcnet_demo    : /home/sv1btl/radae/build/src/lpcnet_demo
[RADE] auxdata        : ON (default)
[RADE] torch threads  : 1 per instance (RADE_TORCH_THREADS to override)
[RADE] architecture   : per-connection (each user tunes independently)
[RADE] listening — waiting for PhantomSDR-Plus clients
```

Πατήστε Ctrl+C για διακοπή.

---

## Βήμα 4 — Τοποθέτηση των διορθωμένων αρχείων

Αντιγράψτε τα ακόλουθα αρχεία από το σύνολο διορθώσεων στο αποθετήριό σας PhantomSDR-Plus.

### Νέο αρχείο — τοποθετήστε το στη ρίζα του αποθετηρίου, δίπλα στο σενάριο εκκίνησης που χρησιμοποιείτε:

```
rade_helper.py
```

### Διορθωμένα αρχεία frontend — τοποθετήστε τα στο `frontend/src/`:

```
audio.js
App.svelte
```

### Τι κάνουν οι διορθώσεις

**`audio.js`** — 5 αλλαγές:
- Κατασκευαστής: 5 νέα πεδία κατάστασης RADE (`decodeRADE`, `_radeSideband`, `_radeSocket`, `_radeCallback`, `_radeReady`, `_radeNextTime`)
- Αποθήκευση PCM πριν την ενίσχυση: το `pcmArrayPreBoost` αποθηκεύεται πριν από την ενίσχυση 300× του FLAC, ώστε το RADE να λαμβάνει το αρχικό πλάτος (η ενίσχυση θα κορέσει το `radae_rxe.py`)
- `playAudio()`: λήψη PCM για το RADE με τον ήχο πριν την ενίσχυση, πριν από την πύλη σίγασης/squelch
- `playAudio()`: φύλακας `if (this.decodeRADE) return` — καταστέλλει την αναπαραγωγή του ακατέργαστου SSB όσο παίζει η αποκωδικοποιημένη από το RADE ομιλία
- Νέες μέθοδοι: `setRADEDecoding()`, `setRADECallback()`, `_radePlayPCM()` με προγραμματισμένη αναπαραγωγή χωρίς κενά μέσω του ρολογιού `_radeNextTime` (αναπαραγωγή στα **16000 Hz** — ο ρυθμός εξόδου του `lpcnet_demo`)

**Κάθε παραλλαγή Svelte** — 6 αλλαγές:
- `demodulationDefaults`: RADEL `{type:'LSB', offsets:[2200,-700]}`, RADEU `{type:'USB', offsets:[-700,2200]}` — το εύρος διέλευσης ξεκινά 700 Hz από το φέρον, με πλάτος 1500 Hz
- Μεταβλητές κατάστασης: `radeEnabled`, `radeConnected`, `radeSynced`, `radeSnr`, `_radeDeactivate()`
- `_radeDeactivate()`: σταματά τον αποκωδικοποιητή και **επαναφέρει τον προεπιλεγμένο τρόπο της μπάντας** από το `bands-config.js` — συμπεριφορά πανομοιότυπη με την απενεργοποίηση των FAX, NAVTEX, FSK
- `_deactivateAll()`: γραμμή καθαρισμού RADE
- `activateSelectedDecoder()`: κλάδοι `radel` και `radeu`
- Αναπτυσσόμενο μενού αποκωδικοποιητών: δύο νέες καταχωρίσεις `<option>`
- Πίνακας κατάστασης: κουκκίδα σύνδεσης, κατάσταση συγχρονισμού/SNR, πλαίσιο σφάλματος

### Σενάρια εκκίνησης

Τα κύρια σενάρια εκκίνησης του διακομιστή (`go.sh`, `kill.sh`, `start-rx888mk2.sh`, `stop-websdr.sh`) **δεν** τροποποιούνται. Το RADE διαχειρίζεται ανεξάρτητα μέσω του `rade.sh` (δείτε το Βήμα 6).

---

## Βήμα 5 — Μεταγλώττιση του frontend

```bash
cd ~/PhantomSDR-Plus/frontend
npm install       # only if node_modules is missing
npm run build
```

Προσέξτε για σφάλματα του αναλυτή Vite/acorn. Ο διορθωμένος κώδικας αποφεύγει σκόπιμα τα `?.`, `??` και τα σκέτα `catch {}`, ώστε να συμμορφώνεται με τον περιορισμό του acorn.

---

## Βήμα 6 — Εγκατάσταση του σεναρίου ελέγχου rade.sh

Το `rade.sh` είναι το ειδικό σενάριο για τη διαχείριση του sidecar RADE. Τα κύρια σενάρια εκκίνησης του διακομιστή (`go.sh`, `kill.sh`, `start-rx888mk2.sh`, `stop-websdr.sh`) **δεν** τροποποιούνται — το RADE ξεκινά και σταματά ανεξάρτητα.

Αντιγράψτε το `rade.sh` στον κατάλογο PhantomSDR-Plus και κάντε το εκτελέσιμο:

```bash
cp rade.sh ~/PhantomSDR-Plus/
chmod +x ~/PhantomSDR-Plus/rade.sh
```

Διαθέσιμες εντολές:

```bash
./rade.sh start      # start sidecar with self-restarting watchdog
./rade.sh stop       # stop sidecar + watchdog + lpcnet_demo children
./rade.sh restart    # stop then start cleanly
./rade.sh status     # show running / stopped + process info
```

Η δραστηριότητα του sidecar καταγράφεται στο `~/PhantomSDR-Plus/rade.log`:

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

> **Γιατί να μην ενσωματωθεί στα σενάρια εκκίνησης;** Κρατώντας το RADE χωριστά, ο διακομιστής μπορεί να λειτουργεί χωρίς RADE (εξοικονομώντας CPU όταν δεν το χρησιμοποιεί κανείς), και το RADE μπορεί να επανεκκινηθεί ανεξάρτητα χωρίς να θιγεί η κύρια διεργασία του διακομιστή.

---

## Βήμα 7 — Άνοιγμα της θύρας 8074

Ο sidecar ακούει στη θύρα **8074**. Ο περιηγητής συνδέεται απευθείας σε αυτή τη θύρα. Η θύρα 8074 πρέπει να είναι προσβάσιμη από έξω.

### Έλεγχος τρέχουσας κατάστασης

```bash
# Is sidecar listening?
ss -tlnp | grep 8074

# Test from outside (not from the server itself — NAT hairpin will give false results)
# Use: https://portchecker.co  →  your-hostname  →  port 8074
```

> **Προειδοποίηση για το NAT hairpin:** η δοκιμή με `curl` από τον διακομιστή προς το δικό του δημόσιο όνομα συχνά επιστρέφει `Connection refused` ακόμη και όταν η θύρα είναι ανοιχτή — πολλοί δρομολογητές μπλοκάρουν τον βρόχο. Δοκιμάζετε πάντα από εξωτερικό μηχάνημα ή με το portchecker.co.

### Άνοιγμα στο iptables

```bash
sudo iptables -I INPUT -p tcp --dport 8074 -j ACCEPT

# Make permanent across reboots:
sudo apt install iptables-persistent
sudo netfilter-persistent save
```

### Άνοιγμα στο ufw

```bash
sudo ufw allow 8074/tcp && sudo ufw reload
```

### Προώθηση στον δρομολογητή σας

Προσθέστε κανόνα NAT/προώθησης θύρας: `θύρα TCP 8074 → τοπική IP διακομιστή : 8074`

### Εναλλακτικά: διαμεσολάβηση μέσω της υπάρχουσας δημόσιας θύρας με Nginx

Αν η θύρα 8074 δεν μπορεί να ανοίξει (φραγή από τον πάροχο κ.λπ.), διαμεσολαβήστε το WebSocket μέσω της υπάρχουσας δημόσιας θύρας σας με Nginx:

```nginx
# Add inside your existing server {} block
location /rade {
    proxy_pass         http://127.0.0.1:8074;
    proxy_http_version 1.1;
    proxy_set_header   Upgrade    $http_upgrade;
    proxy_set_header   Connection "upgrade";
    proxy_set_header   Host       $host;
    proxy_read_timeout 3600s;
}
```

```bash
sudo nginx -t && sudo nginx -s reload
```

Έπειτα αλλάξτε το URI του sidecar στο `audio.js`, μέσα στη `setRADEDecoding()`:

```js
// Find:
var helperUri = uri || ('ws://' + window.location.hostname + ':8074');

// Change to:
var helperUri = uri || ('ws://' + window.location.host + '/rade');
```

Μεταγλωττίστε ξανά το frontend μετά από αυτή την αλλαγή.

---

## Βήμα 8 — Εκκίνηση του διακομιστή

Εκκινήστε το PhantomSDR-Plus κανονικά — το RADE **δεν** ξεκινά αυτόματα:

```bash
cd ~/PhantomSDR-Plus
./start-rx888mk2.sh      # or start-airspyhf.sh,
                         # start-rtl.sh, start-rsp1a.sh
```

Ο διακομιστής ξεκινά χωρίς τον sidecar RADE. Προχωρήστε στο Βήμα 9 για να ενεργοποιήσετε το RADE.

---

## Βήμα 9 — Χειροκίνητη εκκίνηση του RADE

Μόλις λειτουργήσει ο διακομιστής PhantomSDR-Plus, εκκινήστε ξεχωριστά τον sidecar RADE:

```bash
cd ~/PhantomSDR-Plus
./rade.sh start
```

Επαληθεύστε ότι εκτελείται:

```bash
./rade.sh status
```

Αναμενόμενη έξοδος:
```
[RADE] Running
$USER  python3 /home/sv1btl/PhantomSDR-Plus/rade_helper.py ...
```

Παρακολουθήστε το αρχείο καταγραφής εκκίνησης:

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

Αναμενόμενες γραμμές καταγραφής:
```
[RADE] sidecar starting at ...
[RADE] helper starting on ws://0.0.0.0:8074
[RADE] radae_rx.py    : /home/sv1btl/radae/radae_rxe.py
[RADE] model          : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
[RADE] lpcnet_demo    : /home/sv1btl/radae/build/src/lpcnet_demo
[RADE] auxdata        : ON (default)
[RADE] torch threads  : 1 per instance
[RADE] architecture   : per-connection (each user tunes independently)
[RADE] listening — waiting for PhantomSDR-Plus clients
```

Για να σταματήσετε το RADE χωρίς να σταματήσετε τον διακομιστή:

```bash
./rade.sh stop
```

Για να επανεκκινήσετε το RADE (π.χ. μετά από ενημέρωση του `rade_helper.py`):

```bash
./rade.sh restart
```

> **Σημείωση:** το `pkill -f rade_helper.py` από μόνο του δεν αρκεί — το `rade.sh` εκτελεί βρόχο watchdog με αυτόματη επανεκκίνηση που θα ξαναδημιουργήσει τη διεργασία μέσα σε 3 δευτερόλεπτα. Χρησιμοποιείτε πάντα `./rade.sh stop` για πλήρη τερματισμό.

---

## Βήμα 10 — Χρήση του RADE στον περιηγητή

1. Ανοίξτε τη διεπαφή web του PhantomSDR-Plus
2. Βρείτε ενεργούς σταθμούς στο **[qso.freedv.org](https://qso.freedv.org)**
3. Συντονιστείτε στη συχνότητα ένδειξης του σταθμού
4. Στις **Decoder Options** επιλέξτε:
   - **RADE v1 — RADEL (LSB)** για 40 m / 80 m / 160 m
   - **RADE v1 — RADEU (USB)** για 20 m / 17 m / 15 m / 12 m / 10 m
5. Κάντε κλικ στο **Decoder: ON**

### Τα κουμπιά RADEL / RADEU (με ένα πάτημα)

Τα βήματα 4 και 5 μπορούν να αντικατασταθούν από ένα μόνο πάτημα. Ένα ζευγάρι κουμπιών **RADEL** / **RADEU** υπάρχει σε τρία σημεία:

- δίπλα στην επικεφαλίδα **Modes selector** του κύριου πίνακα·
- μέσα στο αναδυόμενο παράθυρο **Modes**·
- μέσα στο αναδυόμενο παράθυρο **Bands**.

Το πάτημα ενός από αυτά επιλέγει τον αποκωδικοποιητή, ανάβει τον διακόπτη Decoder, κλείνει το αναδυόμενο παράθυρο μέσα από το οποίο το πατήσατε και φέρνει το πάνελ του RADE στην οθόνη. Το κουμπί γίνεται μπλε όσο τρέχει το RADE. **Πατήστε το ίδιο κουμπί ξανά για να σταματήσει το RADE** — το πάνελ κλείνει και ο τρόπος λειτουργίας με το passband επανέρχονται όπως περιγράφεται παρακάτω. Τα κουμπιά, το αναπτυσσόμενο μενού **Decoder Options** και το κουμπί ON/OFF μοιράζονται την ίδια κατάσταση.

### Καταστάσεις της ένδειξης του πίνακα

| Ένδειξη | Σημασία |
|---|---|
| 🔴 Κόκκινο — «Connecting to sidecar…» | Η θύρα 8074 δεν είναι προσβάσιμη ή ο sidecar δεν εκτελείται |
| 🟡 Κίτρινο — «Searching for signal…» | Ο sidecar συνδέθηκε, δεν εντοπίστηκε ακόμη πλαίσιο RADE |
| 🟢 Πράσινο — «Synced · SNR x.x dB» | Αποκωδικοποίηση — ακούγεται ομιλία |

### Όταν απενεργοποιείτε τον αποκωδικοποιητή

Ο τρόπος και το εύρος διέλευσης επανέρχονται αυτόματα στη σωστή προεπιλογή για την τρέχουσα συχνότητα, όπως ορίζεται στο `bands-config.js` — όπως ακριβώς με τα FAX, NAVTEX, FSK.

---

## Επαλήθευση και αποσφαλμάτωση

### Εκτελείται ο sidecar;

```bash
ps aux | grep rade_helper | grep -v grep
ss -tlnp | grep 8074
```

### Παρακολούθηση ζωντανής δραστηριότητας

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

Όταν συνδέεται περιηγητής:
```
[RADE] client connected: x.x.x.x:XXXXX
[RADE] x.x.x.x:XXXXX  sps=12000 sideband=LSB
[RADE] x.x.x.x:XXXXX spawning pipeline (torch_threads=1)
```

### Γρήγορη δοκιμή WebSocket

```bash
python3 - << 'EOF'
import asyncio, websockets, json

async def test():
    async with websockets.connect('ws://localhost:8074') as ws:
        await ws.send(json.dumps({'type': 'init', 'sps': 8000, 'sideband': 'LSB'}))
        print(await ws.recv())   # expect: {"type": "status", "connected": true}

asyncio.run(test())
EOF
```

### Κονσόλα περιηγητή (F12)

```
[RADE] ▶ ENABLED LSB @ 12000 Hz → helper ws://localhost:8074
```
Καλό — το WebSocket άνοιξε. Η τιμή σε Hz ταιριάζει με το `audioOutputSps` του διακομιστή σας (συνήθως 8000–12000 Hz).

```
[RADE] sidecar socket error
```
Η θύρα 8074 δεν είναι προσβάσιμη — ελέγξτε το τείχος προστασίας και τον κανόνα NAT του δρομολογητή.

---

## Μεταβλητές περιβάλλοντος

| Μεταβλητή | Προεπιλογή | Περιγραφή |
|---|---|---|
| `RADE_HELPER_PORT` | `8074` | Θύρα TCP στην οποία ακούει ο sidecar |
| `RADE_HELPER_HOST` | `0.0.0.0` | Διεύθυνση δέσμευσης (`127.0.0.1` πίσω από διαμεσολαβητή) |
| `RADAE_DIR` | `~/radae` | Ρίζα του αποθετηρίου radae |
| `RADE_MODEL` | `RADAE_DIR/model19_check3/checkpoints/checkpoint_epoch_100.pth` | Βάρη μοντέλου |
| `LPCNET_DEMO` | `RADAE_DIR/build/src/lpcnet_demo` | Εκτελέσιμο lpcnet_demo |
| `RADE_AUXDATA` | `1` | Θέστε το σε `0` για να περάσει `--noauxdata` στο `radae_rxe.py` |
| `RADE_TORCH_THREADS` | `1` | Νήματα PyTorch/OpenBLAS ανά στιγμιότυπο `radae_rxe.py` — περιορίζει τη χρήση CPU |
| `RADE_PIN_CORES` | `1` | Καρφιτσώνει κάθε αλυσίδα αποκωδικοποίησης σε δικό της σύνολο πυρήνων· το `0` απενεργοποιεί το καρφίτσωμα |
| `RADE_CORES_PER_CLIENT` | `2` | Πυρήνες που αποδίδονται ανά πελάτη όταν το καρφίτσωμα είναι ενεργό |

---

## Αρχεία που άλλαξαν

| Αρχείο | Τύπος | Σημειώσεις |
|---|---|---|
| `rade_helper.py` | **Νέο** | Sidecar Python: διακομιστής WebSocket + αλυσίδα αποκωδικοποίησης δύο διεργασιών |
| `frontend/src/audio.js` | Τροποποιημένο | 4 διορθώσεις |
| `frontend/src/App.svelte` | Τροποποιημένο | 6 διορθώσεις |
| `rade.sh` | **Νέο** | Σενάριο ελέγχου του sidecar RADE (start/stop/restart/status) |
| `go.sh` | **Αμετάβλητο** | Το RADE διαχειρίζεται χωριστά μέσω rade.sh |
| `kill.sh` | **Αμετάβλητο** | Το RADE διαχειρίζεται χωριστά μέσω rade.sh |
| `start-rx888mk2.sh` | **Αμετάβλητο** | Το RADE διαχειρίζεται χωριστά μέσω rade.sh |
| `stop-websdr.sh` | **Αμετάβλητο** | Το RADE διαχειρίζεται χωριστά μέσω rade.sh |
| `spectrumserver.cpp` | **Αμετάβλητο** | Δεν απαιτούνται τροποποιήσεις σε C++ |

---

## Σύνοψη ροής σήματος

```
Antenna → RX-888 MK2 → PhantomSDR-Plus C++ server
                              │
                    FFT + DDC + SSB demodulation
                    (USB or LSB — set by RADEL/RADEU)
                              │
                    Opus/FLAC encode → WebSocket → Browser
                              │
                         audio.js decode()
                              │
                         playAudio(pcmArray)
                              │
               ┌──────────────┴────────────────────────────┐
               │  rawPcm tap (before mute gate)             │
               │  real f32 → zero-padded complex f32 pairs  │
               └──────────────┬────────────────────────────┘
                              │ WebSocket binary → ws://host:8074
                              ▼
                       rade_helper.py
                              │ resample to 8000 Hz if needed
                              │ stdin pipe
                              ▼
          radae_rxe.py  --model_name model19_check3/.../checkpoint_epoch_100.pth
          (PyTorch FARGAN neural vocoder, auxdata ON by default)
                              │ stdout pipe (vocoder features f32)
                              ▼
          lpcnet_demo  -fargan-synthesis  -  -
                              │ stdout: s16 PCM @ 16000 Hz
                              │ sidecar converts s16 → f32
                              │ WebSocket binary frames → browser
                              ▼
                  audio.js  _radePlayPCM()
                  AudioContext.createBuffer(16000 Hz)
                              │
                           Speaker 🔊
```

---

## Αντιμετώπιση προβλημάτων

### Κόκκινο πλαίσιο — «Sidecar not reachable»

```bash
# Is sidecar running?
ps aux | grep rade_helper | grep -v grep

# Start it manually for testing
python3 ~/PhantomSDR-Plus/rade_helper.py &

# Check port is open externally — use portchecker.co NOT curl from the server
# (curl from the server uses NAT loopback and gives false "Connection refused")
```

---

### Η θύρα 8074 εμφανίζεται κλειστή στο portchecker.co παρά τον κανόνα iptables

Ο πάροχος ίσως φιλτράρει τη θύρα ή λείπει ο κανόνας NAT του δρομολογητή. Επιλογές:

1. Δοκιμάστε άλλη θύρα: `RADE_HELPER_PORT=8080 python3 rade_helper.py`
2. Διαμεσολαβήστε μέσω της υπάρχουσας δημόσιας θύρας σας με Nginx (δείτε το Βήμα 7)

---

### `radae_rxe.py: error: unrecognized arguments: model_path`

Η διαδρομή του μοντέλου πρέπει να δίνεται με `--model_name`, όχι ως θεσιακό όρισμα:

```bash
# WRONG — positional argument
python3 radae_rxe.py model19_check3/checkpoints/checkpoint_epoch_100.pth

# CORRECT — named argument
python3 radae_rxe.py --model_name model19_check3/checkpoints/checkpoint_epoch_100.pth
```

---

### `ModuleNotFoundError: No module named 'matplotlib'`

```bash
pip3 install matplotlib
```

Το `radae_rxe.py` εισάγει το matplotlib χωρίς όρους στην αρχή του αρχείου.

---

### `ModuleNotFoundError: No module named 'torch'`

```bash
pip3 install torch
```

---

### `lpcnet_demo: No such file or directory`

Η μεταγλώττιση του radae δεν ολοκληρώθηκε. Μεταγλωττίστε ξανά:

```bash
cd ~/radae/build
cmake .. && make -j$(nproc)
ls src/lpcnet_demo     # should exist now
```

---

### Σφάλμα `size mismatch` στο `inference.sh`

Το `model19_check3` απαιτεί `--auxdata` κατά την κωδικοποίηση με το `inference.sh`:

```bash
./inference.sh model19_check3/checkpoints/checkpoint_epoch_100.pth \
    wav/brian_g8sez.wav /dev/null \
    --rate_Fs --pilots --pilot_eq --eq_ls --cp 0.004 \
    --write_rx rx.f32 --auxdata    # ← required for model19_check3
```

Σημείωση: κατά την **αποκωδικοποίηση** με το `radae_rxe.py`, το `--auxdata` είναι η προεπιλογή — μην το περνάτε.

---

### Κίτρινη ένδειξη — «Searching for signal» — δεν συγχρονίζεται ποτέ

- Επιβεβαιώστε τη σωστή πλευρική ζώνη: RADEL για ≤ 10 MHz, RADEU για > 10 MHz
- Ελέγξτε στο [qso.freedv.org](https://qso.freedv.org) ότι κάποιος σταθμός εκπέμπει αυτή τη στιγμή
- Το RADE v1 χρησιμοποιεί 30 φέροντα σε εύρος 1500 Hz — εμφανίζεται ως συμπαγής ομάδα στον καταρράκτη
- Αφήστε έως 1,5 δευτερόλεπτο για την απόκτηση

---

### `underrun!!!` από το aplay κατά τη δοκιμή της αλυσίδας (Βήμα 3)

Αναμενόμενο μόνο σε δοκιμές εκτός σύνδεσης με αρχεία. Το `radae_rxe.py` επεξεργάζεται πιο αργά από την είσοδο/έξοδο του αρχείου, με αποτέλεσμα να αδειάζει ο ενταμιευτής ήχου. Αυτό δεν συμβαίνει σε ζωντανή λήψη, γιατί ο περιηγητής τροφοδοτεί τον ήχο σε πραγματικό χρόνο.

---

### `ConnectionClosedError: received 1011 (internal error)`

Ο sidecar δέχτηκε τη σύνδεση WebSocket αλλά κατέρρευσε εσωτερικά πριν απαντήσει. Αιτία είναι μια μη συμβατή έκδοση του `rade_helper.py` — μια παλαιότερη έκδοση προσπαθούσε να περάσει έναν `StreamReader` του asyncio ως τυπική είσοδο υποδιεργασίας, κάτι που αποτυγχάνει σιωπηλά και κλείνει με σφάλμα 1011.

**Λύση:** αντικαταστήστε το `rade_helper.py` με την τρέχουσα έκδοση από το σύνολο διορθώσεων. Η τρέχουσα έκδοση χρησιμοποιεί `os.pipe()` για τον διαδιεργασιακό αγωγό και είναι συμβατή με websockets 10.x έως 16.x+.

---

### Πολλοί ταυτόχρονοι χρήστες

Κάθε σύνδεση περιηγητή δημιουργεί το δικό της ανεξάρτητο ζεύγος `radae_rxe.py` + `lpcnet_demo`, οπότε κάθε χρήστης μπορεί να συντονίζεται ελεύθερα σε διαφορετική συχνότητα.

Εξ ορισμού το `radae_rxe.py` χρησιμοποιεί **όλους τους διαθέσιμους πυρήνες CPU** για τις πράξεις πινάκων του PyTorch, προκαλώντας χρήση CPU ~900 % ανά στιγμιότυπο. Το `rade_helper.py` το περιορίζει με δύο βελτιστοποιήσεις:

1. `OMP_NUM_THREADS=1` (και τα αντίστοιχα MKL/OpenBLAS) — περιορίζει το PyTorch σε 1 νήμα
2. Συναρτήσεις μετατροπής ήχου διανυσματοποιημένες με numpy — εξαλείφουν το κόστος των βρόχων της Python

Αποτέλεσμα: κάθε στιγμιότυπο καταναλώνει περίπου **8–10 %** ενός πυρήνα, αρκετά για αποκωδικοποίηση RADE σε πραγματικό χρόνο. Αν ακούτε διακοπές ήχου, αυξήστε σε 2 νήματα:

```bash
RADE_TORCH_THREADS=2 ./rade.sh restart
```

| Ταυτόχρονοι χρήστες RADE | Κατά προσέγγιση CPU |
|---|---|
| 1 | ~9 % |
| 5 | ~45 % |
| 10 | ~90 % |
| 20 | ~180 % |

Σε έναν i5-12450H (12 νήματα) με τον spectrumserver στο ~42 % και το rx888_stream στο ~11 %, έχετε περίπου **1000 % περιθώριο** — αρκετό για **20+ ταυτόχρονους** χρήστες RADE προτού η CPU γίνει πρόβλημα.

> **Ο παραπάνω πίνακας υποθέτει ότι το κόστος CPU κλιμακώνεται γραμμικά με τους χρήστες. Η μέτρηση λέει ότι δεν συμβαίνει αυτό.** Μια εκτέλεση του `rade_loadtest.py` στον ίδιο i5-12450H έδειξε κόστος CPU ανά ακροατή αρκετά κάτω από αυτόν τον πίνακα έως ~24 ακροατές και έπειτα απότομη άνοδο, με το μηχάνημα να σταματά από τη **θερμοκρασία του πακέτου στους 32 ακροατές** — όχι από τη CPU ούτε από το εύρος ζώνης. Θεωρήστε αυτά τα νούμερα πρόχειρο οδηγό μόνο για μικρούς αριθμούς και μετρήστε το δικό σας μηχάνημα: δείτε [Μέτρηση ταυτοχρονίας στο δικό σας υλικό](#μέτρηση-ταυτοχρονίας-στο-δικό-σας-υλικό). Σημειώστε ότι η δοκιμή φόρτου τροφοδοτεί την αλυσίδα με θόρυβο και όχι με πραγματικό σήμα RADE, οπότε η απόλυτη χρήση CPU με πραγματική κίνηση μπορεί να διαφέρει· το αξιόπιστο στοιχείο είναι το *σχήμα* της καμπύλης.

---

## Μέτρηση ταυτοχρονίας στο δικό σας υλικό

Τα παραπάνω νούμερα προέρχονται από ένα συγκεκριμένο μηχάνημα. Το `rade_loadtest.py` (στη ρίζα του αποθετηρίου) μετρά το ίδιο πράγμα στο **δικό σας** — αυξάνει σταδιακά συνθετικούς ακροατές RADE απέναντι στον sidecar και αναφέρει τον τελευταίο αριθμό ακροατών που άντεξε το μηχάνημά σας πριν κάτι υποχωρήσει.

Μετά από κάθε βήμα αφήνει το μηχάνημα να ηρεμήσει και έπειτα δειγματοληπτεί τη θερμοκρασία πακέτου, τη συνολική CPU, τη διαθέσιμη RAM, το swap και το συνολικό RSS όλων των διεργασιών `radae_rxe.py` και `lpcnet_demo`. Σταματά στο πρώτο **γόνατο** — όποιο όριο παραβιαστεί πρώτο — και εμφανίζει τον τελευταίο σταθερό αριθμό.

### Προϋποθέσεις

```bash
sudo apt install python3-websockets python3-psutil
```

Εκτελέστε το **στον υπολογιστή του SDR** (διαβάζει τοπικούς αισθητήρες και μνήμη διεργασιών), με τον spectrumserver και τον sidecar RADE ήδη σε λειτουργία:

```bash
cd ~/PhantomSDR-Plus
python3 rade_loadtest.py
```

Το Ctrl-C κλείνει καθαρά όλες τις συνδέσεις οποιαδήποτε στιγμή.

### Πριν την πρώτη εκτέλεση

Ανοίξτε το αρχείο και ελέγξτε τα δύο τμήματα στην αρχή:

- **`CONFIG`** — το `WS_URL` έχει προεπιλογή `ws://127.0.0.1:8074`· αλλάξτε το αν μετακινήσατε τον sidecar από την προεπιλεγμένη θύρα. Τα `RADE_SPS` (12000) και `RADE_SIDEBAND` (`USB`) πρέπει να ταιριάζουν με ό,τι αναφέρει το frontend σας.
- **`handshake_messages()`** — το μοναδικό πλαίσιο `init` που στέλνει πρέπει να ταιριάζει με την αρχικοποίηση RADE στο `frontend/src/audio.js`. Αν αυτή η χειραψία έχει αποκλίνει, κάθε ακροατής αποτυγχάνει να συνδεθεί και η δοκιμή τερματίζεται αμέσως με αποτυχίες σύνδεσης.

### Κατώφλια γονάτου

Ρυθμίστε τα στο `CONFIG` κατά βούληση — είναι σκόπιμα συντηρητικά:

| Κατώφλι | Προεπιλογή | Σταματά όταν |
|---|---|---|
| `TEMP_KNEE_C` | `85.0` | Η θερμοκρασία πακέτου φτάσει αυτό το όριο |
| `MIN_AVAIL_MB` | `800` | Η διαθέσιμη RAM πέσει κάτω από αυτό |
| `SWAP_GROWTH_MB` | `50` | Το swap ξεπεράσει τη βάση που καταγράφηκε στην εκκίνηση |
| `FAIL_LIMIT` | `3` | Τόσοι ακροατές αποτύχουν να συνδεθούν σε ένα βήμα |
| `MAX_LISTENERS` | `60` | Απόλυτο σταμάτημα ακόμη κι αν δεν εμφανιστεί ποτέ γόνατο |

Το σχήμα της κλιμάκωσης ελέγχεται από τα `STEP` (ακροατές που προστίθενται ανά βήμα, 2 εξ ορισμού), `SETTLE_S` (25 s ηρεμίας πριν τη δειγματοληψία — αυτό επιτρέπει να συσσωρευτεί θερμότητα) και `SAMPLE_S` (παράθυρο μέσου όρου CPU 5 s). Μια πλήρης εκτέλεση έως το προεπιλεγμένο όριο των 60 ακροατών διαρκεί επομένως περίπου 15 λεπτά.

### Ανάγνωση των αποτελεσμάτων

Κάθε βήμα τυπώνει μια γραμμή και προσθέτει μια εγγραφή στο `rade_loadtest.csv`:

| Στήλη | Σημασία |
|---|---|
| `listeners` | Συνθετικοί ακροατές συνδεδεμένοι σε αυτό το βήμα |
| `connect_fails` | Ακροατές που δεν κατάφεραν να δημιουργήσουν ή να διατηρήσουν σύνδεση |
| `pkg_c` | Θερμοκρασία πακέτου, διάμεσος 5 δειγμάτων (ανθεκτική σε αιχμές) |
| `cpu_pct` | Ποσοστό CPU **ολόκληρου του συστήματος**, όχι ανά ακροατή |
| `avail_mb` | Διαθέσιμη RAM |
| `swap_mb` | Swap σε χρήση |
| `dec_rss_mb` | Συνολικό RSS όλων των διεργασιών αποκωδικοποίησης |
| `dec_procs` | Πλήθος διεργασιών αποκωδικοποίησης — αναμένονται **2 ανά ακροατή** (`radae_rxe.py` + `lpcnet_demo`) |

#### Μια μετρημένη εκτέλεση

Στον i5-12450H που αναφέρθηκε παραπάνω, μια πλήρης εκτέλεση τελείωσε έτσι:

```
KNEE at n=32: temp 91.0°C ≥ 85.0
Last stable concurrency: 30 RADE listeners
```

**Η θερμότητα ήταν ο δεσμευτικός περιορισμός**, και μάλιστα με μεγάλη διαφορά. Στο γόνατο υπήρχαν ακόμη 7004 MB διαθέσιμης RAM — 6,2 GB πάνω από το όριο `MIN_AVAIL_MB` — και μηδέν αποτυχίες σύνδεσης σε κάθε βήμα.

Δύο στήλες αξίζουν προσεκτική ανάγνωση:

**Το `dec_rss_mb` υπερεκτιμά το πραγματικό κόστος μνήμης.** Αυξάνεται πολύ σταθερά κατά 295 MB ανά ακροατή (292, 294, 294 … 295 σε όλα τα 16 βήματα), αλλά η *διαθέσιμη* RAM πέφτει μόνο περίπου **202 MB ανά ακροατή**. Οι δύο διεργασίες πίσω από κάθε ακροατή μοιράζονται σελίδες βιβλιοθηκών, και το RSS τις μετρά μία φορά ανά διεργασία. Προεκτείνοντας την κλίση του `avail_mb`, το γόνατο μνήμης θα ερχόταν κοντά στους **63 ακροατές** — πέρα από το απόλυτο όριο των 60, οπότε σε αυτό το μηχάνημα δεν μπορεί ποτέ να ενεργοποιηθεί. Διαστασιολογήστε τη μνήμη με βάση το `avail_mb`, όχι το `dec_rss_mb`.

**Το `cpu_pct` είναι επίπεδο — και μετά δεν είναι.** Παραμένει στο ~5,3 % ολόκληρου του μηχανήματος έως τους 24 ακροατές και έπειτα γίνεται υπεργραμμικό:

| Ακροατές | 24 | 26 | 28 | 30 | 32 |
|---|---|---|---|---|---|
| `cpu_pct` | 6,7 % | 18,4 % | 30,1 % | 49,6 % | 65,2 % |

Πρόκειται για δεκαπλάσια άνοδο της CPU ενώ ο αριθμός ακροατών αυξάνεται κατά ένα τρίτο. Το σημείο καμπής επαναλαμβάνεται στο ίδιο σημείο σε διαφορετικές εκτελέσεις, οπότε αντιμετωπίστε το ως ιδιότητα του μηχανήματος και όχι ως θόρυβο — το κόστος CPU ανά ακροατή είναι περίπου 3,4 % ενός πυρήνα κάτω από το σημείο καμπής και περίπου 20 % πάνω από αυτό. Μην προεκτείνετε νούμερο CPU ανά χρήστη που μετρήθηκε σε χαμηλό αριθμό ακροατών.

> **Η δοκιμή δεν έχει γόνατο CPU.** Τα τέσσερα όρια είναι θερμοκρασία, διαθέσιμη RAM, αύξηση swap και αποτυχίες σύνδεσης — η CPU καταγράφεται αλλά ποτέ δεν τερματίζει την εκτέλεση. Στην παραπάνω εκτέλεση η CPU έφτασε το 65 % και θα συνέχιζε να ανεβαίνει αν δεν είχε πρώτα ενεργοποιηθεί η θερμοκρασία. Αν σας ενδιαφέρει ένα ανώτατο όριο CPU, παρακολουθήστε μόνοι σας τη στήλη ή προσθέστε κατώφλι.

> **Τι αποδεικνύει και τι όχι.** Κάθε συνθετικός ακροατής μεταδίδει τυχαίο θόρυβο χαμηλού πλάτους, όχι πραγματικό σήμα RADE. Αυτό αρκεί ώστε να τρέξει ολόκληρη η αλυσίδα αποκωδικοποίησης και να καταναλωθούν πόροι, οπότε τα νούμερα των πόρων είναι ουσιαστικά — αλλά η δοκιμή δεν λέει τίποτα για την *ποιότητα* αποκωδικοποίησης ή τη συνέχεια του ήχου υπό φόρτο. Επιβεβαιώστε τα με πραγματικούς ακροατές σε πραγματικό σήμα.

### Αν οι πυρήνες κορεστούν πριν το γόνατο

Το RADE καρφιτσώνει έντονα ένα νήμα ανά στιγμιότυπο, οπότε μεμονωμένοι πυρήνες μπορούν να φτάσουν τους ~90 °C ενώ η συνολική CPU φαίνεται αδρανής. Το `rade_helper.py` κατανέμει τις αλυσίδες στους πυρήνες εκ περιτροπής για να το αντισταθμίσει. Αν μια εκτέλεση δείχνει πρόωρα θερμικά γόνατα, διευρύνετε την κατανομή πυρήνων ανά πελάτη:

```bash
RADE_CORES_PER_CLIENT=3 ./rade.sh restart
```

Δεν χρειάζεται επεξεργασία αρχείου — πρόκειται για μεταβλητή περιβάλλοντος (δείτε [Μεταβλητές περιβάλλοντος](#μεταβλητές-περιβάλλοντος))· το `RADE_PIN_CORES=0` απενεργοποιεί εντελώς το καρφίτσωμα.

---

## Ενημέρωση του RADE v1

Η ενσωμάτωση στο PhantomSDR-Plus (`rade_helper.py`, διορθώσεις frontend) είναι μόνο γέφυρα — όλη η λογική αποκωδικοποίησης RADE βρίσκεται στο αποθετήριο `radae`. Οι ενημερώσεις είναι επομένως σχεδόν πάντα ένα απλό `git pull` + νέα μεταγλώττιση, χωρίς αλλαγές στο ίδιο το PhantomSDR-Plus.

### Τυπική ενημέρωση (νέος κώδικας, ίδιο μοντέλο)

```bash
# 1. Pull latest radae code
cd ~/radae
git pull

# 2. Rebuild lpcnet_demo (in case C code changed)
cd build
cmake ..
make -j$(nproc)

# 3. Restart the sidecar — no server restart needed
cd ~/PhantomSDR-Plus
./rade.sh restart
```

Αυτό είναι όλο. Καμία νέα μεταγλώττιση του frontend, καμία επανεκκίνηση διακομιστή, καμία επεξεργασία αρχείων.

### Μόνο νέα βάρη μοντέλου

Αν κυκλοφορήσει νέο σημείο ελέγχου (π.χ. `model20`) χωρίς αλλαγές κώδικα, στρέψτε τον sidecar στα νέα βάρη με τη μεταβλητή περιβάλλοντος — δεν απαιτείται επεξεργασία αρχείου:

```bash
# One-off: start with new model
RADE_MODEL=~/radae/model20/checkpoints/checkpoint_epoch_100.pth ./rade.sh start

# Or permanently — add to your shell profile (~/.bashrc):
export RADE_MODEL=~/radae/model20/checkpoints/checkpoint_epoch_100.pth
```

### Τι απαιτεί κάθε είδος αλλαγής

| Τι άλλαξε στο radae | Απαιτούμενη ενέργεια |
|---|---|
| Νέα βάρη μοντέλου (νέο αρχείο `.pth`) | Ορίστε τη μεταβλητή `RADE_MODEL`, `./rade.sh restart` |
| Αλλαγή κώδικα στο `radae_rxe.py` | `git pull`, `./rade.sh restart` |
| Άλλαξε ο κώδικας C του `lpcnet_demo` | `git pull`, νέα μεταγλώττιση, `./rade.sh restart` |
| Το `radae_rxe.py` μετονομάστηκε ή μετακινήθηκε | Ενημερώστε τη διαδρομή `RADAE_RX` στο `rade_helper.py` (μία γραμμή) |
| Το όρισμα `--model_name` μετονομάστηκε | Ενημερώστε το `radae_cmd` στο `rade_helper.py` (μία γραμμή) |
| Νέος ρυθμός δειγματοληψίας εξόδου (≠ 16000 Hz) | Ενημερώστε το `SPS_OUT` στο `rade_helper.py` + το `createBuffer()` στο `audio.js` |
| Το RADE v2 χρησιμοποιεί άλλο εκτελέσιμο | Ενημερώστε το `RADAE_RX` στο `rade_helper.py` (μία γραμμή) |

### Επαλήθευση ότι η ενημέρωση πέτυχε

Μετά την επανεκκίνηση, επιβεβαιώστε ότι τρέχει ο νέος κώδικας:

```bash
# Check sidecar picked up new radae_rxe.py
./rade.sh status

# Tail log to see startup lines
tail -20 ~/PhantomSDR-Plus/rade.log
```

Το αρχείο καταγραφής πρέπει να δείχνει τη διαδρομή μοντέλου που περιμένετε:
```
[RADE] model : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
```

### Παραμείνετε ενημερωμένοι

Εγγραφείτε στη σελίδα εκδόσεων του αποθετηρίου radae για να ειδοποιείστε για νέα μοντέλα και ενημερώσεις κώδικα:

```
https://github.com/drowe67/radae/releases
```

Ελέγξτε το ιστολόγιο του FreeDV για ανακοινώσεις σχετικά με νέες κυματομορφές και μοντέλα RADE:

```
https://freedv.org/blog/
```

---

*Αναπτύχθηκε και δοκιμάστηκε στο PhantomSDR-Plus (fork sv1btl/PhantomSDR-Plus) με RX-888 MK2 σε Ubuntu 24.04. Ο διακομιστής C++ δεν τροποποιείται.*

*Το RADE αναπτύσσεται από τον David Rowe VK5DGR και την ομάδα FreeDV.* *Δείτε το [freedv.org/radio-autoencoder](https://freedv.org/radio-autoencoder).*

---

### Πλήρης απεγκατάσταση και καθαρή επανεγκατάσταση

Να η πλήρης αποδόμηση πριν εκτελέσετε ξανά το install_rade.sh:
1. Σταματήστε τον sidecar cd ~/PhantomSDR-Plus && ./rade.sh stop
2. Αφαιρέστε το αποθετήριο radae και τη μεταγλώττιση rm -rf ~/radae
3. Αφαιρέστε το torch (εγκατεστημένο στον τοπικό κατάλογο χρήστη) pip3 uninstall -y torch rm -rf ~/.local/lib/python3.11/site-packages/torch*
4. Αφαιρέστε τα πακέτα Python του apt (προαιρετικό — παραλείψτε το αν τα χρησιμοποιούν άλλα) sudo apt-get remove -y python3-numpy python3-scipy python3-matplotlib python3-websockets sudo apt-get autoremove -y
5. Επαληθεύστε ότι όλα αφαιρέθηκαν python3 -c "import torch" 2>&1        # should say ModuleNotFoundError ls ~/radae 2>&1                        # should say No such file or directory
6. Καθαρή εγκατάσταση chmod +x ~/PhantomSDR-Plus/install_rade.sh ~/PhantomSDR-Plus/install_rade.sh
