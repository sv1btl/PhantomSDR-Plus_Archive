# PhantomSDR-Plus Installationsanleitung für Systembetreiber

Diese ausführliche Anleitung führt Sie durch Installation und Konfiguration von PhantomSDR-Plus auf Ihrem Server.

---

## Inhaltsverzeichnis

1. [Systemanforderungen](#systemanforderungen)
2. [Vorbereitung vor der Installation](#vorbereitung-vor-der-installation)
3. [PhantomSDR-Plus installieren](#phantomsdr-plus-installieren) — das Skript und [was es erledigt](#was-das-installationsskript-erledigt)
4. [Autorun-Spot-Reporter (FT8/FT4/WSPR)](#autorun-spot-reporter-ft8ft4wspr)
5. [Konfiguration](#konfiguration)
6. [Gerätespezifische SDR-Einrichtung](#gerätespezifische-sdr-einrichtung)
7. [Test und Überprüfung](#test-und-überprüfung)
8. [Automatischen Start einrichten](#automatischen-start-einrichten)
9. [CPU-Überhitzungsschutz](#cpu-überhitzungsschutz)
10. [Fehlerbehebung](#fehlerbehebung)

**Nur als Nachschlagewerk — das Installationsskript erledigt all dies bereits für Sie.** Lesen Sie diese Abschnitte, wenn Sie eine Distribution verwenden, die keines der Skripte abdeckt, oder wenn Sie einen einzelnen Schritt von Hand reparieren müssen:

- [Abhängigkeiten installieren](#abhängigkeiten-installieren)
- [Node.js und npm installieren](#nodejs-und-npm-installieren)
- [OpenCL installieren](#opencl-installieren-optional-aber-empfohlen)
- [Von Hand bauen](#von-hand-bauen-referenz)
- [Opus-Audiocodec installieren](#opus-audiocodec-installieren)
---

## Systemanforderungen

### Unterstützte Betriebssysteme

**Primär (empfohlen):**
- Ubuntu 24.04 LTS (x86_64) (empfohlen)
- Ubuntu 22.04 LTS (Jammy) — mit `install_ubuntu22.sh`
- Debian 12 (Bookworm) und Debian 13 (Trixie)

**Alternative:**
- Fedora (aktuelle stabile Version)
- Arch Linux (Rolling Release)
- openSUSE Tumbleweed (nicht Leap — siehe Hinweis weiter unten)

### Hardwareanforderungen

**Mindestkonfiguration:**
- CPU: Zweikernprozessor (2 GHz oder mehr)
- RAM: 4 GB
- Speicher: 10 GB freier Platz
- Netzwerk: 100-Mbit/s-Verbindung

**Empfohlene Konfiguration:**
- CPU: Vierkerner oder besser (Ryzen 5 2600, Intel i5-6500T oder besser)
- RAM: 8 GB oder mehr
- Speicher: SSD ab 20 GB
- GPU: AMD/NVIDIA mit OpenCL-Unterstützung (sehr empfehlenswert)
- Netzwerk: 1-Gbit/s-Verbindung

**Hochleistungskonfiguration:**
- CPU: 6 Kerne oder mehr (Ryzen 7, Intel i7 oder besser)
- RAM: 16 GB oder mehr
- Speicher: NVMe-SSD
- GPU: dedizierte GPU mit OpenCL-/CUDA-Unterstützung
- Netzwerk: 1 Gbit/s oder besser

---

## Vorbereitung vor der Installation

### 1. System aktualisieren

```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade -y
sudo reboot

# Fedora
sudo dnf update -y
sudo reboot
```

### 2. Ubuntu-Version prüfen

```bash
lsb_release -a
```

**Die erwartete Ausgabe sollte zeigen:** Ubuntu 24.04 LTS

### 3. Verfügbaren Speicherplatz prüfen

```bash
df -h
```

Stellen Sie sicher, dass in Ihrem Heimatverzeichnis mindestens 10 GB frei sind.

### 4. CPU-Informationen prüfen

```bash
lscpu
```

Notieren Sie die Anzahl der Kerne/Threads zur Optimierung der Konfiguration.

---

## Abhängigkeiten installieren

> [!IMPORTANT]
> **Für eine normale Installation brauchen Sie diesen Abschnitt nicht.** `./install.sh` — bzw. das Installationsskript Ihrer Distribution — erledigt all das für Sie; siehe [Was das Installationsskript erledigt](#was-das-installationsskript-erledigt). Das Folgende ist eine Referenz für eine manuelle Einrichtung, für eine Distribution, die keines der Skripte abdeckt, oder um einen einzelnen Schritt von Hand zu reparieren.


### Ubuntu 24.04 LTS

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  git \
  psmisc \
  wget \
  curl
```

### Fedora

```bash
sudo dnf install -y \
  g++ \
  meson \
  cmake \
  fftw3-devel \
  websocketpp-devel \
  flac-devel \
  zlib-devel \
  boost-devel \
  libzstd-devel \
  opus-devel \
  liquid-dsp-devel \
  git \
  psmisc \
  wget \
  curl
```

### Installation überprüfen

```bash
# Check if key dependencies are installed
pkg-config --modversion fftw3
cmake --version
meson --version
```

---

## Node.js und npm installieren

> [!IMPORTANT]
> **Für eine normale Installation brauchen Sie diesen Abschnitt nicht.** `./install.sh` — bzw. das Installationsskript Ihrer Distribution — erledigt all das für Sie; siehe [Was das Installationsskript erledigt](#was-das-installationsskript-erledigt). Das Folgende ist eine Referenz für eine manuelle Einrichtung, für eine Distribution, die keines der Skripte abdeckt, oder um einen einzelnen Schritt von Hand zu reparieren.


PhantomSDR-Plus benötigt Node.js, um das Frontend zu bauen. Wir verwenden dafür NVM (Node Version Manager).

### 1. NVM installieren

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
```

### 2. NVM laden

**WICHTIG:** Schließen Sie Ihr Terminal und öffnen Sie es erneut, oder führen Sie aus:

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

### 3. NVM-Installation überprüfen

```bash
nvm --version
```

Erwartete Ausgabe: `0.40.4` oder ähnlich

### 4. Node.js installieren

```bash
# Install Node.js 22 - the version every install script requires
nvm install 22

# Make it the default, so systemd units and cron see it too
nvm alias default 22

# Verify installation
node --version
npm --version
```

### 5. Optional: weitere Node-Versionen installieren

```bash
# Install latest version
nvm install node

# Install specific version (if needed)
nvm install 22.22.3

# List installed versions
nvm list

# Use specific version
nvm use 22
```

---

## OpenCL installieren (optional, aber empfohlen)

> [!IMPORTANT]
> **Für eine normale Installation brauchen Sie diesen Abschnitt nicht.** `./install.sh` — bzw. das Installationsskript Ihrer Distribution — erledigt all das für Sie; siehe [Was das Installationsskript erledigt](#was-das-installationsskript-erledigt). Das Folgende ist eine Referenz für eine manuelle Einrichtung, für eine Distribution, die keines der Skripte abdeckt, oder um einen einzelnen Schritt von Hand zu reparieren.


OpenCL verbessert die Leistung erheblich, indem es FFT-Berechnungen auf die GPU auslagert. Dieser Abschnitt behandelt integrierte Intel-Grafik. Für AMD-/NVIDIA-GPUs beachten Sie die Dokumentation des Herstellers.

### Intel-CPU mit integrierter Grafik

#### 1. OpenCL-Basiskomponenten installieren

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  libclfft-dev \
  ocl-icd-opencl-dev \
  clinfo
```

#### 2. Intel Compute Runtime herunterladen

```bash
mkdir -p ~/neo
cd ~/neo

wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
```

#### 3. Intel-OpenCL-Runtime installieren

```bash
sudo dpkg -i *.deb
```

Falls Abhängigkeitsfehler auftreten:

```bash
sudo apt --fix-broken install
```

#### 4. OpenCL-ICD-Loader installieren

```bash
sudo apt update
sudo apt install intel-opencl-icd
```

Falls Fehler auftreten:

```bash
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
```

#### 5. OpenCL-Installation überprüfen

```bash
sudo clinfo
```

Sie sollten Informationen zu Ihrer OpenCL-Plattform und den Geräten sehen. Achten Sie auf:
- Anzahl der Plattformen: 1 (oder mehr)
- Plattformname: Intel(R) OpenCL (oder ähnlich)
- Gerätetyp: GPU oder CPU

#### 6. Neu starten

```bash
sudo reboot
```

### OpenCL auf AMD-GPU

Installieren Sie für AMD-GPUs ROCm:

```bash
# Add ROCm repository
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list

# Install ROCm
sudo apt update
sudo apt install rocm-opencl rocm-clinfo

# Add user to video group
sudo usermod -a -G video $USER

# Reboot
sudo reboot

# Verify
clinfo
```

### OpenCL auf NVIDIA-GPU

Installieren Sie für NVIDIA-GPUs CUDA:

```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-525

# Install CUDA toolkit
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt update
sudo apt install cuda

# Reboot
sudo reboot

# Verify
nvidia-smi
clinfo
```

---

## PhantomSDR-Plus installieren

### Repository klonen, Skripte ausführbar machen, Installation starten

```bash
cd ~
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```

**⚠️ WICHTIG:** Starten Sie nach dem Ende der Installation **Ihr Terminal neu** — das frisch installierte Node.js und Rust liegen erst danach in Ihrem `PATH`.

Nehmen Sie das Skript, das zu Ihrem System passt. Alle leisten dieselbe Arbeit und stellen dieselben Fragen; nur der Paketmanager unterscheidet sich:

| System | Skript |
|---|---|
| Ubuntu 24.04, Debian 13 (Trixie) | `./install.sh` |
| Ubuntu 22.04 (Jammy) | `./install_ubuntu22.sh` |
| Debian 12 (Bookworm) | `./install-Deb12.sh` |
| Fedora | `./install_fedora.sh` |
| Arch | `./install_arch.sh` |
| openSUSE Tumbleweed | `./install_opensuse.sh` |

> **Ubuntu 22.04 hat ein eigenes Installationsskript.** `install_ubuntu22.sh` ist `install.sh` mit drei Jammy-spezifischen Änderungen. Es setzt `DEBIAN_FRONTEND=noninteractive`, damit das mit `python3-matplotlib` hereinkommende `tzdata` den Lauf nicht anhalten kann, um nach Ihrer Zeitzone zu fragen — und danach die Antwort verschluckt, die für die nächste Frage gedacht war. Es ruft `install_rade_ubuntu22.sh` direkt auf, weil Jammys `python3-websockets` 10.1 ist und RADE 11.0 oder neuer braucht. Und es installiert OpenCL in einem einzigen Schritt, da `intel-opencl-icd`, `mesa-opencl-icd` und `pocl-opencl-icd` alle in Jammys eigenen Paketquellen liegen, sodass das Distributionsmenü von `install.sh` hier entfällt. Ein neuerer Compiler ist nicht nötig: Das mitgelieferte GCC 11.4 akzeptiert `-std=c++23` und baut das Backend samt Boost 1.74 — installieren Sie dafür also kein `gcc-12`. Starten Sie das falsche der beiden, bemerkt es das und bietet die Übergabe an.

> **Ubuntu 26.04 (Resolute) und Arch lassen sich übersetzen, sind aber noch nicht im Funkbetrieb erprobt.** Beide bringen ein Boost neuer als 1.87 mit, das die `io_service`-API entfernt hat, gegen die das mitgelieferte websocketpp 0.8.2 geschrieben wurde. Die gepatchten Header, die das Installationsskript hineinkopiert, überbrücken das (`io_context`, `executor_work_guard`, `boost::asio::post`, der moderne Resolver), und eine vollständige Neuinstallation wurde in Containern mit Boost 1.90 und 1.91 von Anfang bis Ende überprüft. Damit ist belegt, dass der Server übersetzt und startet — nicht, dass er stundenlang einen Empfänger bedient. Betrachten Sie beide bis zu einer Rückmeldung als im Produktivbetrieb ungetestet.

> **openSUSE heißt hier Tumbleweed.** Dort ist `install_opensuse.sh` geprüft. Leap 15.6 funktioniert nicht: In seinen Repositories gibt es überhaupt kein `liquid-dsp-devel`, das das Backend braucht, und Boost liegt nur unter versionierten Paketnamen vor. Leap zu unterstützen hieße, fremde OBS-Repositories einzubinden — das bleibt vorerst außen vor.

### Was das Installationsskript erledigt

Nichts muss vorher von Hand vorbereitet werden — keine Paketliste zum Kopieren, kein Node.js zum Nachladen, keine OpenCL-Pakete zum Suchen. Der Ablauf ist von Anfang bis Ende interaktiv, lassen Sie ihn also nicht unbeaufsichtigt, und rechnen Sie je nach Maschine und Anzahl der Extras mit etwa zwanzig Minuten bis deutlich über einer Stunde.

| # | Schritt | Was Sie gefragt werden |
|---|---|---|
| 1 | Erkennt die Distribution und installiert alle Build-Abhängigkeiten (Compiler, meson/ninja, FFTW, Boost, FLAC, Opus, liquid-dsp, zlib/zstd, libcurl …) | nichts |
| 2 | Installiert Node.js 22 über nvm, falls das System keines oder ein zu altes hat | nichts |
| 3 | Baut das Backend mit meson | nichts |
| 4 | Baut den Treiber für Ihren Empfänger — RX888 MkII / RX888, RTL-SDR (Blog V4 wird getrennt gefragt), SDRplay oder keinen. Beim RX888 werden **auch die udev-Regeln installiert**, damit der Server nie `sudo` für das Gerät braucht | welchen SDR Sie haben |
| 5 | Öffnet `frontend/site_information.json` in Ihrem Editor | Rufzeichen, Locator, Hardware, Antenne — **nicht überspringen** |
| 6 | Installiert die Frontend-Abhängigkeiten und baut die Desktop- und `/mobile`-Seiten | nichts |
| 7 | Installiert OpenCL und wählt den Anbieter anhand der gefundenen Hardware (Intel-, AMD- oder NVIDIA-GPU bzw. die x86-CPU-Laufzeit). Gibt es kein OpenCL-fähiges Gerät, sagt es das und fährt fort | bestätigen, Vorgabe ja |
| 8 | Installiert das **Admin-Panel**, den **FreeDV-RADE-V1-Decoder** und den **Statistikserver** — alle drei standardmäßig | jeweils bestätigen, Vorgabe ja; jedes stellt eigene Fragen |
| 9 | Patcht die beiden websocketpp-Header, die die Registrierung bei websdr.org braucht | nichts |
| 10 | Führt als letzte Aktion `recompile.sh` aus, damit alles aus den gepatchten Quellen gebaut wird | `[3] Both backend and frontend` → Startvariante → `[1] build-all.sh` |

Nach einem Neustart sind die RX888-udev-Regeln und ein eventueller OpenCL-Treiber vollständig wirksam; das Skript sagt Ihnen, wann ein Neustart oder eine neue Anmeldung nötig ist.

Beim Einrichten des Admin-Panels bietet der Installer auch die beiden systemd-Units an und **empfiehlt dringend**, sie anzunehmen: Der CPU-Überhitzungsschutz läuft im Panel, ohne sie lässt ein Neustart oder ein Absturz die Maschine ungeschützt. Das Angebot entfällt automatisch dort, wo systemd nicht läuft (Container, WSL1, OpenRC) — siehe [Admin-Panel-Handbuch](ADMIN_PANEL_SETUP.md).

Jedes Extra ist ein normales Skript, das Sie jederzeit auch einzeln starten können — `./setup_admin.sh` ([Handbuch](ADMIN_PANEL_SETUP.md)), `./install_rade.sh` ([Handbuch](RADE_README.md)), `./install-stats-server.sh` ([Handbuch](sdr-stats/README.md)) und `./setup-rx888-udev.sh` — genau diese ruft das Installationsskript auf.

### Von Hand bauen (Referenz)

> [!IMPORTANT]
> **Für eine normale Installation brauchen Sie diesen Abschnitt nicht.** `./install.sh` — bzw. das Installationsskript Ihrer Distribution — erledigt all das für Sie; siehe [Was das Installationsskript erledigt](#was-das-installationsskript-erledigt). Das Folgende ist eine Referenz für eine manuelle Einrichtung, für eine Distribution, die keines der Skripte abdeckt, oder um einen einzelnen Schritt von Hand zu reparieren.

Falls Sie einmal ohne das Installationsskript bauen müssen — eine Distribution, die keines der Skripte abdeckt, oder eine halb fertige Installation reparieren:

#### Backend bauen

```bash
# Clean any previous builds, Configure build with optimization, Compile
rm -rf build
meson setup build --buildtype=release --optimization=3
meson compile -C build

# Verify binary was created
ls -lh build/spectrumserver
```

#### Frontend bauen

```bash
cd frontend

# Install dependencies, Fix any vulnerabilities, Build the frontend
npm install
npm audit fix
npm run build

# Return to project root
cd ..
```

### Installation überprüfen

```bash
# Check if binary exists
ls -lh build/spectrumserver

# Check if frontend was built
ls -lh frontend/dist/

# List important files
ls -lh *.sh *.toml
```

---

## Opus-Audiocodec installieren

> [!IMPORTANT]
> **Für eine normale Installation brauchen Sie diesen Abschnitt nicht.** `./install.sh` — bzw. das Installationsskript Ihrer Distribution — erledigt all das für Sie; siehe [Was das Installationsskript erledigt](#was-das-installationsskript-erledigt). Das Folgende ist eine Referenz für eine manuelle Einrichtung, für eine Distribution, die keines der Skripte abdeckt, oder um einen einzelnen Schritt von Hand zu reparieren.


Opus bietet gegenüber FLAC bessere Tonqualität und geringere Latenz.

### 1. Systembibliothek libopus installieren

```bash
sudo apt-get update
sudo apt-get install -y libopus0 libopus-dev
```

### 2. Opus-Decoder für das Frontend installieren

```bash
cd PhantomSDR-Plus/frontend

# Install npm dependencies if not already done, Install Opus WASM decoder, Fix any vulnerabilities, Rebuild frontend
npm install
npm install @wasm-audio-decoders/opus-ml
npm audit fix
npm run build

# Return to project root
cd ..
```

### 3. Opus-Installation überprüfen

```bash
# Check if Opus system library is installed
pkg-config --modversion opus

# Check if Opus npm package is installed
cd frontend
npm list @wasm-audio-decoders/opus-ml
cd ..
```

---

## Autorun-Spot-Reporter (FT8/FT4/WSPR)

PhantomSDR-Plus bringt einen optionalen **Autorun-Spot-Reporter** mit (im Verzeichnis `autorun/`). Er dekodiert FT8/FT4/WSPR serverseitig direkt vom Empfänger und lädt die Spots zu den Reporting-Netzwerken hoch:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

Er wird vollständig über den Reiter **Admin-Panel → „Spot Reporting"** gesteuert, und **das Reporting ist standardmäßig AUS** — es wird nichts gesendet oder hochgeladen, bis Sie es dort aktivieren. Der Decoder läuft als eigener Node.js-Daemon und greift den Ton des Empfängers lokal ab, benötigt also keine zusätzliche HF-Hardware.

### Voraussetzungen

| Voraussetzung | Anmerkungen |
|---------------|-------------|
| **Node.js 22+** | Dieselbe Laufzeitumgebung, die der Frontend-Build ohnehin braucht — im [Node.js-Schritt](#nodejs-und-npm-installieren) installiert. |
| **npm-Pakete `ws` + `cbor-x`** | Werden über `autorun/node_modules` aufgelöst, einen Symlink auf das `node_modules` des Frontends (beide Pakete sind in `frontend/package.json` deklariert). |
| **`util-linux`** (`taskset`) | Die Schaltfläche „Start" im Admin-Bereich bindet den Daemon per `taskset` an die E-Cores. Praktisch auf jeder Distribution vorhanden; die Installer fügen es ausdrücklich hinzu. |
| **Rufzeichen + Locator** | Werden aus `frontend/site_information.json` gelesen (`siteSysop` / `siteGridSquare`), sofern nicht im Admin-Reiter überschrieben. Spots werden unter diesem Rufzeichen hochgeladen. |

> ⚠️ **Melden Sie nur, was Sie tatsächlich empfangen.** Spots werden unter Ihrem Rufzeichen in öffentliche Netze hochgeladen — aktivieren Sie nur Bänder/Betriebsarten, die Ihr Empfänger wirklich hört, und verwenden Sie Ihren korrekten Locator.

### Automatische Installation

`install.sh` (und die distributionsspezifischen Varianten `install_ubuntu22.sh`, `install-Deb12.sh`, `install_arch.sh`, `install_fedora.sh`, `install_opensuse.sh`) erledigen alles für Sie: Sie installieren Node.js 22 und `util-linux`, führen das `npm install` des Frontends aus und legen anschließend den Symlink `autorun/node_modules` automatisch an. Weitere Schritte sind nicht nötig — die Funktion ist einsatzbereit, sobald `install.sh` fertig ist.

### Manuelle Installation

> [!NOTE]
> Das Installationsskript erledigt dies bereits für Sie: Es legt den Symlink an und installiert `util-linux`. Nutzen Sie die folgenden Schritte nur, um eine Installation von Hand zu reparieren.

Wenn Sie manuell installiert haben (Option B), legen Sie den Symlink nach dem `npm install` des Frontends selbst an, damit der Daemon seine Abhängigkeiten auflösen kann:

```bash
cd ~/PhantomSDR-Plus

# 1. Frontend deps must be installed first (ws + cbor-x live there)
cd frontend && npm install && cd ..

# 2. Link the autorun daemon to the frontend's node_modules
ln -sfn ../frontend/node_modules autorun/node_modules

# 3. Ensure taskset is available (Debian/Ubuntu shown; use your package manager)
sudo apt install -y util-linux
```

> **Hinweis:** `autorun/node_modules` wird von git ignoriert, ein frisches `git clone` enthält es also nie — der Symlink muss nach jedem sauberen Checkout (neu) angelegt werden. Die Installer erledigen das für Sie; der obige Befehl gilt nur für manuelle Einrichtungen.

### Überprüfen

```bash
# The symlink should point at ../frontend/node_modules
ls -l autorun/node_modules

# ws + cbor-x must resolve
ls -d frontend/node_modules/ws frontend/node_modules/cbor-x

# taskset must be on PATH
command -v taskset
```

Öffnen Sie danach das Admin-Panel, wechseln Sie auf den Reiter **Spot Reporting**, tragen Sie Ihre Identität ein, kreuzen Sie die zu dekodierenden Bänder/Betriebsarten an, aktivieren Sie die Ziele und drücken Sie **Start**. Ein Abzeichen „📶 REPORTING" erscheint im Hauptwasserfall, solange das Reporting aktiv ist. (PSK Reporter lädt gebündelt alle 5 Minuten hoch und wsprnet alle 2 Minuten, ein frisch gestarteter Daemon zeigt daher in den ersten Minuten „0 sent" — das ist normal.)

Danach werden zwei verschiedene Zähler angezeigt, die leicht zu verwechseln sind. Die Kacheln **SPOTS UPLOADED PER DECODER** zählen nur den aktuellen Lauf, Stop/Start setzt sie also auf null zurück; die Zahl neben dem Kontrollkästchen jedes Bands bzw. jeder Betriebsart ist der **Gesamtwert seit Beginn**, gespeichert in `autorun-totals.json` und damit über Neustarts hinweg erhalten. Beides beschreibt das [Admin-Panel-Handbuch](ADMIN_PANEL_SETUP.md), ebenso die Seite **Graphen**, die CPU-Takt, CPU-Last, Temperatur und Nutzer online über 15 Minuten bis 24 Stunden darstellt.

> **Wenn Ihre Maschine heiß läuft**, bietet das Panel außerdem einen [thermischen Schutz](ADMIN_PANEL_SETUP.md#thermal-guard), der den Server bei gefährlicher CPU-Temperatur stoppt und wieder startet, sobald sie abgekühlt ist. Seine Schwellen leitet er aus dem kritischen Grenzwert Ihrer eigenen CPU ab, es gibt also nichts zu rechnen, und er funktioniert mit jeder Start-/Stopp-Methode. Er wird mit dem Panel installiert, startet aber im reinen Protokollmodus: Er zeichnet auf, was er *getan hätte*, und ändert nichts, bis Sie ihn in den Einstellungen aktivieren. Dauerdekodierung hält eine CPU rund um die Uhr beschäftigt, daher lohnt sich nach einer Woche Autorun ein Blick in den CRASH-Reiter, um zu sehen, wie nah Ihre Maschine tatsächlich kommt.

> **Der Serverport wird automatisch erkannt.** Der Daemon greift direkt auf den `[server] port` des spectrumservers zu (Loopback + Token, unter Umgehung des Proxys). Er liest diesen Port aus der Konfigurationsdatei, mit der der laufende spectrumserver gestartet wurde, und funktioniert damit ohne Konfiguration auf jedem Port — die Zeile `[autorun] tap backend: …` in `autorun.log` zeigt, was er ermittelt hat. Lief Ihr Server beim Start des Daemons nicht oder haben Sie eine ungewöhnliche Einrichtung, legen Sie ihn in `autorun.json` fest:
> ```json
> "server": { "host": "127.0.0.1", "port": 9002 }
> ```
> Ein falscher Port zeigt sich als `504` / `tap closed 1006` in `autorun.log`, wobei `decodes` bei 0 stehen bleibt.

---

## Konfiguration

### 1. Konfigurationsdatei auswählen

Wählen Sie die passende Konfigurationsdatei für Ihr SDR:

- `config-rtl.toml` – RTL-SDR-Sticks
- `config-rsp1a.toml` – SDRplay RSP1A
- `config-airspyhf.toml` – Airspy HF+ Discovery
- `config-rx888mk2.toml` – RX888 MK2
- `config.example.hackrf.toml` – HackRF One

In diesem Beispiel verwenden wir den RTL-SDR.

### 2. Konfigurationsdatei bearbeiten

```bash
nano config-rtl.toml
```

#### Wichtige Einstellungen

```toml
[server]
port = 9002                      # Web interface port (or everything else)
html_root = "frontend/dist/"     # Frontend location
otherusers = 1                   # Show other users (1=yes, 0=no)
threads = 2                      # Number of server threads

[websdr]
register_online = true           # Register on sdr-list.xyz (true/false)
name = "Your WebSDR Name"        # Display name
antenna = "Your Antenna Type"    # e.g., "Vertical", "Loop", "Dipole"
grid_locator = "AB12cd"          # Your Maidenhead grid square
hostname = "your.domain.com"     # Your domain or IP address

[input]
sps = 2048000                    # Sample rate (adjust for your coverage)
fft_size = 131072                # FFT size (higher = better resolution)
brightness_offset = -10          # Waterfall brightness adjustment
frequency = 145000000            # Base frequency in Hz (145 MHz for 2m)
signal = "iq"                    # "iq" for complex, "real" for real sampling
fft_threads = 2                  # FFT processing threads
accelerator = "opencl"           # "none", "cuda", or "opencl"
audio_sps = 12000                # Audio sample rate (keep at 12000)
audio_compression = "opus"       # "flac" or "opus"
smeter_offset = -2               # S-meter calibration
waterfall_size = 1024            # Waterfall FFT size
waterfall_compression = "zstd"   # Waterfall compression

[input.driver]
name = "stdin"                   # Input driver
format = "u8"                    # Sample format for RTL-SDR

[input.defaults]
frequency = 145500000            # Default tuning frequency
modulation = "FM"                # Default modulation mode
```

#### Richtwerte für die Abtastrate

| Abdeckung | Abtastrate | FFT-Größe |
|-----------|------------|-----------|
| 2 MHz | 2048000 | 131072 |
| 3.2 MHz | 3200000 | 131072 |
| 10 MHz | 10000000 | 1048576 |
| 30 MHz | 30000000 | 2097152 |
| 60 MHz | 60000000 | 8388608 |

### 3. Standortinformationen konfigurieren

```bash
nano frontend/site-information.json
```

Bearbeiten Sie die folgenden Felder:

```json
{
  "siteSysop": "YourCallsign",
  "siteSysopEmailAddress": "your@email.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "Your City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Computer specifications",
  "siteSoftware": "PhantomSDR-Plus v3.7.0",
  "siteReceiver": "Your SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional information",
  "siteIP": "http://your.domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

**IARU-Regionen:**
- **1**: Europa, Afrika, Naher Osten, Nordasien
- **2**: Amerika (Nord, Mitte, Süd), Karibik
- **3**: Asien-Pazifik, Ozeanien

### 4. Frequenzmarker anpassen (optional)

```bash
nano markers.json
```

Fügen Sie Ihre bevorzugten Frequenzen, Relaisfunkstellen und Rundfunksender hinzu.

### 5. Startskript bearbeiten

```bash
nano start-rtl.sh
```

Das Startskript ist ein eigenständiger Starter mit Watchdog. Bearbeiten Sie nur den Block **RECEIVER CONFIGURATION** nahe dem Anfang, damit die Empfängerargumente zu Ihrer Einrichtung passen:

```bash
# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═══
RX_LABEL="RTL-SDR"
RX_COMM="rtl_sdr"                       # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rtl.toml"    # your .toml
FIFO="$PHANTOMDIR/rtl.fifo"
RX_ARGS="${RX_ARGS:--f 145000000 -s 2048000 -}"   # receiver args (edit these)
```

Parameter innerhalb von `RX_ARGS`:
- `-f 145000000`: Mittenfrequenz (145 MHz)
- `-s 2048000`: Abtastrate (2,048 MSPS)

`CONFIG` verweist auf Ihre `.toml`. Sie müssen sonst **nichts** im Skript ändern — die Logik für Start/Neustart/Watchdog/Protokollierung ist allgemeingültig. Sie können die Empfängerargumente auch beim Start überschreiben, ohne die Datei zu bearbeiten: `RX_ARGS="-f 145000000 -s 2048000 -" ./start-rtl.sh` (`RX888_ARGS` für `start-rx888mk2.sh`).

---

## Gerätespezifische SDR-Einrichtung

### RTL-SDR

#### RTL-SDR-Werkzeuge installieren

```bash
sudo apt install -y rtl-sdr
```

#### RTL-SDR testen

```bash
rtl_test
```

Drücken Sie Strg+C zum Beenden. Sie sollten Informationen zur Abtastrate sehen.

#### Konfiguration bearbeiten

```bash
nano config-rtl.toml
```

Übliche Einstellungen für den RTL-SDR:
```toml
sps = 2048000
frequency = 145000000
signal = "iq"
format = "u8"
```

### SDRplay RSP1A

#### SoapySDR und SDRplay-Unterstützung installieren

```bash
# Install SoapySDR
sudo apt install -y soapysdr-tools

# Download SDRplay API
cd ~/Downloads
wget https://www.sdrplay.com/software/SDRplay_RSP_API-Linux-3.07.1.run
chmod +x SDRplay_RSP_API-Linux-3.07.1.run
sudo ./SDRplay_RSP_API-Linux-3.07.1.run

# Install SoapySDRPlay
git clone https://github.com/pothosware/SoapySDRPlay.git
cd SoapySDRPlay
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig
```

#### SDRplay testen

```bash
SoapySDRUtil --find="driver=sdrplay"
```

#### Weitere Hinweise

Siehe die mitgelieferte Datei: `instractions-for-rsp1a`

### Airspy HF+

#### Airspy-Werkzeuge installieren

```bash
sudo apt install -y airspy
```

#### Airspy testen

```bash
airspy_info
```

#### Weitere Hinweise

Siehe die mitgelieferte Datei: `instractions-for-airspy`

### RX888 MK2

#### RX888-Werkzeuge installieren

```bash
# Install rx_tools
git clone https://github.com/rxseger/rx_tools.git
cd rx_tools
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig

# Install RX888 firmware and support
# Follow manufacturer instructions
```

#### rx888_stream ohne sudo ausführen (udev-Regeln)

Standardmäßig ist das Cypress-FX3-USB-Gerät des RX-888 nur für root zugänglich, sodass `rx888_stream` `sudo` bräuchte. Führen Sie das mitgelieferte Hilfsskript einmal aus, um udev-Regeln zu installieren und sich der Gruppe `plugdev` hinzuzufügen:

```bash
./setup-rx888-udev.sh          # re-runs itself with sudo automatically
```

Es schreibt `/etc/udev/rules.d/99-rx888.rules` für alle drei Cypress-FX3-Produkt-IDs (`04b4:00f1`/`00f3` Bootloader und `04b4:8613` mit geladener Firmware), lädt udev neu und legt einen stabilen Symlink `/dev/rx888` an. **Melden Sie sich ab und wieder an** (wegen der Gruppenänderung) und **stecken Sie das Gerät einmal neu an**; danach laufen `rx888_stream` — und der Starter `start-rx888mk2.sh` — ohne `sudo`. Das Skript ist idempotent und kann gefahrlos erneut ausgeführt werden. Für ein anderes Konto: `RX888_USER=<name> ./setup-rx888-udev.sh`.

#### Konfiguration bearbeiten

```bash
nano config-rx888mk2.toml
```

Übliche Einstellungen für den RX888:
```toml
sps = 60000000
frequency = 0
signal = "real"
format = "s16"
fft_size = 8388608
```

### HackRF One

#### HackRF-Werkzeuge installieren

```bash
sudo apt install -y hackrf
```

#### HackRF testen

```bash
hackrf_info
```

---

## Test und Überprüfung

### 1. Testlauf

```bash
# For RTL-SDR
./start-rtl.sh
```

Damit startet der Server **im Hintergrund** (er löst sich ab und kehrt sofort zurück) und beginnt, in `logwebsdr.txt` zu protokollieren.

### 2. Auf Fehler prüfen

Das Skript protokolliert seinen Fortschritt in `logwebsdr.txt` — beobachten Sie ihn live:

```bash
tail -f logwebsdr.txt
```

Achten Sie auf:
- ✅ `Starting the initialization script of the PhantomSDR Server`
- ✅ `<receiver> running (PID …)`
- ✅ `Server started normally`
- ❌ `Server … FAILED …` oder `ERROR: receiver binary '…' not found` (korrigieren Sie die Empfängerargumente bzw. die `.toml` oder installieren Sie das Empfängerwerkzeug und führen Sie das Startskript erneut aus)

### 3. Weboberfläche aufrufen

Öffnen Sie im Browser:
```
http://localhost:9002
```

(Ersetzen Sie die Portnummer durch Ihren konfigurierten Port)

### 4. Funktion überprüfen

- Der Wasserfall sollte angezeigt werden
- Beim Klick auf Signale sollte Ton wiedergegeben werden
- Das S-Meter sollte auf Signale reagieren
- Die Nutzerzahl sollte „1" anzeigen

### 5. Von einem anderen Gerät testen

Von einem anderen Rechner in Ihrem Netzwerk:
```
http://YOUR_SERVER_IP:9002
```

### 6. Ressourcenverbrauch prüfen

```bash
# Monitor CPU usage
htop

# Monitor GPU usage (if OpenCL/CUDA enabled)
nvidia-smi  # For NVIDIA
radeontop   # For AMD

# Monitor network usage
iftop
```

### 7. Server stoppen

Der Server läuft im Hintergrund unter einem Watchdog, **Strg+C stoppt ihn also nicht** (und der Watchdog würde ihn ohnehin neu starten). Verwenden Sie das gemeinsame Stopp-Skript, das für jeden Empfänger funktioniert — es beendet zuerst den Watchdog, dann den Empfänger und `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## Automatischen Start einrichten

### Mit systemd (empfohlen)

#### 1. Service-Datei anlegen

```bash
sudo nano /etc/systemd/system/phantomsdr.service
```

Fügen Sie den folgenden Inhalt ein (Pfade und Benutzer anpassen):

```ini
[Unit]
Description=PhantomSDR-Plus WebSDR Server
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/PhantomSDR-Plus
# Run the watchdog in the FOREGROUND (note the --watchdog flag) so systemd can
# track it. Do NOT use the plain "./start-rtl.sh" here — that form detaches into
# the background and exits, which systemd would treat as the service stopping.
ExecStart=/home/youruser/PhantomSDR-Plus/start-rtl.sh --watchdog
ExecStop=/home/youruser/PhantomSDR-Plus/stop-websdr.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

> Der `--watchdog`-Prozess startet Empfänger und `spectrumserver` bereits selbst neu; `Restart=always` ist nur eine Rückfallebene für den seltenen Fall, dass der Watchdog selbst beendet wird. Da systemd den Server hier überwacht, können Sie `systemctl start/stop/restart` und `journalctl -u phantomsdr -f` verwenden, statt die Skripte von Hand auszuführen.

#### 2. Dienst aktivieren und starten

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable phantomsdr.service

# Start service now
sudo systemctl start phantomsdr.service

# Check status
sudo systemctl status phantomsdr.service
```

#### 3. Dienst verwalten

```bash
# Start
sudo systemctl start phantomsdr

# Stop
sudo systemctl stop phantomsdr

# Restart
sudo systemctl restart phantomsdr

# View logs
sudo journalctl -u phantomsdr -f
```

### Mit Screen (Alternative)

> Meist unnötig: `./start-rtl.sh` löst sich bereits in den Hintergrund ab (per `setsid`) und läuft nach dem Abmelden mit eigenem Watchdog weiter. Screen ist nur dann praktisch, wenn Sie ausdrücklich eine interaktive Sitzung für die Vordergrundform `./start-rtl.sh --watchdog` möchten.

#### 1. Screen installieren

```bash
sudo apt install -y screen
```

#### 2. In einer Screen-Sitzung starten

```bash
screen -S phantomsdr
./start-rtl.sh
```

Drücken Sie Strg+A und dann D zum Ablösen.

#### 3. Sitzung wieder aufnehmen

```bash
screen -r phantomsdr
```

---

## CPU-Überhitzungsschutz

> 📖 **Vollständiges Handbuch: [THERMAL_GUARD.md](THERMAL_GUARD.md)** — die vier Modi und was ein Sysop bei jedem tun muss, Betrieb ohne Panel, die Throttle-Stufe ohne root, Testen und Fehlersuche.

PhantomSDR-Plus bringt einen Wächter mit, der den Server stoppt, wenn die CPU eine gefährliche Temperatur erreicht, und ihn wieder startet, sobald sie abgekühlt ist. Seine Schwellen leitet er aus dem kritischen Grenzwert ab, den Ihre eigene CPU veröffentlicht, es gibt also nichts zu rechnen, und er funktioniert mit jeder Start-/Stopp-Methode.

**Wenn Sie das Admin-Panel betreiben, haben Sie ihn bereits** — er läuft im Panel und wird auf dessen Seite „Einstellungen“ konfiguriert. Siehe das [Admin-Panel-Handbuch](ADMIN_PANEL_SETUP.md#thermal-guard). Der Rest dieses Abschnitts gilt für Installationen **ohne** Panel.

### 1. Prüfen, was der Wächter auf Ihrer Maschine sieht

```bash
cd ~/PhantomSDR-Plus
python3 thermal_guard.py --once
```

```
sensor     : hwmon:coretemp
temperature: 58.0 C
crit       : 100.0 C
mode       : log
thresholds : warn 88.0  throttle 92.0  stop 95.0  resume 75.0 (C)
cpufreq    : not writable — throttle stage disabled
```

Verwendet werden nur echte CPU-Die-Sensoren (`coretemp`, `k10temp`, `zenpower`, `cpu_thermal`); `acpitz` und unbeschriftete Thermal Zones werden bewusst ignoriert, weil sie oft eine Gehäuse- oder Platinentemperatur zig Grad unter der CPU melden. Steht dort `sensor : NONE`, lässt sich diese Maschine nicht schützen — häufig auf einem VPS oder in einem Container —, und der Wächter bleibt untätig, statt es vorzutäuschen.

Dafür muss nichts installiert werden: `thermal_guard.py` kommt mit der Python-Standardbibliothek aus.

### 2. Konfigurieren

Der Wächter liest `admin_config.json` neben `thermal_guard.py`. Legen Sie die Datei an, falls Sie keine haben — ohne Panel haben Sie keine. Das Nötigste:

```json
{
  "sdr_process_name": "spectrumserver",
  "stop_script":  "stop-websdr.sh",
  "start_script": "start-rx888mk2.sh",
  "thermal_mode": "stop+restart"
}
```

- `thermal_mode` — `log` (nur aufzeichnen, der Standard), `throttle`, `stop` oder `stop+restart`. **Diesen Wert müssen Sie setzen**, denn der Wächter wird untätig ausgeliefert: unverändert schreibt er nur auf, was er *getan hätte*. Sie können ihn auch auf der Kommandozeile als `--mode stop+restart` übergeben, was die Datei überschreibt — sind Sie mit allen anderen Standardwerten zufrieden, brauchen Sie also gar keine Konfigurationsdatei.
- `stop_script` / `start_script` — womit der Wächter Ihren Server stoppt und startet. Ohne Stopp-Skript greift er auf `SIGTERM` und nach 10 Sekunden auf `SIGKILL` für `sdr_process_name` zurück. Ohne Start-Skript stoppt er, startet aber nie neu.
- Schwellen und Zeiten lassen sich hier ebenfalls setzen, mit denselben Schlüsselnamen wie im Panel — die vollständige Tabelle steht im [Admin-Panel-Handbuch](ADMIN_PANEL_SETUP.md#thermal-guard).

> **Wenn systemd Ihren SDR-Server überwacht**, lassen Sie `stop_script` auf ein kleines Skript zeigen, das `systemctl stop ihre-unit` ausführt, statt den Wächter den Prozess direkt signalisieren zu lassen. Der Wächter gewinnt ohnehin — solange die CPU zu heiß ist, wiederholt er den Stopp alle 2 Sekunden, sodass alles, was den Server wiederbelebt, rückgängig gemacht wird —, aber ein sauberer Stopp ist besser als ein Kampf im Zwei-Sekunden-Takt.

### 3. Als Dienst betreiben

Das Repository enthält eine fertige Unit, `thermal-guard.service`. Passen Sie darin `User=` und die beiden Pfade an, dann:

```bash
sudo cp thermal-guard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now thermal-guard
systemctl status thermal-guard
```

`User=` muss ein Konto sein, das Ihre Start-/Stopp-Skripte ausführen darf — normalerweise derselbe Benutzer, der den SDR-Server betreibt. **Ein Wächter, der als Benutzer läuft, der den Server nicht stoppen kann, lässt Sie ungeschützt zurück und sieht dabei geschützt aus.**

Um den Wächter aus der Unit statt aus der Konfigurationsdatei scharfzuschalten, ergänzen Sie `ExecStart` um `--mode`:

```ini
ExecStart=/usr/bin/python3 -u /home/sysop/PhantomSDR-Plus/thermal_guard.py --mode stop+restart
```

Ohne systemd:

```bash
cd ~/PhantomSDR-Plus
nohup python3 -u thermal_guard.py --mode stop+restart >> thermal.log 2>&1 &
```

`python3 thermal_guard.py --help` listet alle Optionen auf, auch `--config` für eine Konfigurationsdatei an einem anderen Ort als neben dem Skript.

### 4. Beobachten, dann vertrauen

Alles, was der Wächter tut, landet in `crash.log` im PhantomSDR-Plus-Verzeichnis, ein Ereignis pro Zeile:

```
[THERMAL] warn: 89.0C (warn=88.0 crit=100.0) sustained 31s
[THERMAL] STOPPED server: 96.0C sustained 62s (stop=95.0 crit=100.0) — Started stop-websdr.sh
[THERMAL] lockout: process reappeared at 94.0C — re-stopped [3 time(s) so far]
[THERMAL] recovered: 74.0C held below 75.0 — lockout cleared
```

```bash
grep THERMAL crash.log
```

Lassen Sie `thermal_mode` zunächst eine Woche auf `"log"` und lesen Sie die Datei nach Ihren harten Momenten — einem vollen Rebuild, einem heißen Nachmittag. Steht dort nichts, kam Ihre Maschine nie in die Nähe. Stellen Sie dann den Modus auf `stop`.

Bevor Sie sich darauf verlassen, prüfen Sie den ganzen Weg einmal mit einer fiktiven Messung oberhalb Ihrer Stopp-Schwelle:

```json
"thermal_test_temp": 97
```

Der Wächter behandelt sie als echt, sodass warn → stop → Sperre → Erholung → Neustart auf Wunsch ablaufen. Entfernen Sie die Zeile (oder setzen Sie sie auf `null`), um zum echten Sensor zurückzukehren. Im Modus `stop` wird der Server dabei wirklich gestoppt und Ihre Hörer werden getrennt — machen Sie das also, wenn niemand zuhört, oder testen Sie im Modus `log`, wo gezeigt wird, was passiert *wäre*, ohne etwas anzufassen.

---

## Fehlerbehebung

### Build-Fehler

#### Abhängigkeitsprobleme

```bash
# Ubuntu: Install missing dependencies
sudo apt install --fix-broken

# Fedora: Install missing dependencies
sudo dnf install <package-name>
```

#### Meson-Konfiguration schlägt fehl

```bash
# Clean and reconfigure
rm -rf build
meson setup build --buildtype=release
```

#### Das Backend wurde gebaut, aber es gibt keine Webseite

Das Symptom ist eine Installation, die weitgehend geglückt aussieht: `build/spectrumserver` ist da, der Server startet, und der Browser bekommt nichts — weil `frontend/dist/` nie erzeugt wurde. Suchen Sie in der Ausgabe des Installationsskripts nach:

```
[vite-plugin-top-level-await] missing field `type`
    at Compiler.printSync (node_modules/@swc/core/index.js:257:29)
error during build:
   ❌ Failed: Default
```

`vite-plugin-top-level-await` verlangt `@swc/core` `^1.12.14`, daher löst ein frisches `npm install` auf 1.16.0 auf, dessen `printSync()` den Syntaxbaum ablehnt, den das Plugin ihm übergibt. Mit Ihrer Distribution hat das nichts zu tun — jedes Installationsskript pinnt jetzt die funktionierende Version, und `frontend/package.json` ebenfalls. Eine vor diesem Pin eingerichtete Maschine läuft weiter, bis ihr `node_modules` gelöscht wird; deshalb taucht das bei einer Neuinstallation scheinbar aus dem Nichts auf.

Wenn Sie einen älteren Checkout von Hand reparieren:

```bash
cd frontend
npm pkg set 'overrides.@swc/core=1.15.33'
npm install
./build-all.sh
```

### Laufzeitfehler

#### Port bereits belegt

```bash
# Find process using port
sudo lsof -i :9002

# Kill process
sudo kill -9 <PID>
```

#### Zugriff auf das SDR verweigert

```bash
# Add user to plugdev group
sudo usermod -a -G plugdev $USER

# Reload groups (or log out and back in)
newgrp plugdev
```

Bei einem **RX-888 MkII** reicht das allein nicht — das Cypress-FX3-Gerät benötigt zusätzlich udev-Regeln. Führen Sie das mitgelieferte Hilfsskript aus (es installiert die Regeln *und* fügt Sie zu `plugdev` hinzu), melden Sie sich dann ab und wieder an und stecken Sie das Gerät neu an:

```bash
./setup-rx888-udev.sh
```

#### Audioprobleme

```bash
# Try different codec
# Edit config file and change:
audio_compression = "flac"  # or "opus"

# Rebuild
cd frontend && npm run build && cd ..
```

### OpenCL-Probleme

#### clinfo zeigt keine Geräte

```bash
# Verify drivers are loaded
sudo clinfo

# Check OpenCL ICD files
ls /etc/OpenCL/vendors/

# Reinstall drivers (Intel example)
sudo apt remove --purge intel-opencl-icd
sudo apt install intel-opencl-icd
```

#### Keine Leistungsverbesserung

```bash
# Verify OpenCL is enabled in config
accelerator = "opencl"

# Try different device
# Add to config file:
[input.opencl]
device_id = 0  # Try 0, 1, 2, etc.
```

### Netzwerkprobleme

#### Kein Zugriff von anderen Geräten

```bash
# Check firewall
sudo ufw status
sudo ufw allow 9002/tcp

# Or disable firewall temporarily for testing
sudo ufw disable
```

#### Hohe Latenz

```bash
# Reduce waterfall size in config
waterfall_size = 512

# Increase buffer size
buffer_size = 16384

# Use Opus instead of FLAC
audio_compression = "opus"
```

### Probleme mit dem SDR-Gerät

#### RTL-SDR nicht gefunden

```bash
# Check if device is recognized
lsusb | grep Realtek

# Test with rtl_test
rtl_test

# Try blacklisting DVB-T drivers
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo rmmod dvb_usb_rtl28xxu
```

#### SDRplay nicht gefunden

```bash
# Check API installation
systemctl status sdrplay

# Restart API
sudo systemctl restart sdrplay

# Test with SoapySDR
SoapySDRUtil --find
```

---

## Leistungsoptimierung

### CPU-Optimierung

```toml
# Adjust thread counts based on CPU cores
[server]
threads = 4  # Set to number of cores

[input]
fft_threads = 4  # Set to number of cores
```

### Speicheroptimierung

```toml
# Reduce memory usage
[input]
waterfall_size = 512  # Lower value = less memory
fft_size = 65536      # Lower value = less memory
```

### Netzwerkoptimierung

```toml
# Optimize for limited bandwidth
[input]
audio_compression = "opus"  # More efficient than FLAC
waterfall_compression = "zstd"  # Efficient compression
```

---

## PhantomSDR-Plus aktualisieren

### Manuelle Aktualisierung

```bash
cd PhantomSDR-Plus

# Backup your configuration
cp config-rtl.toml config-rtl.toml.backup
cp frontend/site-information.json frontend/site-information.json.backup

# Pull latest changes
git pull origin main
git submodule update --init --recursive

# Rebuild
meson compile -C build
cd frontend && npm install && npm run build && cd ..
```

### Automatisches Update-Skript

Erstellen Sie `update.sh`:

```bash
#!/bin/bash
cd ~/PhantomSDR-Plus
./stop-websdr.sh
git pull origin main
git submodule update --init --recursive
meson compile -C build
cd frontend && npm install && npm run build && cd ..
./start-rtl.sh
```

---

## Sichern und Wiederherstellen

### Zu sichernde Dateien

- Konfigurationsdateien: `*.toml`
- Standortinformationen: `frontend/site-information.json`
- Marker: `markers.json`
- Eigene Skripte: `start-*.sh`, `stop-*.sh`
- Chatverlauf: `chat_history.txt`
- Hintergrundbild: `frontend/src/assets/background.jpg`

### Sicherungsbefehl

```bash
cd ~/PhantomSDR-Plus
tar -czf phantomsdr-backup-$(date +%Y%m%d).tar.gz \
  *.toml \
  *.sh \
  markers.json \
  chat_history.txt \
  frontend/site-information.json \
  frontend/src/assets/background.jpg
```

### Wiederherstellungsbefehl

```bash
tar -xzf phantomsdr-backup-YYYYMMDD.tar.gz
```

---

## Sicherheitsüberlegungen

### Firewall-Konfiguration

```bash
# Allow only necessary ports
sudo ufw allow 9002/tcp
sudo ufw enable
```

### Reverse-Proxy (optional)

Erwägen Sie nginx oder Apache als Reverse-Proxy für:
- SSL-/TLS-Verschlüsselung
- Zuordnung eines Domainnamens
- Lastverteilung
- Zugriffssteuerung

### Nutzerbegrenzung

Bearbeiten Sie `config.toml`:
```toml
[server]
max_users = 100  # Limit concurrent users
```

---

## Hilfe erhalten

### Ressourcen

- **Dokumentation**: diese Anleitung, README.md, USER_GUIDE.md
- **GitHub Issues**: https://github.com/sv1btl/PhantomSDR-Plus/issues
- **Live-Demo**: http://phantomsdr.no-ip.org:8900/

### Probleme melden

Geben Sie beim Melden von Problemen an:
1. Betriebssystem und Version
2. Modell des SDR-Geräts
3. Inhalt der Konfigurationsdatei
4. Fehlermeldungen
5. Systemressourcenverbrauch (CPU, RAM, GPU)

### Unterstützung durch die Gemeinschaft

- Prüfen Sie vorhandene GitHub-Issues, bevor Sie neue anlegen
- Machen Sie ausführliche Angaben zu Ihrer Einrichtung
- Fügen Sie Protokolle und Fehlermeldungen bei
- Bleiben Sie geduldig und respektvoll

---

## Anhang A: vollständige Abhängigkeitsliste

### Paketliste für Ubuntu 24.04

```
build-essential
cmake
pkg-config
meson
libfftw3-dev
libwebsocketpp-dev
libflac++-dev
zlib1g-dev
libzstd-dev
libboost-all-dev
libopus-dev
libliquid-dev
git
util-linux (taskset — for the autorun spot reporter)
psmisc
wget
curl
rtl-sdr (for RTL-SDR)
airspy (for Airspy)
hackrf (for HackRF)
libclfft-dev (for OpenCL)
ocl-icd-opencl-dev (for OpenCL)
clinfo (for OpenCL)
```

---

## Anhang B: Konfigurationsbeispiele

### Beispiel 1: RTL-SDR für VHF/UHF

```toml
[input]
sps = 2048000
frequency = 145000000
signal = "iq"

[input.driver]
format = "u8"

[input.defaults]
frequency = 145500000
modulation = "FM"
```

### Beispiel 2: RX888 für Kurzwelle (0–30 MHz)

```toml
[input]
sps = 60000000
frequency = 0
signal = "real"
fft_size = 8388608

[input.driver]
format = "s16"

[input.defaults]
frequency = 7100000
modulation = "LSB"
```

### Beispiel 3: HackRF für Breitband-FM

```toml
[input]
sps = 10000000
frequency = 100900000
signal = "iq"

[input.driver]
format = "s8"

[input.defaults]
frequency = 100900000
modulation = "WBFM"
```

---

**Installation abgeschlossen! Sie sollten nun einen voll funktionsfähigen PhantomSDR-Plus-Server haben.**

**73 de SV1BTL & SV2AMK**
