# Panneau d'administration PhantomSDR-Plus — Guide de configuration

> ⚠️ **Avis de sécurité :** gardez ce panneau d'administration sur votre réseau domestique ou derrière un VPN. L'exposition publique du port d'administration n'est pas recommandée sans un durcissement d'authentification approprié.

---

## Vue d'ensemble

Le panneau d'administration se compose de deux services Python :

| Service | Fichier | Rôle |
|---|---|---|
| Panneau d'administration | `admin_server.py` | Application web Flask, liée à `127.0.0.1` (interne uniquement) |
| Proxy inverse | `proxy.py` | Expose à la fois le SDR et le panneau d'administration sur un seul port public |

Les deux services lisent leur configuration dans `admin_config.json`, écrit par `setup_admin.sh`. **Ne modifiez pas directement les constantes de port dans les fichiers Python** — tous les ports et l'adresse IP de l'hôte SDR sont stockés dans `admin_config.json`.

---

## Ce que vous apporte le panneau d'administration

- **Tableau de bord** — état du serveur en direct, CPU/RAM, processus principaux, sortie récente des journaux, terminal
- **Éditeur de configuration** — consultez, modifiez et enregistrez n'importe quel fichier `.toml`, `.sh`, `.json`, `.h`, `.cpp` de votre installation
- **Visionneuse de journaux** — suivez n'importe quel fichier journal en temps réel (serveur SDR, panneau d'administration, RADE, plantages, autorun, proxy)
- **Marqueurs** — consultez et modifiez les marqueurs de fréquence
- **Historique du chat** — consultez le journal du chat WebSDR, effacez-le entièrement ou supprimez des messages individuels sans redémarrer le serveur
- **Message sur la cascade** — diffusez une bannière persistante à tous les utilisateurs connectés, visible en temps réel sur l'affichage en cascade
- **Utilisateurs** — liste en direct des auditeurs connectés avec leur fréquence, leur mode, leur durée de connexion et un bouton ⚡ Kick
- **Suppression de messages du chat** — bouton 🗑 Delete qui retire immédiatement ce seul message du journal
- **Messages diffusés sur la cascade** — permet de pousser une bannière de texte persistante sur la cascade de chaque utilisateur connecté
- **Spot Reporting** — démarrez/arrêtez le décodeur autorun FT8/FT4/WSPR, choisissez les bandes/modes et rapportez les spots à PSK Reporter / wsprnet (désactivé par défaut), avec deux compteurs : des tuiles par décodeur pour l'exécution en cours et un total depuis toujours à côté de chaque case bande/mode
- **Graphiques** — fréquence du CPU, charge du CPU, température du CPU et utilisateurs connectés, tracés sur les 15 dernières minutes / 1 heure / 4 heures / 12 heures / 24 heures
- **Paramètres** — modifiez le mot de passe d'administration, le répertoire de base du SDR, le nom du processus, le port public

---

## Prérequis

- PhantomSDR-Plus déjà installé et en cours d'exécution
- Python 3.8+
- `pip3 install flask psutil aiohttp --break-system-packages`

---

## Étape 1 — Fichiers

Placez ces quatre fichiers dans votre répertoire PhantomSDR-Plus :

```
admin_server.py
manage_admin.sh
setup_admin.sh
proxy.py
```

Rendez les scripts shell exécutables :

```bash
chmod +x setup_admin.sh manage_admin.sh
```

---

## Étape 2 — Lancer le script d'installation

```bash
./setup_admin.sh
```

Le script va :

1. Vérifier que Python 3 est installé
2. Vérifier la présence de `admin_server.py` et `manage_admin.sh`
3. Enregistrer `127.0.0.1` comme `sdr_host` dans la configuration (voir [Le réglage `sdr_host`](#le-réglage-sdr_host))
4. Demander trois numéros de port :
   - **Port de spectrumserver** — le port sur lequel votre serveur SDR écoute (p. ex. `8900`)
   - **Port interne du panneau d'administration** — là où `admin_server.py` se lie localement (p. ex. `3000`)
   - **Port public du proxy** — l'unique port externe combinant SDR + administration (p. ex. `8902`)
5. Installer `flask`, `psutil` et `aiohttp` via pip
6. Accorder à `ss` la capacité `cap_net_admin` (requise pour la fonction d'éjection d'utilisateurs)
7. Écrire `admin_config.json` avec tous les réglages
8. Proposer d'installer un service systemd pour le démarrage automatique

Après l'installation, ouvrez votre navigateur via le proxy :
```
http://YOUR_SERVER_IP:<proxy_port>/admin
```
Mot de passe par défaut : **`admin`**

> ⚠️ **Changez immédiatement le mot de passe** — allez dans Settings à la première connexion. Un assistant de premier lancement vous guidera pour définir le répertoire SDR, le nom du processus, le port public et un nouveau mot de passe.

---

## Étape 3 — Démarrer / arrêter / redémarrer

Utilisez `manage_admin.sh` pour contrôler **à la fois** le panneau d'administration et le proxy :

```bash
./manage_admin.sh start      # start admin panel and proxy
./manage_admin.sh stop       # stop both
./manage_admin.sh restart    # restart both
./manage_admin.sh status     # show running status and PIDs
```

`manage_admin.sh` vérifie que `aiohttp` est installé avant de démarrer le proxy et affiche une erreur claire avec la commande de correction s'il manque.

Si vous avez installé le service systemd lors de la configuration (panneau d'administration uniquement — le proxy est toujours géré via `manage_admin.sh`) :

```bash
sudo systemctl start   phantomsdr-admin
sudo systemctl stop    phantomsdr-admin
sudo systemctl restart phantomsdr-admin
sudo systemctl status  phantomsdr-admin
sudo journalctl -u phantomsdr-admin -f   # live logs
```

---

## Étape 4 — Ouvrir le port du pare-feu

N'ouvrez que le **port public du proxy** dans votre pare-feu. Il est inutile d'exposer le port interne du panneau d'administration :

```bash
sudo ufw allow <proxy_port>
```

---

## Étape 5 — Fonction d'éjection d'utilisateurs

La page Users affiche chaque auditeur actuellement connecté. Chaque ligne indique l'IP de l'utilisateur, sa fréquence, son mode et depuis combien de temps il est connecté. Pour déconnecter un utilisateur, cliquez sur le bouton **⚡ Kick** de sa ligne — seule cette connexion TCP est coupée. Tous les autres auditeurs restent connectés et n'entendent rien.

L'éjection est instantanée et chirurgicale : le serveur ne redémarre pas, l'audio n'est interrompu pour personne d'autre, et l'utilisateur éjecté peut se reconnecter immédiatement (la fonction sert à supprimer des connexions problématiques ou bloquées, pas à bannir).

En interne, l'éjection utilise `ss -K dst <IP> dport <port>` pour fermer le socket TCP concerné. Cela nécessite une capacité Linux que le script d'installation accorde automatiquement. Si vous avez sauté cette étape ou si le bouton signale une erreur, appliquez-la manuellement :

```bash
sudo setcap cap_net_admin+ep $(which ss)
# Verify:
getcap $(which ss)    # should show: cap_net_admin=ep
```

---

## Configuration — admin_config.json

Toute la configuration d'exécution se trouve dans `admin_config.json`, dans votre répertoire PhantomSDR-Plus. `setup_admin.sh` écrit le fichier initial ; les modifications ultérieures peuvent se faire via la page Settings ou en éditant directement le fichier.

Champs clés écrits par `setup_admin.sh` :

| Clé | Description |
|---|---|
| `port` | Port interne du panneau d'administration (`admin_server.py` s'y lie) |
| `public_port` | Port de spectrumserver (utilisé par la page Users pour interroger `/users`) |
| `proxy_port` | Port public sur lequel le proxy écoute |
| `sdr_host` | Hôte utilisé par le proxy pour atteindre spectrumserver — `127.0.0.1` (voir ci-dessous) |
| `password_hash` | Empreinte SHA-256 du mot de passe d'administration |
| `sdr_base_dir` | Chemin de votre installation PhantomSDR-Plus |
| `sdr_process_name` | Nom du processus à surveiller (par défaut : `spectrumserver`) |

Pour changer de ports après l'installation initiale, modifiez `admin_config.json` et redémarrez :

```bash
./manage_admin.sh restart
```

---

## Le réglage `sdr_host`

`proxy.py` se connecte à `spectrumserver` par bouclage — `sdr_host` vaut `127.0.0.1` dans `admin_config.json`, écrit là par `setup_admin.sh`. Vous ne devriez pas avoir à le modifier.

Ne mettez une adresse réelle que si `spectrumserver` tourne sur une **autre machine** que le proxy. Redémarrez ensuite avec `bash manage_admin.sh restart`.

> **Changement :** les versions antérieures exigeaient que `sdr_host` soit l'IP LAN de la machine, car `spectrumserver` fermait les WebSocket arrivant de l'adresse de bouclage. Ce filtre a été supprimé, les connexions locales fonctionnent donc normalement. Deux conséquences : ouvrir `http://localhost:<port>` sur la machine du serveur elle-même affiche désormais l'interface complète (auparavant la page se chargeait mais restait vide), et le proxy ne casse plus quand le DHCP réattribue l'IP de la machine. Si vous mettez à jour et que votre `admin_config.json` contient encore une IP LAN, remplacez-la par `127.0.0.1` ou relancez `setup_admin.sh`.

---

## proxy.py — ce que c'est et quand il est nécessaire

`proxy.py` place à la fois le serveur SDR et le panneau d'administration sur un **seul port public**, en routant par préfixe de chemin :

| Chemin | Redirigé vers |
|---|---|
| `/admin*` | Panneau d'administration (`localhost:<port>`) |
| Tout le reste | Spectrumserver (`<sdr_host>:<public_port>`) |

Sans le proxy, vous devez exposer deux ports séparément. Avec lui, vous n'en exposez qu'un.

Le proxy supprime également la limite de 4 Mo sur la taille des messages WebSocket (important pour les grandes trames FFT du RX-888 à 60 MSPS), transmet les vraies IP des clients via les en-têtes `X-Forwarded-*` et maintient les connexions de longue durée à travers le NAT grâce à un battement de cœur toutes les 30 secondes.

---

## Changer de ports après l'installation

Modifiez directement `admin_config.json` :

```json
{
  "port":        3000,
  "public_port": 9001,
  "proxy_port":  9002,
  "sdr_host":    "127.0.0.1"
}
```

Puis redémarrez les deux services :

```bash
./manage_admin.sh restart
```

Si vous avez également besoin que `admin_server.py` se lie à un autre port au lancement (p. ex. pour le service systemd), vous pouvez le remplacer par la variable d'environnement :

```bash
ADMIN_PORT=3000 python3 admin_server.py
```

Par défaut, `admin_server.py` ne se lie qu'à `127.0.0.1`. Pour l'exécuter seul sans le proxy (développement/tests), liez-le à toutes les interfaces :

```bash
ADMIN_BIND=0.0.0.0 python3 admin_server.py
```

---

## Commandes manuelles utiles

```bash
# Start admin panel manually (foreground)
python3 ~/PhantomSDR-Plus/admin_server.py

# Kill the admin panel
pkill -f admin_server.py

# Kill the proxy
pkill -f proxy.py

# Free a port that is stuck in use
sudo fuser -k 3000/tcp

# Check what is listening on a port
ss -tlnp | grep 3000
```

---

## Fichiers journaux

| Fichier | Contenu |
|---|---|
| `admin.log` | Sortie du panneau d'administration |
| `proxy.log` | Bannière de démarrage du proxy + une ligne de journal d'accès par requête relayée |
| `logwebsdr.txt` | Journal principal du serveur SDR |
| `rade.log` | Journal du sidecar RADE/FreeDV |
| `autorun.log` | Journal du démon de décodage — spots, SNR, dérive |
| `crash.log` | Uniquement des rapports de plantage : traces `[CRASH]` / `[TERMINATE]` et notes `[EXIT]`. **Normalement vide** — tout ce qu'il contient mérite d'être lu |

Tous ces fichiers sont consultables depuis les onglets **Log Viewer** du panneau (LOGWEBSDR,
ADMIN, RADE, CRASH, AUTORUN, PROXY).

### Rotation de proxy.log et admin.log

`proxy.log` enregistre chaque requête relayée et `admin.log` chaque requête qui atteint
le panneau lui-même. Aucun des deux ne fait l'objet d'une rotation par défaut.
L'interrogation du tableau de bord dominait autrefois les deux fichiers —
`/admin/api/status` est appelée toutes les ~3 secondes tant qu'un onglet reste ouvert —
mais ces interrogations sont désormais filtrées des deux journaux (voir plus bas) ; la
rotation sert donc à borner une croissance lente, pas un flot.

Le dépôt fournit une configuration logrotate dans `logrotate/phantomsdr` (quotidienne, ou
plus tôt si un journal dépasse 10 Mo ; conserve 7 archives compressées dans `logproxy/`,
afin qu'elles n'encombrent pas la racine du projet). **Elle dépend du site — ouvrez-la et
changez les deux chemins de journaux, le chemin `olddir` et l'utilisateur `su` pour
correspondre à votre machine avant de l'installer**, puis :

```bash
sudo cp logrotate/phantomsdr /etc/logrotate.d/phantomsdr
sudo logrotate -d /etc/logrotate.d/phantomsdr     # dry run, should list both logs
```

`logrotate/phantomsdr` dans le dépôt et `/etc/logrotate.d/phantomsdr` sont deux copies
**indépendantes** — `cp` ne les relie pas. Modifier le fichier du dépôt ne change rien sur
un système en fonctionnement tant que vous n'avez pas relancé le `sudo cp` ci-dessus. Seule
la copie dans `/etc` est réellement lue par logrotate.

La configuration utilise `copytruncate`, ce qui est indispensable : `manage_admin.sh`
démarre les deux processus avec `>> <log>` et aucun ne rouvre sa sortie standard ; une
rotation par renommage les laisserait donc écrire dans le fichier pivoté tandis que le
nouveau journal resterait éternellement vide.

Les archives arrivent dans `logproxy/` (créé automatiquement par `createolddir`) et sont
nommées `proxy.log.1.gz` … `proxy.log.7.gz`, la plus récente en premier. Lisez-en une avec
`zcat logproxy/proxy.log.1.gz | less`, ou cherchez dans toutes à la fois avec
`zgrep "pattern" logproxy/*.gz`.

Le bouton **Clear Logs** du panneau tronque tous les fichiers du tableau ci-dessus
**sauf `proxy.log`**, délibérément exclu (`CLEAR_EXCLUDE` dans `admin_server.py`) : c'est
le seul enregistrement de qui s'est connecté et quand, et logrotate en borne déjà la
taille ; un bouton d'interface ne doit donc pas pouvoir détruire cet historique. L'onglet
PROXY l'affiche toujours.

Les interrogations réussies sont filtrées des **deux** journaux d'accès, par le
`QuietPollFilter` de `proxy.py` et par celui d'`admin_server.py`. Le tableau de bord appelle
`/admin/api/status` toutes les 3 secondes, et `/admin/api/logs`, `/admin/api/autorun/status`,
`/admin/api/users`, `/admin/api/graph-stats` et `/admin/api/chat` toutes les 5 secondes ;
sans filtrage elles représenteraient ~95 % des deux fichiers. Seuls les `200` simples sur ces
chemins sont écartés — tout autre statut, chemin ou méthode est journalisé comme avant, de
sorte qu'une interrogation en échec reste visible et que chaque action modifiant l'état
(`kick`, `logs/clear`, `autorun/start`, …) passe par un chemin distinct et est toujours
enregistrée.

Comme `proxy.log` est un journal d'accès, il contient les adresses IP des visiteurs et les
chaînes user-agent — gardez-le à l'esprit avant de le partager pour demander de l'aide.

---

## Résumé des accès

| Configuration | SDR | Panneau d'administration |
|---|---|---|
| Sans proxy | `http://YOUR_IP:<public_port>` | `http://YOUR_IP:<port>/admin` |
| Avec proxy | `http://YOUR_IP:<proxy_port>` | `http://YOUR_IP:<proxy_port>/admin` |

---

## Suppression de messages du chat

La page Chat History liste tous les messages du journal de chat actuel. Chaque entrée dispose d'un bouton **🗑 Delete** qui retire immédiatement ce seul message du journal — sans redémarrer le serveur.

Fonctionnement :

- Le panneau d'administration réécrit le fichier de journal du chat sur place, en supprimant uniquement la ligne du message sélectionné.
- Le changement prend effet pour tout utilisateur qui recharge le chat ; l'historique déjà chargé dans les onglets ouverts n'est pas mis à jour rétroactivement.
- Effacer tout le journal (bouton **Clear All**) tronque le fichier, ce qui prend également effet sans redémarrage.

Le bouton de suppression est affiché de manière cohérente dans les cinq variantes de l'application Svelte. Si une suppression semble sans effet, vérifiez que le panneau d'administration a le droit d'écriture sur le fichier de journal du chat :

```bash
ls -l ~/PhantomSDR-Plus/chat.jsonl   # path depends on your config
```

---

## Messages diffusés sur la cascade

Le panneau **Waterfall Message** permet de pousser une bannière de texte persistante sur l'affichage en cascade de chaque utilisateur connecté, sans toucher au processus du serveur.

### Envoyer un message

1. Ouvrez le panneau d'administration et allez dans **Waterfall Message**.
2. Saisissez le texte de votre message et choisissez une couleur (hexadécimale, p. ex. `#ffdd00`).
3. Cliquez sur **Send** — le message apparaît immédiatement sur toutes les vues en cascade actives.

### Effacer le message

Cliquez sur **Clear** pour retirer la bannière de toutes les cascades. L'état du message est conservé en mémoire par le panneau d'administration ; il est effacé automatiquement si le processus du panneau redémarre.

### Fonctionnement

Le panneau d'administration expose deux points de terminaison internes que le proxy relaie :

| Point de terminaison | Méthode | Objet |
|---|---|---|
| `/admin/api/waterfall-message` | `POST` | Définir ou effacer le texte et la couleur de la bannière |
| `/admin/api/waterfall-message` | `GET` | Renvoyer l'état actuel du message au format JSON |

Le frontend interroge l'état du message et l'affiche en superposition sur le canevas de la cascade. Aucune reconnexion WebSocket ni rechargement de page n'est nécessaire côté client.

### Usages typiques

- Annoncer une maintenance programmée : `"Server restart in 10 minutes"`
- Signaler les conditions de propagation : `"Solar flux 180 — 10m wide open"`
- Message de bienvenue : `"Welcome to SV1BTL WebSDR — Athens, KM17"`

---

## Graphiques système

La page **Graphiques** trace quatre mesures sur un axe de temps commun :

- **Fréquence du CPU** — fréquence moyenne sur tous les cœurs, en GHz
- **Charge du CPU** — utilisation totale, en pourcentage
- **Température du CPU** — en °C, avec des repères pointillés à 70 °C (chaud) et 80 °C (critique)
- **Utilisateurs en ligne** — auditeurs connectés au WebSDR à cet instant

Choisissez la plage avec **15 MIN / 1 HOUR / 4 HOURS / 12 HOURS / 24 HOURS**. Le survol du graphique
affiche un réticule et les quatre valeurs de cet instant. Les quatre cartes
au-dessus montrent toujours l'échantillon le plus récent.

### Comment se fait l'échantillonnage

Un thread d'arrière-plan de `admin_server.py` prend un échantillon toutes les
**2 secondes**. Les échantillons sont conservés sur deux niveaux : la dernière
**heure** en pleine résolution de 2 secondes (1800 points) et **24 heures** de
moyennes sur 30 secondes (2880 points) pour les plages longues. La page choisit
le niveau qui couvre la plage demandée et affiche `30s averages` dans l'en-tête
lorsqu'il s'agit du niveau moyenné.

Conserver une journée entière en résolution 2 secondes représenterait ~43000
points : des dizaines de Mo en mémoire, un premier transfert de plusieurs Mo et
environ 40 points par pixel, ce qu'aucun écran ne peut afficher. La moyenne sur
30 secondes tient une journée en 2880 points.

L'échantillonnage démarre avec le panneau d'administration, et non à la première
ouverture de la page : celle-ci s'ouvre donc sur un historique déjà constitué.

Le tampon est **uniquement en mémoire** : rien n'est écrit sur le disque et
l'historique est perdu au redémarrage du panneau. C'est voulu — cela garde la
fonction hors de la rotation des journaux et hors du disque.

2 secondes donnent une vue quasi temps réel et un intervalle assez court pour
ne pas fausser la fréquence du CPU, qui sur un processeur moderne passe de son
horloge de repos à son turbo d'un échantillon à l'autre. Un échantillon coûte
environ une milliseconde : l'échantillonneur est donc négligeable face au serveur
SDR. La page interroge au rythme de chaque niveau — toutes les 2 secondes sur les
plages en direct, toutes les 30 secondes sur les plages moyennées, car demander
plus souvent que les points ne sont produits ne renvoie que des réponses vides.

Pour changer la cadence ou la rétention, modifiez ces constantes au début du bloc
d'échantillonnage dans `admin_server.py`, puis redémarrez :

```python
GRAPH_INTERVAL_S   = 2          # secondes entre les échantillons fins
GRAPH_FINE_S       = 3600       # profondeur du niveau fin (1 h)
GRAPH_COARSE_EVERY = 15         # échantillons fins par point agrégé (15 x 2 s = 30 s)
GRAPH_COARSE_S     = 24 * 3600  # profondeur du niveau agrégé (24 h)
```

### D'où viennent les chiffres

| Mesure | Source |
|---|---|
| Fréquence du CPU | `psutil.cpu_freq()`, à défaut `/sys/devices/system/cpu/cpu*/cpufreq/`. Ce sont les données noyau que `cpufreq-info` met en forme : **cpufrequtils n'est pas requis**. |
| Charge du CPU | `psutil.cpu_percent()` |
| Température du CPU | `psutil.sensors_temperatures()`, à défaut `/sys/class/thermal`, puis la commande `sensors` |
| Utilisateurs en ligne | Le point d'accès `/users` de spectrumserver lui-même — la liste de sessions faisant foi. Compter les sockets avec `ss` ne voit pas les vraies IP des clients derrière proxy.py. |

Si une mesure n'est pas disponible sur votre machine, le panneau le dit au lieu
de tracer une ligne à zéro. Une lecture en échec interrompt la courbe, pour
qu'un trou ne ressemble jamais à une valeur mesurée.

### Pourquoi quatre panneaux et non un seul graphique

Des GHz, des pourcentages, des degrés et un nombre de personnes n'ont pas
d'échelle commune. Les réunir demanderait plusieurs axes y, et les croisements
ainsi produits sont des artefacts de l'échelle, non des faits sur le serveur.
Quatre panneaux empilés sur un même axe de temps gardent la comparaison honnête.
Chaque panneau part de zéro, de sorte que la hauteur de la courbe reste
proportionnelle à la valeur.

La couleur est réservée à la température, où l'ambre et le rouge marquent les
seuils ci-dessus. Les autres panneaux partagent une seule couleur, car chacun ne
contient qu'une série que son titre nomme déjà.

### Point d'accès

`GET /admin/api/graph-stats?since=<epoch>` (connexion requise) renvoie les
échantillons postérieurs à `since`, ce qui permet à la page d'interroger de
façon incrémentale au lieu de retélécharger tout le tampon à chaque cycle.

---

## Spot Reporting (autorun FT8/FT4/WSPR)

L'onglet **Spot Reporting** contrôle le démon autorun (`autorun/index.js`) — un processus
Node.js qui décode FT8/FT4/WSPR côté serveur, directement depuis le récepteur, et téléverse
les spots vers les réseaux de report :

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

**Le report est DÉSACTIVÉ par défaut.** Rien n'est téléversé tant que vous n'avez pas activé
une destination et appuyé sur **Start**. Décodage et téléversement sont indépendants : le
démon peut décoder et journaliser avec le report désactivé, ce qui vous permet de vérifier
l'activité avant que quoi que ce soit ne devienne public.

> ⚠️ Les spots sont téléversés vers des réseaux publics sous **votre indicatif**. N'activez
> que les bandes/modes que votre récepteur entend véritablement, et indiquez le bon locator.

### Prérequis

Le démon autorun nécessite Node.js 22+, les paquets npm `ws` + `cbor-x` (résolus via le lien
symbolique `autorun/node_modules` → `frontend/node_modules`) et `util-linux` (`taskset`). Les
installateurs mettent tout cela en place automatiquement — voir la
[section Rapporteur de spots autorun d'INSTALLATION.md](INSTALLATION.md#rapporteur-de-spots-autorun-ft8ft4wspr).
Si **Start** échoue, ce lien symbolique ou `taskset` en est la cause habituelle (voir Dépannage ci-dessous).

### Utiliser l'onglet

1. **Identité** — indicatif et locator. Pré-remplis depuis `frontend/site_information.json`
   (`siteSysop` / `siteGridSquare`, tronqué à 6 caractères) ; remplacez-les ici si nécessaire.
2. **Matrice bande × mode** — cochez les combinaisons à décoder. Les lignes sont les bandes,
   les colonnes FT8 / FT4 / WSPR ; les cases non prises en charge sont désactivées. WSPR
   couvre en outre les bandes LF/MF (2200 m, 630 m) et un canal 80 m EU supplémentaire.
3. **Destinations** — activez **PSK Reporter** et/ou **wsprnet** (désactivés par défaut).
4. **Max slots** — limite de sécurité sur le nombre de créneaux bande/mode simultanés.
5. **Start / Stop** — lance/arrête le démon (épinglé sur les cœurs CPU les plus élevés avec
   `taskset`, choisis automatiquement selon la machine — voir *Ressources requises et
   limitations* ci-dessous). **Save** / **Reload** enregistrent et relisent la configuration ;
   **Free All** libère tous les créneaux.

La carte d'état s'actualise toutes les 5 s et indique l'état d'exécution, les compteurs de
décodage/téléversement et l'heure du dernier envoi. Un badge **📶 REPORTING** apparaît sur la
cascade principale tant que le report est actif.

> **« 0 sent » pendant les premières minutes est normal.** PSK Reporter téléverse par lots
> toutes les **5 minutes** et wsprnet toutes les **2 minutes** — les spots patientent jusqu'au
> prochain envoi. La carte d'état affiche le nombre en attente et la cadence.

### Changer de bandes ou de modes en cours de fonctionnement

**Les changements ne prennent effet qu'après un redémarrage du démon.**
`autorun/index.js` lit `autorun.json` une seule fois, au démarrage. Il n'y a ni
surveillance de fichier ni signal de rechargement : les seuls signaux traités
sont SIGINT et SIGTERM, qui signifient tous deux l'arrêt. Un démon en cours
continue donc à décoder les créneaux avec lesquels il a été lancé, quoi que vous
enregistriez ensuite.

Pour appliquer un changement :

1. Cochez / décochez les bandes et modes
2. **SAVE CONFIG**
3. **STOP**
4. **START**

Ou simplement **STOP** → modifier les cases → **START**, puisque START enregistre
la configuration avant de lancer.

> ⚠️ **Appuyer sur START sans arrêter d'abord n'applique pas le changement.**
> START enregistre la configuration, puis la requête de démarrage répond
> `already running` et rien n'est relancé. Vous voyez un message « enregistré »
> à côté d'une erreur « already running » alors que le démon poursuit avec les
> **anciennes** bandes — cela ressemble facilement à une réussite. Arrêtez
> toujours d'abord.

Ce qu'un redémarrage fait aux compteurs :

- **Les totaux à côté de chaque case sont conservés** : ils sont dans
  `autorun-totals.json`, qui n'est pas supprimé à l'arrêt.
- **Les tuiles par décodeur repartent de zéro**, elles valent par exécution.
- **Rien n'est perdu de la file** : l'arrêt envoie les spots en attente.
- Une bande **nouvellement activée** part de `0` ; une bande **déjà utilisée**
  reprend son total précédent.
- Une bande que vous **décochez garde son nombre** à côté de la case désormais
  vide ; l'historique n'est pas effacé.

Le décodage ne s'interrompt que les quelques secondes entre STOP et START.

### Compteurs de spots

Deux comptages différents sont affichés ; ils répondent à des questions
différentes.

**SPOTS UPLOADED PER DECODER** — une tuile par décodeur (FT8 / FT4 / WSPR) avec
les spots envoyés **depuis le dernier démarrage du démon**, et en dessous le
nombre de décodages et ceux encore en file. Stop/Start les remet à zéro. Un
décodeur dont la destination est désactivée affiche ses décodages et
`reporting off` plutôt qu'un simple `0` : ici, zéro envoi est un réglage, pas une
panne.

**Le nombre à côté de chaque case** dans BANDS & MODES correspond aux spots
envoyés **depuis toujours** pour cette bande et ce mode. Ils sont conservés dans
`autorun-totals.json` et survivent aux redémarrages. **En ambre avec un point
devant** (`·123`), cela signifie que ce créneau a décodé sans encore rien
envoyer. C'est normal entre deux envois — PSK Reporter émet toutes les 5 minutes
et wsprnet toutes les 2 — de sorte que les compteurs FT8/FT4 restent ambre les
premières minutes après un démarrage. Ils restent également ambre si la
destination de ce décodeur est désactivée. Un `0` simple, sans point, signifie
que ce créneau est activé mais n'a encore rien décodé : WSPR reste à zéro
plusieurs minutes après un démarrage, car il fonctionne sur un cycle de
2 minutes alors que FT8 compte déjà par centaines. Un créneau que le démon n'a
jamais exécuté n'affiche rien. Le survol affiche les envois, les décodages et
l'heure du dernier envoi.

FT8 et FT4 partagent une seule file d'envoi vers PSK Reporter : le démon impute
donc chaque spot à son propre mode et à sa bande au moment de l'envoi ; la
répartition n'est pas estimée après coup à partir des totaux.

**Remettre les compteurs à zéro.** **FREE ALL SLOTS** décoche toutes les bandes
et tous les modes, désactive les deux destinations, arrête le démon et **efface
les compteurs cumulés** : ensuite, plus aucun nombre n'apparaît à côté d'une
case. C'est le seul moyen de les remettre à zéro, et l'opération est
irréversible. Le bouton arrête le démon et attend sa sortie avant de supprimer
`autorun-totals.json`, car le démon réécrit ce fichier à l'arrêt ; le supprimer
sous un démon actif ne ferait que ramener les nombres.

### Ressources requises et limitations

Le démon est volontairement léger et fonctionne sur du matériel modeste (un i5 4 cœurs
convient), mais il existe de vraies limites à connaître.

**L'épinglage CPU d'autorun tient compte de la configuration et est automatique.** Le **démon
autorun** est toujours lancé par le panneau d'administration (`admin_server.py`), son
épinglage est donc défini à chaque installation sans configuration : il déduit une plage de
cœurs `taskset` du nombre de processeurs, en réservant quelques-uns des cœurs les plus élevés
pour le décodage, ou tourne sans épinglage sur ≤ 4 cœurs.

**L'épinglage de spectrumserver dépend de votre méthode de démarrage.** La façon dont vous
lancez spectrumserver varie d'une installation à l'autre (type de SDR, outillage, scripts
personnels) ; ce document ne présuppose donc aucun lanceur particulier. Le panneau
d'administration ne démarre ni n'épingle spectrumserver — cela dépend entièrement de la
commande ou du service que vous utilisez. Si vous voulez tenir spectrumserver à l'écart des
cœurs utilisés par le démon autorun, épinglez-le vous-même avec `taskset` dans votre propre
commande de lancement (voir la section de remplacement ci-dessous). Sinon, il tourne sans
épinglage et l'ordonnanceur du système l'équilibre — correct et sans risque, vous perdez
simplement la séparation délibérée des cœurs.

À titre de référence, le démon autorun réserve ces cœurs élevés (si vous épinglez
spectrumserver, restez donc sur les cœurs bas pour éviter le chevauchement) :

| CPU logiques | Utilisés par le démon autorun | À laisser à spectrumserver |
|---|---|---|
| ≤ 4 | *non épinglé* | *non épinglé* |
| 6 | `5` | `0-4` |
| 8 | `6-7` | `0-5` |
| 12 (p. ex. hybride 8P+4E) | `8-11` | `0-7` |
| 16 | `12-15` | `0-11` |

Sur une machine à **4 cœurs (ou moins)**, il n'y a rien à séparer : le démon autorun tourne
donc lui aussi *sans épinglage* et partage tous les cœurs — correct et sans risque, mais la
FFT du SDR et les rafales de décodage se disputent les mêmes cœurs.

**Limitations connues :**

1. **Le vrai goulot d'étranglement est spectrumserver + la largeur de bande du SDR, pas le
   démon.** Un RX888 à 30 MHz nécessite OpenCL/GPU ; un CPU à peu de cœurs sans GPU capable
   ne peut pas soutenir cette FFT. Associez le matériel modeste à un SDR plus étroit
   (RSP1A ≈ 10 MHz, RTL-SDR ≈ 2.4 MHz).
2. **WSPR est le poste le plus coûteux en CPU.** Son décodeur de Fano est un portage JS
   (~30 s par bande, mono-thread). Le pool de 4 workers exécute 4 décodages en parallèle ;
   activer **plus de ~4 bandes WSPR** à la fois peut faire déborder la file au-delà du
   créneau de 120 s, surtout pendant que le SDR se dispute les cœurs. Les décodages FT8/FT4
   sont peu coûteux en comparaison.
3. **Mise à l'échelle du nombre de créneaux.** Les chiffres de ~2 à 2,5 cœurs / 600 à 700 Mo
   correspondent aux ~28 créneaux complets sur une machine à 8 cœurs. Sur 4 cœurs partagés,
   limitez-vous à quelques bandes (règle : ≤ 6 FT8/FT4 + ≤ 3 WSPR) et surveillez la
   statistique `queued` du pool.
4. **L'épinglage suppose une topologie hybride Intel** (cœurs bas = P-cores plus rapides).
   Sur AMD ou sur des CPU à numérotation SMT entrelacée, la répartition automatique reste
   valable (pas de chevauchement, pas de plantage) mais « les cœurs bas sont plus rapides »
   peut ne pas être littéralement vrai ; sur une puce 4C/8T avec hyperthreading, les cœurs
   hauts sont des jumeaux SMT — confinés, pas totalement isolés. Là où la plage automatique
   n'est pas idéale, utilisez le **remplacement manuel** ci-dessous.
5. **La couverture des bandes est limitée par le récepteur.** La configuration RX888
   (`sps=60000000` → Nyquist à 30 MHz) ne peut pas atteindre le 6 m et au-delà ; la table des
   bandes va de 160 m à 10 m. Les autres SDR couvrent ce que permet leur fenêtre d'accord.
6. **Cadence de report.** PSK Reporter envoie toutes les 5 min, wsprnet toutes les 2 min —
   « 0 sent » les premières minutes est normal, pas un défaut.

### Remplacement manuel de l'épinglage CPU (avancé)

La répartition automatique des cœurs convient à la plupart des machines, mais vous pouvez
forcer un épinglage précis là où ce n'est pas le cas (CCX/CCD AMD, ARM big.LITTLE, SMT
entrelacé). Deux remplacements indépendants, chacun acceptant une liste de cœurs au format
`taskset -c` (`2-3`, `0,2,4`, `0-2,5`) ou `none`/`off`/`unpinned` pour désactiver l'épinglage.
Une valeur invalide est ignorée et la déduction automatique s'applique — une faute de frappe
ne peut jamais empêcher un lancement.

**Démon autorun** — variable d'environnement `AUTORUN_CORES`, ou champ `"cores"` dans
`autorun.json` (l'environnement l'emporte). Le champ `"cores"` est conservé lors du **Save**
du panneau d'administration : une modification manuelle persiste donc. Deux façons de le
définir :

*Option A — `autorun.json` (persistant, recommandé).* Ajoutez une ligne `"cores"` à la
configuration à la racine du dépôt, puis faites **Stop → Start** sur l'onglet Spot Reporting :

```jsonc
// autorun.json
{ "identity": { "callsign": "SV1BTL", "grid": "KM17VX" },
  "reporting": { "pskreporter": true, "wsprnet": false },
  "slots": [ /* … */ ],
  "cores": "2-3" }          // or "none" to run unpinned
```

*Option B — variable d'environnement (ponctuel).* Le démon est lancé par le panneau
d'administration : la variable doit donc figurer dans l'environnement **du panneau** —
définissez-la et redémarrez le panneau (l'environnement l'emporte sur la valeur d'`autorun.json`) :

```bash
AUTORUN_CORES=2-3 ./manage_admin.sh restart
```

**spectrumserver** — épinglez-le vous-même en préfixant `taskset -c <cœurs>` à la commande que
vous utilisez pour démarrer le serveur. Cela fonctionne avec n'importe quelle méthode de
démarrage (lancement direct, chaîne SDR, unité de service, etc.) :

```bash
# pin the server to cores 0-3, direct launch:
taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml < <your-input>
# or in an SDR pipeline:
<your-sdr-source> | taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml
```

> ⚠️ **Faites en sorte que cela survive aux redémarrages.** Un `taskset` en ligne ne
> s'applique qu'à ce lancement précis. Si quelque chose redémarre automatiquement le serveur
> (chien de garde, service systemd, entrée cron/`@reboot`, …), ajoutez le préfixe `taskset`
> à l'intérieur du script ou de l'unité qui le lance réellement — sinon le redémarrage perd
> l'épinglage.

**Vérifier que l'épinglage a pris** — affichez l'affinité CPU réelle des processus en cours :

```bash
taskset -cp "$(pgrep -f 'autorun/index.js')"   # autorun daemon
taskset -cp "$(pgrep -x spectrumserver)"       # spectrumserver
```

**Valeurs acceptées (pour les deux remplacements) :** une liste `taskset -c` (`2-3`, `0,2,4`,
`0-2,5`), ou `none`/`off`/`unpinned` pour aucun épinglage. Tout ce qui est mal formé est
ignoré et la déduction automatique s'applique : une faute de frappe ne peut donc jamais
bloquer le démarrage.

> Sur un Raspberry Pi / toute machine à ≤ 4 cœurs, vous n'avez normalement besoin d'aucun des
> deux — le chemin automatique exécute déjà les deux processus sans épinglage, ce qui est le
> bon choix sur un CPU petit et homogène. Le remplacement s'adresse aux machines plus grandes
> qui ne sont pas des hybrides Intel.

### Fichiers et points de terminaison

| Élément | Objet |
|---|---|
| `autorun.json` | Configuration enregistrée (identité, créneaux, destinations, nombre max de créneaux, remplacement facultatif `cores`). Écrite par l'onglet ; ignorée par git. |
| `autorun-status.json` | État en direct lu par la carte d'état (pid, compteurs, dernier envoi). Écrit toutes les 15 s ; supprimé à l'arrêt. |
| `frontend/dist/autorun-active.json` | Données publiques du badge, servies à `/autorun-active.json`. Vide quand le report est désactivé. |
| `autorun.log` | Sortie standard/erreur du démon. |
| `GET/POST /admin/api/autorun/config` | Lire / écrire `autorun.json` (valide l'indicatif, le locator, les combinaisons bande/mode, la limite de créneaux). |
| `GET /admin/api/autorun/status` | État d'exécution (`pgrep`) + `autorun-status.json`. |
| `POST /admin/api/autorun/start` / `stop` | Lance (`taskset -c <auto> node autorun/index.js`) / envoie `SIGTERM`. La plage de cœurs est déduite du CPU (voir ci-dessus). |

> **Remarque :** après une mise à jour de `admin_server.py`, vous devez exécuter
> `./manage_admin.sh restart` pour charger les nouvelles routes autorun ou une matrice
> bande/mode actualisée. Le démon s'exécute comme un processus distinct : il survit donc aux
> redémarrages du panneau d'administration.

---

## Dépannage

| Problème | Correctif |
|---|---|
| Le panneau d'administration ne démarre pas | Consultez `admin.log` — généralement un paquet Python manquant |
| Le proxy ne démarre pas | Exécutez `python3 -c "import aiohttp"` — en cas d'échec : `pip3 install aiohttp --break-system-packages` |
| `proxy.log` est vide | Vérifiez d'abord que le proxy tourne réellement (`./manage_admin.sh status`). Si oui, vous êtes sur une ancienne version : le lanceur doit utiliser `python3 -u` (non tamponné — sinon la bannière de démarrage ne sort jamais du tampon de 8 Ko), et le `main()` de `proxy.py` doit appeler `logging.basicConfig()` (sinon le journaliseur d'accès d'aiohttp n'a pas de gestionnaire et chaque ligne de requête est perdue, car `web.AppRunner` — contrairement à `web.run_app` — ne configure pas la journalisation). |
| Le proxy démarre mais la cascade est vide | Vérifiez `sdr_host` dans `admin_config.json` — normalement `127.0.0.1`. S'il contient encore une ancienne IP LAN d'une version précédente, corrigez-la et lancez `./manage_admin.sh restart` |
| Le bouton Kick indique « no connections » | Exécutez `getcap $(which ss)` — sans `cap_net_admin`, lancez `sudo setcap cap_net_admin+ep $(which ss)` |
| L'état affiche toujours OFFLINE | Allez dans Settings → SDR Process Name — indiquez le nom exact affiché par `ps -eo comm,args \| grep -v grep` |
| La page Users n'affiche aucune donnée | Vérifiez que le point de terminaison fonctionne : `curl http://127.0.0.1:<public_port>/users` |
| Un navigateur externe obtient NetworkError | Vérifiez que le proxy tourne : `./manage_admin.sh status` |
| Le proxy est cassé après un changement réseau | Concerne uniquement le cas où `sdr_host` contient encore une IP LAN — mettez-le à `127.0.0.1` et lancez `./manage_admin.sh restart` |
| Le bouton de suppression du chat n'a aucun effet | Vérifiez les droits d'écriture sur le fichier de journal du chat : `ls -l ~/PhantomSDR-Plus/chat.jsonl` |
| Le message sur la cascade n'apparaît pas | Vérifiez que le proxy tourne (`./manage_admin.sh status`) et que le frontend est sur une version récente incluant le rendu de la superposition |
| Message sur la cascade perdu après un redémarrage | Comportement attendu — l'état du message n'est qu'en mémoire ; renvoyez-le après le redémarrage du panneau |
| Le « Start » de Spot Reporting échoue / le démon se termine aussitôt | Consultez `autorun.log`. C'est généralement le lien symbolique `autorun/node_modules` manquant (`ln -sfn ../frontend/node_modules autorun/node_modules`) ou `taskset` non installé (`sudo apt install -y util-linux`). |
| Spot Reporting : le démon tourne mais `decodes` reste à 0 et `autorun.log` montre `504` / `tap closed 1006` | La prise audio n'atteint pas spectrumserver. Le démon détecte automatiquement le port depuis la configuration du serveur **en cours d'exécution** ; la ligne de journal `[autorun] tap backend: HOST:PORT` doit correspondre à votre `[server] port`. Si elle est fausse (ou si le serveur n'était pas lancé au démarrage), fixez-le dans `autorun.json` : `"server": { "host": "127.0.0.1", "port": 9002 }`, puis Stop→Start. |
| Spot Reporting affiche « 0 sent » | Normal pendant les premières minutes — PSK Reporter envoie toutes les 5 min, wsprnet toutes les 2 min. Vérifiez qu'une destination est activée et que le démon tourne. |
| Les nouvelles bandes/modes n'apparaissent pas dans la matrice | Redémarrez le panneau d'administration : `./manage_admin.sh restart` (la matrice est chargée au démarrage). |
| `autorun.log` affiche `MODULE_TYPELESS_PACKAGE_JSON` / « Reparsing as ES module … performance overhead » | Avertissement cosmétique (le décodage fonctionne toujours). Il manque `"type": "module"` à `frontend/src/modules/package.json` ; ajoutez cette ligne près du début, puis Stop→Start. Aucune recompilation du frontend n'est nécessaire — le démon importe directement le fichier source. |
| Le « Start » de Spot Reporting échoue avec `taskset: … Invalid argument` sur un PC ancien/modeste | Ne devrait pas se produire avec le lanceur tenant compte de la configuration — la plage de cœurs est déduite du nombre de CPU et passe sans épinglage sur ≤ 4 cœurs. Si cela arrive, votre `admin_server.py` est antérieur à ce changement ; mettez-le à jour (`_autorun_taskset_prefix`) et lancez `./manage_admin.sh restart`. |
| Le badge REPORTING n'apparaît pas sur la cascade | Le report doit être activé avec au moins un créneau ; le badge lit `/autorun-active.json`. Recompilez le frontend si `dist/index.html` est antérieur au badge. |
