# Administratorska ploča PhantomSDR-Plusa — Vodič za postavljanje

> ⚠️ **Sigurnosna napomena:** držite ovu administratorsku ploču na kućnoj mreži ili iza VPN-a. Javno izlaganje administratorskog porta ne preporučuje se bez odgovarajućeg pojačanja autentifikacije.

---

## Pregled

Administratorska ploča sastoji se od dvije Python usluge:

| Usluga | Datoteka | Uloga |
|---|---|---|
| Administratorska ploča | `admin_server.py` | Flask web-aplikacija, veže se na `127.0.0.1` (samo interno) |
| Obratni proxy | `proxy.py` | Izlaže i SDR i administratorsku ploču na jednom javnom portu |

Obje usluge čitaju konfiguraciju iz `admin_config.json`, koju zapisuje `setup_admin.sh`. **Nemojte izravno mijenjati konstante portova u Python datotekama** — svi portovi i IP adresa SDR poslužitelja pohranjeni su u `admin_config.json`.

---

## Što vam administratorska ploča donosi

- **Nadzorna ploča** — stanje poslužitelja uživo, CPU/RAM, najzahtjevniji procesi, nedavni ispis zapisnika, terminal
- **Uređivač konfiguracije** — pregled, uređivanje i spremanje bilo koje `.toml`, `.sh`, `.json`, `.h` ili `.cpp` datoteke u vašoj instalaciji
- **Preglednik zapisnika** — praćenje bilo koje datoteke zapisnika u stvarnom vremenu (SDR poslužitelj, administratorska ploča, RADE, rušenja, autorun, proxy)
- **Oznake** — pregled i uređivanje frekvencijskih oznaka
- **Povijest razgovora** — pregled zapisnika WebSDR razgovora, potpuno brisanje ili uklanjanje pojedinačnih poruka bez ponovnog pokretanja poslužitelja
- **Poruka na slapu** — emitiranje trajne poruke svim spojenim korisnicima, vidljive u stvarnom vremenu na prikazu slapa
- **Korisnici** — popis spojenih slušatelja uživo s njihovom frekvencijom, načinom rada, trajanjem veze i gumbom ⚡ Kick
- **Brisanje poruka razgovora** — gumb 🗑 Delete koji odmah uklanja tu jednu poruku iz zapisnika
- **Emitirane poruke na slapu** — omogućuje slanje trajnog tekstualnog natpisa na slap svakog spojenog korisnika
- **Spot Reporting** — pokretanje/zaustavljanje autorun dekodera FT8/FT4/WSPR, odabir pojaseva/načina rada i prijava spotova na PSK Reporter / wsprnet (prema zadanom isključeno), s dva brojača: pločice po dekoderu za tekući rad i ukupan zbroj od početka uz svaki potvrdni okvir pojasa/načina rada
- **Grafikoni** — frekvencija procesora, opterećenje procesora, temperatura procesora i povezani korisnici, prikazani kroz zadnjih 15 minuta / 1 sat / 4 sata / 12 sati / 24 sata
- **Postavke** — promjena administratorske lozinke, osnovnog direktorija SDR-a, naziva procesa i javnog porta

---

## Preduvjeti

- PhantomSDR-Plus već instaliran i pokrenut
- Python 3.8+
- `pip3 install flask psutil aiohttp --break-system-packages`

---

## Korak 1 — Datoteke

Postavite ove četiri datoteke u svoj PhantomSDR-Plus direktorij:

```
admin_server.py
manage_admin.sh
setup_admin.sh
proxy.py
```

Postavite skripte ljuske kao izvršne:

```bash
chmod +x setup_admin.sh manage_admin.sh
```

---

## Korak 2 — Pokrenite skriptu za postavljanje

```bash
./setup_admin.sh
```

Skripta će:

1. Provjeriti je li instaliran Python 3
2. Provjeriti postoje li `admin_server.py` i `manage_admin.sh`
3. Zabilježiti `127.0.0.1` kao `sdr_host` u konfiguraciji (vidi [Postavka `sdr_host`](#postavka-sdr_host))
4. Zatražiti tri broja porta:
   - **Port spectrumservera** — port na kojem sluša vaš SDR poslužitelj (npr. `8900`)
   - **Interni port administratorske ploče** — gdje se `admin_server.py` lokalno veže (npr. `3000`)
   - **Javni port proxyja** — jedini vanjski port koji objedinjuje SDR + administraciju (npr. `8902`)
5. Instalirati `flask`, `psutil` i `aiohttp` putem pipa
6. Dodijeliti naredbi `ss` mogućnost `cap_net_admin` (potrebnu za značajku Kick Users)
7. Zapisati `admin_config.json` sa svim postavkama
8. Ponuditi instalaciju systemd usluge za automatsko pokretanje

Nakon postavljanja otvorite preglednik putem proxyja:
```
http://YOUR_SERVER_IP:<proxy_port>/admin
```
Zadana lozinka: **`admin`**

> ⚠️ **Odmah promijenite lozinku** — pri prvoj prijavi idite na Settings. Čarobnjak prvog pokretanja vodit će vas kroz postavljanje SDR direktorija, naziva procesa, javnog porta i nove lozinke.

---

## Korak 3 — Pokretanje / zaustavljanje / ponovno pokretanje

Koristite `manage_admin.sh` za upravljanje **i** administratorskom pločom **i** proxyjem zajedno:

```bash
./manage_admin.sh start      # start admin panel and proxy
./manage_admin.sh stop       # stop both
./manage_admin.sh restart    # restart both
./manage_admin.sh status     # show running status and PIDs
```

`manage_admin.sh` prije pokretanja proxyja provjerava je li instaliran `aiohttp` i, ako nedostaje, ispisuje jasnu pogrešku s naredbom za ispravak.

Ako ste tijekom postavljanja instalirali systemd uslugu (samo za administratorsku ploču — proxyjem se uvijek upravlja putem `manage_admin.sh`):

```bash
sudo systemctl start   phantomsdr-admin
sudo systemctl stop    phantomsdr-admin
sudo systemctl restart phantomsdr-admin
sudo systemctl status  phantomsdr-admin
sudo journalctl -u phantomsdr-admin -f   # live logs
```

---

## Korak 4 — Otvorite port na vatrozidu

Na vatrozidu otvorite samo **javni port proxyja**. Interni port administratorske ploče nije potrebno izlagati prema van:

```bash
sudo ufw allow <proxy_port>
```

---

## Korak 5 — Značajka Kick Users

Stranica Users prikazuje svakog trenutačno spojenog slušatelja. Svaki redak prikazuje korisnikovu IP adresu, ugođenu frekvenciju, način rada i trajanje veze. Da biste odspojili jednog korisnika, kliknite gumb **⚡ Kick** u njegovu retku — prekida se samo ta TCP veza. Svi ostali slušatelji ostaju spojeni i ništa ne primjećuju.

Prekid je trenutačan i precizan: poslužitelj se ne pokreće ponovno, nikome drugom se zvuk ne prekida, a odspojeni korisnik može se odmah ponovno spojiti (značajka služi uklanjanju problematičnih ili zaglavljenih veza, a ne zabrani pristupa).

U pozadini prekid koristi `ss -K dst <IP> dport <port>` za rušenje te konkretne TCP utičnice. To zahtijeva Linux mogućnost koju skripta za postavljanje dodjeljuje automatski. Ako ste preskočili postavljanje ili gumb javlja pogrešku, primijenite je ručno:

```bash
sudo setcap cap_net_admin+ep $(which ss)
# Verify:
getcap $(which ss)    # should show: cap_net_admin=ep
```

---

## Konfiguracija — admin_config.json

Sva konfiguracija izvođenja nalazi se u `admin_config.json` u vašem PhantomSDR-Plus direktoriju. `setup_admin.sh` zapisuje početnu datoteku; kasnije promjene mogu se raditi putem stranice Settings ili izravnim uređivanjem datoteke.

Ključna polja koja zapisuje `setup_admin.sh`:

| Ključ | Opis |
|---|---|
| `port` | Interni port administratorske ploče (ondje se veže `admin_server.py`) |
| `public_port` | Port spectrumservera (koristi ga stranica Users za upit na `/users`) |
| `proxy_port` | Javni port na kojem sluša proxy |
| `sdr_host` | Računalo preko kojeg proxy doseže spectrumserver — `127.0.0.1` (vidi dolje) |
| `password_hash` | SHA-256 sažetak administratorske lozinke |
| `sdr_base_dir` | Putanja do vaše PhantomSDR-Plus instalacije |
| `sdr_process_name` | Naziv procesa za nadzor (zadano: `spectrumserver`) |

Za promjenu portova nakon početnog postavljanja uredite `admin_config.json` i ponovno pokrenite:

```bash
./manage_admin.sh restart
```

---

## Postavka `sdr_host`

`proxy.py` se na `spectrumserver` spaja preko povratne (loopback) adrese — `sdr_host` je `127.0.0.1` u `admin_config.json`, gdje ga upisuje `setup_admin.sh`. Ne biste to trebali morati mijenjati.

Postavite stvarnu adresu samo ako `spectrumserver` radi na **drugom računalu** od proxyja. Zatim ponovno pokrenite s `bash manage_admin.sh restart`.

> **Promjena:** starije verzije zahtijevale su da `sdr_host` bude LAN IP računala, jer je `spectrumserver` zatvarao WebSocket veze koje dolaze s povratne adrese. Taj je filtar uklonjen, pa lokalne veze rade normalno. Dvije posljedice: otvaranje `http://localhost:<port>` na samom poslužiteljskom računalu sada prikazuje cijelo sučelje (prije bi se stranica učitala, ali ostala prazna), a proxy se više ne kvari kad DHCP dodijeli računalu novu IP adresu. Ako nadograđujete, a vaš `admin_config.json` još sadrži LAN IP, promijenite ga u `127.0.0.1` ili ponovno pokrenite `setup_admin.sh`.

---

## proxy.py — što je i kada vam treba

`proxy.py` smješta i SDR poslužitelj i administratorsku ploču na **jedan javni port**, usmjeravajući prema prefiksu putanje:

| Putanja | Usmjerava se na |
|---|---|
| `/admin*` | Administratorsku ploču (`localhost:<port>`) |
| Sve ostalo | Spectrumserver (`<sdr_host>:<public_port>`) |

Bez proxyja morate izložiti dva porta zasebno. S proxyjem izlažete samo jedan.

Proxy također uklanja ograničenje veličine WebSocket poruke od 4 MB (važno za velike FFT okvire s RX-888 pri 60 MSPS), prosljeđuje stvarne IP adrese klijenata putem `X-Forwarded-*` zaglavlja i održava dugotrajne veze kroz NAT pomoću otkucaja svakih 30 sekundi.

---

## Promjena portova nakon postavljanja

Uredite `admin_config.json` izravno:

```json
{
  "port":        3000,
  "public_port": 9001,
  "proxy_port":  9002,
  "sdr_host":    "127.0.0.1"
}
```

Zatim ponovno pokrenite obje usluge:

```bash
./manage_admin.sh restart
```

Ako uz to trebate da se `admin_server.py` pri pokretanju veže na drugi port (npr. u systemd usluzi), to možete nadjačati varijablom okruženja:

```bash
ADMIN_PORT=3000 python3 admin_server.py
```

Prema zadanom, `admin_server.py` veže se samo na `127.0.0.1`. Za samostalno pokretanje bez proxyja (razvoj/testiranje) vežite ga na sva sučelja:

```bash
ADMIN_BIND=0.0.0.0 python3 admin_server.py
```

---

## Korisne ručne naredbe

```bash
# Start admin panel manually (foreground)
python3 ~/PhantomSDR-Plus/admin_server.py

# Kill the admin panel
pkill -f admin_server.py

# Kill the proxy
pkill -f proxy.py

# Free a port that is stuck in use
sudo fuser -k 3000/tcp

# Check what is listening on a port
ss -tlnp | grep 3000
```

---

## Datoteke zapisnika

| Datoteka | Sadržaj |
|---|---|
| `admin.log` | Ispis administratorske ploče |
| `proxy.log` | Natpis pri pokretanju proxyja + jedan redak pristupa po proslijeđenom zahtjevu |
| `logwebsdr.txt` | Glavni zapisnik SDR poslužitelja |
| `rade.log` | Zapisnik RADE/FreeDV sidecara |
| `autorun.log` | Zapisnik dekoderskog daemona — spotovi, SNR, drift |
| `crash.log` | Samo izvještaji o rušenju: `[CRASH]` / `[TERMINATE]` backtraceovi i `[EXIT]` bilješke. **Uobičajeno prazan** — sve što se u njemu nađe vrijedi pročitati |

Sve se to može čitati iz kartica **Log Viewer** na ploči (LOGWEBSDR,
ADMIN, RADE, CRASH, AUTORUN, PROXY).

### Rotiranje proxy.log i admin.log

`proxy.log` bilježi svaki proslijeđeni zahtjev, a `admin.log` svaki zahtjev koji stigne do
same ploče. Nijedan se ne rotira prema zadanom. Ispitivanja nadzorne ploče nekoć su
dominirala objema datotekama — `/admin/api/status` okida svakih ~3 sekunde dok je kartica
otvorena — ali sada se filtriraju iz oba zapisnika (vidi niže), pa rotacija ograničava spor
rast, a ne poplavu.

Repozitorij donosi logrotate konfiguraciju u `logrotate/phantomsdr` (dnevno, ili ranije ako
zapisnik prijeđe 10 MB; čuva 7 gzip arhiva u `logproxy/` kako ne bi zatrpavale korijen
projekta). **Ovisi o instalaciji — otvorite je i prije instalacije promijenite dvije putanje
zapisnika, putanju `olddir` i korisnika `su` da odgovaraju vašem računalu**, zatim:

```bash
sudo cp logrotate/phantomsdr /etc/logrotate.d/phantomsdr
sudo logrotate -d /etc/logrotate.d/phantomsdr     # dry run, should list both logs
```

`logrotate/phantomsdr` u repozitoriju i `/etc/logrotate.d/phantomsdr` dvije su **neovisne
kopije** — `cp` ih ne povezuje. Uređivanje datoteke u repozitoriju ne mijenja ništa na
pokrenutom sustavu dok ponovno ne izvršite gornji `sudo cp`. Logrotate zapravo čita samo
kopiju u `/etc`.

Konfiguracija koristi `copytruncate`, što je nužno: `manage_admin.sh` pokreće oba procesa s
`>> <log>` i nijedan ponovno ne otvara svoj standardni izlaz, pa bi ih rotacija temeljena na
preimenovanju ostavila da pišu u rotiranu datoteku dok bi novi zapisnik zauvijek ostao prazan.

Arhive završavaju u `logproxy/` (stvara se automatski zahvaljujući `createolddir`) i nose
nazive `proxy.log.1.gz` … `proxy.log.7.gz`, najnovija prva. Jednu pročitajte naredbom
`zcat logproxy/proxy.log.1.gz | less`, ili pretražite sve odjednom pomoću
`zgrep "pattern" logproxy/*.gz`.

Gumb **Clear Logs** na ploči prazni svaku datoteku iz gornje tablice **osim `proxy.log`**, koja
je namjerno izuzeta (`CLEAR_EXCLUDE` u `admin_server.py`): to je jedini zapis o tome tko se i
kada spojio, a logrotate mu već ograničava veličinu, pa gumb u sučelju ne bi smio moći uništiti
tu povijest. Kartica PROXY i dalje je prikazuje.

Uspješna ispitivanja filtriraju se iz **oba** zapisnika pristupa, `QuietPollFilterom` u
`proxy.py` i onim u `admin_server.py`. Nadzorna ploča poziva `/admin/api/status` svake
3 sekunde, a `/admin/api/logs`, `/admin/api/autorun/status`, `/admin/api/users`,
`/admin/api/graph-stats` i `/admin/api/chat` svakih 5 sekundi; nefiltrirani bi činili ~95 %
obiju datoteka. Izbacuju se samo obični `200` na tim putanjama — svaki drugi status, putanja
ili metoda bilježi se kao i prije, pa neuspjelo ispitivanje ostaje vidljivo, a svaka radnja
koja mijenja stanje (`kick`, `logs/clear`, `autorun/start`, …) ide zasebnom putanjom i uvijek
se zapisuje.

Budući da je `proxy.log` zapisnik pristupa, sadrži IP adrese posjetitelja i nizove user-agenta
— imajte to na umu prije nego što ga podijelite tražeći pomoć.

---

## Sažetak pristupa

| Postava | SDR | Administratorska ploča |
|---|---|---|
| Bez proxyja | `http://YOUR_IP:<public_port>` | `http://YOUR_IP:<port>/admin` |
| S proxyjem | `http://YOUR_IP:<proxy_port>` | `http://YOUR_IP:<proxy_port>/admin` |

---

## Brisanje poruka razgovora

Stranica Chat History navodi svaku poruku u trenutačnom zapisniku razgovora. Svaki unos ima gumb **🗑 Delete** koji odmah uklanja tu jednu poruku iz zapisnika — bez ponovnog pokretanja poslužitelja.

Kako to radi:

- Administratorska ploča prepisuje datoteku zapisnika razgovora na mjestu, uklanjajući samo redak odabrane poruke.
- Promjena vrijedi za svakog korisnika koji ponovno učita razgovor; već učitana povijest u otvorenim karticama preglednika ne ažurira se retroaktivno.
- Brisanje cijelog zapisnika (gumb **Clear All**) prazni datoteku, što također djeluje bez ponovnog pokretanja.

Gumb za brisanje dosljedno se prikazuje u svih pet Svelte inačica aplikacije. Ako se čini da brisanje nema učinka, provjerite ima li administratorska ploča pravo pisanja u datoteku zapisnika razgovora:

```bash
ls -l ~/PhantomSDR-Plus/chat.jsonl   # path depends on your config
```

---

## Emitirane poruke na slapu

Ploča **Waterfall Message** omogućuje slanje trajnog tekstualnog natpisa na prikaz slapa svakog spojenog korisnika bez diranja procesa poslužitelja.

### Slanje poruke

1. Otvorite administratorsku ploču i idite na **Waterfall Message**.
2. Upišite tekst poruke i odaberite boju (heksadecimalno, npr. `#ffdd00`).
3. Kliknite **Send** — poruka se odmah pojavljuje u svim aktivnim prikazima slapa.

### Uklanjanje poruke

Kliknite **Clear** da uklonite natpis sa svih slapova. Stanje poruke administratorska ploča drži u memoriji; briše se automatski ako se proces ploče ponovno pokrene.

### Kako to radi

Administratorska ploča izlaže dvije interne krajnje točke koje proxy prosljeđuje:

| Krajnja točka | Metoda | Svrha |
|---|---|---|
| `/admin/api/waterfall-message` | `POST` | Postavljanje ili brisanje trenutačnog teksta i boje natpisa |
| `/admin/api/waterfall-message` | `GET` | Vraćanje trenutačnog stanja poruke kao JSON |

Sučelje ispituje stanje poruke i iscrtava je kao preklop na platnu slapa. Na strani klijenta nije potrebno ni ponovno spajanje WebSocketa ni ponovno učitavanje stranice.

### Uobičajene primjene

- Najava planiranog održavanja: `"Server restart in 10 minutes"`
- Naznaka uvjeta na pojasu: `"Solar flux 180 — 10m wide open"`
- Poruka dobrodošlice: `"Welcome to SV1BTL WebSDR — Athens, KM17"`

---

## Grafikoni sustava

Stranica **Grafikoni** crta četiri veličine na zajedničkoj vremenskoj osi:

- **Frekvencija procesora** — prosječni takt svih jezgri, u GHz
- **Opterećenje procesora** — ukupna iskorištenost, u postotcima
- **Temperatura procesora** — u °C, s crtkanim oznakama na 70 °C (toplo) i 80 °C (kritično)
- **Korisnici na vezi** — slušatelji spojeni na WebSDR u tom trenutku

Raspon birate s **15 MIN / 1 HOUR / 4 HOURS / 12 HOURS / 24 HOURS**. Prelaskom miša preko grafikona
pojavljuje se nitni križ s sve četiri vrijednosti tog trenutka. Četiri kartice
iznad grafikona uvijek prikazuju najnoviji uzorak.

### Kako se uzorkuje

Pozadinska dretva u `admin_server.py` uzima jedan uzorak svake **2 sekunde**.
Uzorci se čuvaju u dvije razine: zadnji **1 sat** u punoj razlučivosti od 2
sekunde (1800 točaka) i **24 sata** tridesetsekundnih prosjeka (2880 točaka) za
duge raspone. Stranica bira razinu koja pokriva odabrani raspon i u zaglavlju
piše `30s averages` kada gledate prosječenu razinu.

Cijeli dan u razlučivosti od 2 sekunde bio bi ~43000 točaka — deseci MB memorije,
prvi prijenos od nekoliko megabajta i oko 40 točaka po pikselu, što nijedan
zaslon ne može prikazati. Prosjek na 30 sekundi drži dan u 2880 točaka.

Uzorkovanje kreće zajedno s administracijskom pločom, a ne pri prvom otvaranju
stranice, pa se stranica otvara na povijesti koja već postoji.

Međuspremnik je **samo u memoriji**: ništa se ne zapisuje na disk, a povijest se
gubi pri ponovnom pokretanju ploče. To je namjerno — funkciju drži izvan
rotacije zapisnika i s diska.

2 sekunde daju gotovo živu sliku i dovoljno su kratke da ne izobliče frekvenciju
procesora, koja na suvremenom procesoru od uzorka do uzorka skače između takta
mirovanja i turba. Jedan uzorak košta otprilike jednu milisekundu, pa je
uzorkivač zanemariv uz SDR poslužitelj. Stranica pita u ritmu svoje razine —
svake 2 sekunde na živim rasponima, svakih 30 sekundi na prosječenima, jer češće
pitanje vraća samo prazne odgovore.

Za promjenu ritma ili trajanja pohrane uredite ove konstante na početku bloka
uzorkivača u `admin_server.py` i ponovno pokrenite:

```python
GRAPH_INTERVAL_S   = 2          # sekundi između finih uzoraka
GRAPH_FINE_S       = 3600       # dokle seže fina razina (1 h)
GRAPH_COARSE_EVERY = 15         # finih uzoraka po skupnoj točki (15 x 2 s = 30 s)
GRAPH_COARSE_S     = 24 * 3600  # dokle seže skupna razina (24 h)
```

### Odakle dolaze brojke

| Veličina | Izvor |
|---|---|
| Frekvencija procesora | `psutil.cpu_freq()`, uz zamjenu `/sys/devices/system/cpu/cpu*/cpufreq/`. To su isti podaci jezgre koje oblikuje `cpufreq-info`, pa **cpufrequtils nije potreban**. |
| Opterećenje procesora | `psutil.cpu_percent()` |
| Temperatura procesora | `psutil.sensors_temperatures()`, uz zamjenu `/sys/class/thermal`, zatim naredba `sensors` |
| Korisnici na vezi | Vlastita krajnja točka `/users` poslužitelja spectrumserver — mjerodavan popis sesija. Brojanje priključaka s `ss` ne vidi stvarne IP adrese klijenata iza proxy.py. |

Ako neka veličina na vašem računalu nije dostupna, taj to okvir kaže umjesto da
crta ravnu nulu. Neuspjelo očitanje prekida liniju, da praznina nikada ne izgleda
kao izmjerena vrijednost.

### Zašto četiri okvira, a ne jedan grafikon

GHz, postotak, stupnjevi i broj ljudi nemaju zajedničku skalu. Crtanje u jednom
grafikonu tražilo bi više y-osi, a sjecišta koja pritom nastaju artefakt su
skaliranja, a ne činjenica o poslužitelju. Četiri složena okvira na jednoj
vremenskoj osi drže usporedbu poštenom. Svaki okvir počinje od nule, pa visina
krivulje ostaje razmjerna vrijednosti.

Boja je pridržana za temperaturu, gdje jantarna i crvena označavaju gornje
pragove. Ostali okviri dijele jednu boju jer svaki sadrži jednu jedinu seriju
koju njegov naslov već imenuje.

### Krajnja točka

`GET /admin/api/graph-stats?since=<epoch>` (potrebna prijava) vraća uzorke novije
od `since`, pa stranica pita postupno umjesto da svaki ciklus ponovno preuzima
cijeli međuspremnik.

---

## Spot Reporting (autorun FT8/FT4/WSPR)

Kartica **Spot Reporting** upravlja autorun daemonom (`autorun/index.js`) — Node.js procesom
koji dekodira FT8/FT4/WSPR na poslužiteljskoj strani izravno s prijamnika i šalje spotove u
mreže za prijavu:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

**Prijavljivanje je prema zadanom ISKLJUČENO.** Ništa se ne šalje dok ne uključite odredište i
pritisnete **Start**. Dekodiranje i slanje neovisni su: daemon može dekodirati i zapisivati s
isključenim prijavljivanjem, pa možete provjeriti aktivnost prije nego išta postane javno.

> ⚠️ Spotovi se šalju u javne mreže pod **vašim pozivnim znakom**. Uključite samo pojaseve i
> načine rada koje vaš prijamnik doista čuje i postavite ispravan lokator.

### Preduvjeti

Autorun daemon treba Node.js 22+, npm pakete `ws` + `cbor-x` (razrješavaju se preko simboličke
poveznice `autorun/node_modules` → `frontend/node_modules`) i `util-linux` (`taskset`).
Instalacijske skripte sve to postavljaju automatski — vidi
[odjeljak Autorun Spot Reporter u INSTALLATION.md](INSTALLATION.md#autorun-spot-reporter-ft8ft4wspr).
Ako **Start** ne uspije, uobičajeni je uzrok ta poveznica ili `taskset` (vidi Rješavanje problema niže).

### Korištenje kartice

1. **Identitet** — pozivni znak i lokator. Unaprijed popunjeni iz
   `frontend/site_information.json` (`siteSysop` / `siteGridSquare`, skraćeno na 6 znakova);
   ovdje ih po potrebi zamijenite.
2. **Matrica pojas × način rada** — označite kombinacije za dekodiranje. Retci su pojasevi,
   stupci FT8 / FT4 / WSPR; nepodržane ćelije su onemogućene. WSPR dodatno pokriva LF/MF
   pojaseve (2200 m, 630 m) i dodatni europski kanal na 80 m.
3. **Odredišta** — uključite **PSK Reporter** i/ili **wsprnet** (oboje prema zadanom isključeno).
4. **Max slots** — sigurnosno ograničenje broja mjesta pojas/način rada koja mogu raditi istodobno.
5. **Start / Stop** — pokreće/gasi daemon (vezan uz gornje CPU jezgre pomoću `taskset`, koje se
   biraju automatski prema računalu — vidi *Zahtjevi za resursima i ograničenja* niže).
   **Save** / **Reload** spremaju i ponovno čitaju konfiguraciju; **Free All** prazni sva mjesta.

Kartica stanja osvježava se svakih 5 s i prikazuje stanje rada, brojače dekodiranja/slanja i
vrijeme posljednjeg slanja. Oznaka **📶 REPORTING** pojavljuje se na glavnom slapu dok je
prijavljivanje aktivno.

> **„0 sent" prvih nekoliko minuta je normalno.** PSK Reporter šalje skupno svakih **5 minuta**,
> a wsprnet svake **2 minute** — spotovi čekaju u redu do sljedećeg slanja. Kartica stanja
> prikazuje broj u čekanju i ritam slanja.

### Promjena pojaseva ili načina rada dok radi

**Promjene ne vrijede dok se daemon ponovno ne pokrene.** `autorun/index.js`
čita `autorun.json` samo jednom, pri pokretanju. Nema nadzora datoteke ni signala
za ponovno učitavanje — jedini signali koje obrađuje su SIGINT i SIGTERM, a oba
znače gašenje. Daemon koji radi zato i dalje dekodira slotove s kojima je
pokrenut, što god poslije spremili.

Za primjenu promjene:

1. Označite / odznačite pojaseve i načine rada
2. **SAVE CONFIG**
3. **STOP**
4. **START**

Ili jednostavno **STOP** → promijenite kućice → **START**, jer START sprema
konfiguraciju prije pokretanja.

> ⚠️ **Pritisak na START bez prethodnog STOP-a ne primjenjuje promjenu.** START
> sprema konfiguraciju, a zatim zahtjev za pokretanje odgovara `already running`
> i ništa se ne pokreće ponovno. Vidjet ćete poruku „spremljeno" uz pogrešku
> „already running" dok daemon nastavlja sa **starim** pojasevima — lako se čita
> kao uspjeh. Uvijek prvo STOP.

Što ponovno pokretanje čini brojačima:

- **Ukupni brojevi uz svaku kućicu ostaju** — nalaze se u `autorun-totals.json`,
  koji se pri gašenju ne briše.
- **Pločice po dekoderu vraćaju se na nulu**, vrijede po pokretanju.
- **Ništa iz reda se ne gubi**: gašenje prvo pošalje spotove na čekanju.
- **Novouključeni** pojas kreće od `0`; pojas koji ste **već koristili** nastavlja
  svoj prijašnji zbroj.
- Pojas koji **odznačite zadržava svoj broj** uz sada praznu kućicu; povijest se
  ne briše.

Dekodiranje staje samo na nekoliko sekundi između STOP-a i START-a.

### Brojači spotova

Prikazana su dva različita brojanja koja odgovaraju na različita pitanja.

**SPOTS UPLOADED PER DECODER** — pločica po dekoderu (FT8 / FT4 / WSPR) sa
spotovima poslanima **od zadnjeg pokretanja daemona**, a ispod broj dekodiranja i
koliko ih još čeka u redu. Stop/Start ih vraća na nulu. Dekoder čije je odredište
isključeno prikazuje svoja dekodiranja i `reporting off` umjesto golog `0`, jer
je ondje nula slanja postavka, a ne kvar.

**Broj uz svaku kućicu** u BANDS & MODES je broj **ukupno** poslanih spotova za
tu kombinaciju pojasa i načina rada. Čuva se u `autorun-totals.json` i preživljava
ponovna pokretanja. **Jantarno s točkom ispred** (`·123`) znači da je taj slot
dekodirao, ali još ništa nije poslao. To je normalno između slanja — PSK Reporter
šalje svakih 5 minuta, a wsprnet svake 2 — pa FT8/FT4 brojači prvih nekoliko
minuta nakon pokretanja stoje jantarno. Jantarno ostaje i ako je odredište tog
dekodera isključeno. Obična `0` bez točke znači da je slot uključen, ali još
ništa nije dekodirao — WSPR stoji na nuli nekoliko minuta nakon pokretanja jer
radi u ciklusu od 2 minute, dok FT8 već broji u stotinama. Slot koji daemon
nikada nije pokrenuo ne prikazuje ništa. Prelaskom miša vide se slanja,
dekodiranja i vrijeme zadnjeg slanja.

FT8 i FT4 dijele jedan red za slanje prema PSK Reporteru, pa daemon svaki spot
pripisuje vlastitom načinu rada i pojasu u trenutku slanja; podjela se ne
procjenjuje naknadno iz ukupnih brojeva.

**Poništavanje brojača.** **FREE ALL SLOTS** odznačuje sve pojaseve i načine
rada, isključuje oba odredišta, zaustavlja daemon i **briše ukupne brojače** —
nakon toga uz nijednu kućicu nema broja. To je jedini način da ih poništite i ne
može se poništiti. Gumb zaustavlja daemon i čeka da izađe prije brisanja
`autorun-totals.json`, jer daemon tu datoteku ponovno zapisuje pri gašenju;
brisanje dok daemon radi samo bi vratilo brojeve.

### Zahtjevi za resursima i ograničenja

Daemon je namjerno lagan i radi na hardveru skromnih resursa (četverojezgreni i5 je dovoljan),
ali postoje stvarna ograničenja kojih treba biti svjestan.

**Vezanje autoruna uz jezgre svjesno je konfiguracije i automatsko.** **Autorun daemon** uvijek
pokreće administratorska ploča (`admin_server.py`), pa se njegovo vezanje postavlja pri svakoj
instalaciji bez ikakve konfiguracije: iz broja procesora izvodi raspon jezgri za `taskset`,
rezervirajući nekoliko gornjih jezgri za dekodiranje, ili radi bez vezanja na ≤ 4 jezgre.

**Vezanje spectrumservera ovisi o vašem načinu pokretanja.** Način na koji pokrećete
spectrumserver razlikuje se među instalacijama (vrsta SDR-a, alati, osobne skripte), pa ovaj
dokument ne pretpostavlja nikakav određeni pokretač. Administratorska ploča ne pokreće niti veže
spectrumserver — to u potpunosti ovisi o naredbi ili usluzi kojom ga izvodite. Ako želite
spectrumserver držati podalje od jezgri koje koristi autorun daemon, vežite ga sami pomoću
`taskset` u vlastitoj naredbi za pokretanje (vidi odjeljak o zamjeni niže). Ako to ne učinite,
jednostavno radi bez vezanja, a raspoređivač operacijskog sustava ga uravnotežuje — ispravno i
sigurno, samo gubite namjerno razdvajanje jezgri.

Za orijentaciju, autorun daemon rezervira ove gornje jezgre (pa ako vežete spectrumserver,
zadržite ga na nižima kako biste izbjegli preklapanje):

| Logičkih CPU-a | Koristi autorun daemon | Ostaviti za spectrumserver |
|---|---|---|
| ≤ 4 | *bez vezanja* | *bez vezanja* |
| 6 | `5` | `0-4` |
| 8 | `6-7` | `0-5` |
| 12 (npr. hibrid 8P+4E) | `8-11` | `0-7` |
| 16 | `12-15` | `0-11` |

Na računalu s **4 jezgre (ili manje)** nema se što razdvajati, pa i autorun daemon radi *bez
vezanja* i dijeli sve jezgre — ispravno i sigurno, ali FFT SDR-a i naleti dekodiranja natječu
se za iste jezgre.

**Poznata ograničenja:**

1. **Pravo usko grlo su spectrumserver i širina pojasa SDR-a, a ne daemon.** RX888 na 30 MHz
   traži OpenCL/GPU; procesor s malo jezgri bez sposobnog GPU-a ne može održati taj FFT.
   Uparite skromni hardver s užim SDR-om (RSP1A ≈ 10 MHz, RTL-SDR ≈ 2.4 MHz).
2. **WSPR je najzahtjevniji za CPU.** Njegov Fano dekoder je JS port (~30 s po pojasu,
   jednodretveni). Skup od 4 workera izvodi 4 dekodiranja paralelno; uključivanje **više od
   ~4 WSPR pojasa** odjednom može produljiti red preko intervala od 120 s, osobito dok se SDR
   natječe za jezgre. Dekodiranja FT8/FT4 u usporedbi su jeftina.
3. **Skaliranje broja mjesta.** Podatak od ~2–2,5 jezgre / 600–700 MB odnosi se na punih ~28
   mjesta na osmojezgrenom računalu. Na 4 dijeljene jezgre ograničite se na nekoliko pojaseva
   (smjernica: ≤ 6 FT8/FT4 + ≤ 3 WSPR) i pratite statistiku `queued` skupa.
4. **Vezanje pretpostavlja hibridnu Intel topologiju** (niže jezgre = brže P-jezgre). Na AMD-u
   ili procesorima s isprepletenim SMT numeriranjem automatska podjela i dalje vrijedi (bez
   preklapanja, bez rušenja), ali „niže jezgre su brže" možda ne vrijedi doslovno; na čipu
   4C/8T s hyperthreadingom gornje su jezgre SMT blizanci — ograničene, ali ne i potpuno
   izolirane. Ondje gdje automatski raspon nije idealan, upotrijebite **ručnu zamjenu** niže.
5. **Pokrivenost pojaseva ograničava prijamnik.** Konfiguracija RX888
   (`sps=60000000` → Nyquist na 30 MHz) ne doseže 6 m i više; tablica pojaseva ide od 160 m do
   10 m. Drugi SDR-ovi pokrivaju ono što dopušta njihov ugođeni prozor.
6. **Ritam prijavljivanja.** PSK Reporter šalje svakih 5 min, wsprnet svake 2 min — „0 sent"
   prvih nekoliko minuta normalno je, a ne kvar.

### Ručna zamjena vezanja uz jezgre (napredno)

Automatski izvedena podjela jezgri prikladna je za većinu računala, no možete nametnuti
određeno vezanje ondje gdje nije (AMD CCX/CCD, ARM big.LITTLE, isprepleteni SMT). Dvije su
neovisne zamjene, a svaka prihvaća popis jezgri u obliku `taskset -c` (`2-3`, `0,2,4`,
`0-2,5`) ili `none`/`off`/`unpinned` za isključivanje vezanja. Neispravna vrijednost se
zanemaruje i primjenjuje se automatsko izvođenje — tipfeler nikada ne može spriječiti pokretanje.

**Autorun daemon** — varijabla okruženja `AUTORUN_CORES` ili polje `"cores"` u `autorun.json`
(okruženje ima prednost). Polje `"cores"` čuva se pri **Save** u administratorskoj ploči, pa
ručna izmjena ostaje. Dva načina da ga postavite:

*Mogućnost A — `autorun.json` (trajno, preporučeno).* Dodajte redak `"cores"` u konfiguraciju u
korijenu repozitorija, zatim na kartici Spot Reporting učinite **Stop → Start**:

```jsonc
// autorun.json
{ "identity": { "callsign": "SV1BTL", "grid": "KM17VX" },
  "reporting": { "pskreporter": true, "wsprnet": false },
  "slots": [ /* … */ ],
  "cores": "2-3" }          // or "none" to run unpinned
```

*Mogućnost B — varijabla okruženja (jednokratno).* Daemon pokreće administratorska ploča, pa
varijabla mora biti u okruženju **ploče** — postavite je i ponovno pokrenite ploču (okruženje
ima prednost pred vrijednošću u `autorun.json`):

```bash
AUTORUN_CORES=2-3 ./manage_admin.sh restart
```

**spectrumserver** — vežite ga sami tako da naredbi kojom pokrećete poslužitelj dodate prefiks
`taskset -c <jezgre>`. To radi sa svakim načinom pokretanja (izravno pokretanje, SDR cjevovod,
jedinica usluge itd.):

```bash
# pin the server to cores 0-3, direct launch:
taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml < <your-input>
# or in an SDR pipeline:
<your-sdr-source> | taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml
```

> ⚠️ **Pobrinite se da preživi ponovna pokretanja.** Ugrađeni `taskset` vrijedi samo za to
> jedno pokretanje. Ako nešto automatski ponovno pokreće poslužitelj (watchdog, systemd usluga,
> cron/`@reboot` unos …), dodajte prefiks `taskset` unutar skripte ili jedinice koja ga zapravo
> pokreće — inače ponovno pokretanje gubi vezanje.

**Provjerite je li vezanje primijenjeno** — ispišite stvarni afinitet CPU-a pokrenutih procesa:

```bash
taskset -cp "$(pgrep -f 'autorun/index.js')"   # autorun daemon
taskset -cp "$(pgrep -x spectrumserver)"       # spectrumserver
```

**Prihvaćene vrijednosti (za obje zamjene):** popis u obliku `taskset -c` (`2-3`, `0,2,4`,
`0-2,5`) ili `none`/`off`/`unpinned` za rad bez vezanja. Sve neispravno zanemaruje se i
primjenjuje se automatsko izvođenje, pa tipfeler nikada ne može blokirati pokretanje.

> Na Raspberry Piju / bilo kojem računalu s ≤ 4 jezgre obično ne trebate nijednu — automatski
> put već pokreće oba procesa bez vezanja, što je ispravan izbor na malom, homogenom procesoru.
> Zamjena je namijenjena većim računalima koja nisu Intel hibridi.

### Datoteke i krajnje točke

| Stavka | Svrha |
|---|---|
| `autorun.json` | Spremljena konfiguracija (identitet, mjesta, odredišta, najveći broj mjesta, neobavezna zamjena `cores`). Zapisuje je kartica; git je zanemaruje. |
| `autorun-status.json` | Trenutačno stanje koje čita kartica stanja (pid, brojači, posljednje slanje). Zapisuje se svakih 15 s; uklanja se pri zaustavljanju. |
| `frontend/dist/autorun-active.json` | Javni podaci oznake, posluženi na `/autorun-active.json`. Prazno kada je prijavljivanje isključeno. |
| `autorun.log` | Standardni izlaz i pogreške daemona. |
| `GET/POST /admin/api/autorun/config` | Čitanje/pisanje `autorun.json` (provjerava pozivni znak, lokator, kombinacije pojas/način rada, ograničenje mjesta). |
| `GET /admin/api/autorun/status` | Stanje rada (`pgrep`) + `autorun-status.json`. |
| `POST /admin/api/autorun/start` / `stop` | Pokretanje (`taskset -c <auto> node autorun/index.js`) / `SIGTERM`. Raspon jezgri izvodi se iz procesora (vidi gore). |

> **Napomena:** nakon nadogradnje `admin_server.py` morate izvršiti `./manage_admin.sh restart`
> kako bi se učitale nove autorun rute ili ažurirana matrica pojas/način rada. Daemon radi kao
> zaseban proces, pa preživljava ponovna pokretanja administratorske ploče.

---

## Rješavanje problema

| Problem | Rješenje |
|---|---|
| Administratorska ploča se ne pokreće | Provjerite `admin.log` — obično nedostaje Python paket |
| Proxy se ne pokreće | Izvršite `python3 -c "import aiohttp"` — ako ne uspije: `pip3 install aiohttp --break-system-packages` |
| `proxy.log` je prazan | Prvo provjerite radi li proxy uopće (`./manage_admin.sh status`). Ako radi, imate staru verziju: pokretač mora koristiti `python3 -u` (bez međuspremnika — inače natpis pri pokretanju nikad ne napusti međuspremnik od 8 KB), a `main()` u `proxy.py` mora pozvati `logging.basicConfig()` (inače aiohttpov zapisivač pristupa nema rukovatelja i svaki se redak zahtjeva odbacuje, jer `web.AppRunner` — za razliku od `web.run_app` — ne konfigurira zapisivanje). |
| Proxy se pokreće, ali je slap prazan | Provjerite `sdr_host` u `admin_config.json` — uobičajeno `127.0.0.1`. Ako još sadrži stari LAN IP iz prethodne verzije, promijenite ga i izvršite `./manage_admin.sh restart` |
| Gumb Kick javlja „no connections" | Izvršite `getcap $(which ss)` — ako nema `cap_net_admin`, izvršite `sudo setcap cap_net_admin+ep $(which ss)` |
| Stanje uvijek prikazuje OFFLINE | Idite na Settings → SDR Process Name i unesite točan naziv koji prikazuje `ps -eo comm,args \| grep -v grep` |
| Stranica Users ne prikazuje podatke | Provjerite radi li krajnja točka: `curl http://127.0.0.1:<public_port>/users` |
| Vanjski preglednik javlja NetworkError | Provjerite radi li proxy: `./manage_admin.sh status` |
| Proxy se pokvario nakon promjene mreže | Odnosi se samo na slučaj kad `sdr_host` još sadrži LAN IP — postavite ga na `127.0.0.1` i izvršite `./manage_admin.sh restart` |
| Gumb za brisanje razgovora nema učinka | Provjerite pravo pisanja u datoteku zapisnika razgovora: `ls -l ~/PhantomSDR-Plus/chat.jsonl` |
| Poruka na slapu se ne pojavljuje | Potvrdite da proxy radi (`./manage_admin.sh status`) i da je sučelje iz novije verzije koja uključuje iscrtavanje preklopa |
| Poruka na slapu izgubljena nakon ponovnog pokretanja | Očekivano — stanje poruke je samo u memoriji; pošaljite je ponovno nakon ponovnog pokretanja ploče |
| „Start" u Spot Reportingu ne uspijeva / daemon se odmah gasi | Provjerite `autorun.log`. Obično nedostaje simbolička poveznica `autorun/node_modules` (`ln -sfn ../frontend/node_modules autorun/node_modules`) ili nije instaliran `taskset` (`sudo apt install -y util-linux`). |
| Spot Reporting: daemon radi, ali `decodes` ostaje 0, a `autorun.log` pokazuje `504` / `tap closed 1006` | Audio odvod ne može doseći spectrumserver. Daemon automatski otkriva port iz konfiguracije **pokrenutog** poslužitelja; redak zapisnika `[autorun] tap backend: HOST:PORT` mora odgovarati vašem `[server] port`. Ako nije točan (ili poslužitelj nije radio pri pokretanju), zadajte ga u `autorun.json`: `"server": { "host": "127.0.0.1", "port": 9002 }`, zatim Stop→Start. |
| Spot Reporting prikazuje „0 sent" | Normalno prvih nekoliko minuta — PSK Reporter šalje svakih 5 min, wsprnet svake 2 min. Provjerite je li uključeno odredište i radi li daemon. |
| Novi pojasevi/načini rada ne prikazuju se u matrici | Ponovno pokrenite administratorsku ploču: `./manage_admin.sh restart` (matrica se učitava pri pokretanju ploče). |
| `autorun.log` prikazuje `MODULE_TYPELESS_PACKAGE_JSON` / „Reparsing as ES module … performance overhead" | Kozmetičko upozorenje (dekodiranje i dalje radi). U `frontend/src/modules/package.json` nedostaje `"type": "module"`; dodajte taj redak pri vrhu, zatim Stop→Start. Ponovna izgradnja sučelja nije potrebna — daemon izravno uvozi izvornu datoteku. |
| „Start" u Spot Reportingu ne uspijeva uz `taskset: … Invalid argument` na starom/malom računalu | Ne bi se trebalo događati s pokretačem svjesnim konfiguracije — raspon jezgri izvodi se iz broja procesora i na ≤ 4 jezgre radi bez vezanja. Ako se dogodi, vaš `admin_server.py` stariji je od te promjene; ažurirajte ga (`_autorun_taskset_prefix`) i izvršite `./manage_admin.sh restart`. |
| Oznaka REPORTING ne pojavljuje se na slapu | Prijavljivanje mora biti uključeno s barem jednim mjestom; oznaka čita `/autorun-active.json`. Ponovno izgradite sučelje ako je `dist/index.html` stariji od oznake. |
