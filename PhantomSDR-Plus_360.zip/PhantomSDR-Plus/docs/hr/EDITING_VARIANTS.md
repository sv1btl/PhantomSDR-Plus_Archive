# PhantomSDR-Plus — Kako uređivati varijante frontenda

*(nakon što su četiri datoteke `App__*_smeter_.svelte` spojene u jednu `App.svelte`)*

---

## 1. Što su varijante

Dva neovisna izbora koji daju četiri kombinacije:

```
smeter = "analog"     instrument s pomičnom kazaljkom
       = "digital"    segmentirani stupčasti instrument

layout = "v1"         izbornik načina rada gore, izbornik pojasa dolje
       = "v2"         izbornik pojasa gore, izbornik načina rada dolje
                      (pomiče i red gumba za fino ugađanje na mobitelu)
```

| URL | smeter | layout |
|-----|--------|--------|
| `/` | *(ono što ste odabrali kao zadano u `recompile.sh`)* | |
| `/analog/` | analog | v1 |
| `/digital/` | digital | v1 |
| `/v2-analog/` | analog | v2 |
| `/v2-digital/` | digital | v2 |
| `/mobile/` | *zasebna stranica, gradi je `build-mobile.sh` — nije varijanta* | |

Varijanta se **ne** upisuje ni u jednu izvornu datoteku. `src/main.js` je nepromjenjiva ulazna točka koja komponenti predaje dvije vrijednosti definirane u vrijeme izgradnje:

```js
const app = new App({
  target: document.getElementById('app'),
  props: { smeter: __PHANTOM_SMETER__, layout: __PHANTOM_LAYOUT__ }
})
```

`vite.config.js` ih popunjava pri izgradnji, uzimajući prvo od navedenog što je postavljeno:

1. **`PHANTOM_SMETER` / `PHANTOM_LAYOUT`** — varijable okoline koje svaki `build-*.sh` izvozi za varijantu koju gradi.
2. **`frontend/variant.json`** — zadana vrijednost stranice, koju upisuje `recompile.sh`. Izgradnja korijena (`/`) ne prosljeđuje varijantu pa završava ovdje.
3. **`analog` / `v1`** — pričuvna vrijednost.

Budući da se ulazna datoteka nikada ne mijenja, sve izgradnje čitaju identičan izvorni kod — upravo to omogućuje da `build-all.sh` gradi varijante paralelno.

Unutar `App.svelte` propovi se pretvaraju u dvije zastavice u retcima 20-21:

```js
$: isAnalog = smeter !== "digital";
$: isV2     = layout === "v2";
```

Koristite te dvije zastavice — nikada `smeter`/`layout` izravno — kako bi se cijela datoteka čitala na isti način.

---

## 2. Koja datoteka što radi

### `frontend/src/main.js` — 12 redaka

Ulazna točka. Ništa osim instanciranja App-a i dviju `__PHANTOM_*__` vrijednosti koje prosljeđuje kao propove.
**Nepromjenjiva** je — ni `recompile.sh` ni skripte za izgradnju je više ne prepisuju, a upravo to omogućuje istovremenu izgradnju varijanti.

> **Ne stavljajte ovdje kod aplikacije.** To je ulazna datoteka, a ne mjesto za logiku.

### `frontend/src/App.svelte` — ~17130 redaka

Cijela aplikacija: slap, ugađanje, dekoderi, oznake, ploče, raspored za računalo I prilagodljivi raspored za mobitel. Gotovo svaka izmjena koju ćete ikada raditi ide ovdje.

### `frontend/src/lib/SMeterAnalog.svelte` — 824 retka

Instrument s pomičnom kazaljkom, u cijelosti: crtanje brojčanika, kazaljka, prebacivanje svijetlog/tamnog brojčanika i njegov ključ u localStorage, te zaglađivanje kazaljke.

- Ulazni prop: `dbm` — KALIBRIRANA snaga u dBm.
- Prima i: `mobile` — manji atributi canvasa za raspored na mobitelu.
- Podešavanje: `SMOOTH_TIME_MS` u retku 55. Manje = brža kazaljka, više = glađa. Trenutno 16 (jedan okvir pri 60 fps, praktički donja granica).

### `frontend/src/lib/SMeterDigital.svelte` — 184 retka

Segmentirani stupčasti instrument, u cijelosti.

- Ulazni propovi: `rawDb` — SIROVA vrijednost `audio.getPowerDb()`
- `smeterOffset` — `audio.smeter_offset`
- `mobile` — manji atributi canvasa

> **NAPOMENA:** ovaj instrument namjerno se napaja SIROVOM snagom plus pomakom, a NE kalibriranom dBm vrijednošću koju koristi analogni brojčanik. Oduvijek je imao vlastito preslikavanje. Davanje kalibrirane vrijednosti pomaknulo bi svako očitanje na svakoj digitalnoj postaji. Nemojte „ujednačavati“ ova dva ulaza.

### `frontend/src/lib/BandSelector.svelte` — 69 redaka

Mreža gumba pojaseva. Prikazuje se dvaput u `App.svelte` (jednom po rasporedu).

### `frontend/src/lib/ModesSelector.svelte` — 75 redaka

Mreža gumba načina rada. Prikazuje se dvaput u `App.svelte`.

### `frontend/src/lib/StatusIndicators.svelte` — 122 retka

Statusne žaruljice (mute, squelch, NR, NB, NS, AN, CTCSS).
Prima prop `wide`: digitalni raspored koristi šire žaruljice od analognog. Obje Tailwind klase (`w-8` i `w-10`) napisane su u cijelosti unutar komponente — Tailwindov skener vidi samo doslovna imena klasa, pa ih nikada ne gradite spajanjem znakovnih nizova.

Sve ostale datoteke u `frontend/src/lib/` (Spectrogram, PassbandTuner, FrequencyInput, VersionSelector, ...) starije su od ovog posla i nisu mijenjane.

---

## 3. Izmjena koja utječe samo na neke varijante

Umotajte je u zastavicu. U oznakama:

```svelte
{#if isAnalog}
  ...ovo vide samo analogne postaje...
{:else}
  ...ovo vide samo digitalne postaje...
{/if}

{#if isV2} ... {/if}          {#if !isV2} ... {/if}
```

U atributu class:

```svelte
class="p-4 {isAnalog ? 'text-xs' : 'text-sm'} rounded-md"
```

Napišite obje mogućnosti kao cjelovite doslovne nizove, kao gore. Tailwind pretražuje izvorni kod za potpunim imenima klasa; `text-{size}` ili spojeno ime uklanja se iz CSS-a i stil tiho nestaje.

U bloku `<script>`: pokušajte uopće ne granati. Skripta namjerno računa ulaze OBAJU instrumenata u svakom ciklusu —

```js
smeterDbm    = powerDb;                    // analogni brojčanik
smeterRawDb  = audio.getPowerDb();         // digitalni brojčanik
smeterOffset = audio.smeter_offset;        // digitalni brojčanik
```

— pa samo oznake moraju birati. Zato u datoteci od 17000 redaka postoji samo 15 prekidača varijanti. Neka tako i ostane; grananje na razini skripte je ono što je razdvojilo četiri stare datoteke.

---

## 4. Gdje su prekidači varijanti

Petnaest mjesta u `App.svelte`. Brojevi redaka pomiču se pri uređivanju — pouzdan način da ih sve pronađete je:

```bash
cd frontend/src && grep -n 'isAnalog\|isV2' App.svelte
```

U trenutku pisanja:

| Redak | Zastavica | Što prebacuje |
|-------|-----------|---------------|
| 20 | | deklaracija `isAnalog` |
| 21 | | deklaracija `isV2` |
| 8062 | `isV2` | računalo: izbornik pojasa prvi (poredak v2) |
| 8090 | `isV2` | računalo: veličina naslova ploče |
| 8686 | `isV2` | računalo: izbornik načina rada prvi (poredak v1) |
| 8717 | `isAnalog` | najmanja širina ploče instrumenta (kazaljka je uža) |
| 8730 | `isAnalog` | samo analogno: redak datuma/vremena iznad instrumenta |
| 8819 | `isAnalog` | samo analogno: statusne žaruljice + razdjelnik |
| 8834 | `isAnalog` | samo digitalno: redak vremena, široke žaruljice i sam izbor `<SMeterDigital>` / `<SMeterAnalog>` |
| 8861 | `isAnalog` | okomiti razmaci bloka frekvencije |
| 8864 | `isAnalog` | gornja margina bloka finog ugađanja |
| 12288 | `isV2` | mobitel: red finog ugađanja iznad (poredak v2) |
| 12347 | `isAnalog` | mobitel: koji se instrument prikazuje |
| 12433 | `isV2` | mobitel: red finog ugađanja ispod (poredak v1) |
| 13204 | `isAnalog` | veličina teksta gumba noise gate |

Sve ostalo u datoteci zajedničko je svim četirima varijantama.

---

## 5. Ostale postavke koje vrijedi znati

| Mjesto | Konstanta | Svrha |
|--------|-----------|-------|
| `App.svelte` redak 5034 | `const visualGain = 1.1;` | Kalibracija analognog instrumenta. Svakih 0,10 otprilike je 5 dBm na očitanju. |
| `SMeterAnalog.svelte` redak 55 | `const SMOOTH_TIME_MS = 16;` | Vremenska konstanta zaglađivanja kazaljke, u milisekundama. |
| `SMeterDigital.svelte` redak 149 | `const DIGITAL_BAR_TRIM = 0;` | Pomiče traku za cijele segmente. |
| `SMeterDigital.svelte` redak 31 | `const numberOfDots = 35;` | Broj segmenata trake. |

---

## 6. Nakon uređivanja — ponovna izgradnja

Najjednostavnije, iz korijena repozitorija:

```bash
./recompile.sh
```

Stavka izbornika **[2]** ponovno gradi frontend i pita koju varijantu treba posluživati korijen stranice (`/`). Taj se odabir bilježi u `frontend/variant.json` (i odražava u `VersionSelector.svelte`) — nijedna izvorna datoteka ne kopira se niti prepisuje. Stavka **[1]** je samo backend, **[3]** je oboje.

Ili izravno, iz `frontend/`:

```
./build-all.sh          gradi /, /analog/, /digital/, /v2-analog/,
                        /v2-digital/ I /mobile/  <-- obično koristite ovo
./build-default.sh      samo korijen stranice
./build-analog.sh       samo /analog/
./build-digital.sh      samo /digital/
./build-v2-analog.sh    samo /v2-analog/
./build-v2-digital.sh   samo /v2-digital/
./build-mobile.sh       samo /mobile/
```

`build-all.sh` NE poziva pet skripti po varijanti — ima vlastitu kopiju iste logike (`build_version SMETER LAYOUT NAME OUTDIR BASE LOG`, retci 69-97). Ako mijenjate način na koji se varijanta gradi, promijenite to na OBA mjesta ili će se dva puta razići.

Od skripti za pojedinačnu varijantu razlikuje se i u tri stvari koje vrijedi znati:

- Gradi **paralelno**, po tri odjednom. Povećajte to s `PHANTOM_BUILD_JOBS=5 ./build-all.sh` ako stroj ima jezgre i hlađenje.
- Postavlja `PHANTOM_KEEP_OUTDIR=1` kako Vite ne bi praznio izlazne direktorije, nego sam čisti `dist/` — briše sadržaj, ali zadržava `users.json`, koji `spectrumserver` u pogonu prepisuje pri svakom spajanju i odspajanju slušatelja. `--outDir` korijenske izgradnje *sadrži* izlazne direktorije varijanti, pa bi prepuštanje pražnjenja Viteu izazvalo utrku s istovremenim izgradnjama.
- `/mobile` gradi zadnje, kada je izlaz za računalo gotov.

**Bitovi izvršavanja:** `recompile.sh` pokreće `chmod +x` na skripti prije nego što je izvrši, a `build-all.sh` namjerno poziva `bash build-mobile.sh` umjesto `./build-mobile.sh`, pa nedostajući bit više ne ruši izgradnju. Prijenos skripte kroz GitHubovo web sučelje ipak je vraća na 644, pa ako neku pokrećete izravno:

```bash
chmod +x frontend/build-*.sh
```

---

## 7. Kako provjeriti izmjenu prije nego joj povjerujete

Zeleni `vite build` **NIJE** dovoljan. Izgradnja ne može vidjeti identifikator koji je nestao pri premještanju koda između datoteka — to je `ReferenceError` tijekom izvođenja i stranica se jednostavno ne učita. Dogodilo se dvaput.

### 1) Provjera nedefiniranih identifikatora (hvata upravo taj kvar)

```bash
cd frontend
npx eslint --no-eslintrc \
    --parser svelte-eslint-parser \
    --rule '{"no-undef":"error"}' \
    --env browser,es2022 \
    src/App.svelte src/lib/SMeter*.svelte
```

Očekuje se jedan poznati, bezopasni pogodak:

```
'dBmCalOffset' is not defined
```

`typeof x === 'number'` nad nedeklariranim imenom nikada ne baca iznimku, pa taj izraz već daje 0. Sve ostalo je pravi problem.

### 2) Izgradite, pa UČITAJTE SVIH PET STRANICA U PREGLEDNIKU

Ne samo onu koju ste mijenjali — prekidač varijante može slomiti ostale tri dok vaša radi.

```
/   /analog/   /digital/   /v2-analog/   /v2-digital/   /mobile/
```

Otvorite konzolu preglednika na svakoj. Prazna ili napola iscrtana stranica s `ReferenceError` u konzoli potpis je gornje greške.

### 3) Nikada ne ostavljajte `frontend/dist/` u djelomičnom stanju

Goli `npx vite build` prazni izlazni direktorij i sa sobom odnosi mape varijanti (`/analog`, `/digital`, `/v2-analog`, `/v2-digital`) — živa stranica na sve odgovara s 404 do sljedeće uspješne izgradnje. Uvijek gradite kroz skripte: `build-all.sh` postavlja `PHANTOM_KEEP_OUTDIR=1` i sam obavlja čišćenje, čuvajući `dist/users.json`. Ako ste u dvojbi, jednostavno ponovno pokrenite `./build-all.sh`.
