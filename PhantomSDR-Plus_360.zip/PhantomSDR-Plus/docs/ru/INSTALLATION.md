# Руководство по установке PhantomSDR-Plus для системных операторов

Это подробное руководство проведёт вас через установку и настройку PhantomSDR-Plus на вашем сервере.

---

## Содержание

1. [Системные требования](#системные-требования)
2. [Подготовка к установке](#подготовка-к-установке)
3. [Установка зависимостей](#установка-зависимостей)
4. [Установка Node.js и npm](#установка-nodejs-и-npm)
5. [Установка OpenCL (необязательно, но рекомендуется)](#установка-opencl-необязательно-но-рекомендуется)
6. [Установка PhantomSDR-Plus](#установка-phantomsdr-plus)
7. [Установка аудиокодека Opus](#установка-аудиокодека-opus)
8. [Autorun Spot Reporter (FT8/FT4/WSPR)](#autorun-spot-reporter-ft8ft4wspr)
9. [Настройка](#настройка)
10. [Настройка для конкретных устройств SDR](#настройка-для-конкретных-устройств-sdr)
11. [Проверка и тестирование](#проверка-и-тестирование)
12. [Настройка автозапуска](#настройка-автозапуска)
13. [Устранение неполадок](#устранение-неполадок)

---

## Системные требования

### Поддерживаемые операционные системы

**Основная (рекомендуется):**
- Ubuntu 24.04 LTS (x86_64) (рекомендуется)

**Альтернатива:**
- Fedora (последний стабильный выпуск)

### Требования к оборудованию

**Минимальная конфигурация:**
- Процессор: двухъядерный (от 2 ГГц)
- ОЗУ: 4 ГБ
- Накопитель: 10 ГБ свободного места
- Сеть: соединение 100 Мбит/с

**Рекомендуемая конфигурация:**
- Процессор: четырёхъядерный или лучше (Ryzen 5 2600, Intel i5-6500T или лучше)
- ОЗУ: 8 ГБ и более
- Накопитель: SSD от 20 ГБ
- GPU: AMD/NVIDIA с поддержкой OpenCL (крайне желательно)
- Сеть: соединение 1 Гбит/с

**Высокопроизводительная конфигурация:**
- Процессор: 6 и более ядер (Ryzen 7, Intel i7 или лучше)
- ОЗУ: 16 ГБ и более
- Накопитель: NVMe SSD
- GPU: отдельная видеокарта с поддержкой OpenCL/CUDA
- Сеть: 1 Гбит/с и выше

---

## Подготовка к установке

### 1. Обновите систему

```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade -y
sudo reboot

# Fedora
sudo dnf update -y
sudo reboot
```

### 2. Проверьте версию Ubuntu

```bash
lsb_release -a
```

**Ожидаемый вывод должен показать:** Ubuntu 24.04 LTS

### 3. Проверьте свободное место на диске

```bash
df -h
```

Убедитесь, что в вашем домашнем каталоге есть не менее 10 ГБ свободного места.

### 4. Проверьте сведения о процессоре

```bash
lscpu
```

Запомните число ядер/потоков для оптимизации конфигурации.

---

## Установка зависимостей

### Ubuntu 24.04 LTS

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  git \
  psmisc \
  wget \
  curl
```

### Fedora

```bash
sudo dnf install -y \
  g++ \
  meson \
  cmake \
  fftw3-devel \
  websocketpp-devel \
  flac-devel \
  zlib-devel \
  boost-devel \
  libzstd-devel \
  opus-devel \
  liquid-dsp-devel \
  git \
  psmisc \
  wget \
  curl
```

### Проверьте установку

```bash
# Check if key dependencies are installed
pkg-config --modversion fftw3
cmake --version
meson --version
```

---

## Установка Node.js и npm

PhantomSDR-Plus требует Node.js для сборки веб-интерфейса. Для установки воспользуемся NVM (Node Version Manager).

### 1. Установите NVM

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
```

### 2. Загрузите NVM

**ВАЖНО:** закройте и снова откройте терминал либо выполните:

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

### 3. Проверьте установку NVM

```bash
nvm --version
```

Ожидаемый вывод: `0.40.4` или похожий

### 4. Установите Node.js

```bash
# Install Node.js 22 - the version every install script requires
nvm install 22

# Make it the default, so systemd units and cron see it too
nvm alias default 22

# Verify installation
node --version
npm --version
```

### 5. Необязательно: установите другие версии Node

```bash
# Install latest version
nvm install node

# Install specific version (if needed)
nvm install 22.22.3

# List installed versions
nvm list

# Use specific version
nvm use 22
```

---

## Установка OpenCL (необязательно, но рекомендуется)

OpenCL существенно повышает производительность, перенося вычисления FFT на GPU. Этот раздел посвящён встроенной графике Intel. Для GPU AMD/NVIDIA обратитесь к документации производителя.

### Процессор Intel со встроенной графикой

#### 1. Установите базовые компоненты OpenCL

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  libclfft-dev \
  ocl-icd-opencl-dev \
  clinfo
```

#### 2. Скачайте Intel Compute Runtime

```bash
mkdir -p ~/neo
cd ~/neo

wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
```

#### 3. Установите среду выполнения Intel OpenCL

```bash
sudo dpkg -i *.deb
```

Если возникают ошибки зависимостей:

```bash
sudo apt --fix-broken install
```

#### 4. Установите загрузчик OpenCL ICD

```bash
sudo apt update
sudo apt install intel-opencl-icd
```

Если возникают ошибки:

```bash
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
```

#### 5. Проверьте установку OpenCL

```bash
sudo clinfo
```

Вы должны увидеть сведения о вашей платформе и устройствах OpenCL. Обратите внимание на:
- Число платформ: 1 (или больше)
- Название платформы: Intel(R) OpenCL (или похожее)
- Тип устройства: GPU или CPU

#### 6. Перезагрузитесь

```bash
sudo reboot
```

### OpenCL на GPU AMD

Для видеокарт AMD установите ROCm:

```bash
# Add ROCm repository
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list

# Install ROCm
sudo apt update
sudo apt install rocm-opencl rocm-clinfo

# Add user to video group
sudo usermod -a -G video $USER

# Reboot
sudo reboot

# Verify
clinfo
```

### OpenCL на GPU NVIDIA

Для видеокарт NVIDIA установите CUDA:

```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-525

# Install CUDA toolkit
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt update
sudo apt install cuda

# Reboot
sudo reboot

# Verify
nvidia-smi
clinfo
```

---

## Установка PhantomSDR-Plus

### Клонирование репозитория, права на выполнение скриптов, автоматическая установка

```bash
cd ~
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```
**⚠️ ВАЖНО:** после завершения `install.sh` **перезапустите терминал**, прежде чем продолжать.

### 4. Вариант Б: установка вручную

Если вы предпочитаете ручную установку или автоматическая не удалась:

#### Сборка backend

```bash
# Clean any previous builds, Configure build with optimization, Compile
rm -rf build
meson setup build --buildtype=release --optimization=3
meson compile -C build

# Verify binary was created
ls -lh build/spectrumserver
```

#### Сборка frontend

```bash
cd frontend

# Install dependencies, Fix any vulnerabilities, Build the frontend
npm install
npm audit fix
npm run build

# Return to project root
cd ..
```

### Проверьте установку

```bash
# Check if binary exists
ls -lh build/spectrumserver

# Check if frontend was built
ls -lh frontend/dist/

# List important files
ls -lh *.sh *.toml
```

---

## Установка аудиокодека Opus

Opus обеспечивает лучшее качество звука и меньшую задержку по сравнению с FLAC.

### 1. Установите системную библиотеку libopus

```bash
sudo apt-get update
sudo apt-get install -y libopus0 libopus-dev
```

### 2. Установите декодер Opus для веб-интерфейса

```bash
cd PhantomSDR-Plus/frontend

# Install npm dependencies if not already done, Install Opus WASM decoder, Fix any vulnerabilities, Rebuild frontend
npm install
npm install @wasm-audio-decoders/opus-ml
npm audit fix
npm run build

# Return to project root
cd ..
```

### 3. Проверьте установку Opus

```bash
# Check if Opus system library is installed
pkg-config --modversion opus

# Check if Opus npm package is installed
cd frontend
npm list @wasm-audio-decoders/opus-ml
cd ..
```

---

## Autorun Spot Reporter (FT8/FT4/WSPR)

В состав PhantomSDR-Plus входит необязательный **autorun spot reporter** (в каталоге
`autorun/`). Он декодирует FT8/FT4/WSPR на стороне сервера прямо с приёмника и выгружает
споты в сети отчётности:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

Управление ведётся целиком из вкладки **панель администратора → «Spot Reporting»**, и
**отчётность по умолчанию ВЫКЛЮЧЕНА** — ничего не передаётся и не выгружается, пока вы её
там не включите. Декодер работает как отдельная служба Node.js и получает звук приёмника
локально, поэтому дополнительного РЧ-оборудования не требуется.

### Требования

| Требование | Примечания |
|------------|------------|
| **Node.js 22+** | Та же среда выполнения, что уже нужна для сборки веб-интерфейса — устанавливается на [шаге Node.js](#установка-nodejs-и-npm). |
| **Пакеты npm `ws` + `cbor-x`** | Разрешаются через `autorun/node_modules` — символическую ссылку на `node_modules` веб-интерфейса (оба пакета объявлены в `frontend/package.json`). |
| **`util-linux`** (`taskset`) | Кнопка «Start» в админке привязывает службу к E-ядрам через `taskset`. Есть практически в любом дистрибутиве; установщики добавляют его явно. |
| **Позывной + локатор** | Читаются из `frontend/site_information.json` (`siteSysop` / `siteGridSquare`), если не переопределены во вкладке администратора. Споты выгружаются под этим позывным. |

> ⚠️ **Сообщайте только то, что действительно принимаете.** Споты выгружаются в публичные
> сети под вашим позывным — включайте только те диапазоны и виды связи, которые ваш приёмник
> действительно слышит, и указывайте правильный локатор.

### Автоматическая установка

`install.sh` (и варианты для дистрибутивов: `install-Deb12.sh`, `install_arch.sh`,
`install_fedora.sh`, `install_opensuse.sh`) делают всё за вас: устанавливают Node.js 22 и
`util-linux`, выполняют `npm install` для веб-интерфейса и затем автоматически создают
символическую ссылку `autorun/node_modules`. Дополнительных шагов не требуется — функция
готова, как только `install.sh` завершится.

### Установка вручную

Если вы устанавливали вручную (вариант Б), создайте символическую ссылку сами после
`npm install` веб-интерфейса, чтобы служба смогла разрешить свои зависимости:

```bash
cd ~/PhantomSDR-Plus

# 1. Frontend deps must be installed first (ws + cbor-x live there)
cd frontend && npm install && cd ..

# 2. Link the autorun daemon to the frontend's node_modules
ln -sfn ../frontend/node_modules autorun/node_modules

# 3. Ensure taskset is available (Debian/Ubuntu shown; use your package manager)
sudo apt install -y util-linux
```

> **Примечание:** `autorun/node_modules` игнорируется git, поэтому свежий `git clone`
> никогда его не содержит — ссылку нужно (пере)создавать после каждой чистой выгрузки.
> Установщики делают это за вас; команда выше нужна только при ручной настройке.

### Проверка

```bash
# The symlink should point at ../frontend/node_modules
ls -l autorun/node_modules

# ws + cbor-x must resolve
ls -d frontend/node_modules/ws frontend/node_modules/cbor-x

# taskset must be on PATH
command -v taskset
```

Затем откройте панель администратора, перейдите на вкладку **Spot Reporting**, укажите свои
данные, отметьте диапазоны и виды связи для декодирования, включите приёмники отчётов и
нажмите **Start**. На главном водопаде появится значок «📶 REPORTING», пока отчётность
активна. (PSK Reporter выгружает пакетами каждые 5 минут, а wsprnet — каждые 2 минуты,
поэтому только что запущенная служба первые минуты показывает «0 sent» — это нормально.)

Далее показываются два разных счётчика, которые легко перепутать. Плитки
**SPOTS UPLOADED PER DECODER** считают только текущий запуск, поэтому Stop/Start
обнуляет их; число рядом с каждым флажком диапазона/вида связи — это **итог за всё
время** для этой позиции, он хранится в `autorun-totals.json` и переживает
перезапуски. Оба счётчика описаны в [руководстве по панели администратора](ADMIN_PANEL_SETUP.md),
там же — страница **Графики**, где строятся частота процессора, нагрузка,
температура и число слушателей за период от 15 минут до 24 часов.

> **Порт сервера определяется автоматически.** Служба подключается напрямую к
> `[server] port` самого spectrumserver (петлевой интерфейс + токен, минуя прокси). Она
> читает этот порт из файла конфигурации, с которым был запущен работающий spectrumserver,
> поэтому работает на любом порту без настройки — строка `[autorun] tap backend: …` в
> `autorun.log` показывает, что было определено. Если ваш сервер не работал в момент запуска
> службы или у вас нестандартная конфигурация, укажите порт явно в `autorun.json`:
> ```json
> "server": { "host": "127.0.0.1", "port": 9002 }
> ```
> Неверный порт проявляется как `504` / `tap closed 1006` в `autorun.log`, а `decodes`
> остаётся равным 0.

---

## Настройка

### 1. Выберите файл конфигурации

Выберите файл конфигурации, подходящий для вашего SDR:

- `config-rtl.toml` — свистки RTL-SDR
- `config-rsp1a.toml` — SDRplay RSP1A
- `config-airspyhf.toml` — Airspy HF+ Discovery
- `config-rx888mk2.toml` — RX888 MK2
- `config.example.hackrf.toml` — HackRF One

В этом примере используем RTL-SDR.

### 2. Отредактируйте файл конфигурации

```bash
nano config-rtl.toml
```

#### Ключевые параметры

```toml
[server]
port = 9002                      # Web interface port (or everything else)
html_root = "frontend/dist/"     # Frontend location
otherusers = 1                   # Show other users (1=yes, 0=no)
threads = 2                      # Number of server threads

[websdr]
register_online = true           # Register on sdr-list.xyz (true/false)
name = "Your WebSDR Name"        # Display name
antenna = "Your Antenna Type"    # e.g., "Vertical", "Loop", "Dipole"
grid_locator = "AB12cd"          # Your Maidenhead grid square
hostname = "your.domain.com"     # Your domain or IP address

[input]
sps = 2048000                    # Sample rate (adjust for your coverage)
fft_size = 131072                # FFT size (higher = better resolution)
brightness_offset = -10          # Waterfall brightness adjustment
frequency = 145000000            # Base frequency in Hz (145 MHz for 2m)
signal = "iq"                    # "iq" for complex, "real" for real sampling
fft_threads = 2                  # FFT processing threads
accelerator = "opencl"           # "none", "cuda", or "opencl"
audio_sps = 12000                # Audio sample rate (keep at 12000)
audio_compression = "opus"       # "flac" or "opus"
smeter_offset = -2               # S-meter calibration
waterfall_size = 1024            # Waterfall FFT size
waterfall_compression = "zstd"   # Waterfall compression

[input.driver]
name = "stdin"                   # Input driver
format = "u8"                    # Sample format for RTL-SDR

[input.defaults]
frequency = 145500000            # Default tuning frequency
modulation = "FM"                # Default modulation mode
```

#### Ориентиры по частоте дискретизации

| Охват | Частота дискретизации | Размер FFT |
|-------|------------------------|------------|
| 2 МГц | 2048000 | 131072 |
| 3.2 МГц | 3200000 | 131072 |
| 10 МГц | 10000000 | 1048576 |
| 30 МГц | 30000000 | 2097152 |
| 60 МГц | 60000000 | 8388608 |

### 3. Настройте сведения о площадке

```bash
nano frontend/site-information.json
```

Отредактируйте следующие поля:

```json
{
  "siteSysop": "YourCallsign",
  "siteSysopEmailAddress": "your@email.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "Your City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Computer specifications",
  "siteSoftware": "PhantomSDR-Plus v3.6.0",
  "siteReceiver": "Your SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional information",
  "siteIP": "http://your.domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

**Районы IARU:**
- **1**: Европа, Африка, Ближний Восток, Северная Азия
- **2**: Америка (Северная, Центральная, Южная), Карибский бассейн
- **3**: Азиатско-Тихоокеанский регион, Океания

### 4. Настройте частотные маркеры (необязательно)

```bash
nano markers.json
```

Добавьте свои любимые частоты, ретрансляторы и вещательные станции.

### 5. Отредактируйте скрипт запуска

```bash
nano start-rtl.sh
```

Скрипт запуска — самодостаточный лаунчер со сторожевым процессом. Правьте только блок
**RECEIVER CONFIGURATION** в начале файла, чтобы аргументы приёмника соответствовали вашей
конфигурации:

```bash
# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═══
RX_LABEL="RTL-SDR"
RX_COMM="rtl_sdr"                       # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rtl.toml"    # your .toml
FIFO="$PHANTOMDIR/rtl.fifo"
RX_ARGS="${RX_ARGS:--f 145000000 -s 2048000 -}"   # receiver args (edit these)
```

Параметры внутри `RX_ARGS`:
- `-f 145000000`: центральная частота (145 МГц)
- `-s 2048000`: частота дискретизации (2,048 MSPS)

`CONFIG` указывает на ваш `.toml`. Больше **ничего** в скрипте править не нужно — логика
запуска/перезапуска/сторожа/журналирования универсальна. Аргументы приёмника можно также
переопределить при запуске, не редактируя файл:
`RX_ARGS="-f 145000000 -s 2048000 -" ./start-rtl.sh`
(`RX888_ARGS` для `start-rx888mk2.sh`).

---

## Настройка для конкретных устройств SDR

### RTL-SDR

#### Установите инструменты RTL-SDR

```bash
sudo apt install -y rtl-sdr
```

#### Проверьте RTL-SDR

```bash
rtl_test
```

Нажмите Ctrl+C для остановки. Вы должны увидеть сведения о частоте дискретизации.

#### Отредактируйте конфигурацию

```bash
nano config-rtl.toml
```

Типичные настройки для RTL-SDR:
```toml
sps = 2048000
frequency = 145000000
signal = "iq"
format = "u8"
```

### SDRplay RSP1A

#### Установите SoapySDR и поддержку SDRplay

```bash
# Install SoapySDR
sudo apt install -y soapysdr-tools

# Download SDRplay API
cd ~/Downloads
wget https://www.sdrplay.com/software/SDRplay_RSP_API-Linux-3.07.1.run
chmod +x SDRplay_RSP_API-Linux-3.07.1.run
sudo ./SDRplay_RSP_API-Linux-3.07.1.run

# Install SoapySDRPlay
git clone https://github.com/pothosware/SoapySDRPlay.git
cd SoapySDRPlay
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig
```

#### Проверьте SDRplay

```bash
SoapySDRUtil --find="driver=sdrplay"
```

#### Дополнительные инструкции

См. включённый файл: `instractions-for-rsp1a`

### Airspy HF+

#### Установите инструменты Airspy

```bash
sudo apt install -y airspy
```

#### Проверьте Airspy

```bash
airspy_info
```

#### Дополнительные инструкции

См. включённый файл: `instractions-for-airspy`

### RX888 MK2

#### Установите инструменты RX888

```bash
# Install rx_tools
git clone https://github.com/rxseger/rx_tools.git
cd rx_tools
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig

# Install RX888 firmware and support
# Follow manufacturer instructions
```

#### Запуск rx888_stream без sudo (правила udev)

По умолчанию USB-устройство Cypress FX3 у RX-888 доступно только root, поэтому
`rx888_stream` потребовал бы `sudo`. Выполните один раз входящий в комплект вспомогательный
скрипт, чтобы установить правила udev и добавить себя в группу `plugdev`:

```bash
./setup-rx888-udev.sh          # re-runs itself with sudo automatically
```

Он записывает `/etc/udev/rules.d/99-rx888.rules` для всех трёх идентификаторов продуктов
Cypress FX3 (`04b4:00f1`/`00f3` — загрузчик и `04b4:8613` — с загруженной прошивкой),
перезагружает udev и создаёт постоянную ссылку `/dev/rx888`. **Выйдите из системы и войдите
снова** (чтобы применилось изменение группы) и один раз **переподключите устройство**; после
этого `rx888_stream` — и лаунчер `start-rx888mk2.sh` — работают без `sudo`. Скрипт
идемпотентен, его безопасно запускать повторно. Для другой учётной записи:
`RX888_USER=<имя> ./setup-rx888-udev.sh`.

#### Отредактируйте конфигурацию

```bash
nano config-rx888mk2.toml
```

Типичные настройки для RX888:
```toml
sps = 60000000
frequency = 0
signal = "real"
format = "s16"
fft_size = 8388608
```

### HackRF One

#### Установите инструменты HackRF

```bash
sudo apt install -y hackrf
```

#### Проверьте HackRF

```bash
hackrf_info
```

---

## Проверка и тестирование

### 1. Пробный запуск

```bash
# For RTL-SDR
./start-rtl.sh
```

Это запускает сервер **в фоне** (скрипт отсоединяется и сразу возвращает управление) и
начинает вести журнал в `logwebsdr.txt`.

### 2. Проверьте наличие ошибок

Скрипт записывает ход работы в `logwebsdr.txt` — следите за ним в реальном времени:

```bash
tail -f logwebsdr.txt
```

Обратите внимание на:
- ✅ `Starting the initialization script of the PhantomSDR Server`
- ✅ `<receiver> running (PID …)`
- ✅ `Server started normally`
- ❌ `Server … FAILED …` или `ERROR: receiver binary '…' not found` (исправьте аргументы
  приёмника либо `.toml`, или установите утилиту приёмника, затем снова запустите скрипт)

### 3. Откройте веб-интерфейс

Перейдите в браузере по адресу:
```
http://localhost:9002
```

(Замените номер порта на настроенный вами)

### 4. Проверьте работоспособность

- Водопад должен отображаться
- Звук должен воспроизводиться при щелчке по сигналам
- S-метр должен реагировать на сигналы
- Счётчик пользователей должен показывать «1»

### 5. Проверьте с другого устройства

С другого компьютера в вашей сети:
```
http://YOUR_SERVER_IP:9002
```

### 6. Проверьте потребление ресурсов

```bash
# Monitor CPU usage
htop

# Monitor GPU usage (if OpenCL/CUDA enabled)
nvidia-smi  # For NVIDIA
radeontop   # For AMD

# Monitor network usage
iftop
```

### 7. Остановите сервер

Сервер работает в фоне под сторожевым процессом, поэтому **Ctrl+C его не остановит** (а
сторож просто перезапустит его). Используйте общий скрипт остановки, работающий для любого
приёмника: он сначала останавливает сторожа, затем приёмник и `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## Настройка автозапуска

### С помощью systemd (рекомендуется)

#### 1. Создайте файл службы

```bash
sudo nano /etc/systemd/system/phantomsdr.service
```

Добавьте следующее содержимое (поправьте пути и пользователя):

```ini
[Unit]
Description=PhantomSDR-Plus WebSDR Server
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/PhantomSDR-Plus
# Run the watchdog in the FOREGROUND (note the --watchdog flag) so systemd can
# track it. Do NOT use the plain "./start-rtl.sh" here — that form detaches into
# the background and exits, which systemd would treat as the service stopping.
ExecStart=/home/youruser/PhantomSDR-Plus/start-rtl.sh --watchdog
ExecStop=/home/youruser/PhantomSDR-Plus/stop-websdr.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

> Процесс `--watchdog` уже сам перезапускает приёмник и `spectrumserver`; `Restart=always`
> — лишь подстраховка на редкий случай, когда завершится сам сторож. Поскольку здесь
> сервером управляет systemd, можно использовать `systemctl start/stop/restart` и
> `journalctl -u phantomsdr -f` вместо ручного запуска скриптов.

#### 2. Включите и запустите службу

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable phantomsdr.service

# Start service now
sudo systemctl start phantomsdr.service

# Check status
sudo systemctl status phantomsdr.service
```

#### 3. Управление службой

```bash
# Start
sudo systemctl start phantomsdr

# Stop
sudo systemctl stop phantomsdr

# Restart
sudo systemctl restart phantomsdr

# View logs
sudo journalctl -u phantomsdr -f
```

### С помощью Screen (альтернатива)

> Обычно не требуется: `./start-rtl.sh` уже уходит в фон (через `setsid`) и продолжает
> работать после выхода из системы, со своим сторожевым процессом. Screen полезен, только
> если вам специально нужен интерактивный сеанс для запуска формы переднего плана
> `./start-rtl.sh --watchdog`.

#### 1. Установите Screen

```bash
sudo apt install -y screen
```

#### 2. Запустите в сеансе Screen

```bash
screen -S phantomsdr
./start-rtl.sh
```

Нажмите Ctrl+A, затем D, чтобы отсоединиться.

#### 3. Вернитесь к сеансу

```bash
screen -r phantomsdr
```

---

## Устранение неполадок

### Ошибки сборки

#### Проблемы с зависимостями

```bash
# Ubuntu: Install missing dependencies
sudo apt install --fix-broken

# Fedora: Install missing dependencies
sudo dnf install <package-name>
```

#### Не удаётся выполнить конфигурацию Meson

```bash
# Clean and reconfigure
rm -rf build
meson setup build --buildtype=release
```

### Ошибки времени выполнения

#### Порт уже занят

```bash
# Find process using port
sudo lsof -i :9002

# Kill process
sudo kill -9 <PID>
```

#### Отказано в доступе к SDR

```bash
# Add user to plugdev group
sudo usermod -a -G plugdev $USER

# Reload groups (or log out and back in)
newgrp plugdev
```

Для **RX-888 MkII** одного этого мало — устройству Cypress FX3 нужны ещё и правила udev.
Запустите входящий в комплект скрипт (он устанавливает правила *и* добавляет вас в
`plugdev`), затем выйдите и войдите снова и переподключите устройство:

```bash
./setup-rx888-udev.sh
```

#### Проблемы со звуком

```bash
# Try different codec
# Edit config file and change:
audio_compression = "flac"  # or "opus"

# Rebuild
cd frontend && npm run build && cd ..
```

### Проблемы с OpenCL

#### clinfo не показывает устройств

```bash
# Verify drivers are loaded
sudo clinfo

# Check OpenCL ICD files
ls /etc/OpenCL/vendors/

# Reinstall drivers (Intel example)
sudo apt remove --purge intel-opencl-icd
sudo apt install intel-opencl-icd
```

#### Производительность не выросла

```bash
# Verify OpenCL is enabled in config
accelerator = "opencl"

# Try different device
# Add to config file:
[input.opencl]
device_id = 0  # Try 0, 1, 2, etc.
```

### Проблемы с сетью

#### Нет доступа с других устройств

```bash
# Check firewall
sudo ufw status
sudo ufw allow 9002/tcp

# Or disable firewall temporarily for testing
sudo ufw disable
```

#### Высокая задержка

```bash
# Reduce waterfall size in config
waterfall_size = 512

# Increase buffer size
buffer_size = 16384

# Use Opus instead of FLAC
audio_compression = "opus"
```

### Проблемы с устройством SDR

#### RTL-SDR не найден

```bash
# Check if device is recognized
lsusb | grep Realtek

# Test with rtl_test
rtl_test

# Try blacklisting DVB-T drivers
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo rmmod dvb_usb_rtl28xxu
```

#### SDRplay не найден

```bash
# Check API installation
systemctl status sdrplay

# Restart API
sudo systemctl restart sdrplay

# Test with SoapySDR
SoapySDRUtil --find
```

---

## Оптимизация производительности

### Оптимизация процессора

```toml
# Adjust thread counts based on CPU cores
[server]
threads = 4  # Set to number of cores

[input]
fft_threads = 4  # Set to number of cores
```

### Оптимизация памяти

```toml
# Reduce memory usage
[input]
waterfall_size = 512  # Lower value = less memory
fft_size = 65536      # Lower value = less memory
```

### Оптимизация сети

```toml
# Optimize for limited bandwidth
[input]
audio_compression = "opus"  # More efficient than FLAC
waterfall_compression = "zstd"  # Efficient compression
```

---

## Обновление PhantomSDR-Plus

### Обновление вручную

```bash
cd PhantomSDR-Plus

# Backup your configuration
cp config-rtl.toml config-rtl.toml.backup
cp frontend/site-information.json frontend/site-information.json.backup

# Pull latest changes
git pull origin main
git submodule update --init --recursive

# Rebuild
meson compile -C build
cd frontend && npm install && npm run build && cd ..
```

### Скрипт автоматического обновления

Создайте `update.sh`:

```bash
#!/bin/bash
cd ~/PhantomSDR-Plus
./stop-websdr.sh
git pull origin main
git submodule update --init --recursive
meson compile -C build
cd frontend && npm install && npm run build && cd ..
./start-rtl.sh
```

---

## Резервное копирование и восстановление

### Файлы для резервной копии

- Файлы конфигурации: `*.toml`
- Сведения о площадке: `frontend/site-information.json`
- Маркеры: `markers.json`
- Пользовательские скрипты: `start-*.sh`, `stop-*.sh`
- История чата: `chat_history.txt`
- Фоновое изображение: `frontend/src/assets/background.jpg`

### Команда резервного копирования

```bash
cd ~/PhantomSDR-Plus
tar -czf phantomsdr-backup-$(date +%Y%m%d).tar.gz \
  *.toml \
  *.sh \
  markers.json \
  chat_history.txt \
  frontend/site-information.json \
  frontend/src/assets/background.jpg
```

### Команда восстановления

```bash
tar -xzf phantomsdr-backup-YYYYMMDD.tar.gz
```

---

## Вопросы безопасности

### Настройка межсетевого экрана

```bash
# Allow only necessary ports
sudo ufw allow 9002/tcp
sudo ufw enable
```

### Обратный прокси (необязательно)

Рассмотрите использование nginx или Apache в качестве обратного прокси для:
- шифрования SSL/TLS
- привязки доменного имени
- балансировки нагрузки
- контроля доступа

### Ограничение числа пользователей

Отредактируйте `config.toml`:
```toml
[server]
max_users = 100  # Limit concurrent users
```

---

## Получение помощи

### Ресурсы

- **Документация**: это руководство, README.md, USER_GUIDE.md
- **GitHub Issues**: https://github.com/sv1btl/PhantomSDR-Plus/issues
- **Живая демонстрация**: http://phantomsdr.no-ip.org:8900/

### Сообщения о проблемах

Сообщая о проблеме, укажите:
1. операционную систему и её версию
2. модель устройства SDR
3. содержимое файла конфигурации
4. сообщения об ошибках
5. потребление системных ресурсов (ЦП, ОЗУ, GPU)

### Поддержка сообщества

- Прежде чем создавать новые issue, просмотрите существующие на GitHub
- Приводите подробные сведения о своей конфигурации
- Прилагайте журналы и сообщения об ошибках
- Будьте терпеливы и уважительны

---

## Приложение А: полный список зависимостей

### Список пакетов Ubuntu 24.04

```
build-essential
cmake
pkg-config
meson
libfftw3-dev
libwebsocketpp-dev
libflac++-dev
zlib1g-dev
libzstd-dev
libboost-all-dev
libopus-dev
libliquid-dev
git
util-linux (taskset — for the autorun spot reporter)
psmisc
wget
curl
rtl-sdr (for RTL-SDR)
airspy (for Airspy)
hackrf (for HackRF)
libclfft-dev (for OpenCL)
ocl-icd-opencl-dev (for OpenCL)
clinfo (for OpenCL)
```

---

## Приложение Б: примеры конфигурации

### Пример 1: RTL-SDR для УКВ

```toml
[input]
sps = 2048000
frequency = 145000000
signal = "iq"

[input.driver]
format = "u8"

[input.defaults]
frequency = 145500000
modulation = "FM"
```

### Пример 2: RX888 для КВ (0-30 МГц)

```toml
[input]
sps = 60000000
frequency = 0
signal = "real"
fft_size = 8388608

[input.driver]
format = "s16"

[input.defaults]
frequency = 7100000
modulation = "LSB"
```

### Пример 3: HackRF для широкополосной ЧМ

```toml
[input]
sps = 10000000
frequency = 100900000
signal = "iq"

[input.driver]
format = "s8"

[input.defaults]
frequency = 100900000
modulation = "WBFM"
```

---

**Установка завершена! Теперь у вас должен быть полностью работоспособный сервер PhantomSDR-Plus.**

**73 de SV1BTL & SV2AMK**
