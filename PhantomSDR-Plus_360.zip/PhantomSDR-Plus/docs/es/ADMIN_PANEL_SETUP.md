# Panel de administración de PhantomSDR-Plus — Guía de configuración

> ⚠️ **Aviso de seguridad:** mantenga este panel de administración en su red doméstica o detrás de una VPN. No se recomienda exponer públicamente el puerto de administración sin un refuerzo adecuado de la autenticación.

---

## Descripción general

El panel de administración consta de dos servicios de Python:

| Servicio | Archivo | Función |
|---|---|---|
| Panel de administración | `admin_server.py` | Aplicación web Flask, se enlaza a `127.0.0.1` (solo interna) |
| Proxy inverso | `proxy.py` | Expone tanto el SDR como el panel de administración en un único puerto público |

Ambos servicios leen su configuración de `admin_config.json`, que escribe `setup_admin.sh`. **No edite las constantes de puerto directamente en los archivos de Python**: todos los puertos y la IP del host SDR se guardan en `admin_config.json`.

---

## Qué le ofrece el panel de administración

- **Panel de control** — estado del servidor en directo, CPU/RAM, procesos principales, salida reciente de los registros, terminal
- **Editor de configuración** — ver, editar y guardar cualquier archivo `.toml`, `.sh`, `.json`, `.h` o `.cpp` de su instalación
- **Visor de registros** — seguir cualquier archivo de registro en tiempo real (servidor SDR, panel de administración, RADE, fallos, autorun, proxy)
- **Marcadores** — ver y editar los marcadores de frecuencia
- **Historial del chat** — ver el registro del chat del WebSDR, borrarlo por completo o eliminar mensajes concretos sin reiniciar el servidor
- **Mensaje en la cascada** — difundir un cartel persistente a todos los usuarios conectados, visible en tiempo real en la cascada
- **Usuarios** — lista en directo de oyentes conectados con su frecuencia, modo, duración y un botón ⚡ Kick
- **Eliminación de mensajes del chat** — botón 🗑 Delete que quita de inmediato ese único mensaje del registro
- **Mensajes difundidos en la cascada** — permite enviar un cartel de texto persistente a la cascada de cada usuario conectado
- **Spot Reporting** — iniciar/detener el decodificador autorun de FT8/FT4/WSPR, elegir bandas y modos e informar de spots a PSK Reporter / wsprnet (desactivado por defecto), con dos contadores: paneles por decodificador para la ejecución actual y un total histórico junto a cada casilla de banda/modo
- **Gráficas** — frecuencia de CPU, carga de CPU, temperatura de CPU y usuarios conectados, representados en los últimos 15 minutos / 1 hora / 4 horas / 12 horas / 24 horas
- **Ajustes** — cambiar la contraseña de administrador, el directorio base del SDR, el nombre del proceso y el puerto público

---

## Requisitos

- PhantomSDR-Plus ya instalado y en funcionamiento
- Python 3.8+
- `pip3 install flask psutil aiohttp --break-system-packages`

---

## Paso 1 — Archivos

Coloque estos cuatro archivos dentro de su directorio PhantomSDR-Plus:

```
admin_server.py
manage_admin.sh
setup_admin.sh
proxy.py
```

Haga ejecutables los scripts de shell:

```bash
chmod +x setup_admin.sh manage_admin.sh
```

---

## Paso 2 — Ejecutar el script de configuración

```bash
./setup_admin.sh
```

El script hará lo siguiente:

1. Comprobar que Python 3 está instalado
2. Verificar que existen `admin_server.py` y `manage_admin.sh`
3. Registrar `127.0.0.1` como `sdr_host` en la configuración (véase [El ajuste `sdr_host`](#el-ajuste-sdr_host))
4. Pedir tres números de puerto:
   - **Puerto de spectrumserver** — el puerto en el que escucha su servidor SDR (p. ej., `8900`)
   - **Puerto interno del panel de administración** — donde `admin_server.py` se enlaza localmente (p. ej., `3000`)
   - **Puerto público del proxy** — el único puerto externo que combina SDR y administración (p. ej., `8902`)
5. Instalar `flask`, `psutil` y `aiohttp` mediante pip
6. Conceder a `ss` la capacidad `cap_net_admin` (necesaria para la función de expulsar usuarios)
7. Escribir `admin_config.json` con todos los ajustes
8. Ofrecer la instalación de un servicio systemd para el arranque automático

Tras la configuración, abra el navegador a través del proxy:
```
http://YOUR_SERVER_IP:<proxy_port>/admin
```
Contraseña por defecto: **`admin`**

> ⚠️ **Cambie la contraseña de inmediato**: vaya a Settings en el primer inicio de sesión. Un asistente de primera ejecución le guiará para establecer el directorio del SDR, el nombre del proceso, el puerto público y una contraseña nueva.

---

## Paso 3 — Iniciar / detener / reiniciar

Use `manage_admin.sh` para controlar **conjuntamente** el panel de administración y el proxy:

```bash
./manage_admin.sh start      # start admin panel and proxy
./manage_admin.sh stop       # stop both
./manage_admin.sh restart    # restart both
./manage_admin.sh status     # show running status and PIDs
```

`manage_admin.sh` comprueba que `aiohttp` esté instalado antes de arrancar el proxy y muestra un error claro con el comando de solución si falta.

Si instaló el servicio systemd durante la configuración (solo el panel de administración; el proxy siempre se gestiona con `manage_admin.sh`):

```bash
sudo systemctl start   phantomsdr-admin
sudo systemctl stop    phantomsdr-admin
sudo systemctl restart phantomsdr-admin
sudo systemctl status  phantomsdr-admin
sudo journalctl -u phantomsdr-admin -f   # live logs
```

---

## Paso 4 — Abrir el puerto en el cortafuegos

Abra en el cortafuegos únicamente el **puerto público del proxy**. No es necesario exponer al exterior el puerto interno del panel de administración:

```bash
sudo ufw allow <proxy_port>
```

---

## Paso 5 — Función de expulsar usuarios

La página Users muestra a todos los oyentes conectados en ese momento. Cada fila indica la IP del usuario, la frecuencia sintonizada, el modo y cuánto tiempo lleva conectado. Para desconectar a un usuario, pulse el botón **⚡ Kick** de su fila: solo se corta esa conexión TCP. Los demás oyentes siguen conectados y no notan nada.

La expulsión es instantánea y quirúrgica: el servidor no se reinicia, no se interrumpe el audio de nadie más y el usuario expulsado puede volver a conectarse de inmediato (la función sirve para eliminar conexiones problemáticas o bloqueadas, no para vetar).

Internamente, la expulsión usa `ss -K dst <IP> dport <port>` para cerrar ese socket TCP concreto. Esto requiere una capacidad de Linux que el script de configuración concede automáticamente. Si se saltó la configuración o el botón informa de un error, aplíquela manualmente:

```bash
sudo setcap cap_net_admin+ep $(which ss)
# Verify:
getcap $(which ss)    # should show: cap_net_admin=ep
```

---

## Configuración — admin_config.json

Toda la configuración de ejecución reside en `admin_config.json`, dentro de su directorio PhantomSDR-Plus. `setup_admin.sh` escribe el archivo inicial; los cambios posteriores pueden hacerse desde la página Settings o editando el archivo directamente.

Campos clave escritos por `setup_admin.sh`:

| Clave | Descripción |
|---|---|
| `port` | Puerto interno del panel de administración (donde se enlaza `admin_server.py`) |
| `public_port` | Puerto de spectrumserver (usado por la página Users para consultar `/users`) |
| `proxy_port` | Puerto público en el que escucha el proxy |
| `sdr_host` | Host que usa el proxy para llegar a spectrumserver — `127.0.0.1` (véase más abajo) |
| `password_hash` | Hash SHA-256 de la contraseña de administrador |
| `sdr_base_dir` | Ruta de su instalación de PhantomSDR-Plus |
| `sdr_process_name` | Nombre del proceso a vigilar (por defecto: `spectrumserver`) |

Para cambiar los puertos tras la configuración inicial, edite `admin_config.json` y reinicie:

```bash
./manage_admin.sh restart
```

---

## El ajuste `sdr_host`

`proxy.py` se conecta a `spectrumserver` por bucle local — `sdr_host` es `127.0.0.1` en `admin_config.json`, escrito ahí por `setup_admin.sh`. No debería necesitar cambiarlo.

Póngale una dirección real solo si `spectrumserver` se ejecuta en una **máquina distinta** a la del proxy. Después reinicie con `bash manage_admin.sh restart`.

> **Cambio:** las versiones anteriores exigían que `sdr_host` fuera la IP local de la máquina, porque `spectrumserver` cerraba los WebSocket que llegaban desde la dirección de bucle local. Ese filtro se ha eliminado, así que las conexiones locales funcionan con normalidad. Dos consecuencias: abrir `http://localhost:<port>` en la propia máquina del servidor ahora muestra la interfaz completa (antes cargaba la página pero se quedaba en blanco), y el proxy ya no se rompe cuando DHCP reasigna la IP de la máquina. Si está actualizando y su `admin_config.json` todavía contiene una IP local, cámbiela a `127.0.0.1` o vuelva a ejecutar `setup_admin.sh`.

---

## proxy.py — qué es y cuándo lo necesita

`proxy.py` coloca tanto el servidor SDR como el panel de administración en un **único puerto público**, enrutando según el prefijo de la ruta:

| Ruta | Se dirige a |
|---|---|
| `/admin*` | Panel de administración (`localhost:<port>`) |
| Todo lo demás | Spectrumserver (`<sdr_host>:<public_port>`) |

Sin el proxy tendría que exponer dos puertos por separado. Con él solo expone uno.

El proxy también elimina el límite de 4 MB en el tamaño de los mensajes WebSocket (importante para las tramas FFT grandes del RX-888 a 60 MSPS), reenvía las IP reales de los clientes mediante cabeceras `X-Forwarded-*` y mantiene vivas las conexiones de larga duración a través de NAT con un latido cada 30 segundos.

---

## Cambiar los puertos tras la configuración

Edite `admin_config.json` directamente:

```json
{
  "port":        3000,
  "public_port": 9001,
  "proxy_port":  9002,
  "sdr_host":    "127.0.0.1"
}
```

Después reinicie ambos servicios:

```bash
./manage_admin.sh restart
```

Si además necesita que `admin_server.py` se enlace a otro puerto al arrancar (p. ej., en el servicio systemd), puede sobrescribirlo con la variable de entorno:

```bash
ADMIN_PORT=3000 python3 admin_server.py
```

Por defecto, `admin_server.py` solo se enlaza a `127.0.0.1`. Para ejecutarlo por separado sin el proxy (desarrollo/pruebas), enlácelo a todas las interfaces:

```bash
ADMIN_BIND=0.0.0.0 python3 admin_server.py
```

---

## Comandos manuales útiles

```bash
# Start admin panel manually (foreground)
python3 ~/PhantomSDR-Plus/admin_server.py

# Kill the admin panel
pkill -f admin_server.py

# Kill the proxy
pkill -f proxy.py

# Free a port that is stuck in use
sudo fuser -k 3000/tcp

# Check what is listening on a port
ss -tlnp | grep 3000
```

---

## Archivos de registro

| Archivo | Contenido |
|---|---|
| `admin.log` | Salida del panel de administración |
| `proxy.log` | Cartel de arranque del proxy + una línea de registro de acceso por cada petición reenviada |
| `logwebsdr.txt` | Registro principal del servidor SDR |
| `rade.log` | Registro del sidecar RADE/FreeDV |
| `autorun.log` | Registro del demonio decodificador — spots, SNR, deriva |
| `crash.log` | Solo informes de fallos: trazas `[CRASH]` / `[TERMINATE]` y notas `[EXIT]`. **Normalmente vacío**: cualquier cosa que contenga merece leerse |

Todos ellos pueden leerse desde las pestañas del **Log Viewer** del panel (LOGWEBSDR,
ADMIN, RADE, CRASH, AUTORUN, PROXY).

### Rotación de proxy.log y admin.log

`proxy.log` registra cada petición reenviada y `admin.log` cada petición que llega al propio
panel. Ninguno de los dos se rota por defecto. Antes las consultas del panel dominaban ambos
archivos —`/admin/api/status` se lanza cada ~3 segundos mientras haya una pestaña abierta—,
pero ahora se filtran de los dos registros (véase más abajo), así que la rotación sirve para
acotar un crecimiento lento, no una avalancha.

El repositorio incluye una configuración de logrotate en `logrotate/phantomsdr` (diaria, o
antes si un registro supera los 10 MB; conserva 7 archivos comprimidos en `logproxy/`, para
que no llenen la raíz del proyecto). **Es específica de cada instalación: ábrala y cambie las
dos rutas de registro, la ruta `olddir` y el usuario `su` para que coincidan con su máquina
antes de instalarla**, y después:

```bash
sudo cp logrotate/phantomsdr /etc/logrotate.d/phantomsdr
sudo logrotate -d /etc/logrotate.d/phantomsdr     # dry run, should list both logs
```

`logrotate/phantomsdr` en el repositorio y `/etc/logrotate.d/phantomsdr` son dos copias
**independientes**: `cp` no las enlaza. Editar el archivo del repositorio no cambia nada en un
sistema en marcha hasta que vuelva a ejecutar el `sudo cp` anterior. Logrotate solo lee la
copia de `/etc`.

La configuración usa `copytruncate`, algo imprescindible: `manage_admin.sh` arranca ambos
procesos con `>> <log>` y ninguno reabre su salida estándar, de modo que una rotación basada
en renombrado los dejaría escribiendo en el archivo rotado mientras el nuevo registro quedaría
vacío para siempre.

Los archivos comprimidos van a `logproxy/` (creado automáticamente por `createolddir`) y se
llaman `proxy.log.1.gz` … `proxy.log.7.gz`, el más reciente primero. Lea uno con
`zcat logproxy/proxy.log.1.gz | less`, o búsquelos todos a la vez con
`zgrep "pattern" logproxy/*.gz`.

El botón **Clear Logs** del panel vacía todos los archivos de la tabla anterior **excepto
`proxy.log`**, que se excluye deliberadamente (`CLEAR_EXCLUDE` en `admin_server.py`): es el
único registro de quién se conectó y cuándo, y logrotate ya limita su tamaño, así que un botón
de la interfaz no debería poder destruir ese historial. La pestaña PROXY sigue mostrándolo.

Las consultas correctas se filtran de **ambos** registros de acceso, mediante el
`QuietPollFilter` de `proxy.py` y el de `admin_server.py`. El panel llama a
`/admin/api/status` cada 3 segundos y a `/admin/api/logs`, `/admin/api/autorun/status`,
`/admin/api/users`, `/admin/api/graph-stats` y `/admin/api/chat` cada 5 segundos; sin filtrar
serían el ~95 % de los dos archivos. Solo se descartan los `200` simples en esas rutas:
cualquier otro estado, ruta o método se registra como antes, de modo que una consulta fallida
sigue siendo visible y cada acción que cambia el estado (`kick`, `logs/clear`,
`autorun/start`, …) usa una ruta distinta y queda siempre registrada.

Como `proxy.log` es un registro de acceso, contiene direcciones IP de visitantes y cadenas de
user-agent; téngalo en cuenta antes de compartirlo al pedir ayuda.

---

## Resumen de acceso

| Configuración | SDR | Panel de administración |
|---|---|---|
| Sin proxy | `http://YOUR_IP:<public_port>` | `http://YOUR_IP:<port>/admin` |
| Con proxy | `http://YOUR_IP:<proxy_port>` | `http://YOUR_IP:<proxy_port>/admin` |

---

## Eliminación de mensajes del chat

La página Chat History enumera todos los mensajes del registro de chat actual. Cada entrada tiene un botón **🗑 Delete** que quita de inmediato ese único mensaje del registro, sin reiniciar el servidor.

Cómo funciona:

- El panel de administración reescribe el archivo de registro del chat sobre la marcha, eliminando solo la línea del mensaje seleccionado.
- El cambio surte efecto para cualquier usuario que recargue el chat; el historial ya cargado en pestañas abiertas no se actualiza retroactivamente.
- Vaciar todo el registro (botón **Clear All**) trunca el archivo, lo que también surte efecto sin reiniciar.

El botón de eliminar se muestra de forma coherente en las cinco variantes de la aplicación Svelte. Si una eliminación no parece surtir efecto, confirme que el panel de administración tiene permiso de escritura sobre el archivo de registro del chat:

```bash
ls -l ~/PhantomSDR-Plus/chat.jsonl   # path depends on your config
```

---

## Mensajes difundidos en la cascada

El panel **Waterfall Message** permite enviar un cartel de texto persistente a la cascada de cada usuario conectado sin tocar el proceso del servidor.

### Enviar un mensaje

1. Abra el panel de administración y vaya a **Waterfall Message**.
2. Escriba el texto del mensaje y elija un color (hexadecimal, p. ej., `#ffdd00`).
3. Pulse **Send**: el mensaje aparece de inmediato en todas las vistas de cascada activas.

### Borrar el mensaje

Pulse **Clear** para quitar el cartel de todas las cascadas. El estado del mensaje se mantiene en memoria en el panel de administración; se borra automáticamente si el proceso del panel se reinicia.

### Cómo funciona

El panel de administración expone dos puntos finales internos que el proxy reenvía:

| Punto final | Método | Finalidad |
|---|---|---|
| `/admin/api/waterfall-message` | `POST` | Fijar o borrar el texto y el color del cartel actual |
| `/admin/api/waterfall-message` | `GET` | Devolver el estado actual del mensaje en JSON |

El frontend consulta el estado del mensaje y lo dibuja superpuesto sobre el lienzo de la cascada. En el cliente no hace falta ni reconectar el WebSocket ni recargar la página.

### Usos habituales

- Anunciar un mantenimiento programado: `"Server restart in 10 minutes"`
- Señalar las condiciones de banda: `"Solar flux 180 — 10m wide open"`
- Mensaje de bienvenida: `"Welcome to SV1BTL WebSDR — Athens, KM17"`

---

## Gráficas del sistema

La página **Gráficas** representa cuatro magnitudes sobre un eje de tiempo común:

- **Frecuencia de CPU** — frecuencia media de todos los núcleos, en GHz
- **Carga de CPU** — utilización total, en porcentaje
- **Temperatura de CPU** — en °C, con guías discontinuas a 70 °C (caliente) y 80 °C (crítica)
- **Usuarios conectados** — oyentes conectados al WebSDR en ese momento

Elija el intervalo con **15 MIN / 1 HOUR / 4 HOURS / 12 HOURS / 24 HOURS**. Al pasar el ratón por la
gráfica aparece una cruz con los cuatro valores de ese instante. Las cuatro
tarjetas superiores muestran siempre la muestra más reciente.

### Cómo se muestrea

Un hilo en segundo plano de `admin_server.py` toma una muestra cada **2
segundos**. Las muestras se guardan en dos niveles: la última **hora** a
resolución completa de 2 segundos (1800 puntos) y **24 horas** de promedios de 30
segundos (2880 puntos) para los intervalos largos. La página elige el nivel que
cubre el intervalo elegido e indica `30s averages` en la cabecera cuando está
mostrando el nivel promediado.

Guardar un día entero a 2 segundos serían ~43000 puntos: decenas de MB de
memoria, una primera descarga de varios megabytes y unos 40 puntos por píxel de
lienzo, que ninguna pantalla puede representar. Promediar a 30 segundos mantiene
un día en 2880 puntos.

El muestreo arranca junto con el panel de administración, no al abrir la página
por primera vez, de modo que la página se abre sobre un historial que ya existe.

El búfer está **solo en memoria**: no se escribe nada en disco y el historial se
pierde al reiniciar el panel. Es deliberado: mantiene la función fuera de la
rotación de registros y del disco.

2 segundos ofrecen una vista casi en vivo y es un intervalo lo bastante corto
para no falsear la frecuencia de CPU, que en un procesador moderno salta entre el
reloj de reposo y el turbo de una muestra a la siguiente. Una muestra cuesta
alrededor de un milisegundo, así que el muestreo es insignificante frente al
servidor SDR. La página consulta al ritmo de cada nivel: cada 2 segundos en los
intervalos en vivo y cada 30 segundos en los promediados, porque preguntar más a
menudo de lo que se generan puntos solo devuelve respuestas vacías.

Para cambiar la cadencia o la retención, edite estas constantes al principio del
bloque del muestreador en `admin_server.py` y reinicie:

```python
GRAPH_INTERVAL_S   = 2          # segundos entre muestras finas
GRAPH_FINE_S       = 3600       # alcance del nivel fino (1 h)
GRAPH_COARSE_EVERY = 15         # muestras finas por punto agregado (15 x 2 s = 30 s)
GRAPH_COARSE_S     = 24 * 3600  # alcance del nivel agregado (24 h)
```

### De dónde salen los números

| Magnitud | Origen |
|---|---|
| Frecuencia de CPU | `psutil.cpu_freq()`, con respaldo en `/sys/devices/system/cpu/cpu*/cpufreq/`. Son los mismos datos del kernel que formatea `cpufreq-info`, por lo que **cpufrequtils no es necesario**. |
| Carga de CPU | `psutil.cpu_percent()` |
| Temperatura de CPU | `psutil.sensors_temperatures()`, con respaldo en `/sys/class/thermal` y después la orden `sensors` |
| Usuarios conectados | El propio endpoint `/users` de spectrumserver — la lista de sesiones autorizada. Contar sockets con `ss` no ve las IP reales de los clientes detrás de proxy.py. |

Si una magnitud no está disponible en su máquina, ese panel lo indica en lugar
de dibujar una línea plana a cero. Una lectura fallida interrumpe la línea, de
modo que un hueco nunca parezca un valor medido.

### Por qué cuatro paneles y no una sola gráfica

GHz, porcentaje, grados y un recuento de personas no comparten escala. Dibujarlos
en una sola gráfica exige varios ejes y, los cruces que se producen son artefactos
del escalado, no hechos sobre el servidor. Cuatro paneles apilados sobre un eje
de tiempo mantienen la comparación honesta. Cada panel arranca en cero, así la
altura de la curva sigue siendo proporcional al valor.

El color queda reservado para la temperatura, donde el ámbar y el rojo marcan los
umbrales indicados. Los demás paneles comparten un color porque cada uno contiene
una sola serie que su propio título ya nombra.

### Endpoint

`GET /admin/api/graph-stats?since=<epoch>` (requiere inicio de sesión) devuelve
las muestras posteriores a `since`, de modo que la página consulta de forma
incremental en lugar de descargar todo el búfer en cada ciclo.

---

## Spot Reporting (autorun FT8/FT4/WSPR)

La pestaña **Spot Reporting** controla el demonio autorun (`autorun/index.js`), un proceso
Node.js que decodifica FT8/FT4/WSPR en el servidor, directamente del receptor, y sube los
spots a las redes de reporte:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

**El reporte está DESACTIVADO por defecto.** No se sube nada hasta que active un destino y
pulse **Start**. Decodificar y subir son procesos independientes: el demonio puede decodificar
y registrar con el reporte desactivado, de modo que pueda comprobar la actividad antes de que
nada se haga público.

> ⚠️ Los spots se suben a redes públicas con **su indicativo**. Active únicamente las bandas y
> modos que su receptor oiga de verdad, e indique el localizador correcto.

### Requisitos previos

El demonio autorun necesita Node.js 22+, los paquetes npm `ws` + `cbor-x` (resueltos mediante
el enlace simbólico `autorun/node_modules` → `frontend/node_modules`) y `util-linux`
(`taskset`). Los instaladores lo preparan todo automáticamente; véase la
[sección Autorun Spot Reporter de INSTALLATION.md](INSTALLATION.md#autorun-spot-reporter-ft8ft4wspr).
Si **Start** falla, la causa habitual es ese enlace simbólico o `taskset` (véase la resolución de problemas más abajo).

### Uso de la pestaña

1. **Identidad** — indicativo y localizador. Se rellenan previamente desde
   `frontend/site_information.json` (`siteSysop` / `siteGridSquare`, recortado a 6 caracteres);
   modifíquelos aquí si es necesario.
2. **Matriz banda × modo** — marque las combinaciones que desea decodificar. Las filas son
   bandas y las columnas FT8 / FT4 / WSPR; las celdas no admitidas están desactivadas. WSPR
   cubre además las bandas de LF/MF (2200 m, 630 m) y un canal adicional de 80 m para Europa.
3. **Destinos** — active **PSK Reporter** y/o **wsprnet** (ambos desactivados por defecto).
4. **Max slots** — límite de seguridad sobre cuántas ranuras banda/modo pueden ejecutarse a la vez.
5. **Start / Stop** — lanza o detiene el demonio (fijado a los núcleos de CPU superiores con
   `taskset`, elegidos automáticamente según la máquina; véase *Requisitos de recursos y
   limitaciones* más abajo). **Save** / **Reload** guardan y releen la configuración;
   **Free All** vacía todas las ranuras.

La tarjeta de estado se actualiza cada 5 s y muestra el estado de ejecución, los contadores de
decodificación/subida y la hora de la última subida. Aparece un distintivo **📶 REPORTING** en
la cascada principal mientras el reporte está activo.

> **Ver «0 sent» durante los primeros minutos es normal.** PSK Reporter sube por lotes cada
> **5 minutos** y wsprnet cada **2 minutos**: los spots esperan en cola hasta el siguiente
> envío. La tarjeta de estado muestra el número pendiente y la cadencia.

### Cambiar bandas o modos mientras está en marcha

**Los cambios no surten efecto hasta que se reinicia el demonio.**
`autorun/index.js` lee `autorun.json` una sola vez, al arrancar. No hay
vigilancia del archivo ni señal de recarga: las únicas señales que atiende son
SIGINT y SIGTERM, que significan apagar. Un demonio en marcha sigue por tanto
decodificando las ranuras con las que se lanzó, guarde usted lo que guarde
después.

Para aplicar un cambio:

1. Marque / desmarque las bandas y modos
2. **SAVE CONFIG**
3. **STOP**
4. **START**

O simplemente **STOP** → cambiar las casillas → **START**, ya que START guarda la
configuración antes de lanzar.

> ⚠️ **Pulsar START sin parar antes no aplica el cambio.** START guarda la
> configuración y después la petición de arranque responde `already running` y no
> se relanza nada. Verá un aviso de «guardado» junto a un error «already running»
> mientras el demonio continúa con las bandas **antiguas**: es fácil tomarlo por
> un éxito. Pare siempre primero.

Qué hace un reinicio con los contadores:

- **Los totales junto a cada casilla se conservan**: están en
  `autorun-totals.json`, que no se borra al apagar.
- **Las tarjetas por decodificador vuelven a cero**, son por ejecución.
- **No se pierde nada de la cola**: el apagado envía los spots pendientes.
- Una banda **recién activada** empieza en `0`; una banda ya **usada antes**
  retoma su total anterior.
- Una banda que **desmarque conserva su número** junto a la casilla ahora vacía;
  el historial no se borra.

La decodificación solo se detiene los pocos segundos entre STOP y START.

### Contadores de spots

Se muestran dos recuentos distintos, que responden a preguntas distintas.

**SPOTS UPLOADED PER DECODER** — una tarjeta por decodificador (FT8 / FT4 /
WSPR) con los spots subidos **desde el último arranque del demonio** y, debajo,
el número de decodificaciones y cuántos siguen en cola. Stop/Start los pone a
cero. Un decodificador cuyo destino está desactivado muestra sus decodificaciones
y `reporting off` en lugar de un `0` a secas, porque ahí cero subidas es un
ajuste, no un fallo.

**El número junto a cada casilla** en BANDS & MODES son los spots subidos
**de todo el tiempo** para esa banda y modo. Se guardan en `autorun-totals.json`
y sobreviven a los reinicios. **En ámbar y con un punto delante** (`·123`)
significa que esa ranura ha decodificado pero aún no ha subido nada. Es normal
entre envíos —PSK Reporter sube cada 5 minutos y wsprnet cada 2—, así que los
contadores de FT8/FT4 quedan en ámbar los primeros minutos tras un arranque.
También sigue en ámbar si el destino de ese decodificador está apagado. Un `0`
a secas, sin punto, significa que esa ranura está activada pero aún no ha
decodificado nada: WSPR se queda en cero varios minutos tras un arranque, porque
funciona en un ciclo de 2 minutos mientras FT8 ya cuenta por centenares. Una
ranura que el demonio nunca ha ejecutado no muestra nada. Al pasar el ratón se ven las subidas, las decodificaciones y la hora de
la última subida.

FT8 y FT4 comparten una única cola de subida a PSK Reporter, así que el demonio
imputa cada spot a su propio modo y banda en el momento del envío; el reparto no
se estima después a partir de los totales.

**Poner a cero los contadores.** **FREE ALL SLOTS** desmarca todas las bandas y
modos, apaga ambos destinos, detiene el demonio y **borra los contadores
históricos**: después no se muestra ningún número junto a ninguna casilla. Es la
única forma de reiniciarlos y no se puede deshacer. El botón detiene el demonio y
espera a que termine antes de borrar `autorun-totals.json`, porque el demonio
reescribe ese archivo al apagarse; borrarlo con el demonio en marcha
simplemente devolvería los números.

### Requisitos de recursos y limitaciones

El demonio es deliberadamente ligero y funciona en hardware modesto (un i5 de cuatro núcleos
basta), pero conviene conocer sus límites reales.

**La fijación de CPU de autorun tiene en cuenta la configuración y es automática.** El
**demonio autorun** siempre lo lanza el panel de administración (`admin_server.py`), así que su
fijación se establece en cada instalación sin configuración alguna: deriva un rango de núcleos
para `taskset` a partir del número de CPU, reservando algunos de los núcleos superiores para la
decodificación, o se ejecuta sin fijación con ≤ 4 núcleos.

**La fijación de spectrumserver depende de su propio método de arranque.** La forma de lanzar
spectrumserver varía entre instalaciones (tipo de SDR, herramientas, scripts personales), así
que este documento no presupone ningún lanzador concreto. El panel de administración no
arranca ni fija spectrumserver: eso depende por completo del comando o servicio que use para
ejecutarlo. Si quiere mantener spectrumserver fuera de los núcleos que usa el demonio autorun,
fíjelo usted mismo con `taskset` en su propio comando de arranque (véase la sección de
sustitución más abajo). Si no lo hace, simplemente se ejecuta sin fijación y el planificador
del sistema lo equilibra: es correcto y seguro, solo pierde la separación deliberada de núcleos.

Como referencia, el demonio autorun reserva estos núcleos superiores (así que, si fija
spectrumserver, manténgalo en los inferiores para evitar solapamientos):

| CPU lógicas | Usa el demonio autorun | Dejar para spectrumserver |
|---|---|---|
| ≤ 4 | *sin fijar* | *sin fijar* |
| 6 | `5` | `0-4` |
| 8 | `6-7` | `0-5` |
| 12 (p. ej., híbrido 8P+4E) | `8-11` | `0-7` |
| 16 | `12-15` | `0-11` |

En una máquina de **4 núcleos (o menos)** no hay nada que separar, así que el demonio autorun
también se ejecuta *sin fijar* y comparte todos los núcleos: es correcto y seguro, pero la FFT
del SDR y las ráfagas de decodificación compiten por los mismos núcleos.

**Limitaciones conocidas:**

1. **El verdadero cuello de botella es spectrumserver y el ancho de banda del SDR, no el
   demonio.** Un RX888 a 30 MHz necesita OpenCL/GPU; una CPU con pocos núcleos y sin una GPU
   capaz no puede sostener esa FFT. Combine el hardware modesto con un SDR más estrecho
   (RSP1A ≈ 10 MHz, RTL-SDR ≈ 2.4 MHz).
2. **WSPR es lo que más CPU consume.** Su decodificador de Fano es un port a JS (~30 s por
   banda, de un solo hilo). El grupo de 4 workers ejecuta 4 decodificaciones en paralelo;
   activar **más de ~4 bandas de WSPR** a la vez puede hacer que la cola supere la ranura de
   120 s, sobre todo mientras el SDR compite por los núcleos. Las decodificaciones de FT8/FT4
   son baratas en comparación.
3. **Escalado del número de ranuras.** La cifra de ~2-2,5 núcleos / 600-700 MB corresponde a
   las ~28 ranuras completas en una máquina de 8 núcleos. Con 4 núcleos compartidos,
   limítese a unas pocas bandas (orientación: ≤ 6 FT8/FT4 + ≤ 3 WSPR) y vigile la estadística
   `queued` del grupo.
4. **La fijación presupone una topología híbrida de Intel** (núcleos bajos = P-cores más
   rápidos). En AMD o en CPU con numeración SMT intercalada, el reparto automático sigue siendo
   válido (sin solapamientos ni fallos), pero «los núcleos bajos son más rápidos» puede no
   cumplirse literalmente; en un chip 4C/8T con hyperthreading, los núcleos superiores son
   hermanos SMT: quedan acotados, no del todo aislados. Cuando el rango automático no sea el
   idóneo, use la **sustitución manual** que se describe abajo.
5. **La cobertura de bandas la limita el receptor.** La configuración del RX888
   (`sps=60000000` → Nyquist de 30 MHz) no llega a 6 m ni por encima; la tabla de bandas va de
   160 m a 10 m. Otros SDR cubren lo que permita su ventana sintonizada.
6. **Cadencia de reporte.** PSK Reporter envía cada 5 min y wsprnet cada 2 min: ver «0 sent»
   los primeros minutos es normal, no un fallo.

### Sustitución manual de la fijación de CPU (avanzado)

El reparto automático de núcleos es adecuado para la mayoría de las máquinas, pero puede forzar
una fijación concreta donde no lo sea (CCX/CCD de AMD, ARM big.LITTLE, SMT intercalado). Hay dos
sustituciones independientes, cada una acepta una lista de núcleos al estilo `taskset -c`
(`2-3`, `0,2,4`, `0-2,5`) o `none`/`off`/`unpinned` para desactivar la fijación. Un valor no
válido se ignora y se aplica la derivación automática: una errata nunca podrá impedir un arranque.

**Demonio autorun** — variable de entorno `AUTORUN_CORES`, o un campo `"cores"` en
`autorun.json` (el entorno tiene prioridad). El campo `"cores"` se conserva al pulsar **Save**
en el panel, de modo que una edición manual permanece. Dos formas de establecerlo:

*Opción A — `autorun.json` (persistente, recomendada).* Añada una línea `"cores"` a la
configuración en la raíz del repositorio y luego haga **Stop → Start** en la pestaña Spot
Reporting:

```jsonc
// autorun.json
{ "identity": { "callsign": "SV1BTL", "grid": "KM17VX" },
  "reporting": { "pskreporter": true, "wsprnet": false },
  "slots": [ /* … */ ],
  "cores": "2-3" }          // or "none" to run unpinned
```

*Opción B — variable de entorno (puntual).* El demonio lo lanza el panel de administración, así
que la variable debe estar en el entorno **del panel**: defínala y reinicie el panel (el
entorno gana sobre el valor de `autorun.json`):

```bash
AUTORUN_CORES=2-3 ./manage_admin.sh restart
```

**spectrumserver** — fíjelo usted mismo anteponiendo `taskset -c <núcleos>` al comando con el
que arranque el servidor. Funciona con cualquier método de arranque (lanzamiento directo,
canalización de SDR, unidad de servicio, etc.):

```bash
# pin the server to cores 0-3, direct launch:
taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml < <your-input>
# or in an SDR pipeline:
<your-sdr-source> | taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml
```

> ⚠️ **Haga que sobreviva a los reinicios.** Un `taskset` en línea solo se aplica a ese
> arranque concreto. Si algo reinicia el servidor automáticamente (un watchdog, un servicio
> systemd, una entrada de cron/`@reboot`, …), añada el prefijo `taskset` dentro del script o la
> unidad que realmente lo arranca; de lo contrario, el reinicio pierde la fijación.

**Compruebe que la fijación surtió efecto** — muestre la afinidad de CPU real de los procesos
en ejecución:

```bash
taskset -cp "$(pgrep -f 'autorun/index.js')"   # autorun daemon
taskset -cp "$(pgrep -x spectrumserver)"       # spectrumserver
```

**Valores admitidos (en ambas sustituciones):** una lista `taskset -c` (`2-3`, `0,2,4`,
`0-2,5`), o `none`/`off`/`unpinned` para no fijar. Cualquier valor mal formado se ignora y se
aplica la derivación automática, así que una errata nunca podrá bloquear el arranque.

> En una Raspberry Pi o cualquier equipo de ≤ 4 núcleos no suele hacer falta ninguna de las
> dos: la vía automática ya ejecuta ambos procesos sin fijar, que es lo correcto en una CPU
> pequeña y homogénea. La sustitución está pensada para máquinas mayores que no sean híbridos
> de Intel.

### Archivos y puntos finales

| Elemento | Finalidad |
|---|---|
| `autorun.json` | Configuración guardada (identidad, ranuras, destinos, máximo de ranuras, sustitución opcional `cores`). La escribe la pestaña; git la ignora. |
| `autorun-status.json` | Estado en directo que lee la tarjeta de estado (pid, contadores, última subida). Se escribe cada 15 s; se elimina al parar. |
| `frontend/dist/autorun-active.json` | Datos públicos del distintivo, servidos en `/autorun-active.json`. Vacío cuando el reporte está desactivado. |
| `autorun.log` | Salida estándar y de error del demonio. |
| `GET/POST /admin/api/autorun/config` | Leer / escribir `autorun.json` (valida indicativo, localizador, combinaciones banda/modo y límite de ranuras). |
| `GET /admin/api/autorun/status` | Estado de ejecución (`pgrep`) + `autorun-status.json`. |
| `POST /admin/api/autorun/start` / `stop` | Lanza (`taskset -c <auto> node autorun/index.js`) / envía `SIGTERM`. El rango de núcleos se deriva de la CPU (véase más arriba). |

> **Nota:** tras actualizar `admin_server.py` debe ejecutar `./manage_admin.sh restart` para
> cargar las nuevas rutas de autorun o una matriz banda/modo actualizada. El demonio se ejecuta
> como un proceso aparte, así que sobrevive a los reinicios del panel de administración.

---

## Resolución de problemas

| Problema | Solución |
|---|---|
| El panel de administración no arranca | Consulte `admin.log`: suele faltar un paquete de Python |
| El proxy no arranca | Ejecute `python3 -c "import aiohttp"`; si falla: `pip3 install aiohttp --break-system-packages` |
| `proxy.log` está vacío | Compruebe primero que el proxy realmente se está ejecutando (`./manage_admin.sh status`). Si es así, tiene una versión antigua: el lanzador debe usar `python3 -u` (sin búfer; de lo contrario el cartel de arranque nunca sale del búfer de 8 KB) y el `main()` de `proxy.py` debe llamar a `logging.basicConfig()` (si no, el registrador de accesos de aiohttp no tiene manejador y se descarta cada línea de petición, porque `web.AppRunner` —a diferencia de `web.run_app`— no configura el registro). |
| El proxy arranca pero la cascada aparece en blanco | Compruebe `sdr_host` en `admin_config.json`: normalmente `127.0.0.1`. Si todavía contiene una IP local antigua de una versión anterior, cámbiela y ejecute `./manage_admin.sh restart` |
| El botón Kick dice «no connections» | Ejecute `getcap $(which ss)`; si no aparece `cap_net_admin`, ejecute `sudo setcap cap_net_admin+ep $(which ss)` |
| El estado siempre muestra OFFLINE | Vaya a Settings → SDR Process Name y ponga el nombre exacto que muestra `ps -eo comm,args \| grep -v grep` |
| La página Users no muestra datos | Verifique que el punto final funciona: `curl http://127.0.0.1:<public_port>/users` |
| Un navegador externo da NetworkError | Compruebe que el proxy está en marcha: `./manage_admin.sh status` |
| El proxy dejó de funcionar tras un cambio de red | Solo aplica si `sdr_host` todavía contiene una IP local: póngalo en `127.0.0.1` y ejecute `./manage_admin.sh restart` |
| El botón de borrar del chat no hace nada | Compruebe el permiso de escritura del archivo de registro del chat: `ls -l ~/PhantomSDR-Plus/chat.jsonl` |
| El mensaje de la cascada no aparece | Confirme que el proxy está en marcha (`./manage_admin.sh status`) y que el frontend es de una compilación reciente que incluye el renderizador de la superposición |
| El mensaje de la cascada se pierde tras reiniciar | Es lo previsto: el estado del mensaje solo está en memoria; vuelva a enviarlo tras reiniciar el panel |
| El «Start» de Spot Reporting falla / el demonio se cierra al instante | Consulte `autorun.log`. Suele faltar el enlace simbólico `autorun/node_modules` (`ln -sfn ../frontend/node_modules autorun/node_modules`) o `taskset` no está instalado (`sudo apt install -y util-linux`). |
| Spot Reporting: el demonio funciona pero `decodes` sigue en 0 y `autorun.log` muestra `504` / `tap closed 1006` | La toma de audio no llega a spectrumserver. El demonio detecta el puerto automáticamente a partir de la configuración del servidor **en ejecución**; la línea de registro `[autorun] tap backend: HOST:PORT` debe coincidir con su `[server] port`. Si es incorrecta (o el servidor no estaba en marcha al arrancar), fíjelo en `autorun.json`: `"server": { "host": "127.0.0.1", "port": 9002 }`, y después Stop→Start. |
| Spot Reporting muestra «0 sent» | Normal durante los primeros minutos: PSK Reporter envía cada 5 min y wsprnet cada 2 min. Confirme que hay un destino activado y que el demonio está en marcha. |
| Las bandas o modos nuevos no aparecen en la matriz | Reinicie el panel de administración: `./manage_admin.sh restart` (la matriz se carga al arrancar el panel). |
| `autorun.log` muestra `MODULE_TYPELESS_PACKAGE_JSON` / «Reparsing as ES module … performance overhead» | Aviso cosmético (la decodificación sigue funcionando). A `frontend/src/modules/package.json` le falta `"type": "module"`; añada esa línea cerca del principio y haga Stop→Start. No hace falta recompilar el frontend: el demonio importa el archivo fuente directamente. |
| El «Start» de Spot Reporting falla con `taskset: … Invalid argument` en un PC antiguo o modesto | No debería ocurrir con el lanzador que tiene en cuenta la configuración: el rango de núcleos se deriva del número de CPU y no se fija con ≤ 4 núcleos. Si sucede, su `admin_server.py` es anterior a ese cambio; actualícelo (`_autorun_taskset_prefix`) y ejecute `./manage_admin.sh restart`. |
| El distintivo REPORTING no aparece en la cascada | El reporte debe estar activado con al menos una ranura; el distintivo lee `/autorun-active.json`. Recompile el frontend si `dist/index.html` es anterior al distintivo. |
