#!/bin/bash
# Build ONLY the Analog version with auto title fix

set -e

echo "📦 Building Analog S-Meter Version with auto title fix"

if [ ! -f "src/App.svelte" ]; then
    echo "❌ Error: src/App.svelte not found!"
    exit 1
fi

# The variant is passed to vite as a build-time define (see vite.config.js),
# so this script no longer rewrites src/main.js.  Nothing to back up, nothing
# to restore if the build fails, and build-all.sh can run the variants at the
# same time without them fighting over one entry file.
export PHANTOM_SMETER="analog"
export PHANTOM_LAYOUT="v1"

npm run build -- --outDir "dist/analog" --base "/analog/"

if [ -f "favicon.ico" ]; then
    mkdir -p dist/analog
    cp favicon.ico dist/analog/
fi

echo ""
echo "🔧 Auto-fixing title and favicon..."
if [ -f "fix-title-python.py" ]; then
    python3 fix-title-python.py
else
    echo "⚠️  Run manually: python3 fix-title-python.py"
fi

echo ""
echo "✅ Analog version built with title fix!"
echo "🌐 Test: cd dist && python3 -m http.server port_used"
echo "   Visit: http://localhost:port_used/analog/index.html"
