# PhantomSDR-Plus WebSDR (version 3.6.0)

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-cyan.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-3.6.0-cyan.svg)](https://github.com/sv1btl/PhantomSDR-Plus)

## Note: Tested on Debian 12 (Bookworm), Debian 13 (Trixie), Ubuntu 22.04, Ubuntu 24.04,  Ubuntu 26.04.

**New in v.3.6.0**

* All variants of App.svelte have been merged in one file,
* A new QRSS Grabber implementation has been added.
* A new SSTV decoder implementation has been added.
* A new FAX decoder implementation has been added.
* A new PSK31 decoder implementation has been added.
* A new Olivia decoder implementation has been added.
* All frequency schedules have been fully updated. Inactive frequencies have been removed, current information has been added, and the transmitting station is now displayed in the decoder window.
* The frontend/GUI AGC system has been redesigned.
* A new simplified mobile interface has been added as a standalone `.svelte` component. It is available at:  `http://your_server:PORT/mobile` This interface does not include a waterfall display, but it supports all operating modes, including RADE. The previous mobile interface remains available for users who require access to additional information and functionality. The `./recompile.sh` script has also been updated to support the new mobile GUI. The interface has been tested on both Android and iOS.
* The main GUI has been redesigned with more realistic 3D visual effects throughout the interface. All `.svelte` files have been updated accordingly.
* A **TUNE** button has been added to the **Users** tab, allowing the user to tune directly to another listener’s frequency.
* The analog and digital S-meters have been calibrated to provide consistent signal-level readings. A signal generator was used during the calibration process.
* The decoders are no longer reached through the Bandwidth row, which has been removed. A **Decoders** button row now sits on the main panel, directly under the Modes selector — one button per decoder (FT8, FT4, FT2, CW, WSPR, FAX, SSTV, NAVTEX, RTTY) — while **RADEL** and **RADEU** sit beside the Modes selector itself and are repeated inside the Modes and Bands pop-ups. One press starts the decoder and opens its window; a second press stops it.
* The Admin Panel has a new **Graphs** page plotting CPU frequency, CPU load, CPU temperature and users online on one shared time axis, over **15 MIN / 1 HOUR / 4 HOURS / 12 HOURS / 24 HOURS**. Sampling runs every 2 seconds in memory only (nothing is written to disk) and is kept in two tiers — 1 hour at full 2-second resolution plus 24 hours of 30-second averages — so a full day stays readable instead of becoming ~43000 points. Hovering the plot draws a crosshair with all four values at that instant.
* The frontend now rebuilds in about **half the time**. `build-all.sh` used to build the same sources five times one after another, because the S-meter variant was written into `src/main.js` before each build and only one build could own that file at a time. The variant is now passed to Vite as a build-time value, so every build reads the same unmodified sources and they run **in parallel** — a full `build-all.sh`, including `/mobile` and the title/favicon pass, drops by about **50%**. Nothing changes in how you use `./recompile.sh`. The number of builds running at once defaults to 3, which keeps the CPU cool on a laptop; raise it with `PHANTOM_BUILD_JOBS=5 ./build-all.sh` if your machine has the cores and the cooling for it. The variant chosen for the site root (`/`) is now remembered in `frontend/variant.json` — previously that choice could be overwritten by `build-default.sh`, so selecting, for example, the Digital S-meter as default still served the analog page at `/`.
* Two new modes have been added to the **FSK / RTTY** decoder window: **PSK31** and **Olivia**. Both sit in the same window's Variant dropdown alongside the three existing FSK variants, and the panel adapts to whichever is selected — the shift, baud, framing, encoding and invert controls are hidden for the two new modes, which have no mark/space tone pair. PSK31 corrects its own tuning error over about ±25 Hz and reports the recovered carrier and the transmitter's IMD; Olivia offers the four common configurations (**8/250** — the default the panel opens on — plus **16/500, 32/1000, 16/1000**), searches blindly for synchronisation because the mode sends no preamble, and has a **Squelch** slider controlling how strong the error-correction match must be before text is printed. See the [decoder documentation](docs/DECODERS.md).
* **A running decoder now owns the mode and the passband.** The mode used to follow the band plan in `bands-config.js` on every retune, which quietly undid whatever a decoder had set up: FT8 on 40 m flipped the receiver to LSB as soon as the dial moved, and the narrow decoder passbands widened back to the full SSB filter. A running decoder now keeps the mode and passband it needs across retunes, including a jump to another band, and the band's own mode returns when the decoder is switched off. Mode buttons still win — a deliberate choice by the operator is never overridden — and the CW decoder is unaffected, since it decodes in whatever mode you are listening in.
* The **QRSS grabber** has a **Band** list of the QRSS/MEPT windows from 2200 m to 6 m. Picking one and pressing **Tune** goes to that window in **CW** with a passband sized for the mode, so the dial reads the true QRSS frequency and the trace lands on the centre line of the display. Bands where two conventions are in use (40, 80, 160 and 10 m) list both windows. While a window is tuned the grabber holds the receiver the same way a decoder does, and the passband follows the dial as you hunt along the band. See the [decoder documentation](docs/DECODERS.md).
* The **Users** list marks your own session **you** when `users.html` is opened as a page of its own, not only inside the pop-up window. The page has no receiver of its own, so it asks whichever tab of the interface does — over the page's parent frame in the pop-up, and over a same-origin broadcast channel when standalone. With no interface tab open on that address there is no session to mark, and the list is shown unmarked as before.
* The four start scripts — `start-rx888mk2.sh`, `start-airspyhf.sh`, `start-rtl.sh` and `start-rsp1a.sh` — now **tell you what they are doing** instead of detaching in silence. Each one mirrors the start-up log to your terminal while the server comes up and then prints a summary saying whether the receiver, `spectrumserver`, the **RADE sidecar** and **websdr.org registration** are all up, before handing back the prompt; `Ctrl-C` stops only the mirroring, never the server. Add `-q` for the previous two-line output. The **RADE sidecar is now built into the start scripts** — it starts once the server is confirmed running, is restarted on its own if it exits (without restarting the server), is stopped by `stop-websdr.sh`, and can be skipped with `RADE_ENABLED=0`; where RADE is not installed the server starts normally and the summary just says the sidecar was not activated. Each script also reads your `.toml` and reports whether **[websdr.org] enabled** and **[websdr] register_online** are switched on, then waits for websdr.org to answer so the registration can be seen succeeding. Finally, `spectrumserver`'s own output — which was previously discarded — is kept in **`spectrumserver.log`** (rotating at 10 MB), with the `[WebSDROrg]` lines also copied into `logwebsdr.txt` — minus the routine `/~~orgstatus` and keep-alive-ping chatter, so what you read there is the registration story and any errors, not a running tally.
* The Admin Panel's Spot Reporting page now keeps **two separate counters**. The **SPOTS UPLOADED PER DECODER** tiles (FT8 / FT4 / WSPR) count uploads **since the daemon last started**, with the decode count and queue depth under each; a decoder whose destination is switched off shows `reporting off` instead of a bare `0`. The number beside each **BANDS & MODES** checkbox is that band+mode's **all-time** upload total, stored in `autorun-totals.json` so it survives restarts — a leading dot (`·123`) means the slot has decoded but not yet uploaded. See the [Admin Panel documentation](docs/ADMIN_PANEL_SETUP.md).
------------------

We also provide a wide range of additional **features**:

* A new `install.sh` installation procedure that simplifies the initial server setup.
* A `recompile.sh` script for quickly rebuilding the backend, the frontend, or both.
* A modern, futuristic user-interface design.
* **CATsync** support through the [CATsync Tool for WebSDRs](https://catsyncsdr.wordpress.com/) application.
* A full-featured, password-protected Admin Panel for remote server management without requiring direct SSH access. It provides access to server logs, chat moderation, user messaging, chat-message deletion without restarting the server, user disconnection, command execution, file editing, and other administrative functions.
* Integrated decoders for **FT8, FT4, FT2, CW, QRSS Grabber, WSPR, HF FAX, SSTV, NAVTEX, FSK/RTTY, PSK31, Olivia, and FreeDV RADE V1**. See the [decoder documentation](docs/DECODERS.md).
* Integrated **C-QUAM AM Stereo** decoding. C-QUAM audio uses Opus compression by default, while the remaining audio modes use FLAC.
* All decoders have been moved off the main browser thread. Each decoder now runs in its own Web Worker, preventing signal decoding from competing with audio playback and GUI processing.
* Automatic spot reporting to **PSK Reporter** and **WSPRnet**. A built-in autorun engine locally decodes off-air signals and uploads reception reports without requiring additional software:
  * **FT8 and FT4 → [PSK Reporter](https://pskreporter.info/)** using the native IPFIX/UDP protocol. Spots are batched and transmitted at the recommended interval of at least five minutes.
  * **WSPR → [WSPRnet](https://wsprnet.org/)** using the standard WSPRnet upload endpoint. WSPR reports are sent only to WSPRnet to prevent duplicate submissions.
* Integrated FreeDV Reporter and DX Cluster tools.
* Automatic C-QUAM status indication. When a C-QUAM transmission is detected, the button label turns green. While operating in AM mode, pressing the button again enables synchronous AM detection on the carrier. The label then turns yellow and displays `SAM`. Pressing the button once more returns the receiver to standard AM mode.
* A configurable band-plan overlay on the waterfall, with independent brightness, frequency-range, and visibility settings for each band.
* An improved custom colour-map system. A reversed spectrum and waterfall layout is used by default across all interface variants, although this behaviour can be changed manually.
* Optimized FLAC and Opus encoders with balanced latency. Both operate at 16-bit resolution, providing a theoretical dynamic range of approximately 96 dB. ⭐
* Numerous redesigned and optimized functions, including:
  * Reduced end-to-end latency.
  * Noise Reduction.
  * Noise Cancellation.
  * Noise Blanker.
  * Synchronous AM enabled by default.
  * Selectable AGC modes.
  * Automatic squelch.
  * Configurable buffer settings.
  * Automatic waterfall-level adjustment.
  * Mouse-wheel frequency tuning.
  * Keyboard shortcuts.
  * Zoom slider.
  * Enhanced mobile GUI.
  * Selectable Noise Gate with presets.
  * Precise mouse-based tuning with a frequency readout directly on the waterfall.
* Integrated audio Compressor and Equalizer, with manual configuration and reset controls.
* Redesigned bookmarks with on-screen labels and import/export functionality.
* Four selectable GUI templates, accessible through a floating pop-up menu.
* Support for running the GUI through `localhost`.
* An optional monitoring tool that adds real-time server-status information to the PhantomSDR application.
* An on-screen real-time audio spectrogram.
* A “Magic Eye” signal-strength indicator that emulates the behaviour of EM84 tuning-indicator tubes used in vintage radio receivers.
* Audio recording and combined video/audio recording of either the complete waterfall or a user-selected region.
* A real-time connected-user list with geolocation data, map integration, and user statistics covering configurable time periods. Your own session is marked **you** in the list, whether it is opened from the interface or as a standalone `users.html` page.
* Improved server stability and fault reporting. If `spectrumserver` crashes or malfunctions, diagnostic information is written to `crash.log`.
* The `crash.log` file can be accessed both from the server’s root directory and through the Admin Panel.
* An optimized mobile GUI.
* Client-side CPU and memory usage have been reduced as much as possible.
* PhantomSDR is registered with the following WebSDR directories:
  * [sdr-list.xyz](https://sdr-list.xyz)
  * [sdr.shbrg.nl](https://sdr.shbrg.nl/sdr/)
  * [websdr.org](http://websdr.org/)
* Supported receivers currently include the **RX-888, RTL-SDR Blog V4, Airspy HF+ Discovery, HackRF, and SDRplay RSP1A**, including compatible clones through SoapySDR. Support for additional receivers is planned.

- More to come!...

## Features
- WebSDR which can handle multiple hundreds of users depending on the Hardware.
- Common demodulation modes.
- Can handle high sample rate SDRs (70MSPS real, 35MSPS IQ).
- Support for both IQ and real data.
- Full decoder support.
- Lightweight mobile view at **/mobile** for phones on limited data plans.

## Benchmarks
- Ryzen 5* 2600 - All Cores - RX888 MKii with 64MHZ Sample Rate, 32MHZ IQ takes up 38-40% - per User it takes about nothing, 50 Users don't even take 1% of the CPU.
- RX 580 - RX888 MKII with 64MHZ Sample Rate, 32MHZ IQ takes up 28-35% - same as the Ryzen per User it takes about nothing (should handle many).
- Intel i5-6500T - RX888 MKII - 60MHz Sample Rate, 30MHz IQ, OpenCL installed and enabled, about 10-12%. 100 users is no problem with OpenCL as the GPU does the heavy lifting.

## Screenshots

The SV1BTL WebSDR: http://phantomsdr.no-ip.org:8900/

![Screenshot](docs/websdr.png) ![Screenshot](docs/websdr2.png) ![Screenshot](docs/websdr3.png)

(https://sdr-list.xyz)

## Building
Optional dependencies such as cuFFT or clFFT can be installed too.

### Ubuntu and Debian Prerequisites
```
sudo apt-get install curl build-essential cmake pkg-config meson libusb-1.0-0-dev libfftw3-dev libwebsocketpp-dev libflac++-dev zlib1g-dev libzstd-dev libboost-all-dev libopus-dev libliquid-dev git psmisc
```

### Fedora Prerequisites
```
dnf install g++ meson cmake fftw3-devel websocketpp-devel flac-devel zlib-devel boost-devel libzstd-devel opus-devel liquid-dsp-devel git
```
Inside the PhantomSDR folder there is a script for Fedora named **install_fedora.sh**.

### For use with Arch and openSUSE
Inside the PhantomSDR folder there are scripts for Arch and openSUSE named **install_arc.sh** and **install_opensusse.sh**.

### Step 1 - Building the binary automatically
Restart your terminal after running install.sh, otherwise it won't work.
```
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```
The install.sh script will install everything needed to run the server. <br />

**NB** The script can also install OpenCL for Intel CPUs if you answer "yes" when prompted. Please make sure your PC supports OpenCL first. The script will also check for compatible versions of Vite, Node.js, npm, etc., as follows:<br />

> [!NOTE]
> 
> **🎯 NB - After the final installation**  
>
> If you want to be **registered on the websdr.org map**, follow these instructions: <br />
> 1.- Prepare your .toml file, as explained in the section "The .toml file": <br />
>
> [websdr.org] <br />
> enabled     = true # or false <br />
> public_host = "your_ip_address" <br />
> public_port = PORT <br />
> qth         = "QTH_Locator" <br />
> description = "CALLSIGN PhantomSDR+" <br />
> email       = "mail@domain.com" <br />
> logo        = "logo.jpg" <br />
>
> 2.- Then run the following in a terminal:
> ```
> cp ~/PhantomSDR-Plus/request.hpp  ~/PhantomSDR-Plus/subprojects/websocketpp-0.8.2/websocketpp/http/request.hpp && cp ~/PhantomSDR-Plus/connection_impl.hpp  ~/PhantomSDR-Plus/subprojects/websocketpp-0.8.2/websocketpp/impl/connection_impl.hpp
> ```
> 3.- and finally recompile the frontend and backend in a terminal:
> ```
> cd PhantomSDR-Plus/
> ./recompile.sh
> ```

### Step 2 - Building other options manually

## Installing stats server
```
cd PhantomSDR-Plus
./install-stats-server.sh
```

## Installing Admin Panel
```
cd PhantomSDR-Plus
./setup_admin.sh
```

## Installing the FreeDV RADE V1 decoder
For Debian Bookworm, Debian Trixie or Ubuntu 24.04
```
cd PhantomSDR-Plus
./install_rade.sh
```

or for Ubuntu 22.04
```
cd PhantomSDR-Plus
./install_rade_ubuntu22.sh
```
-----------------

## OPENCL INSTALL (Intel CPU)
```
sudo apt install build-essential cmake pkg-config meson libfftw3-dev libwebsocketpp-dev libflac++-dev zlib1g-dev libzstd-dev libboost-all-dev libopus-dev libliquid-dev
sudo apt install libclfft-dev
sudo apt install ocl-icd-opencl-dev clinfo
sudo reboot
```
```
mkdir neo
cd neo
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
sudo dpkg -i *.deb
```
```
sudo apt update
sudo apt install intel-opencl-icd
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
sudo clinfo
```

## Examples
Remember to set the frequency and sample rate correctly in the start script for your
receiver (e.g. `start-rtl.sh`). In each start script these live in the **RECEIVER
CONFIGURATION** block near the top — edit the `RX_ARGS` line (for `start-rx888mk2.sh`
it is `RX888_ARGS`). The command examples below show what those arguments become. <br />
You also need to modify the .toml file, e.g. config-rtl.toml

### RTL-SDR
```
rtl_sdr -f 145000000 -s 2048000 - | ./build/spectrumserver --config config.toml
```
**in .toml** <br />
sps=2048000 # RTLSDR Input Sample Rate for 144-146 MHz receiving <br />
frequency=145000000 # Baseband frequency <br />

frequency=145000000 # Default frequency to show user <br />
modulation="FM" # Default modulation <br />

**and in sites-information** <br />
"siteSDRBaseFrequency": 145000000,<br />
"siteSDRBandwidth": 2048000,

### HackRF (10 Msps, WBFM; format: s8)
```
hackrf_transfer -r - -f 100900000 -s 10000000 | ./build/spectrumserver --config config.toml
```
### Airspy HF+ (912 ksps, AM; format: s16)
```
airspy_rx -r - -f 648000 -s 912000 | ./build/spectrumserver --config config.toml
```
### SDRplay RSP1A (8 Msps, LSB; format: s16)
```
rx_sdr -d driver=sdrplay -f 7100000 -s 8000000 - | ./build/spectrumserver --config config.toml
```
### RX888 MK2 (real sampling 6 Msps; format: s16, signal=real)
```
rx888_stream -s 6000000 | ./build/spectrumserver --config config.toml
```

## Start files and configs added for various receivers
Some require Soapy and RX_TOOLS to be installed, otherwise they will not work — for example the Airspy Discovery and the SDRplay RSP1A.<br />
I've also added psutils, as it is needed for the killall command.<br />
Don't forget to disable OpenCL if you didn't install it (though installing it is recommended).

### Self-contained launcher + watchdog
Each start script — `start-rx888mk2.sh`, `start-airspyhf.sh`, `start-rtl.sh`,
`start-rsp1a.sh` — is a **single self-contained script that starts, restarts,
watchdogs and logs** the server, and that also brings up the **RADE sidecar** and
reports your **directory registration** status. You only ever need that one start
script plus the shared `stop-websdr.sh`; there is no separate check, restart, kill
or RADE file to run.

```bash
./start-rtl.sh        # start (or cleanly restart), showing progress in the terminal
./start-rtl.sh -q     # same, but quiet: two lines instead of the live log
./stop-websdr.sh      # stop the server, its watchdog and RADE (works for ANY receiver)
```

What running a start script does:
- Stops any instance already running, then launches the receiver → `spectrumserver`
  chain and **detaches** (via `setsid`) so it keeps running after you close the terminal.
- **Shows you what is happening.** The watchdog has to be detached from your terminal,
  so it writes to the log; the launcher mirrors that log to the screen while the server
  comes up, then prints a summary and returns you to the prompt. Pressing `Ctrl-C`
  during the mirror stops only the mirroring — the server and watchdog keep running.
- Runs a **watchdog** that auto-restarts the chain in place if the receiver or
  `spectrumserver` dies — no external cron/systemd needed.
- Starts the **RADE sidecar** (`rade_helper.py`) once the receiver and `spectrumserver`
  are both confirmed up, and restarts it on its own if it later exits — without
  restarting the server with it. If RADE is not installed the server starts normally
  and the summary simply notes that the sidecar was not activated.
- Reports whether **[websdr.org] enabled** and **[websdr] register_online** are turned
  on in your `.toml`, and waits for websdr.org to answer so you can see the
  registration actually succeed rather than guessing.
- Writes human-readable progress to **`logwebsdr.txt`** (`tail -f logwebsdr.txt` to
  watch), and `spectrumserver`'s own output to **`spectrumserver.log`**, which rotates
  at 10 MB. The `[WebSDROrg]` registration lines appear in both, minus the routine
  chatter, which is kept to `spectrumserver.log` alone so it cannot swamp
  `logwebsdr.txt`: the `/~~orgstatus` callback (every few seconds) and the 60-second
  keep-alive ping. What stays in `logwebsdr.txt` is the registration story — connect,
  first ping, acceptance, one confirmation after each later reconnect — plus every
  error, which is never filtered.
- Uses a **`flock` lock** so only one receiver/server runs at a time — starting a
  different receiver first stops the current one.

A successful start ends like this:

```
  ────────────────────────────────────────────────────────────
  ✔ server is up   (spectrumserver + rx888_stream running)
  ✔ RADE sidecar running
  ✔ websdr.org registered (your.host.example:8900)
  · SDR directory posting enabled (errors only, in spectrumserver.log)
  Full log: /path/to/PhantomSDR-Plus/logwebsdr.txt
```

A `·` line is information only, nothing is wrong; `!` means something that should be
running is not, and `✖` means the server did not come up in the time allowed — in that
last case the watchdog is still retrying, so check `logwebsdr.txt`.

The scripts are fully self-contained (they derive their own directory, no hard-coded
paths). Useful overrides, all optional:
- `SPECTRUM_CORES=0-3 ./start-rtl.sh` — pin `spectrumserver` to specific CPU cores
  (`none` disables pinning; otherwise it auto-derives a sensible range from `nproc`).
- `RX_ARGS="…" ./start-rtl.sh` — override the receiver arguments without editing the
  file (`RX888_ARGS` for `start-rx888mk2.sh`).
- `RADE_ENABLED=0 ./start-rtl.sh` — start the server without the RADE sidecar.


## During installation, the script will open the site-information.json file in your favourite editor for you to edit and save. Don't skip this step!

	"siteSysop": "your name or callsign",
	"siteSysopEmailAddress": "mail@mail.net",
	"siteGridSquare": "QTH locator",
	"siteCity": "City Country",
	"siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
	"siteHardware": "Hardware you are using, ",
	"siteSoftware": "Software you are using",
	"siteReceiver": "Receiver model",
	"siteAntenna": "Receiving Antenna.",
	"siteNote": "This is a bright new open-source WebSDR project, under active development.",
	"siteIP": "http://Your site IP:port",
	"siteStats": "http://Your site IP:3001",
	"siteSDRBaseFrequency": 0,
	"siteSDRBandwidth": 30000000,
	"siteRegion": 1,
	"siteChatEnabled": true


Where: <br />

**"siteInformation"**: "https://github.com/sv1btl/PhantomSDR-Plus" — please don't change this. It points to the project's GitHub repository.<br />
**"siteIP": "http://Your site IP:port"** — e.g. http://mysite.com:9002 <br />
**"siteStats": "http://Your site IP:3001"** — e.g. http://mysite.com:3001, or any other port you chose during the monitor tool setup. <br />
**"siteSDRBandwidth"**: enter the usable bandwidth of your receiver — e.g. 2048000 for the RTL, or 60000000 or 1200000000 for the RX-888, etc.<br />

**"siteRegion"**: select your IARU region, where:<br />
1 is for Africa, Europe, the Middle East and northern Asia,<br />
2 is for the Americas — North, Central and South America, as well as the Caribbean — and<br />
3 is for Oceania, East Asia, Southeast Asia and the Pacific Islands.<br />

"siteChatEnabled": **true** determines whether the chat window is enabled.<br />


## The .toml file

You also need to edit these sections in the .toml file you use:

[server]
port=PORT # Server port
html_root="frontend/dist/" # HTML files to be hosted
otherusers=1 # Send where other users are listening, 0 to disable
threads=6

[websdr]
register_online=true # Enable directory registration updates
register_urls=[
  "https://sdr-list.xyz/api/update_websdr",
  "https://sdr.shbrg.nl/api/update_websdr"
  ] # One or more directory endpoints that accept the same JSON payload
name="CALSIGN CATsync PhantomSDR+" # Name that is shown on https://sdr-list.xyz and/or https://sdr.shbrg.nl/sdr/
antenna="WIRE" # Antenna that is shown on https://sdr-list.xyz
grid_locator="QTH_LOCATOR" # 4- or 6-character grid locator, shown on https://sdr-list.xyz and used for the distance of FT8 signals
hostname="your_IP" # If you use ddns or something to host with a domain enter it here for https://sdr-list.xyz

[server]<br />
port=9002 # Select your Server port<br />
html_root="frontend/dist/" # HTML files to be hosted<br />
otherusers=1 # Send where other users are listening, 0 to disable<br />
threads=2<br />

[websdr.org]
enabled     = true # or false
public_host = "your_ip_address"
public_port = PORT
qth         = "QTH_Locator"
description = "CALLSIGN PhantomSDR+"
email       = "mail@domain.com"
logo        = "logo.jpg"

[websdr]<br />
register_online=true # or false. If the SDR should be registered on https://sdr-list.xyz then put it to true<br />
name="Name" # Name that is shown on https://sdr-list.xyz<br />
antenna="Whip" # Antenna that is shown on https://sdr-list.xyz<br />
grid_locator="QTH Locator" # 4- or 6-character grid locator, shown on https://sdr-list.xyz and used for the distance of FT8 signals<br />
hostname="your IP, or ddns, or no-ip" # If you host with a domain via ddns or similar, enter it here for https://sdr-list.xyz<br />

[input] # depends on the receiver you use. The following settings are for the RTL<br />
sps=1536000 # RTL Input Sample Rate. For RX888 sps will be 60000000 for 0-30 MHz receiving<br />
fft_size=131072 # For RTL. FFT bins alternative for RX888 are 1048576, 2097152, 4194304 (default for RX888), 8388608, 16777216, look at https://www.mymathtables.com/numbers/power-exponentiation/power-of-2.html<br />
brightness_offset=-10 # Waterfall brightness offset. Reduce to negative if you see black regions in the waterfall<br />
frequency=1242000 # Baseband frequency<br />
signal="iq" # real or iq (real for RX888)<br />
fft_threads=2<br />
accelerator="none" # Accelerator: none, cuda, opencl<br />
audio_sps=12000 # Audio Sample Rate. Keep it always to 12000 for FT8 and Opus<br />
audio_compression="flac" # flac or opus (default is flac)<br />
smeter_offset=-2<br />
waterfall_size=1024<br />
waterfall_compression="zstd"<br />

[input.driver]<br />
name="stdin" # Driver name<br />
format="u8" # Sample format: u8, s8, u16, s16, u32, s32, f32, f64 -> use s16 for RX888<br />

[input.defaults]<br />
frequency=7120000 # Default frequency to show user<br />
modulation="LSB" # Default modulation<br />


## The bands-config.js
This file is located in frontend/src/bands-config.js and defines the bands the SysOp creates. <br />
- You will see something like the following, and you are free to edit it as you like:
   ```
   - const bands = 
   .....
   - { ITU: 1,
            name: '40m', min: -30, max: 110, initFreq: '7120000', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
	},
	{ ITU: 2,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7300000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7050000 },
              { mode: MODES.LSB, startFreq: 7050000, endFreq: 7300000 }]
	},
	{ ITU: 3,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)',
            modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
   .....
   etc
   ```
   **Where:** <br />
   - **ITU** is the region in which the server is located,
   - **min & max** are the waterfall brightness limits for the given band,
   - **initFreq** is the initial frequency to tune to when the band is selected,
   - **publishBand** sets whether the band is shown: 1 for amateur bands, 2 for broadcast bands,
   - **startFreq & endFreq** define the band limits,
   - **stepi** is the default mouse-wheel step for the band, and **modes** is the preferred default mode for the band.

- After making changes, **run ./recompile.sh in a terminal** from the PhantomSDR-Plus folder.


## Background image

The image is located at PhantomSDR-Plus/frontend/src/assets/background.jpg<br />
Replace it with the image you prefer, but keep the same filename.


## The mobile view

When the server address is entered in a mobile browser, the **mobile interface** is selected automatically. This interface is specifically optimized for smartphone screens and provides almost all the functionality available in the desktop version within a compact layout.<br />

A **second, much lighter web interface for phones**, reachable at:
```
http://your_server:port/mobile
```
It is a separate page, not a re-layout of the main app, and it draws **no waterfall**. It opens only the audio connection, which is where the saving comes from: measured on a live receiver, the full interface streams about **68 MiB/hour** (audio + waterfall + events) against roughly **30 MiB/hour** for the mobile view — a little over **half the data**. The first page load is 105 KiB against 294 KiB. <br />

It contains: frequency entry and tuning steps, modes (including SAM and the RADE **RADEL/RADEU** decoders), a digital S-meter bar with the S1…+60 dB scale, volume / squelch / buffer controls, band buttons from `bands-config.js`, bookmarks, the connected-users list with a tune-to button, and chat. The layout adapts to both portrait and landscape. <br />

Two buttons at the bottom switch to the other interfaces: **Mobile extended view** (the main app's own mobile layout) and **Full desktop view** (the complete interface, forced on a phone). The main app's mobile layout in turn carries a **Simple mobile view** button back to `/mobile`. <br />

Bookmarks are stored per device. To move them between a phone and a PC, use the Export / Import buttons in the Marks tab — they produce a QR code and a text block that can be pasted into the other browser. <br />

The page is built by **frontend/build-mobile.sh**, which `build-all.sh` also calls. It is self-contained in `dist/mobile/` with its own `assets/` folder, so that directory can be copied on its own. <br />

## The recompile tool
The **recompile.sh** script is located in the root folder of PhantomSDR-Plus and must be run in a terminal window. <br />
It offers the following options: <br />
```
What would you like to recompile?

  [1] Backend only
  [2] Frontend only (with default variant selection)
  [3] Both backend and frontend
  [0] Exit

Select an option [0-3]: 
```
If you select [2] Frontend only (with default variant selection), you will be given these options:

```
==========================================
Select Default Variant
==========================================

Which version should the site root (/) serve?

  [1] Analog S-Meter      (smeter=analog,  layout=v1)
  [2] Digital S-Meter     (smeter=digital, layout=v1)
  [3] V2 Analog S-Meter   (smeter=analog,  layout=v2)
  [4] V2 Digital S-Meter  (smeter=digital, layout=v2)

Select default variant [1-4]: 
```
Pick the default layout to be loaded initially. The other variants can still be selected from a floating popup window. <br /> 
Then a new options menu appears: <br />
```
==========================================
Frontend Build Options
==========================================

Select which frontend build script to run:

  [1] build-all.sh           - Build all versions (recommended)  [+ /mobile]
  [2] build-default.sh       - Build default version only
  [3] build-analog.sh        - Build analog S-meter version
  [4] build-digital.sh       - Build digital S-meter version
  [5] build-v2-analog.sh     - Build V2 analog S-meter version
  [6] build-v2-digital.sh    - Build V2 digital S-meter version
  [7] Custom selection       - Choose multiple builds
  [8] build-mobile.sh        - Build the mobile page only (/mobile)
  [0] Skip frontend build

Select an option [0-8]: 
```
The script will build the separate /dist folders, each with its own index.html, and will include the favicon.ico and the SysOp name in the title of each web page. <br />
Option **[1]** also builds the mobile page; **[8]** rebuilds only `/mobile` and leaves the desktop versions untouched. Options **[2]-[6]** do not touch it. <br />

> **Note:** always build through these scripts. A bare `npx vite build` empties `dist/` and removes the variant folders (`/analog`, `/digital`, `/v2-analog`, `/v2-digital`).

If you intend to **edit** the interface rather than just rebuild it, see **[Editing the Variants](docs/EDITING_VARIANTS.md)** - it covers the `isAnalog` / `isV2` flags in the merged `App.svelte`, where every variant switch sits, and how to verify an edit before trusting it.


## The Monitor tool
This is an optional feature that adds real-time server monitoring to your PhantomSDR application through an automated installation script.<br />
Please refer to the **[Readme](docs/sdr-stats/README.md)** for detailed instructions.


## The Admin area
This is an optional feature that adds a real-time admin control panel to your PhantomSDR application through an automated installation script.<br />
Please refer to the **[Readme](docs/ADMIN_PANEL_SETUP.md)** for detailed instructions.


## The waterfall floor tool
`./waterfall.sh` changes the default minimum waterfall level (the noise floor of the waterfall display), which is `-30` dB out of the box. <br />
A **higher** value (e.g. `-15`) gives a **darker** waterfall, a **lower** value (e.g. `-45`) a **brighter** one. <br />
The script asks for the new value and updates every place it is defined - `this.minWaterfall` in `frontend/src/waterfall.js` and the initial value, the "min" reset case and the bookmark defaults in `frontend/src/App.svelte` - then offers to run `./recompile.sh` for you. <br />
It finds each spot by pattern instead of by line number, so it keeps working after future updates, and it writes timestamped `.bak-*` backups of both files before editing.

```bash
./waterfall.sh          # interactive
./waterfall.sh -s       # just show the current values
./waterfall.sh -v -15   # set the value directly (add -y to skip the questions)
```


## Final notes
If you reinstall or upgrade, please back up your previous installation, as you may need some of these files: <br /> 
- site_information.json (in frontend),
- markers.json, the start and stop scripts, your .toml file and possibly chat_history.txt (all located in the root of the PhantomSDR-Plus folder),
- bands-config.js (in frontend/src). <br />
Restore your originals after the installation, so you don't have to edit them again. <br />
Don't forget to recompile afterwards.


## 📚 Documentation

For detailed information about installation, usage, and the project structure, please refer to the comprehensive documentation. The **`doc` folder** also contains translations of the main documents in several languages:

### 📖 For System Operators:

- **[Readme](docs/README.md)** - General instructions
  - Key Features
  - Supported Hardware
  - Quick Start
  - Installation
  - Performance Benchmarks
  - Usage
  - Configuration, Customization

- **[Installation Guide](docs/INSTALLATION.md)** - Complete step-by-step installation instructions
  - System requirements and preparation
  - Dependency installation (Ubuntu/Fedora)
  - Node.js and npm setup
  - OpenCL configuration (Intel/AMD/NVIDIA)
  - SDR device-specific setup
  - Systemd service configuration
  - Troubleshooting and optimization

- **[Project Structure](docs/PROJECT_STRUCTURE.md)** - Directory tree and code organization
  - Complete directory tree visualization
  - Source code structure and organization
  - Configuration file formats
  - Build system documentation
  - File modification guidelines

- **[Editing the Variants](docs/EDITING_VARIANTS.md)** - Editing the merged `App.svelte` and rebuilding it
  - What the S-meter and layout variants are
  - Which file does what
  - Making a change that affects only some variants
  - Where the variant switches are
  - Rebuilding, and how to check an edit before trusting it

- **[Monitor Tool](docs/sdr-stats/README.md)** - for detailed instructions adding the monitor tool.
  - Auto installation script
  - Files for manual installation
  
- **[Admin area](docs/ADMIN_PANEL_SETUP.md)** - for detailed instructions adding the admin control tool.
  - Auto installation script
  - Files for manual installation    

### 👥 For End Users:

- **[User Guide](docs/USER_GUIDE.md)** - Complete guide for using the WebSDR
  - Interface overview and navigation
  - Tuning and demodulation modes
  - Advanced features (AGC, NR, NB, etc.)
  - Digital mode decoders (FT8)
  - Keyboard shortcuts and bookmarks
  - Mobile device usage
  - Troubleshooting and FAQ
- **[Decoders](docs/DECODERS.md)** - Complete guide for using the decoders of the PhantomSDR

### 🎯 Quick Links:

- **Live Demo**: http://phantomsdr.no-ip.org:8900/
- **WebSDR Directory**: https://sdr-list.xyz
- **GitHub Issues**: [Report bugs or request features](https://github.com/sv1btl/PhantomSDR-Plus/issues)

---

## -- 73 de SV1BTL & SV2AMK --
