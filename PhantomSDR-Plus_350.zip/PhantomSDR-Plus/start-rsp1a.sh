#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  PhantomSDR-Plus  –  start-rsp1a.sh
#  Universal launcher + watchdog for an SDRplay RSP1A front end (via SoapySDR rx_sdr).
#
#  Same self-contained design as start-rx888mk2.sh: one script that STARTS,
#  RESTARTS, WATCHDOGS (auto-restarts on failure) and LOGS the server. Derives
#  its own directory — no hard-coded or user-specific paths. Shares stop-websdr.sh.
#
#  Usage:
#    ./start-rsp1a.sh              start (or restart) the server in the background
#    ./stop-websdr.sh              stop the server + watchdog (separate script)
#
#  Env overrides (optional):
#    SPECTRUM_CORES=0-3            pin spectrumserver to these CPUs (taskset list)
#    SPECTRUM_CORES=none          do not pin at all
#    RX_ARGS="…"                  override the rx_sdr argument string
#
#  NOTE: not tested on RSP1A hardware — it reuses the exact control/watchdog
#  logic validated on RX-888; only the receiver command/config differ. The
#  sdrplay service restart in prestart() needs root / passwordless sudo.
# ─────────────────────────────────────────────────────────────────────────────

PHANTOMDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SELF="$PHANTOMDIR/$(basename "${BASH_SOURCE[0]}")"

# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═════════════════
RX_LABEL="SDRplay RSP1A"
RX_COMM="rx_sdr"                                   # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rsp1a.toml"
FIFO="$PHANTOMDIR/rsp1a.fifo"
RX_ARGS="${RX_ARGS:--f 4000000 -s 8000000 -d driver=sdrplay -g RFGR=1 -t rfnotch_ctrl=false -F CS16 -}"
RX_CMD=(rx_sdr)                                    # binary; args come from RX_ARGS
prestart() {
    # SDRplay needs its API service running. Best-effort; needs root/passwordless
    # sudo (a password prompt here would hang the watchdog, so it's suppressed).
    service sdrplay restart >/dev/null 2>&1 \
        || sudo -n service sdrplay restart >/dev/null 2>&1 \
        || true
    sleep 2
}
# ═════════════════════════════════════════════════════════════════════════════

LOG="$PHANTOMDIR/logwebsdr.txt"
SPECTRUM="$PHANTOMDIR/build/spectrumserver"
STOP="$PHANTOMDIR/stop-websdr.sh"
LOCK="$PHANTOMDIR/.watchdog.lock"

SS_PID=""
RX_PID=""
SS_TASKSET=()

# ── logging helpers ─────────────────────────────────────────────────────────
log()   { echo "$*"          >> "$LOG"; }
stamp() { date --rfc-email   >> "$LOG"; }

# ── is a process alive (by exact command name), excluding zombies? ───────────
is_running() {
    local pid stat
    for pid in $(pgrep -x "$1" 2>/dev/null); do
        stat=$(awk '{print $3}' "/proc/$pid/stat" 2>/dev/null)
        case "$stat" in Z) ;; "") ;; *) return 0 ;; esac
    done
    return 1
}

# ── kill only the receiver/server processes (never the watchdog) ─────────────
kill_receivers() {
    killall -KILL "$RX_COMM" 2>/dev/null
    sleep 1
    killall -KILL spectrumserver 2>/dev/null
    sleep 2
    [ -n "$RX_PID" ] && wait "$RX_PID" 2>/dev/null; RX_PID=""
    [ -n "$SS_PID" ] && wait "$SS_PID" 2>/dev/null; SS_PID=""
}

# ── derive an optional CPU pin for spectrumserver (generic, via nproc) ───────
compute_taskset() {
    SS_TASKSET=()
    command -v taskset >/dev/null 2>&1 || return
    local override nproc reserve hi
    case "$(printf '%s' "${SPECTRUM_CORES:-}" | tr '[:upper:]' '[:lower:]')" in
        "")                override="" ;;
        none|off|unpinned) return ;;
        *[!0-9,-]*)        override="" ;;
        *)                 override="$SPECTRUM_CORES" ;;
    esac
    if [ -n "$override" ]; then
        SS_TASKSET=(taskset -c "$override")
        return
    fi
    nproc=$(nproc 2>/dev/null || echo 0)
    if [ "$nproc" -gt 4 ]; then
        if [ "$nproc" -ge 12 ]; then reserve=4; else reserve=$(( nproc / 4 )); [ "$reserve" -lt 1 ] && reserve=1; fi
        hi=$(( nproc - reserve - 1 ))
        SS_TASKSET=(taskset -c "0-$hi")
    fi
}

# ── start the receiver (FIFO pre-open + retry) ───────────────────────────────
start_receiver() {
    if ! command -v "${RX_CMD[0]}" >/dev/null 2>&1; then
        log "ERROR: receiver binary '${RX_CMD[0]}' not found in PATH"
        return 1
    fi
    local attempt
    for attempt in 1 2 3; do
        log "Starting $RX_LABEL ($RX_COMM, attempt $attempt/3)..."
        rm -f "$FIFO"
        mkfifo "$FIFO"
        exec 8<>"$FIFO"
        # shellcheck disable=SC2086
        "${RX_CMD[@]}" $RX_ARGS > "$FIFO" &
        RX_PID=$!
        sleep 5
        if kill -0 "$RX_PID" 2>/dev/null; then
            log "$RX_COMM running (PID $RX_PID)"
            return 0
        fi
        exec 8>&-
        RX_PID=""
        sleep 5
    done
    return 1
}

# ── start spectrumserver, then release the pre-opened FIFO fd ─────────────────
start_spectrumserver() {
    "${SS_TASKSET[@]}" "$SPECTRUM" --config "$CONFIG" < "$FIFO" &
    SS_PID=$!
    sleep 2
    exec 8>&-
    sleep 3
}

# ── bring the whole chain up and confirm it (polls, no fixed sleep) ──────────
bring_up() {
    local kind="$1" i failed=""
    kill_receivers
    if ! start_receiver; then
        stamp; log "Server ${kind} FAILED — $RX_COMM did not start"; log " "
        return 1
    fi
    start_spectrumserver

    for i in $(seq 1 24); do
        if is_running spectrumserver && is_running "$RX_COMM"; then
            stamp
            [ "$kind" = "initial" ] && log "Server started normally" || log "Server restarted normally"
            log " "
            return 0
        fi
        sleep 5
    done

    is_running spectrumserver || failed="spectrumserver"
    is_running "$RX_COMM"     || failed="${failed:+$failed + }$RX_COMM"
    stamp; log "Server ${kind} FAILED — ${failed:-processes} did not come up"; log " "
    return 1
}

# ── watchdog loop: restart in place whenever a process dies ──────────────────
watchdog_loop() {
    local reason
    while true; do
        sleep 5
        reason=""
        is_running spectrumserver || reason="spectrumserver"
        is_running "$RX_COMM"     || reason="${reason:+$reason + }$RX_COMM"
        if [ -n "$reason" ]; then
            stamp
            log "PhantomSDR Server Broken: $reason — performing restart"
            log " "
            bring_up "restart"
        fi
    done
}

# ── watchdog entry point (the detached process) ──────────────────────────────
watchdog_main() {
    exec 9>"$LOCK"
    if command -v flock >/dev/null 2>&1 && ! flock -n 9; then
        echo "$(basename "$SELF"): another watchdog is already running — exiting" >&2
        exit 0
    fi
    stamp
    log "Starting the initialization script of the PhantomSDR Server ($RX_LABEL)"
    log " "
    compute_taskset
    prestart
    bring_up "initial"
    watchdog_loop
}

# ── launcher entry point (what the user runs) ────────────────────────────────
launch() {
    [ -x "$STOP" ] && "$STOP" >/dev/null 2>&1
    sleep 5
    echo "PhantomSDR-Plus ($RX_LABEL) starting in the background."
    echo "Progress is logged to: $LOG"
    if command -v setsid >/dev/null 2>&1; then
        setsid "$SELF" --watchdog >/dev/null 2>&1 &
    else
        nohup "$SELF" --watchdog >/dev/null 2>&1 &
    fi
    disown 2>/dev/null
    exit 0
}

case "${1:-}" in
    --watchdog)          watchdog_main ;;
    ""|start|restart)    launch ;;
    *) echo "usage: $(basename "$0") [start|restart]" >&2; exit 1 ;;
esac
