# PhantomSDR-Plus

**Ein erweiterter Open-Source-WebSDR-Server mit fortschrittlichen Funktionen und futuristischem Design**

PhantomSDR-Plus ist ein Fork von PhantomSDR und stellt einen leistungsstarken Software-Defined-Radio-(SDR-)Webserver bereit, der Hunderte gleichzeitiger Nutzer bedienen kann. Er bietet eine verbesserte Benutzeroberfläche, Unterstützung mehrerer Decoder, eine Bandplan-Visualisierung sowie Kompatibilität mit verschiedenen SDR-Hardwareplattformen.

---

## 🌟 Wichtigste Funktionen

### Leistung und Skalierbarkeit
- **Mehrbenutzerbetrieb**: Hunderte gleichzeitiger Nutzer, je nach Hardware
- **Hohe Abtastrate**: Unterstützung von SDRs bis 70 MSPS (real) / 35 MSPS (IQ)
- **Hardwarebeschleunigung**: OpenCL- und CUDA-Unterstützung für GPU-beschleunigte Verarbeitung
- **Optimiertes Streaming**: FLAC- und Opus-Audiokompression mit geringer Latenz

### Benutzeroberfläche
- **Futuristisches Design**: moderne, responsive Weboberfläche
- **Für Mobilgeräte optimiert**: verbesserte mobile Oberfläche für unterwegs
- **Bandplan-Visualisierung**: interaktiver Wasserfall mit Frequenzband-Overlays
- **Anpassbare Farbpaletten**: mehrere Farbschemata für den Wasserfall
- **Doppeltes S-Meter**: wahlweise analoge oder digitale Signalanzeige

### Signalverarbeitung
- **Mehrere Demodulationsarten**: AM, FM, USB, LSB, CW und mehr
- **Synchrone AM-Demodulation**: verbesserte AM-Empfangsqualität
- **Rauschminderung**: fortschrittliches NR, NC (Noise Cancel) und NB (Noise Blanker)
- **AGC-Optionen**: mehrere Betriebsarten der automatischen Verstärkungsregelung
- **Auto-Squelch**: automatische, rauschbasierte Rauschsperrenschwelle

### Erweiterte Funktionen
- **Digitale Decoder**: FT8, FT4, FT2, CW, WSPR, HF-FAX, SSTV, NAVTEX, FSK/RTTY und FreeDV RADE, jeweils in einem eigenen Hintergrund-Thread, sodass die Dekodierung das Audio nie unterbricht (siehe [Decoder](DECODERS.md))
- **Statistik-Dashboard**: Server- und Nutzerstatistiken in Echtzeit
- **Lesezeichensystem**: Import/Export von Frequenz-Lesezeichen
- **Tastenkürzel**: effiziente Navigation und Bedienung
- **Mausrad-Unterstützung**: intuitive Frequenzabstimmung
- **WebSDR-Verzeichnis**: Anbindung an https://sdr-list.xyz

---

## 📋 Unterstützte Hardware

PhantomSDR-Plus unterstützt eine breite Palette von SDR-Empfängern:

| Gerät | Abtastrate | Format | Schnittstelle |
|-------|------------|--------|---------------|
| **RX888 MK2** | bis 64 MHz | 16 Bit | nativ |
| **RTL-SDR** | bis 3.2 MHz | 8 Bit | rtl_sdr |
| **HackRF One** | bis 20 MHz | 8 Bit | hackrf_transfer |
| **Airspy HF+** | bis 912 kHz | 16 Bit | airspy_rx |
| **Airspy Discovery** | variabel | 16 Bit | SoapySDR |
| **SDRplay RSP1A** | bis 10 MHz | 16 Bit | SoapySDR |
| **Weitere Geräte** | variabel | verschieden | SoapySDR/rx_tools |

---

## 🚀 Schnellstart

### Systemanforderungen

**Minimum:**
- Ubuntu 22.04 LTS (empfohlen) oder Fedora
- 2-Kern-CPU
- 4 GB RAM
- 10 GB Festplattenspeicher

**Empfohlen:**
- Ubuntu 24.04 LTS
- CPU mit 4+ Kernen (Ryzen 5 2600 oder Intel i5-6500T oder besser)
- 8 GB RAM
- GPU mit OpenCL-Unterstützung (optional, aber sehr empfehlenswert)
- SSD-Speicher

### Installation

```bash
# Das Repository klonen
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus

# Skripte ausführbar machen
chmod +x *.sh

# Automatische Installation ausführen
./install.sh
```

**Hinweis:** Starten Sie nach dem Ausführen von `install.sh` Ihr Terminal neu, bevor Sie fortfahren.

Ausführliche Installationsanweisungen finden Sie in [INSTALLATION.md](INSTALLATION.md).

---

## 📊 Leistungsmessungen

| Hardware | Abtastrate | CPU-Auslastung | Nutzerkapazität |
|----------|------------|----------------|------------------|
| Ryzen 5 2600 (alle Kerne) | 64 MHz (32 MHz IQ) | 38–40 % | 100+ Nutzer |
| AMD RX 580 (GPU) | 64 MHz (32 MHz IQ) | 28–35 % | 100+ Nutzer |
| Intel i5-6500T (mit OpenCL) | 60 MHz (30 MHz IQ) | 10–12 % | 100+ Nutzer |

*Hinweis: Der CPU-Mehraufwand pro Nutzer ist minimal (< 1 % pro Nutzer), wenn die Hardwarebeschleunigung aktiviert ist.*

---

## 🎯 Verwendung

### Grundlegender Betrieb

1. **SDR konfigurieren**: Bearbeiten Sie die passende Konfigurationsdatei (z. B. `config-rtl.toml`)
2. **Standortinformationen aktualisieren**: Bearbeiten Sie `frontend/site-information.json`
3. **Server starten**: Führen Sie das passende Startskript aus:
   ```bash
   ./start-rtl.sh      # Für RTL-SDR
   ./start-rsp1a.sh    # Für SDRplay RSP1A
   ./start-airspyhf.sh # Für Airspy HF+
   ./start-rx888mk2.sh # Für RX888 MK2
   ```
   Jedes Startskript ist **eigenständig**: Es beendet eine laufende Instanz, startet den
   Empfänger + `spectrumserver`, **löst sich in den Hintergrund** (übersteht das Schließen des
   Terminals) und betreibt einen **Watchdog**, der die Kette bei einem Absturz automatisch neu
   startet. Der Fortschritt wird in `logwebsdr.txt` protokolliert — beobachten Sie ihn mit
   `tail -f logwebsdr.txt`. Ein erneuter Aufruf eines Startskripts entspricht einem sauberen
   Neustart, und eine `flock`-Sperre stellt sicher, dass immer nur ein Empfänger läuft.
   Optional: `SPECTRUM_CORES=0-3`, um CPUs festzulegen, `RX_ARGS="…"`, um Empfängerargumente
   ohne Bearbeiten der Datei zu überschreiben (`RX888_ARGS` beim RX888).
4. **Oberfläche aufrufen**: Öffnen Sie im Browser `http://localhost:PORT` (Standardport je nach Konfiguration unterschiedlich)

### Server stoppen

Ein gemeinsames Stopp-Skript funktioniert für **jeden** Empfänger — es beendet zuerst den
Watchdog (damit er nicht automatisch neu startet), dann den Empfänger und `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## 🔧 Konfiguration

### Wesentliche Konfigurationsdateien

1. **`config-[Gerät].toml`** – Server- und SDR-Konfiguration
   - Servereinstellungen (Port, Threads, HTML-Wurzelverzeichnis)
   - Eingangseinstellungen (Abtastrate, FFT-Größe, Frequenz)
   - Optionen zur WebSDR-Registrierung
   - Einstellungen zur Audiokompression
   - Nach Änderungen den Server neu starten.

2. **`frontend/site-information.json`** – öffentliche Standortinformationen
   - Angaben zum Betreiber (Rufzeichen, E-Mail, Standort)
   - Informationen zu Hardware und Antenne
   - Region- und Bandbreiteneinstellungen
   - Chat aktivieren/deaktivieren
   - Führen Sie nach Änderungen recompile.sh in einem Terminal aus.

3. **`markers.json`** – Frequenzmarker und Bandplan

4. **`frontend/src/bands-config.js`** – Bandplan-Konfiguration
   Diese Datei liegt unter frontend/src/bands-config.js und definiert die Bänder, die der SysOp anlegt. <br />
- Sie sehen etwa Folgendes und können es nach Belieben bearbeiten:
   ```
   - const bands = 
   .....
   - { ITU: 1,
            name: '40m', min: -30, max: 110, initFreq: '7120000', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
	},
	{ ITU: 2,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7300000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7050000 },
              { mode: MODES.LSB, startFreq: 7050000, endFreq: 7300000 }]
	},
	{ ITU: 3,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)',
            modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
   .....
   etc
   ```
   **Dabei gilt:** <br />
   - **ITU** ist die Region, in der sich der Server befindet,
   - **min und max** sind die Helligkeitsgrenzen des Wasserfalls für das jeweilige Band,
   - **initFreq** ist die Frequenz, auf die bei Auswahl des Bandes zunächst abgestimmt wird,
   - **publishBand** legt fest, ob das Band angezeigt wird: 1 für Amateurbänder, 2 für Rundfunkbänder,
   - **startFreq und endFreq** definieren die Bandgrenzen,
   - **stepi** ist die Standard-Mausradschrittweite für das Band, und **modes** ist die bevorzugte Standardbetriebsart für das Band.

- Führen Sie nach Änderungen **recompile.sh in einem Terminal** aus dem Ordner PhantomSDR-Plus aus.

Konfigurationsbeispiele finden Sie in den mitgelieferten Beispieldateien:
- `config-rtl.toml` – RTL-SDR-Konfiguration
- `config-rsp1a.toml` – SDRplay-RSP1A-Konfiguration
- `config-airspyhf.toml` – Airspy-HF+-Konfiguration
- `config-rx888mk2.toml` – RX888-MK2-Konfiguration

---

## 🎨 Anpassung

### Hintergrundbild ändern

Ersetzen Sie `frontend/src/assets/background.jpg` durch Ihr bevorzugtes Bild (behalten Sie denselben Dateinamen bei).

- Führen Sie nach der Änderung recompile.sh in einem Terminal aus.


### Auswahl des Audio-Codecs

Wählen Sie in Ihrer `.toml`-Konfiguration zwischen FLAC und Opus:
```toml
[input]
audio_compression="opus"  # or "flac"
```
- Starten Sie nach der Änderung den Server neu.


### S-Meter-Kalibrierung
Das S-Meter ist bereits kalibriert; falls Sie es nachjustieren möchten, gehen Sie so vor:
- Für das **digitale S-Meter** passen Sie es in der von Ihnen verwendeten .toml-Datei an. Suchen Sie 'smeter_offset=' im Abschnitt [input], ändern Sie den Wert und starten Sie den Server neu.
- Für das **analoge S-Meter** bearbeiten Sie 'App__analog_smeter_.svelte' und 'App__v2_analog_smeter_.svelte', beide in frontend/src. Suchen Sie 'const visualGain = ' und ändern Sie den Wert so, dass digitales und analoges S-Meter dasselbe anzeigen. Anschließend neu kompilieren. Ein Neustart des Servers ist nicht erforderlich.


### GUI-Varianten

Im Verzeichnis frontend stehen mehrere GUI-Varianten zur Verfügung. Zum Umschalten:
- Führen Sie recompile.sh in einem Terminal aus.

---

## 📚 Dokumentation

- **[INSTALLATION.md](INSTALLATION.md)** – vollständige Installationsanleitung für Systembetreiber
- **[ADMIN_PANEL_SETUP.md](ADMIN_PANEL_SETUP.md)** – Installationsanleitung für administrierende Systembetreiber
- **[USER_GUIDE.md](USER_GUIDE.md)** – Anleitung für Endnutzer zur Bedienung des WebSDR
- **[PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)** – Verzeichnisstruktur und Codeorganisation

---

## 🌐 Online-WebSDR-Liste

Registrieren Sie Ihren WebSDR im offiziellen Verzeichnis: https://sdr-list.xyz

Setzen Sie `register_online=true` in Ihrer `.toml`-Konfigurationsdatei, um sich automatisch zu registrieren.

---

## 🐛 Fehlerbehebung

### Häufige Probleme

**OpenCL funktioniert nicht**
- Stellen Sie sicher, dass die Treiber korrekt installiert sind
- Prüfen Sie es mit dem Befehl `clinfo`
- Siehe INSTALLATION.md für die ausführliche OpenCL-Einrichtung

**Probleme mit der Audiolatenz**
- Wechseln Sie testweise zwischen den Codecs FLAC und Opus
- Passen Sie die Puffereinstellungen in der Konfiguration an
- Sorgen Sie für ausreichende CPU-/GPU-Ressourcen

**Build-Fehler**
- Prüfen Sie, ob alle Abhängigkeiten installiert sind
- Versuchen Sie, das Build-Verzeichnis zu bereinigen: `rm -rf build && meson setup build`
- Prüfen Sie auf widersprüchliche Bibliotheksversionen

---

## 🤝 Mitwirken

Beiträge sind willkommen! Dies ist ein unabhängiger Fork mit zusätzlichen Funktionen. Bitte:

1. Forken Sie das Repository
2. Erstellen Sie einen Feature-Branch
3. Committen Sie Ihre Änderungen
4. Pushen Sie den Branch
5. Erstellen Sie einen Pull Request

---

## 📄 Lizenz

Dieses Projekt steht unter der GNU General Public License v3.0 – Einzelheiten finden Sie in der Datei [LICENSE](../../LICENSE).

---

## 👥 Autoren und Danksagungen

- **SV1BTL und SV2AMK** – Entwicklung und Erweiterungen von PhantomSDR-Plus
- Basierend auf dem ursprünglichen PhantomSDR-Projekt

---

## 🔗 Links

- **Live-Demo**: http://phantomsdr.no-ip.org:8900/
- **WebSDR-Verzeichnis**: https://sdr-list.xyz
- **GitHub-Repository**: https://github.com/sv1btl/PhantomSDR-Plus

---

## 📞 Unterstützung

- **Probleme**: Melden Sie Fehler über [GitHub Issues](https://github.com/sv1btl/PhantomSDR-Plus/issues)
- **E-Mail**: Kontakt sv1btl@otenet.gr 

---

## ⚡ Leistungstipps

1. **Aktivieren Sie OpenCL/CUDA** für GPU-Beschleunigung – reduziert die CPU-Last drastisch
2. **Verwenden Sie SSD-Speicher** für bessere E/A-Leistung
3. **Weisen Sie ausreichend RAM zu** – mindestens 8 GB empfohlen
4. **Optimieren Sie die FFT-Größe** – größere FFT = bessere Auflösung, aber mehr CPU-Last
5. **Erwägen Sie eine dedizierte GPU** – AMD oder NVIDIA mit OpenCL-Unterstützung

---

**73 de SV1BTL & SV2AMK**

*Ausführliche Einrichtungsanweisungen finden Sie in INSTALLATION.md*
*Die Bedienungsanleitung für Endnutzer finden Sie in USER_GUIDE.md*
