# PhantomSDR-Plus — Benutzerhandbuch der Decoder

Dieses Handbuch behandelt alle in PhantomSDR-Plus integrierten Decoder. Alle Decoder werden auf dieselbe, nachfolgend beschriebene Weise aktiviert; danach folgen die Einrichtungsanweisungen für jeden einzelnen Decoder.

---

## Inhaltsverzeichnis

1. [Einen Decoder starten](#1-einen-decoder-starten)
2. [FT8](#2-ft8)
3. [FT4-FT2](#3-ft4-ft2)
4. [CW — Morsetelegrafie](#4-cw--morsetelegrafie)
5. [WSPR](#5-wspr)
6. [HF-FAX / WEFAX](#6-hf-fax--wefax)
7. [NAVTEX](#7-navtex)
8. [FSK / RTTY](#8-fsk--rtty)
9. [SSTV](#9-sstv)
10. [Allgemeine Tipps](#10-allgemeine-tipps)

---

## 1. Einen Decoder starten

Alle Decoder erreichen Sie über den Abschnitt **Decoder Options** unterhalb der Bedienelemente des Audiospektrogramms im Hauptfenster.

**Schritte:**

1. Klicken Sie auf die Schaltfläche **Decoder: OFF**, um sie auf **Decoder: ON** umzuschalten (sie wird blau, wenn sie aktiv ist).
2. Öffnen Sie das Auswahlmenü, das rechts neben der Schaltfläche erscheint, und wählen Sie den gewünschten Decoder.
3. Das Bedienfeld des gewählten Decoders erscheint unterhalb der Bedienelemente — folgen Sie den decoderspezifischen Anweisungen im entsprechenden Abschnitt dieses Handbuchs.
4. Um die Dekodierung zu beenden, wählen Sie **— Select decoder —** aus dem Menü, oder klicken Sie auf **Decoder: ON**, um wieder auf OFF zu schalten.

> Es kann immer nur ein Decoder aktiv sein. Der Wechsel zu einem anderen Decoder beendet den vorherigen automatisch.

**Die Dekodierung läuft im Hintergrund.** SSTV, HF-FAX, NAVTEX, FSK/RTTY und CW laufen jeweils in einem eigenen Web-Worker-Thread, sodass die Dekodierarbeit nie mit der Audiowiedergabe oder dem Wasserfall konkurriert. Das Starten oder Beenden eines Decoders unterbricht den Ton nicht, und die Oberfläche bleibt reaktionsschnell, während ein Bild oder eine Seite empfangen wird. Alle Decoder erhalten Rohaudio, das *vor* AGC, Rauschminderung und Stummschaltung abgegriffen wird — den Empfänger stummzuschalten oder diese Einstellungen nach Gehör zu verändern, wirkt sich also nicht auf die Dekodierung aus.

---

## 2. FT8

**Worum es geht:** FT8 ist eine weit verbreitete digitale Schwachsignal-Betriebsart, die Funkamateure weltweit nutzen. Aussendungen dauern genau 15 Sekunden, und das Protokoll kann Signale bis 20–25 dB unter dem Rauschteppich aufnehmen. Es ist die am häufigsten genutzte Betriebsart für Weitverbindungen (DX).

### Empfohlene Frequenzen (USB)

| Band | Frequenz |
|------|----------|
| 160 m | 1.840 MHz |
| 80 m  | 3.573 MHz |
| 40 m  | 7.074 MHz |
| 30 m  | 10.136 MHz |
| 20 m  | 14.074 MHz |
| 17 m  | 18.100 MHz |
| 15 m  | 21.074 MHz |
| 12 m  | 24.915 MHz |
| 10 m  | 28.074 MHz |

### Einrichtung

1. Stimmen Sie auf eine der oben genannten FT8-Frequenzen ab und stellen Sie die Betriebsart auf **USB**.
2. Aktivieren Sie den Decoder und wählen Sie **FT8** aus dem Menü.
3. Das Bedienfeld **FT8 Messages** erscheint automatisch darunter.

### Die Ausgabe lesen

Die Meldungsliste zeigt dekodierte Aussendungen, sobald sie eintreffen. Jeder 15-Sekunden-Zyklus liefert einen neuen Schwung Meldungen. Das Feld **Farthest** (oben rechts im Bedienfeld) zeigt die größte in der laufenden Sitzung dekodierte Entfernung in Kilometern.

Typisches Meldungsformat: `CQ DX AA1BB FN31` — ein CQ-Ruf des Rufzeichens AA1BB aus dem Planquadrat FN31.

> **Tipp:** FT8 ist eng zeitsynchronisiert. Ihr Browser nutzt die Uhr Ihres Rechners; weicht die Systemzeit um mehr als ein paar Sekunden ab, schlägt die Dekodierung fehl. Halten Sie Ihre Systemzeit per NTP synchron.

---

## 3. FT4-FT2

**Worum es geht:** FT4 ist eine schnellere Variante von FT8, gedacht für Contest-Betrieb. Jeder Sendezyklus dauert 7,5 Sekunden (die Hälfte von FT8), wodurch die Betriebsart doppelt so schnell ist, aber ein etwas stärkeres Signal benötigt.
FT2 ist eine noch schnellere Variante von FT8. Es handelt sich um eine ultraschnelle 77-Bit-Betriebsart mit TR-Perioden von 3,75 Sekunden (= die Hälfte von FT4) — noch experimentell.

### Empfohlene Frequenzen (USB)

| Band | Frequenz FT4|
|------|-----------|
| 80 m  | 3.575 MHz |
| 40 m  | 7.047 MHz |
| 30 m  | 10.140 MHz |
| 20 m  | 14.080 MHz |
| 15 m  | 21.140 MHz |
| 10 m  | 28.180 MHz |

| Band | Frequenz FT2|
|------|-----------|
|160 m | 1.843 bis 1.846 |
|80 m   | 3.578 bis 3.581 |
|60 m   | 5.360 (regionale Vorschriften beachten) |
|40 m   | 7.052 bis 7.062 |
|30 m   | 10.144 |
|20 m   | 14.084 |
|17 m   | 18.108 |
|15 m   | 21.144 |
|12 m   | 24.923 |
|10 m   | 28.184 |

### Einrichtung

1. Stimmen Sie auf eine FT4-Frequenz ab und stellen Sie die Betriebsart auf **USB**.
2. Aktivieren Sie den Decoder und wählen Sie **FT4** oder **FT2** aus dem Menü.
3. Das Bedienfeld **FT4 Messages** bzw. **FT2 Messages** erscheint darunter, im Aufbau identisch mit dem FT8-Bedienfeld.

> **Hinweis:** FT4 und FT8 verwenden unterschiedliche Spektralformate und sind nicht austauschbar. Achten Sie darauf, dass Sie auf einer FT4-Frequenz stehen, wenn Sie diesen Decoder nutzen.

---

## 4. CW — Morsetelegrafie

**Worum es geht:** Der CW-Decoder horcht auf Morsesignale (Continuous Wave) und wandelt sie in Echtzeit in Text um. Er verfolgt die Signalfrequenz automatisch und passt sich der Gebegeschwindigkeit des Operators an.

### Empfohlene Frequenzen

CW ist auf allen Amateurbändern aktiv, typischerweise im unteren Teil jedes Bandes. Übliche Stellen:

| Band | Segment |
|------|---------|
| 40 m  | 7.000–7.040 MHz |
| 20 m  | 14.000–14.070 MHz |
| 15 m  | 21.000–21.080 MHz |

### Einrichtung

1. Stimmen Sie auf ein CW-Signal ab und verwenden Sie je nach Situation die Demodulationsart **CW** oder **CW-L**.
2. Aktivieren Sie den Decoder und wählen Sie **CW** aus dem Menü.
3. Das Bedienfeld **CW Decoder** erscheint darunter.

### Die Ausgabe lesen

- Die Kopfzeile des Bedienfelds zeigt die erkannte Signalfrequenz in Hz (z. B. `≈ 700 Hz`) und die geschätzte Gebegeschwindigkeit in Wörtern pro Minute (z. B. `· 22 WPM`).
- Wird kein Signal erkannt, zeigt die Kopfzeile **scanning…**
- Der dekodierte Text läuft in bernsteinfarbener Festbreitenschrift durch. Der blinkende Cursor (▋) markiert die Stelle, an der gerade geschrieben wird.
- Klicken Sie auf **Clear**, um den Ausgabepuffer zu löschen.

> **Tipps:**
> - Zentrieren Sie Ihren Durchlassbereich auf den CW-Ton. Der Decoder arbeitet am besten, wenn das CW-Signal etwa zwischen 400 und 900 Hz im Audiospektrum liegt.
> - Sehr schnelles oder sehr langsames Geben sowie stark handgetastetes (unregelmäßiges) Morsen können die Genauigkeit verringern.
> - Der Decoder liefert die besten Ergebnisse bei einem einzelnen sauberen Signal. Starkes QRM benachbarter Signale auf demselben Band kann ihn verwirren.

---

## 5. WSPR

**Worum es geht:** WSPR (Weak Signal Propagation Reporter, ausgesprochen „whisper") ist eine Bakenbetriebsart für extrem schwache Signale, die KW-Ausbreitungswege weltweit kartiert. Jede Aussendung dauert etwa 110 Sekunden und passt in einen 200 Hz breiten Kanal. Der Decoder wartet auf einen vollständigen, an UTC ausgerichteten 2-Minuten-Zeitschlitz, bevor er dekodiert.

### Empfohlene Frequenzen (USB, Anzeigefrequenz)

| Band | Anzeigefrequenz |
|------|-----------------|
| 160 m | 1.836.600 MHz |
| 80 m  | 3.568.600 MHz |
| 40 m  | 7.038.600 MHz |
| 30 m  | 10.138.700 MHz |
| 20 m  | 14.095.600 MHz |
| 17 m  | 18.104.600 MHz |
| 15 m  | 21.094.600 MHz |

### Einrichtung

1. Stimmen Sie auf eine der oben genannten WSPR-Anzeigefrequenzen ab und stellen Sie die Betriebsart auf **USB**.
2. Das WSPR-Signal belegt den Audiobereich 1400–1600 Hz. Der Durchlassbereich muss nicht weiter angepasst werden.
3. Aktivieren Sie den Decoder und wählen Sie **WSPR** aus dem Menü.
4. Das Bedienfeld **WSPR-2 Decoder** erscheint darunter.

### Die Ausgabe lesen

Das Bedienfeld zeigt einen Fortschrittsbalken für den aktuellen 2-Minuten-Zeitschlitz:

- **Cyanfarbener Balken füllt sich** — Signaldaten werden gesammelt (0–116 s im Zeitschlitz).
- **Bernsteinfarbener Balken pulsiert** — Dekodierung läuft (letzte ~4 s des Zeitschlitzes).
- **Leerer Balken** — Warten auf die nächste gerade UTC-Minute.

Jeder erfolgreich dekodierte Spot erscheint in einer Tabelle mit folgenden Spalten:

| Spalte | Bedeutung |
|--------|-----------|
| UTC | Zeit des Spots (gerade Minute) |
| Callsign | Die Station, die gesendet hat |
| Grid | Maidenhead-Locator des Senders |
| Power | Sendeleistung in dBm |
| Freq | Genaue Audiofrequenz (Hz) innerhalb des WSPR-Durchlassbereichs |
| SNR | Signal-Rausch-Verhältnis in dB |

Klicken Sie auf **Clear**, um die Spot-Liste zu löschen.

> **Tipp:** Die WSPR-Dekodierung erfordert eine sehr genaue Systemzeit (innerhalb ±1 Sekunde zu UTC). Der erste Zeitschlitz nach dem Aktivieren des Decoders beginnt mit der nächsten geraden UTC-Minute — eine kurze Wartezeit ist normal.

---

## 6. HF-FAX / WEFAX

**Worum es geht:** HF-Radiofax (auch WEFAX genannt) wird von Küstenwachen und Wetterdiensten weltweit genutzt, um Wetterkarten, Seegangskarten und Bodenanalysen über Kurzwelle auszustrahlen. Der Decoder setzt das Bild Zeile für Zeile zusammen, während es empfangen wird.

### Einrichtung

1. Aktivieren Sie den Decoder und wählen Sie **HF FAX / WEFAX** aus dem Menü.
2. Das Bedienfeld **HF FAX / WEFAX Receiver** erscheint darunter.
3. **Wählen Sie eine Station** im Auswahlmenü Station. Über 20 Stationen stehen zur Verfügung und decken Europa, Asien, Ozeanien und Amerika ab (z. B. DDH3/DDK3 Deutschland, SVJ4/GR Griechenland, JMH Japan, NMG USA New Orleans).
4. Sendet die Station auf mehreren Frequenzen, wählen Sie die gewünschte im Untermenü **Frequency**.
5. Klicken Sie auf **▶ Tune**, um den Wasserfall automatisch auf diese Station abzustimmen.
6. Die Betriebsart wird automatisch auf **USB** gesetzt.

### Sendeplan

Ist eine Station gewählt, erscheint eine Countdown-Tabelle **Next Transmissions** mit den nächsten 4 geplanten Aussendungen in UTC und einem laufenden Countdown:

- Normal (grau/grün) — die Aussendung steht bevor.
- **Bernstein ⚡** — die Aussendung beginnt in weniger als 3 Minuten; jetzt den Decoder scharfschalten.
- **Rot ●** — die Aussendung beginnt in weniger als 30 Sekunden; der Empfang steht unmittelbar bevor.

### Parameter

Die meisten Stationen verwenden die Standardvorgaben (mit ★ markiert). Ändern Sie sie nur, wenn Sie wissen, dass die Station abweichende Einstellungen nutzt.

| Parameter | Vorgabe | Beschreibung |
|-----------|---------|--------------|
| LPM | 120 ★ | Zeilen pro Minute — die Trommeldrehzahl |
| IOC | 576 ★ | Kooperationsindex — bestimmt die Pixel pro Zeile |
| Shift | 800 Hz ★ | Frequenzhub zwischen Schwarz- und Weißton |

### Bedienelemente

- **⇔ Auto-align** — standardmäßig aktiviert. Synchronisiert automatisch auf das Phasensignal zu Beginn jedes Bildes. Deaktivieren Sie es nur, wenn Sie bei einem nachweislich guten Signal Ausrichtungsprobleme haben.
- **⇅ Invert** — vertauscht Schwarz und Weiß. Verwenden Sie es, wenn das Bild als Negativ erscheint (weiße Flächen dort, wo Schwarz sein sollte).
- **↺ Refresh** — löscht die Zeichenfläche und setzt den Decoder zurück. Nutzen Sie es zwischen zwei Aussendungen oder wenn das Bild reißt oder verläuft.
- **⤓ Save PNG** — speichert die aktuelle Zeichenfläche als PNG-Datei auf Ihrem Rechner.

### Statusanzeigen

Unter dem Bild zeigen zwei Tonanzeigen:

- **300 Hz phasing** — leuchtet cyan, wenn der Phasenton am Bildanfang erkannt wird.
- **450 Hz stop** — leuchtet rot, wenn der Stoppton am Bildende erkannt wird.

> **Hinweis:** Das Bild läuft nach oben — die zuletzt empfangene Zeile erscheint immer unten auf der Zeichenfläche. Steht **[PHASING]** in der Kopfzeile, hat der Decoder auf einen neuen Bildanfang eingerastet.

---

## 7. NAVTEX

**Worum es geht:** NAVTEX ist das internationale seefunkgestützte Aussendungssystem für küstennahe Sicherheitsinformationen — Navigationswarnungen, Wettervorhersagen sowie Such- und Rettungsmeldungen. Es verwendet 100-Baud-FSK (SITOR-B mit FEC) und wird weltweit auf eigenen Kanälen empfangen.

### Verfügbare Kanäle

| Kanal | Frequenz | Verwendung |
|-------|----------|------------|
| International | 518 kHz | Englischsprachig, international |
| National | 490 kHz | Aussendungen in der Landessprache |
| KW (×5) | 4209.5 / 6314 / 8416.5 / 12579 / 16806.5 kHz | KW-NAVTEX mit großer Reichweite |

### Einrichtung

1. Aktivieren Sie den Decoder und wählen Sie **NAVTEX** aus dem Menü. Der Empfänger schaltet automatisch auf **USB**.
2. Das Bedienfeld **NAVTEX Receiver** erscheint.
3. Wählen Sie den gewünschten Kanal im Menü **Station** (z. B. `International — 518 kHz`).
4. Klicken Sie auf **⇒ Tune & Set IF**, um den Wasserfall automatisch abzustimmen und den Durchlassbereich auf das richtige Audiofenster einzuengen. Die Betriebsart wird automatisch auf **USB** gesetzt. Die Anzeigefrequenz liegt 500 Hz unter der Kanalmitte, sodass das NAVTEX-Signal bei 500 Hz im Audio erscheint.

### Sendeplan

Die Plantabelle listet alle bekannten Stationen des gewählten Kanals mit:

- ihrem ITU-Kennbuchstaben und der Landesflagge
- der nächsten Sendezeit in UTC
- einem laufenden Countdown bis zur nächsten Aussendung
- **Bernstein ⚡** bei unter 2 Minuten / **Rot ●** bei unter 30 Sekunden — jetzt den Decoder scharfschalten

### Die Ausgabe lesen

Der dekodierte Text erscheint in blaugrüner Festbreitenschrift. Die Meldungsgrenzen sind klar markiert:

```
━━ ZCZC MA12 ━━
... message content ...
━━ NNNN ━━
```

`ZCZC` markiert den Anfang einer Meldung. Die drei folgenden Zeichen kennzeichnen Station (`M`), Thema (`A` = Navigationswarnungen) und laufende Nummer (`12`). `NNNN` markiert das Ende.

Klicken Sie auf **Clear**, um den Meldungspuffer zu löschen.

> **Hinweis:** NAVTEX arbeitet auf MF- und LF-Frequenzen (518/490 kHz). Die Empfangsreichweite beträgt typischerweise 200–400 Seemeilen vom Sender. Die KW-Kanäle (4–17 MHz) bieten eine deutlich größere Reichweite.

---

## 8. FSK / RTTY

**Worum es geht:** Ein universeller FSK-(Frequency-Shift Keying-)/RTTY-Decoder mit drei Betriebsvarianten: maritimes FSK (SITOR), Wetter-RTTY und Amateur-RTTY. Jede Variante bringt eine auf ihre Standardparameter abgestimmte Voreinstellung mit.

### Varianten und Voreinstellungen

| Variante | Mitte | Shift | Baud | Rahmen | Kodierung |
|----------|-------|-------|------|--------|-----------|
| Maritimes FSK / SITOR | 500 Hz | 170 Hz | 100 | 7N1 | CCIR-476 |
| Wetter-RTTY | 1000 Hz | 450 Hz | 50 | 5N1.5 | ITA2 |
| Amateur-RTTY | 1000 Hz | 170 Hz | 45.45 | 5N1.5 | ITA2 |

### Einrichtung

1. Aktivieren Sie den Decoder und wählen Sie **FSK / RTTY** aus dem Menü.
2. Das Bedienfeld **FSK / RTTY Decoder** erscheint.
3. Wählen Sie die **Variant** (Maritime, Weather oder Ham). Die Parameter werden automatisch angepasst.
4. Wählen Sie im Menü **Known frequency** eine übliche Frequenz für die gewählte Variante und klicken Sie auf **Tune**, um dorthin zu springen.
5. Stimmen Sie fein nach, bis der dekodierte Text stabil und lesbar wird.

### Bekannte Frequenzen nach Variante

**Maritimes FSK / SITOR**
- 518.0 kHz — internationales NAVTEX
- 490.0 kHz — nationales NAVTEX
- 4209.5 / 6314,0 / 8416.5 / 12579,0 / 16806.5 / 22376.0 kHz — KW-SITOR

**Wetter-RTTY**
- 4583,0 / 7646,0 / 10100,8 / 11039,0 / 14467.3 kHz — DWD (Deutscher Wetterdienst)

**Amateur-RTTY**
- 3590 kHz (80 m), 7043 kHz (40 m), 10143 kHz (30 m), 14083 kHz (20 m), 21083 kHz (15 m), 28083 kHz (10 m)

### Parameter

| Parameter | Beschreibung |
|-----------|--------------|
| Center audio (Hz) | Die Audiofrequenz der Mitte zwischen Mark und Space |
| Shift (Hz) | Frequenzunterschied zwischen Mark- und Space-Ton |
| Baud | Symbolrate |
| Framing | Datenbits, Parität, Stoppbits (z. B. 7N1 = 7 Datenbits, keine Parität, 1 Stoppbit) |
| Encoding | Zeichensatz (CCIR-476, ITA2/Baudot oder ASCII) |
| Invert mark / space | Vertauscht Mark- und Space-Ton |
| Auto shift detect | Versucht, den Shift automatisch aus dem eingehenden Signal zu messen |

### Signalmesswerte

Die Statusleiste zeigt laufende Messwerte:

- **Mark / Space** — gemessene Audiofrequenz des jeweiligen Tons (Hz)
- **SNR** — Signal-Rausch-Verhältnis in dB
- **Lock** — Einrastqualität des Decoders in Prozent
- **Timing** — `LOCKED`, wenn der Bittakt synchronisiert ist, `SEARCH` während der Suche

### Weitere Bedienelemente

- **⇒ Set IF Band-Pass** — engt den Durchlassbereich des Empfängers so ein, dass er das FSK-Signal anhand der aktuellen Mitten- und Shift-Einstellungen eng umschließt. Nach dem Abstimmen zu verwenden, um Trennschärfe zu verbessern und Nachbarkanalstörungen zu verringern.
- **⟳ Auto-tune Center** — löst einen automatischen Suchlauf aus, um die Mark-/Space-Töne zu finden und einzurasten. Nützlich, wenn Sie nahe an der richtigen Frequenz sind, die Töne aber leicht danebenliegen.

> **Hinweis zur Betriebsart:** Der FSK-Decoder übernimmt im aktiven Zustand die Steuerung von Demodulationsart und ZF-Durchlassbereich. Beide werden automatisch wiederhergestellt, wenn Sie den Decoder abschalten.
>
> **Hinweis zur Polarität:** Für RTTY (Wetter) müssen Sie meist **Invert mark / space** ankreuzen. Für maritimes FSK (SITOR-/NAVTEX-artig) und Amateur-RTTY lassen Sie das Kästchen leer. Ist der dekodierte Text unleserlich, sollten Sie zuerst dieses Kästchen umschalten.

---

## 9. SSTV

**Worum es geht:** Slow-Scan-Television überträgt Standbilder über einen gewöhnlichen SSB-Sprechfunkkanal, Zeile für Zeile, als frequenzmodulierten Ton zwischen 1500 Hz (Schwarz) und 2300 Hz (Weiß). Ein vollständiges Bild dauert je nach Betriebsart zwischen 36 Sekunden und 4½ Minuten.

### Empfohlene Frequenzen (USB)

| Band | Frequenz | Betriebsart | Anmerkungen |
|------|----------|-------------|-------------|
| 20 m | 14.230 MHz | USB | Die wichtigste internationale SSTV-Anruffrequenz — mit Abstand die aktivste |
| 20 m | 14.233 MHz | USB | Ausweichfrequenz, wenn 14.230 belegt ist |
| 15 m | 21.340 MHz | USB | |
| 10 m | 28.680 MHz | USB | Aktiv bei Bandöffnungen |
| 40 m | 7.171 MHz | LSB | |
| 80 m | 3.845 MHz | LSB | Regional, abends |

**Das Seitenband wird für Sie gewählt.** Beim Start des Decoders wird **LSB unterhalb 10 MHz** und **USB oberhalb** gewählt, entsprechend der üblichen Amateurfunkpraxis. Auf dem falschen Seitenband ist die Tonzuordnung invertiert, und das Bild lässt sich nicht dekodieren. Treffen Sie auf eine Station, die sich nicht an die Konvention hält, wechseln Sie das Seitenband einfach von Hand — der Decoder läuft weiter, löscht das Bild und beginnt mit der neuen Einstellung von vorn.

### Einrichtung

1. Aktivieren Sie den Decoder und wählen Sie **SSTV** aus dem Menü. Der Empfänger wechselt das Seitenband automatisch — USB über 10 MHz, LSB darunter.
2. Stimmen Sie so ab, dass die Bildtöne in der Mitte des Durchlassbereichs liegen. Ein richtig abgestimmtes Signal hat seine Synchronimpulse bei 1200 Hz und den Bildinhalt zwischen 1500 und 2300 Hz.
3. Belassen Sie **Mode** auf **Auto**, sofern Sie nicht bereits wissen, was gesendet wird. Das Bild baut sich Zeile für Zeile auf.

### Betriebsarten

| Einstellung | Bild | Dauer |
|-------------|------|-------|
| **Auto** | automatisch erkannt | — |
| Martin M1 / M2 | 320×256 Farbe | 114 s / 58 s |
| Scottie S1 / S2 | 320×256 Farbe | 110 s / 71 s |
| Scottie DX | 320×256 Farbe | 269 s |
| Robot 36 / 72 | 320×240 Farbe | 36 s / 72 s |

**Auto** arbeitet auf zwei Wegen: Es liest den **VIS-Kopf** — den digitalen Betriebsartencode, der in den ersten 300 ms einer Aussendung gesendet wird — und bestimmt, falls der Kopf verpasst wurde (Sie sind zu spät eingestiegen oder er ging im QSB verloren), die Betriebsart stattdessen aus dem Timing der Synchronimpulse. Die Wahl einer bestimmten Betriebsart erzwingt diese, aber der Decoder prüft dennoch die Synchronisation, bevor er etwas zeichnet — eine falsche Wahl liefert also kein Bild statt Rauschen.

### Die Ausgabe lesen

Die Statuszeile unter den Bedienelementen zeigt, was der Decoder gerade tut:

| Status | Bedeutung |
|--------|-----------|
| `Waiting for VIS / AUTO lock` | Horcht; noch nichts erkannt |
| `Martin M1? verifying sync…` | Ein Kandidat wurde gefunden und wird anhand der nächsten Zeilen bestätigt |
| `Martin M1 lock (VIS)` | Eingerastet über den VIS-Kopf |
| `Martin M1 lock (AUTO)` | Eingerastet über das Synchron-Timing |
| `Martin M1 lock (MANUAL)` | Über die Schaltfläche **⏺ Force** gestartet |
| `Candidate rejected (no sync)` | Der Kandidat wurde nicht bestätigt — bei Rauschen normal |
| `— sync lost, resetting` | Das Signal verschwand mitten im Bild |
| `Frame complete` | Das vollständige Bild wurde empfangen |

Die erkannte Betriebsart erscheint außerdem grün neben dem Titel **SSTV**, und der Zeilenzähler zeigt den Fortschritt.

### Bedienelemente

| Schaltfläche | Aktion |
|--------------|--------|
| **▶ Start** | Schaltet den Decoder scharf. Er zeichnet nicht von selbst ein Bild — ein Einrasten muss weiterhin über den VIS-Kopf oder die Synchronerkennung erfolgen. |
| **■ Stop** | Beendet die Dekodierung. |
| **↺ Reset** | Löscht die Zeichenfläche und schaltet an Ort und Stelle wieder scharf. Zwischen zwei Bildern oder nach dem Nachstimmen zu verwenden. |
| **⏺ Force** | Beginnt **sofort** in der im Menü gewählten Betriebsart zu zeichnen und überspringt VIS- und Synchronerkennung vollständig. Nur verfügbar, wenn Mode nicht auf **Auto** steht. |
| **💾 Save** | Speichert das aktuelle Bild als PNG. |

**Wann Force zu verwenden ist.** Wenn Sie im Wasserfall ein Bild sehen, der Decoder aber nicht darauf einrastet — eine ungewöhnliche Betriebsart, ein für die Detektoren zu schwaches oder zu verzerrtes Signal oder ein verpasster Kopf —, wählen Sie die Betriebsart von Hand und drücken Sie **⏺ Force**. Das Bild wird im Moment des Klicks verankert, und die Betriebsartenmarkierung zeigt `MANUAL`, sodass Sie es von einem VIS- oder AUTO-Einrasten unterscheiden können. Der Decoder rastet dennoch auf einen echten Synchronimpuls ein, wenn er einen findet — ein etwas zu früher oder zu später Klick wird also korrigiert.

Da Force sämtliche Sicherheitsprüfungen überspringt, malt es bereitwillig Rauschen, wenn Sie es auf einem leeren Kanal drücken, und es stoppt nicht von allein — drücken Sie **■ Stop** oder **↺ Reset**.

### Anmerkungen

- **Rauschen startet den Decoder nicht.** Statische Entladungen, Funkenstörungen und Netzbrumm reichten früher aus, um eine Dekodierung auszulösen. Jede Erkennungsstufe prüft nun, dass der Ton wirklich ein Ton ist, und bestätigt den Kandidaten anhand der folgenden Zeilen, bevor ein einziger Bildpunkt gezeichnet wird. Erwarten Sie, dass der Decoder auf einem leeren Band still bleibt.
- **Das Bild verläuft schräg, wenn Sie neben der Frequenz liegen.** SSTV verzeiht Abstimmfehler nicht. Neigen sich die Zeilen, stimmen Sie in kleinen Schritten nach und lassen Sie das nächste Bild neu beginnen.
- Farbbalance und Schärfe sind fest eingestellt; es gibt nichts nachzuregeln.

---

## 10. Allgemeine Tipps

**Decoder: ON muss zuerst eingeschaltet werden.** Das Auswahlmenü ist deaktiviert (ausgegraut), bis Sie die Decoder-Schaltfläche anklicken.

**Immer nur ein Decoder.** Die Auswahl eines neuen Decoders im Menü beendet automatisch den zuvor aktiven und setzt alle von ihm vorgenommenen Betriebsart- oder Durchlassbereichsänderungen zurück.

**Die Betriebsart wird für Sie verwaltet.** HF-FAX und NAVTEX schalten den Empfänger sofort nach der Auswahl auf USB, SSTV wählt das Seitenband anhand des Bandes (LSB unter 10 MHz, USB darüber), und FAX, NAVTEX sowie FSK passen zusätzlich den Durchlassbereich an, wenn Sie ihre Tune-Schaltfläche anklicken. Beim Beenden des Decoders wird die Standardbetriebsart des Bandes wiederhergestellt.

**Das Einschalten eines Decoders unterbricht den Ton nicht mehr.** Die Decoder laufen in eigenen Threads, sodass es beim Starten, Stoppen oder Wechseln weder Lücke noch Klick noch Aussetzer gibt.

**Die Genauigkeit der Systemuhr zählt.** FT8, FT4 und WSPR sind zeitkritisch. Sie dekodieren in festen, an UTC ausgerichteten Fenstern. Weicht Ihre Rechneruhr um mehr als 1–2 Sekunden ab, sinken die Dekodierraten deutlich. Halten Sie Ihre Uhr mit einem NTP-Client genau.

**Signalqualität schlägt Signalstärke.** Die meisten dieser Decoder sind für schwache Signale ausgelegt. Ein ruhigeres Band mit geringerem Rauschen ist oft ergiebiger als ein lautes, störungsreiches Signal. Nutzen Sie Wasserfall und Durchlassbereichseinstellungen, um QRM zu erkennen und zu meiden, bevor Sie einen Decoder aktivieren.

**Nutzen Sie die Schaltflächen Refresh oder Clear großzügig.** FAX-Bilder verlaufen, wenn die Anzeigefrequenz leicht danebenliegt, und Textdecoder sammeln Störzeichen an. Ein Neuanfang nach Abstimmkorrekturen liefert oft eine deutlich sauberere Ausgabe.

---

*PhantomSDR-Plus — sv1btl-Fork — [phantomsdr.no-ip.org](http://phantomsdr.no-ip.org:8900)*
