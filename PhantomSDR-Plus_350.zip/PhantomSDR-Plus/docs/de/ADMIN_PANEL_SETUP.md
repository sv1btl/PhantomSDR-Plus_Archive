# PhantomSDR-Plus Admin-Panel — Einrichtungsanleitung

> ⚠️ **Sicherheitshinweis:** Halten Sie dieses Admin-Panel in Ihrem Heimnetz oder hinter einem VPN. Eine öffentliche Freigabe des Admin-Ports ist ohne geeignete Absicherung der Authentifizierung nicht zu empfehlen.

---

## Überblick

Das Admin-Panel besteht aus zwei Python-Diensten:

| Dienst | Datei | Rolle |
|---|---|---|
| Admin-Panel | `admin_server.py` | Flask-Webanwendung, bindet an `127.0.0.1` (nur intern) |
| Reverse-Proxy | `proxy.py` | Stellt sowohl das SDR als auch das Admin-Panel auf einem einzigen öffentlichen Port bereit |

Beide Dienste lesen ihre Konfiguration aus `admin_config.json`, das von `setup_admin.sh` geschrieben wird. **Ändern Sie Portkonstanten nicht direkt in den Python-Dateien** — alle Ports und die IP des SDR-Hosts liegen in `admin_config.json`.

---

## Was das Admin-Panel bietet

- **Dashboard** — Serverstatus in Echtzeit, CPU/RAM, Top-Prozesse, aktuelle Protokollausgabe, Terminal
- **Konfigurationseditor** — beliebige `.toml`-, `.sh`-, `.json`-, `.h`- und `.cpp`-Dateien Ihrer Installation ansehen, bearbeiten und speichern
- **Protokollanzeige** — jede Protokolldatei in Echtzeit verfolgen (SDR-Server, Admin-Panel, RADE, Absturz, Autorun, Proxy)
- **Marker** — Frequenzmarker ansehen und bearbeiten
- **Chatverlauf** — das WebSDR-Chatprotokoll ansehen, vollständig leeren oder einzelne Nachrichten löschen, ohne den Server neu zu starten
- **Wasserfallnachricht** — ein dauerhaftes Banner an alle verbundenen Nutzer senden, in Echtzeit auf der Wasserfallanzeige sichtbar
- **Nutzer** — Live-Liste der verbundenen Hörer mit ihrer Frequenz, Betriebsart, Dauer und einer ⚡-Kick-Schaltfläche
- **Löschen von Chatnachrichten** — 🗑-Delete-Schaltfläche, die genau diese eine Nachricht sofort aus dem Protokoll entfernt
- **Wasserfall-Rundnachrichten** — erlaubt es, ein dauerhaftes Textbanner in den Wasserfall jedes verbundenen Nutzers zu schieben
- **Spot Reporting** — den Autorun-Decoder für FT8/FT4/WSPR starten/stoppen, Bänder/Betriebsarten wählen und Spots an PSK Reporter / wsprnet melden (standardmäßig AUS)
- **Einstellungen** — Admin-Passwort, SDR-Basisverzeichnis, Prozessname und öffentlichen Port ändern

---

## Voraussetzungen

- PhantomSDR-Plus bereits installiert und in Betrieb
- Python 3.8+
- `pip3 install flask psutil aiohttp --break-system-packages`

---

## Schritt 1 — Dateien

Legen Sie diese vier Dateien in Ihr PhantomSDR-Plus-Verzeichnis:

```
admin_server.py
manage_admin.sh
setup_admin.sh
proxy.py
```

Machen Sie die Shell-Skripte ausführbar:

```bash
chmod +x setup_admin.sh manage_admin.sh
```

---

## Schritt 2 — Das Einrichtungsskript ausführen

```bash
./setup_admin.sh
```

Das Skript wird:

1. prüfen, ob Python 3 installiert ist
2. das Vorhandensein von `admin_server.py` und `manage_admin.sh` überprüfen
3. Ihre LAN-IP automatisch erkennen (als `sdr_host` in der Konfiguration gespeichert — siehe [Warum die LAN-IP wichtig ist](#warum-die-lan-ip-wichtig-ist))
4. nach drei Portnummern fragen:
   - **Spectrumserver-Port** — der Port, auf dem Ihr SDR-Server lauscht (z. B. `8900`)
   - **Interner Port des Admin-Panels** — wo `admin_server.py` lokal bindet (z. B. `3000`)
   - **Öffentlicher Proxy-Port** — der einzige externe Port, der SDR + Admin vereint (z. B. `8902`)
5. `flask`, `psutil` und `aiohttp` per pip installieren
6. `ss` die Fähigkeit `cap_net_admin` gewähren (für die Kick-Funktion erforderlich)
7. `admin_config.json` mit allen Einstellungen schreiben
8. anbieten, einen systemd-Dienst für den automatischen Start einzurichten

Öffnen Sie nach der Einrichtung Ihren Browser über den Proxy:
```
http://YOUR_SERVER_IP:<proxy_port>/admin
```
Standardpasswort: **`admin`**

> ⚠️ **Ändern Sie das Passwort sofort** — gehen Sie bei der ersten Anmeldung zu Settings. Ein Assistent beim ersten Start führt Sie durch das Festlegen von SDR-Verzeichnis, Prozessname, öffentlichem Port und neuem Passwort.

---

## Schritt 3 — Starten / Stoppen / Neu starten

Verwenden Sie `manage_admin.sh`, um **beides** — Admin-Panel und Proxy — gemeinsam zu steuern:

```bash
./manage_admin.sh start      # start admin panel and proxy
./manage_admin.sh stop       # stop both
./manage_admin.sh restart    # restart both
./manage_admin.sh status     # show running status and PIDs
```

`manage_admin.sh` prüft vor dem Start des Proxys, ob `aiohttp` installiert ist, und gibt bei Fehlen eine klare Fehlermeldung samt Behebungsbefehl aus.

Falls Sie bei der Einrichtung den systemd-Dienst installiert haben (nur Admin-Panel — der Proxy wird stets über `manage_admin.sh` verwaltet):

```bash
sudo systemctl start   phantomsdr-admin
sudo systemctl stop    phantomsdr-admin
sudo systemctl restart phantomsdr-admin
sudo systemctl status  phantomsdr-admin
sudo journalctl -u phantomsdr-admin -f   # live logs
```

---

## Schritt 4 — Firewall-Port öffnen

Öffnen Sie in Ihrer Firewall nur den **öffentlichen Proxy-Port**. Der interne Port des Admin-Panels muss nicht nach außen freigegeben werden:

```bash
sudo ufw allow <proxy_port>
```

---

## Schritt 5 — Kick-Funktion

Die Seite Users zeigt jeden aktuell verbundenen Hörer. Jede Zeile nennt die IP des Nutzers, die eingestellte Frequenz, die Betriebsart und die Verbindungsdauer. Um einen Nutzer zu trennen, klicken Sie in seiner Zeile auf **⚡ Kick** — nur diese eine TCP-Verbindung wird beendet. Alle anderen Hörer bleiben verbunden und bemerken nichts.

Der Kick ist sofort und punktgenau: Der Server startet nicht neu, für niemanden sonst wird der Ton unterbrochen, und der getrennte Nutzer kann sich sofort wieder verbinden (die Funktion dient dem Entfernen störender oder hängender Verbindungen, nicht dem Sperren).

Intern nutzt der Kick `ss -K dst <IP> dport <port>`, um den betreffenden TCP-Socket abzubauen. Das erfordert eine Linux-Fähigkeit, die das Einrichtungsskript automatisch gewährt. Falls Sie die Einrichtung übersprungen haben oder die Schaltfläche einen Fehler meldet, setzen Sie sie manuell:

```bash
sudo setcap cap_net_admin+ep $(which ss)
# Verify:
getcap $(which ss)    # should show: cap_net_admin=ep
```

---

## Konfiguration — admin_config.json

Die gesamte Laufzeitkonfiguration liegt in `admin_config.json` in Ihrem PhantomSDR-Plus-Verzeichnis. `setup_admin.sh` schreibt die Erstfassung; spätere Änderungen sind über die Seite Settings oder durch direktes Bearbeiten der Datei möglich.

Wichtige von `setup_admin.sh` geschriebene Felder:

| Schlüssel | Beschreibung |
|---|---|
| `port` | Interner Port des Admin-Panels (`admin_server.py` bindet hier) |
| `public_port` | Spectrumserver-Port (von der Seite Users genutzt, um `/users` abzufragen) |
| `proxy_port` | Öffentlicher Port, auf dem der Proxy lauscht |
| `sdr_host` | LAN-IP, über die der Proxy spectrumserver erreicht (siehe unten) |
| `password_hash` | SHA-256-Hash des Admin-Passworts |
| `sdr_base_dir` | Pfad zu Ihrer PhantomSDR-Plus-Installation |
| `sdr_process_name` | Zu überwachender Prozessname (Standard: `spectrumserver`) |

Um Ports nach der Ersteinrichtung zu ändern, bearbeiten Sie `admin_config.json` und starten neu:

```bash
./manage_admin.sh restart
```

---

## Warum die LAN-IP wichtig ist

`proxy.py` verbindet sich mit `spectrumserver` über die **LAN-IP** der Maschine (gespeichert als `sdr_host`), nicht über `127.0.0.1`. Das ist nötig, weil spectrumserver WebSocket-Wasserfalldaten für Verbindungen von der Loopback-Adresse stillschweigend verwirft. Mit der LAN-IP behandelt spectrumserver den Proxy als normalen Client.

`setup_admin.sh` erkennt die LAN-IP automatisch und schreibt sie in `admin_config.json`. Ändert sich Ihr Netzwerk (z. B. neue DHCP-Zuweisung), führen Sie `setup_admin.sh` erneut aus oder aktualisieren `sdr_host` in `admin_config.json` von Hand und starten neu.

---

## proxy.py — was es ist und wann Sie es brauchen

`proxy.py` legt sowohl den SDR-Server als auch das Admin-Panel auf einen **einzigen öffentlichen Port** und leitet nach Pfadpräfix weiter:

| Pfad | Weitergeleitet an |
|---|---|
| `/admin*` | Admin-Panel (`localhost:<port>`) |
| Alles andere | Spectrumserver (`<sdr_host>:<public_port>`) |

Ohne den Proxy müssen Sie zwei Ports getrennt freigeben. Mit ihm geben Sie nur einen frei.

Der Proxy hebt außerdem die 4-MB-Grenze für WebSocket-Nachrichten auf (wichtig für große FFT-Rahmen des RX-888 bei 60 MSPS), leitet die echten Client-IPs über `X-Forwarded-*`-Header weiter und hält langlebige Verbindungen mit einem 30-Sekunden-Heartbeat durch NAT hindurch am Leben.

---

## Ports nach der Einrichtung ändern

Bearbeiten Sie `admin_config.json` direkt:

```json
{
  "port":        3000,
  "public_port": 9001,
  "proxy_port":  9002,
  "sdr_host":    "192.168.1.x"
}
```

Starten Sie dann beide Dienste neu:

```bash
./manage_admin.sh restart
```

Wenn `admin_server.py` beim Start zusätzlich an einen anderen Port binden soll (z. B. beim systemd-Dienst), können Sie das per Umgebungsvariable überschreiben:

```bash
ADMIN_PORT=3000 python3 admin_server.py
```

Standardmäßig bindet `admin_server.py` nur an `127.0.0.1`. Um es eigenständig ohne Proxy zu betreiben (Entwicklung/Test), binden Sie an alle Schnittstellen:

```bash
ADMIN_BIND=0.0.0.0 python3 admin_server.py
```

---

## Nützliche manuelle Befehle

```bash
# Start admin panel manually (foreground)
python3 ~/PhantomSDR-Plus/admin_server.py

# Kill the admin panel
pkill -f admin_server.py

# Kill the proxy
pkill -f proxy.py

# Free a port that is stuck in use
sudo fuser -k 3000/tcp

# Check what is listening on a port
ss -tlnp | grep 3000
```

---

## Protokolldateien

| Datei | Inhalt |
|---|---|
| `admin.log` | Ausgabe des Admin-Panels |
| `proxy.log` | Startbanner des Proxys + eine Zugriffszeile je weitergeleiteter Anfrage |
| `logwebsdr.txt` | Hauptprotokoll des SDR-Servers |
| `rade.log` | Protokoll des RADE-/FreeDV-Sidecars |

Alle sind über die Reiter der **Log Viewer** im Panel lesbar (LOGWEBSDR,
ADMIN, RADE, CRASH, AUTORUN, PROXY).

### proxy.log und admin.log rotieren

`proxy.log` verzeichnet jede weitergeleitete Anfrage, einschließlich der
`/admin/api/status`-Abfrage des Dashboards alle ~3 Sekunden — grob **1 MB pro Stunde,
solange das Panel im Browser geöffnet ist**. Weder diese Datei noch `admin.log` wird
standardmäßig rotiert.

Das Repository liefert eine logrotate-Konfiguration unter `logrotate/phantomsdr` (täglich,
oder früher, wenn ein Protokoll 10 MB überschreitet; behält 7 gzip-Archive in `logproxy/`,
damit sie das Projektwurzelverzeichnis nicht zumüllen). **Sie ist standortspezifisch — öffnen
Sie sie und passen Sie die beiden Protokollpfade, den `olddir`-Pfad und den `su`-Benutzer an
Ihre Maschine an, bevor Sie sie installieren**, dann:

```bash
sudo cp logrotate/phantomsdr /etc/logrotate.d/phantomsdr
sudo logrotate -d /etc/logrotate.d/phantomsdr     # dry run, should list both logs
```

`logrotate/phantomsdr` im Repository und `/etc/logrotate.d/phantomsdr` sind zwei
**unabhängige Kopien** — `cp` verknüpft sie nicht. Änderungen an der Repository-Datei wirken
sich auf einem laufenden System erst aus, wenn Sie das obige `sudo cp` erneut ausführen. Nur
die Kopie in `/etc` liest logrotate tatsächlich.

Die Konfiguration verwendet `copytruncate`, was zwingend nötig ist: `manage_admin.sh` startet
beide Prozesse mit `>> <log>`, und keiner öffnet seine Standardausgabe erneut; eine Rotation
per Umbenennung ließe sie also weiter in die rotierte Datei schreiben, während das neue
Protokoll für immer leer bliebe.

Archive landen in `logproxy/` (von `createolddir` automatisch angelegt) und heißen
`proxy.log.1.gz` … `proxy.log.7.gz`, das neueste zuerst. Lesen Sie eines mit
`zcat logproxy/proxy.log.1.gz | less` oder durchsuchen Sie alle auf einmal mit
`zgrep "pattern" logproxy/*.gz`.

Die Schaltfläche **Clear Logs** des Panels leert jede Datei der obigen Tabelle **außer
`proxy.log`**, das bewusst ausgenommen ist (`CLEAR_EXCLUDE` in `admin_server.py`): Es ist der
einzige Nachweis, wer wann verbunden war, und logrotate begrenzt seine Größe bereits — eine
Schaltfläche in der Oberfläche soll diese Historie nicht zerstören können. Der Reiter PROXY
zeigt sie weiterhin an.

Erfolgreiche Abfragen von `/admin/api/status` und `/admin/api/logs` werden aus dem
Zugriffsprotokoll herausgefiltert (`QuietPollFilter` in `proxy.py`) — das Dashboard ruft sie
alle paar Sekunden auf und sie würden sonst ~90 % der Datei ausmachen. Fehlschläge auf diesen
Pfaden werden weiterhin protokolliert, ebenso alles andere.

Da `proxy.log` ein Zugriffsprotokoll ist, enthält es Besucher-IP-Adressen und User-Agent-
Zeichenketten — denken Sie daran, bevor Sie es bei einer Hilfeanfrage weitergeben.

---

## Zugriffsübersicht

| Aufbau | SDR | Admin-Panel |
|---|---|---|
| Ohne Proxy | `http://YOUR_IP:<public_port>` | `http://YOUR_IP:<port>/admin` |
| Mit Proxy | `http://YOUR_IP:<proxy_port>` | `http://YOUR_IP:<proxy_port>/admin` |

---

## Löschen von Chatnachrichten

Die Seite Chat History listet jede Nachricht des aktuellen Chatprotokolls auf. Jeder Eintrag hat eine Schaltfläche **🗑 Delete**, die genau diese eine Nachricht sofort aus dem Protokoll entfernt — ohne Serverneustart.

So funktioniert es:

- Das Admin-Panel schreibt die Chatprotokolldatei an Ort und Stelle neu und entfernt dabei nur die Zeile der gewählten Nachricht.
- Die Änderung wirkt für jeden Nutzer, der den Chat neu lädt; bereits geladener Chatverlauf in offenen Browser-Tabs wird nicht rückwirkend aktualisiert.
- Das Leeren des gesamten Protokolls (Schaltfläche **Clear All**) kürzt die Datei, was ebenfalls ohne Neustart wirkt.

Die Löschschaltfläche wird in allen fünf Svelte-App-Varianten einheitlich dargestellt. Scheint eine Löschung nicht zu wirken, prüfen Sie, ob das Admin-Panel Schreibrechte auf die Chatprotokolldatei hat:

```bash
ls -l ~/PhantomSDR-Plus/chat.jsonl   # path depends on your config
```

---

## Wasserfall-Rundnachrichten

Das Panel **Waterfall Message** erlaubt es, ein dauerhaftes Textbanner in die Wasserfallanzeige jedes verbundenen Nutzers zu schieben, ohne den Serverprozess anzufassen.

### Eine Nachricht senden

1. Öffnen Sie das Admin-Panel und gehen Sie zu **Waterfall Message**.
2. Geben Sie Ihren Nachrichtentext ein und wählen Sie eine Farbe (hexadezimal, z. B. `#ffdd00`).
3. Klicken Sie auf **Send** — die Nachricht erscheint sofort in allen aktiven Wasserfallansichten.

### Die Nachricht löschen

Klicken Sie auf **Clear**, um das Banner aus allen Wasserfällen zu entfernen. Der Nachrichtenzustand wird vom Admin-Panel im Speicher gehalten; er wird automatisch gelöscht, wenn der Panel-Prozess neu startet.

### Funktionsweise

Das Admin-Panel stellt zwei interne Endpunkte bereit, die der Proxy weiterleitet:

| Endpunkt | Methode | Zweck |
|---|---|---|
| `/admin/api/waterfall-message` | `POST` | Aktuellen Bannertext und -farbe setzen oder löschen |
| `/admin/api/waterfall-message` | `GET` | Aktuellen Nachrichtenzustand als JSON zurückgeben |

Das Frontend fragt den Nachrichtenzustand ab und rendert ihn als Overlay auf der Wasserfall-Zeichenfläche. Auf Clientseite ist weder eine WebSocket-Neuverbindung noch ein Neuladen der Seite nötig.

### Typische Anwendungen

- Geplante Wartung ankündigen: `"Server restart in 10 minutes"`
- Bandbedingungen melden: `"Solar flux 180 — 10m wide open"`
- Begrüßung: `"Welcome to SV1BTL WebSDR — Athens, KM17"`

---

## Spot Reporting (Autorun FT8/FT4/WSPR)

Der Reiter **Spot Reporting** steuert den Autorun-Daemon (`autorun/index.js`) — einen
Node.js-Prozess, der FT8/FT4/WSPR serverseitig direkt vom Empfänger dekodiert und die Spots
zu den Reporting-Netzwerken hochlädt:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

**Das Reporting ist standardmäßig AUS.** Es wird nichts hochgeladen, bis Sie ein Ziel
aktivieren und **Start** drücken. Dekodieren und Hochladen sind unabhängig voneinander: Der
Daemon kann bei ausgeschaltetem Reporting dekodieren und protokollieren, sodass Sie die
Aktivität prüfen können, bevor etwas öffentlich wird.

> ⚠️ Spots werden unter **Ihrem Rufzeichen** in öffentliche Netze hochgeladen. Aktivieren Sie
> nur Bänder/Betriebsarten, die Ihr Empfänger wirklich hört, und tragen Sie den korrekten
> Locator ein.

### Voraussetzungen

Der Autorun-Daemon benötigt Node.js 22+, die npm-Pakete `ws` + `cbor-x` (aufgelöst über den
Symlink `autorun/node_modules` → `frontend/node_modules`) sowie `util-linux` (`taskset`). Die
Installer richten all das automatisch ein — siehe den
[Abschnitt Autorun-Spot-Reporter in INSTALLATION.md](INSTALLATION.md#autorun-spot-reporter-ft8ft4wspr).
Schlägt **Start** fehl, ist meist dieser Symlink oder `taskset` die Ursache (siehe Fehlerbehebung unten).

### Den Reiter verwenden

1. **Identität** — Rufzeichen und Locator. Vorausgefüllt aus `frontend/site_information.json`
   (`siteSysop` / `siteGridSquare`, auf 6 Zeichen gekürzt); hier bei Bedarf überschreiben.
2. **Band-×-Betriebsart-Matrix** — kreuzen Sie die zu dekodierenden Kombinationen an. Zeilen
   sind Bänder, Spalten FT8 / FT4 / WSPR; nicht unterstützte Felder sind deaktiviert. WSPR
   deckt zusätzlich die LF-/MF-Bänder (2200 m, 630 m) und einen zusätzlichen 80-m-EU-Kanal ab.
3. **Ziele** — aktivieren Sie **PSK Reporter** und/oder **wsprnet** (beide standardmäßig aus).
4. **Max slots** — eine Sicherheitsgrenze dafür, wie viele Band-/Betriebsart-Slots gleichzeitig laufen dürfen.
5. **Start / Stop** — startet/beendet den Daemon (per `taskset` an die obersten CPU-Kerne
   gebunden, automatisch für die Maschine gewählt — siehe *Ressourcenbedarf und Grenzen*
   unten). **Save** / **Reload** speichern und lesen die Konfiguration neu; **Free All** leert
   alle Slots.

Die Statuskarte aktualisiert sich alle 5 s und zeigt Laufzustand, Dekodier-/Uploadzähler und
den letzten Uploadzeitpunkt. Ein Abzeichen **📶 REPORTING** erscheint im Hauptwasserfall,
solange das Reporting aktiv ist.

> **„0 sent" in den ersten Minuten ist normal.** PSK Reporter lädt gebündelt alle
> **5 Minuten** hoch, wsprnet alle **2 Minuten** — Spots warten bis zum nächsten Absenden.
> Die Statuskarte zeigt die Anzahl der wartenden Spots und die Taktung.

### Ressourcenbedarf und Grenzen

Der Daemon ist bewusst schlank und läuft auf ressourcenarmer Hardware (ein 4-Kern-i5 genügt),
es gibt aber reale Grenzen, die man kennen sollte.

**Das CPU-Pinning von Autorun ist konfigurationsbewusst und automatisch.** Der
**Autorun-Daemon** wird stets vom Admin-Panel (`admin_server.py`) gestartet, sein Pinning wird
daher bei jeder Installation ohne Konfiguration gesetzt: Aus der Anzahl der CPUs wird ein
`taskset`-Kernbereich abgeleitet, der einige der obersten Kerne für das Dekodieren reserviert;
bei ≤ 4 Kernen läuft er ungebunden.

**Das Pinning von spectrumserver liegt bei Ihrer eigenen Startmethode.** Wie Sie
spectrumserver starten, unterscheidet sich je nach Installation (SDR-Typ, Werkzeuge, eigene
Skripte), daher setzt dieses Dokument keinen bestimmten Starter voraus. Das Admin-Panel
startet und bindet spectrumserver nicht — das hängt ganz vom Befehl oder Dienst ab, mit dem
Sie ihn ausführen. Wollen Sie spectrumserver von den Kernen fernhalten, die der
Autorun-Daemon nutzt, binden Sie ihn selbst mit `taskset` in Ihrem Startbefehl (siehe
Abschnitt zum Überschreiben unten). Tun Sie das nicht, läuft er einfach ungebunden und der
Scheduler des Betriebssystems verteilt ihn — korrekt und sicher, nur ohne die bewusste
Kerntrennung.

Zur Orientierung reserviert der Autorun-Daemon diese oberen Kerne (wenn Sie spectrumserver
binden, bleiben Sie also bei den unteren Kernen, um Überschneidungen zu vermeiden):

| Logische CPUs | Vom Autorun-Daemon genutzt | Für spectrumserver frei lassen |
|---|---|---|
| ≤ 4 | *ungebunden* | *ungebunden* |
| 6 | `5` | `0-4` |
| 8 | `6-7` | `0-5` |
| 12 (z. B. Hybrid 8P+4E) | `8-11` | `0-7` |
| 16 | `12-15` | `0-11` |

Auf einer Maschine mit **4 Kernen (oder weniger)** gibt es nichts zu trennen, daher läuft auch
der Autorun-Daemon *ungebunden* und teilt sich alle Kerne — korrekt und sicher, aber die
SDR-FFT und die Dekodierschübe konkurrieren um dieselben Kerne.

**Bekannte Grenzen:**

1. **Der eigentliche Engpass ist spectrumserver + die SDR-Bandbreite, nicht der Daemon.** Ein
   RX888 bei 30 MHz braucht OpenCL/GPU; eine CPU mit wenigen Kernen ohne leistungsfähige GPU
   kann diese FFT nicht tragen. Kombinieren Sie schwache Hardware mit einem schmaleren SDR
   (RSP1A ≈ 10 MHz, RTL-SDR ≈ 2.4 MHz).
2. **WSPR ist der CPU-Flaschenhals.** Sein Fano-Decoder ist eine JS-Portierung (~30 s pro
   Band, einfädig). Der 4-Worker-Pool führt 4 Dekodierungen parallel aus; mehr als **etwa 4
   WSPR-Bänder** gleichzeitig können die Warteschlange über den 120-s-Zeitschlitz hinaus
   verlängern, besonders während das SDR um Kerne konkurriert. FT8-/FT4-Dekodierungen sind im
   Vergleich günstig.
3. **Skalierung der Slot-Anzahl.** Die Angabe von ~2–2,5 Kernen / 600–700 MB gilt für die
   vollen ~28 Slots auf einer 8-Kern-Maschine. Auf 4 gemeinsam genutzten Kernen bleiben Sie
   bei wenigen Bändern (Richtwert: ≤ 6 FT8/FT4 + ≤ 3 WSPR) und beobachten die
   `queued`-Statistik des Pools.
4. **Das Pinning setzt eine hybride Intel-Topologie voraus** (untere Kerne = schnellere
   P-Cores). Auf AMD oder CPUs mit verschränkter SMT-Nummerierung bleibt die automatische
   Aufteilung gültig (keine Überschneidung, kein Absturz), aber „untere Kerne sind schneller"
   trifft womöglich nicht wörtlich zu; bei einem 4C/8T-Modell mit Hyperthreading sind die
   oberen Kerne SMT-Geschwister — eingegrenzt, nicht vollständig isoliert. Wo der automatische
   Bereich nicht ideal ist, nutzen Sie das **manuelle Überschreiben** unten.
5. **Die Bandabdeckung wird vom Empfänger begrenzt.** Die RX888-Konfiguration
   (`sps=60000000` → Nyquist bei 30 MHz) erreicht das 6-m-Band und darüber nicht; die
   Bandtabelle reicht von 160 m bis 10 m. Andere SDRs decken ab, was ihr Abstimmfenster erlaubt.
6. **Reporting-Taktung.** PSK Reporter sendet alle 5 min, wsprnet alle 2 min — „0 sent" in
   den ersten Minuten ist normal, kein Fehler.

### Manuelles Überschreiben des CPU-Pinnings (fortgeschritten)

Die automatisch abgeleitete Kernaufteilung passt für die meisten Maschinen, aber Sie können
dort ein bestimmtes Pinning erzwingen, wo sie es nicht tut (AMD CCX/CCD, ARM big.LITTLE,
verschränktes SMT). Zwei unabhängige Überschreibungen, jede akzeptiert eine Kernliste im
`taskset -c`-Format (`2-3`, `0,2,4`, `0-2,5`) oder `none`/`off`/`unpinned`, um das Pinning
abzuschalten. Ein ungültiger Wert wird ignoriert und die automatische Ableitung greift — ein
Tippfehler kann einen Start also nie verhindern.

**Autorun-Daemon** — Umgebungsvariable `AUTORUN_CORES` oder ein Feld `"cores"` in
`autorun.json` (die Umgebung gewinnt). Das Feld `"cores"` bleibt beim **Save** im Admin-Panel
erhalten, eine Handänderung bleibt also bestehen. Zwei Wege, es zu setzen:

*Variante A — `autorun.json` (dauerhaft, empfohlen).* Fügen Sie der Konfiguration im
Repository-Wurzelverzeichnis eine Zeile `"cores"` hinzu und führen Sie dann im Reiter Spot
Reporting **Stop → Start** aus:

```jsonc
// autorun.json
{ "identity": { "callsign": "SV1BTL", "grid": "KM17VX" },
  "reporting": { "pskreporter": true, "wsprnet": false },
  "slots": [ /* … */ ],
  "cores": "2-3" }          // or "none" to run unpinned
```

*Variante B — Umgebungsvariable (einmalig).* Der Daemon wird vom Admin-Panel gestartet, die
Variable muss also in der Umgebung **des Panels** stehen — setzen Sie sie und starten Sie das
Panel neu (die Umgebung gewinnt gegenüber dem Wert in `autorun.json`):

```bash
AUTORUN_CORES=2-3 ./manage_admin.sh restart
```

**spectrumserver** — binden Sie ihn selbst, indem Sie `taskset -c <Kerne>` dem Befehl
voranstellen, mit dem Sie den Server starten. Das funktioniert mit jeder Startmethode
(direkter Aufruf, SDR-Pipeline, Service-Unit usw.):

```bash
# pin the server to cores 0-3, direct launch:
taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml < <your-input>
# or in an SDR pipeline:
<your-sdr-source> | taskset -c 0-3 ./build/spectrumserver --config <your-config>.toml
```

> ⚠️ **Sorgen Sie dafür, dass es Neustarts übersteht.** Ein `taskset` in der Befehlszeile gilt
> nur für diesen einen Start. Startet etwas den Server automatisch neu (ein Watchdog, ein
> systemd-Dienst, ein cron-/`@reboot`-Eintrag …), fügen Sie das `taskset`-Präfix in das
> Skript oder die Unit ein, die ihn tatsächlich startet — sonst geht das Pinning beim Neustart
> verloren.

**Prüfen, ob das Pinning gegriffen hat** — die tatsächliche CPU-Affinität der laufenden
Prozesse ausgeben:

```bash
taskset -cp "$(pgrep -f 'autorun/index.js')"   # autorun daemon
taskset -cp "$(pgrep -x spectrumserver)"       # spectrumserver
```

**Zulässige Werte (beide Überschreibungen):** eine `taskset -c`-Liste (`2-3`, `0,2,4`,
`0-2,5`) oder `none`/`off`/`unpinned` für kein Pinning. Alles Fehlerhafte wird ignoriert und
die automatische Ableitung greift, ein Tippfehler kann den Start also nie blockieren.

> Auf einem Raspberry Pi / jeder Maschine mit ≤ 4 Kernen brauchen Sie in der Regel keines von
> beidem — der automatische Weg lässt beide Prozesse bereits ungebunden laufen, was auf einer
> kleinen, homogenen CPU die richtige Wahl ist. Das Überschreiben ist für größere Maschinen
> gedacht, die keine Intel-Hybriden sind.

### Dateien und Endpunkte

| Element | Zweck |
|---|---|
| `autorun.json` | Gespeicherte Konfiguration (Identität, Slots, Ziele, max. Slots, optionales `cores`-Pinning). Vom Reiter geschrieben; von git ignoriert. |
| `autorun-status.json` | Live-Status, den die Statuskarte liest (PID, Zähler, letzter Upload). Alle 15 s geschrieben; beim Stoppen entfernt. |
| `frontend/dist/autorun-active.json` | Öffentliche Abzeichendaten, ausgeliefert unter `/autorun-active.json`. Leer, wenn das Reporting aus ist. |
| `autorun.log` | Standard- und Fehlerausgabe des Daemons. |
| `GET/POST /admin/api/autorun/config` | `autorun.json` lesen/schreiben (prüft Rufzeichen, Locator, Band-/Betriebsart-Kombinationen, Slot-Grenze). |
| `GET /admin/api/autorun/status` | Laufzustand (`pgrep`) + `autorun-status.json`. |
| `POST /admin/api/autorun/start` / `stop` | Startet (`taskset -c <auto> node autorun/index.js`) / sendet `SIGTERM`. Der Kernbereich wird von der CPU abgeleitet (siehe oben). |

> **Hinweis:** Nach einem Upgrade von `admin_server.py` müssen Sie `./manage_admin.sh restart`
> ausführen, um neue Autorun-Routen oder eine aktualisierte Band-/Betriebsart-Matrix zu laden.
> Der Daemon läuft als eigener Prozess und übersteht daher Neustarts des Admin-Panels.

---

## Fehlerbehebung

| Problem | Abhilfe |
|---|---|
| Admin-Panel startet nicht | Prüfen Sie `admin.log` — meist ein fehlendes Python-Paket |
| Proxy startet nicht | Führen Sie `python3 -c "import aiohttp"` aus — schlägt es fehl: `pip3 install aiohttp --break-system-packages` |
| `proxy.log` ist leer | Prüfen Sie zuerst, ob der Proxy wirklich läuft (`./manage_admin.sh status`). Wenn ja, nutzen Sie eine alte Version: Der Starter muss `python3 -u` verwenden (ungepuffert — sonst verlässt das Startbanner nie den 8-KB-Puffer), und `main()` in `proxy.py` muss `logging.basicConfig()` aufrufen (sonst hat aiohttps Zugriffslogger keinen Handler und jede Anfragezeile geht verloren, weil `web.AppRunner` — anders als `web.run_app` — die Protokollierung nicht konfiguriert). |
| Proxy startet, aber der Wasserfall bleibt leer | Prüfen Sie `sdr_host` in `admin_config.json` — es muss Ihre LAN-IP sein, nicht `127.0.0.1` |
| Kick-Schaltfläche meldet „no connections" | Führen Sie `getcap $(which ss)` aus — fehlt `cap_net_admin`, setzen Sie `sudo setcap cap_net_admin+ep $(which ss)` |
| Status zeigt immer OFFLINE | Gehen Sie zu Settings → SDR Process Name — tragen Sie den exakten Namen ein, den `ps -eo comm,args \| grep -v grep` anzeigt |
| Seite Users zeigt keine Daten | Prüfen Sie den Endpunkt: `curl http://127.0.0.1:<public_port>/users` |
| Externer Browser meldet NetworkError | Prüfen Sie, ob der Proxy läuft: `./manage_admin.sh status` |
| Falsche Ports nach Netzwerkänderung | Aktualisieren Sie `sdr_host` in `admin_config.json` und führen Sie `./manage_admin.sh restart` aus |
| Chat-Löschschaltfläche wirkt nicht | Prüfen Sie die Schreibrechte auf die Chatprotokolldatei: `ls -l ~/PhantomSDR-Plus/chat.jsonl` |
| Wasserfallnachricht erscheint nicht | Prüfen Sie, ob der Proxy läuft (`./manage_admin.sh status`) und das Frontend auf einem aktuellen Build mit Overlay-Renderer ist |
| Wasserfallnachricht nach Neustart verschwunden | Erwartet — der Nachrichtenzustand liegt nur im Speicher; senden Sie sie nach dem Neustart des Admin-Panels erneut |
| „Start" bei Spot Reporting schlägt fehl / Daemon beendet sich sofort | Prüfen Sie `autorun.log`. Meist fehlt der Symlink `autorun/node_modules` (`ln -sfn ../frontend/node_modules autorun/node_modules`) oder `taskset` ist nicht installiert (`sudo apt install -y util-linux`). |
| Spot Reporting: Daemon läuft, aber `decodes` bleibt 0 und `autorun.log` zeigt `504` / `tap closed 1006` | Der Audioabgriff erreicht spectrumserver nicht. Der Daemon erkennt den Port automatisch aus der Konfiguration des **laufenden** Servers; die Protokollzeile `[autorun] tap backend: HOST:PORT` muss zu Ihrem `[server] port` passen. Stimmt sie nicht (oder lief der Server beim Start nicht), fixieren Sie ihn in `autorun.json`: `"server": { "host": "127.0.0.1", "port": 9002 }`, dann Stop→Start. |
| Spot Reporting zeigt „0 sent" | In den ersten Minuten normal — PSK Reporter sendet alle 5 min, wsprnet alle 2 min. Prüfen Sie, ob ein Ziel aktiviert ist und der Daemon läuft. |
| Neue Bänder/Betriebsarten erscheinen nicht in der Matrix | Starten Sie das Admin-Panel neu: `./manage_admin.sh restart` (die Matrix wird beim Start geladen). |
| `autorun.log` zeigt `MODULE_TYPELESS_PACKAGE_JSON` / „Reparsing as ES module … performance overhead" | Kosmetische Warnung (die Dekodierung funktioniert weiterhin). In `frontend/src/modules/package.json` fehlt `"type": "module"`; fügen Sie die Zeile nahe dem Anfang ein und führen Sie Stop→Start aus. Kein Frontend-Neubau nötig — der Daemon importiert die Quelldatei direkt. |
| „Start" bei Spot Reporting scheitert mit `taskset: … Invalid argument` auf einem alten/kleinen PC | Sollte mit dem konfigurationsbewussten Starter nicht vorkommen — der Kernbereich wird aus der CPU-Anzahl abgeleitet und läuft bei ≤ 4 Kernen ungebunden. Tritt es auf, ist Ihr `admin_server.py` älter als diese Änderung; aktualisieren Sie es (`_autorun_taskset_prefix`) und führen Sie `./manage_admin.sh restart` aus. |
| REPORTING-Abzeichen fehlt im Wasserfall | Das Reporting muss mit mindestens einem Slot eingeschaltet sein; das Abzeichen liest `/autorun-active.json`. Bauen Sie das Frontend neu, wenn `dist/index.html` älter als das Abzeichen ist. |
