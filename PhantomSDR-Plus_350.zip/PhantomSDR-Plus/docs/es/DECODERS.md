# PhantomSDR-Plus — Manual del usuario de los decodificadores

Esta guía cubre todos los decodificadores integrados disponibles en PhantomSDR-Plus. Todos los decodificadores comparten el mismo procedimiento de activación, descrito a continuación, seguido de las instrucciones de configuración de cada uno.

---

## Índice

1. [Cómo iniciar un decodificador](#1-cómo-iniciar-un-decodificador)
2. [FT8](#2-ft8)
3. [FT4-FT2](#3-ft4-ft2)
4. [CW — código Morse](#4-cw--código-morse)
5. [WSPR](#5-wspr)
6. [FAX de HF / WEFAX](#6-fax-de-hf--wefax)
7. [NAVTEX](#7-navtex)
8. [FSK / RTTY](#8-fsk--rtty)
9. [SSTV](#9-sstv)
10. [Consejos generales](#10-consejos-generales)

---

## 1. Cómo iniciar un decodificador

Se accede a todos los decodificadores desde la sección **Decoder Options**, situada bajo los controles del espectrograma de audio en el panel principal.

**Pasos:**

1. Haga clic en el botón **Decoder: OFF** para cambiarlo a **Decoder: ON** (se vuelve azul cuando está activo).
2. Abra el menú desplegable que aparece a la derecha del botón y seleccione el decodificador que desee.
3. El panel del decodificador elegido aparecerá bajo los controles; siga las instrucciones específicas de ese decodificador en la sección correspondiente de esta guía.
4. Para detener la decodificación, seleccione **— Select decoder —** en el desplegable, o haga clic en el botón **Decoder: ON** para volver a ponerlo en OFF.

> Solo puede haber un decodificador activo a la vez. Cambiar a otro decodificador detiene automáticamente el anterior.

**La decodificación se ejecuta en segundo plano.** SSTV, FAX de HF, NAVTEX, FSK/RTTY y CW se ejecutan cada uno en un hilo Web Worker independiente, de modo que el trabajo de decodificación nunca compite con la reproducción de audio ni con la cascada. Iniciar o detener un decodificador no interrumpe el audio, y la interfaz sigue respondiendo mientras se recibe una imagen o una página. Todos los decodificadores reciben audio en bruto tomado *antes* del AGC, la reducción de ruido y el silenciado, así que silenciar el receptor o ajustar esos parámetros a su gusto no afecta a la decodificación.

---

## 2. FT8

**Qué es:** FT8 es un modo digital de señal débil muy popular entre los radioaficionados de todo el mundo. Las transmisiones duran exactamente 15 segundos y el protocolo puede copiar señales hasta 20-25 dB por debajo del nivel de ruido. Es el modo más utilizado para contactos a larga distancia (DX).

### Frecuencias recomendadas (USB)

| Banda | Frecuencia |
|-------|------------|
| 160 m | 1.840 MHz |
| 80 m  | 3.573 MHz |
| 40 m  | 7.074 MHz |
| 30 m  | 10.136 MHz |
| 20 m  | 14.074 MHz |
| 17 m  | 18.100 MHz |
| 15 m  | 21.074 MHz |
| 12 m  | 24.915 MHz |
| 10 m  | 28.074 MHz |

### Configuración

1. Sintonice una de las frecuencias de FT8 indicadas arriba y ponga el modo en **USB**.
2. Active el decodificador y seleccione **FT8** en el desplegable.
3. El panel **FT8 Messages** aparece automáticamente debajo.

### Lectura de la salida

La lista de mensajes muestra las transmisiones decodificadas a medida que llegan. Cada ciclo de 15 segundos produce un nuevo lote de mensajes. El campo **Farthest** (arriba a la derecha del panel) indica la mayor distancia decodificada en la sesión actual, en kilómetros.

Formato de mensaje típico: `CQ DX AA1BB FN31` — una llamada CQ del indicativo AA1BB situado en el cuadrante FN31.

> **Consejo:** FT8 está estrechamente sincronizado en el tiempo. Su navegador usa el reloj del ordenador; si el reloj del sistema se desvía más de un par de segundos, la decodificación fallará. Mantenga la hora del sistema sincronizada por NTP.

---

## 3. FT4-FT2

**Qué es:** FT4 es una variante más rápida de FT8 diseñada para operar en concursos. Cada ciclo de transmisión dura 7,5 segundos (la mitad que FT8), lo que lo hace el doble de rápido pero exige una señal algo más fuerte.
FT2 es una variante aún más rápida de FT8. Es un modo ultrarrápido de 77 bits con periodos TR de 3,75 segundos (= la mitad que FT4); todavía experimental.

### Frecuencias recomendadas (USB)

| Banda | Frecuencia FT4|
|-------|-----------|
| 80 m  | 3.575 MHz |
| 40 m  | 7.047 MHz |
| 30 m  | 10.140 MHz |
| 20 m  | 14.080 MHz |
| 15 m  | 21.140 MHz |
| 10 m  | 28.180 MHz |

| Banda | Frecuencia FT2|
|-------|-----------|
|160 m | 1.843 a 1.846 |
|80 m   | 3.578 a 3.581 |
|60 m   | 5.360 (consulte la normativa regional local) |
|40 m   | 7.052 a 7.062 |
|30 m   | 10.144 |
|20 m   | 14.084 |
|17 m   | 18.108 |
|15 m   | 21.144 |
|12 m   | 24.923 |
|10 m   | 28.184 |

### Configuración

1. Sintonice una frecuencia de FT4 y ponga el modo en **USB**.
2. Active el decodificador y seleccione **FT4** o **FT2** en el desplegable.
3. El panel **FT4 Messages** o **FT2 Messages** aparece debajo, con la misma disposición que el panel de FT8.

> **Nota:** FT4 y FT8 usan formatos espectrales distintos y no son intercambiables. Asegúrese de estar en una frecuencia de FT4 al usar este decodificador.

---

## 4. CW — código Morse

**Qué es:** el decodificador de CW escucha señales en código Morse (onda continua) y las convierte en texto en tiempo real. Sigue automáticamente la frecuencia de la señal y se adapta a la velocidad de manipulación del operador.

### Frecuencias recomendadas

La CW está activa en todas las bandas de aficionado, normalmente en la parte baja de cada banda. Puntos habituales:

| Banda | Segmento |
|-------|----------|
| 40 m  | 7.000–7.040 MHz |
| 20 m  | 14.000–14.070 MHz |
| 15 m  | 21.000–21.080 MHz |

### Configuración

1. Sintonice una señal de CW usando el modo de demodulación **CW** o **CW-L** según proceda.
2. Active el decodificador y seleccione **CW** en el desplegable.
3. El panel **CW Decoder** aparece debajo.

### Lectura de la salida

- La cabecera del panel muestra la frecuencia detectada de la señal en Hz (p. ej., `≈ 700 Hz`) y la velocidad de manipulación estimada en palabras por minuto (p. ej., `· 22 WPM`).
- Si no se detecta señal, la cabecera muestra **scanning…**
- El texto decodificado se desplaza en caracteres ámbar de paso fijo. El cursor parpadeante (▋) marca dónde se está escribiendo.
- Haga clic en **Clear** para borrar el búfer de salida.

> **Consejos:**
> - Centre el paso de banda en el tono de CW. El decodificador funciona mejor cuando la señal de CW se sitúa aproximadamente entre 400 y 900 Hz en el espectro de audio.
> - Una manipulación muy rápida o muy lenta, así como un Morse muy manual (irregular), pueden reducir la precisión.
> - El decodificador rinde mejor con una única señal limpia. Un QRM fuerte de señales cercanas en la misma banda puede confundirlo.

---

## 5. WSPR

**Qué es:** WSPR (Weak Signal Propagation Reporter, pronunciado «whisper») es un modo baliza de señales ultradébiles que cartografía las trayectorias de propagación en HF por todo el mundo. Cada transmisión dura unos 110 segundos y cabe en una ranura de 200 Hz de ancho. El decodificador espera a una ranura completa de 2 minutos alineada con UTC antes de decodificar.

### Frecuencias recomendadas (USB, dial)

| Banda | Frecuencia de dial |
|-------|--------------------|
| 160 m | 1.836.600 MHz |
| 80 m  | 3.568.600 MHz |
| 40 m  | 7.038.600 MHz |
| 30 m  | 10.138.700 MHz |
| 20 m  | 14.095.600 MHz |
| 17 m  | 18.104.600 MHz |
| 15 m  | 21.094.600 MHz |

### Configuración

1. Sintonice una de las frecuencias de dial de WSPR anteriores y ponga el modo en **USB**.
2. La señal WSPR ocupa el margen de audio 1400-1600 Hz. No hace falta ajustar más el paso de banda.
3. Active el decodificador y seleccione **WSPR** en el desplegable.
4. El panel **WSPR-2 Decoder** aparece debajo.

### Lectura de la salida

El panel muestra una barra de progreso para la ranura de 2 minutos en curso:

- **Barra cian llenándose**: recogida de datos de señal (de 0 a 116 s dentro de la ranura).
- **Barra ámbar parpadeando**: decodificación en curso (los últimos ~4 s de la ranura).
- **Barra vacía**: esperando al siguiente minuto UTC par.

Cada punto (spot) decodificado con éxito se muestra en una tabla con las siguientes columnas:

| Columna | Significado |
|---------|-------------|
| UTC | Hora del spot (minuto par) |
| Callsign | La estación que transmitió |
| Grid | Localizador Maidenhead del transmisor |
| Power | Potencia transmitida en dBm |
| Freq | Frecuencia de audio exacta (Hz) dentro del paso de banda de WSPR |
| SNR | Relación señal/ruido en dB |

Haga clic en **Clear** para borrar la lista de spots.

> **Consejo:** la decodificación de WSPR requiere una hora del sistema muy precisa (±1 segundo respecto a UTC). La primera ranura tras activar el decodificador comenzará en el siguiente minuto UTC par; una breve espera es normal.

---

## 6. FAX de HF / WEFAX

**Qué es:** el radiofax de HF (también conocido como WEFAX) lo utilizan los servicios de guardacostas y meteorológicos de todo el mundo para difundir mapas del tiempo, cartas del estado del mar y análisis de superficie por onda corta. El decodificador reconstruye la imagen línea a línea a medida que se recibe.

### Configuración

1. Active el decodificador y seleccione **HF FAX / WEFAX** en el desplegable.
2. El panel **HF FAX / WEFAX Receiver** aparece debajo.
3. **Seleccione una estación** en el desplegable Station. Hay más de 20 estaciones disponibles que cubren Europa, Asia, Oceanía y América (p. ej., DDH3/DDK3 Alemania, SVJ4/GR Grecia, JMH Japón, NMG EE. UU. Nueva Orleans).
4. Si la estación emite en más de una frecuencia, seleccione la deseada en el subdesplegable **Frequency**.
5. Haga clic en **▶ Tune** para sintonizar automáticamente la cascada en esa estación.
6. El modo se fuerza automáticamente a **USB**.

### Horario de emisiones

Al seleccionar una estación aparece una tabla de cuenta atrás **Next Transmissions** con las 4 próximas emisiones programadas en UTC y una cuenta atrás en directo:

- Normal (gris/verde): la transmisión está próxima.
- **Ámbar ⚡**: la transmisión empieza en menos de 3 minutos; prepare ya el decodificador.
- **Rojo ●**: la transmisión empieza en menos de 30 segundos; la recepción es inminente.

### Parámetros

La mayoría de las estaciones usan los valores estándar por defecto (marcados con ★). Cámbielos solo si sabe que la estación emplea ajustes no estándar.

| Parámetro | Por defecto | Descripción |
|-----------|-------------|-------------|
| LPM | 120 ★ | Líneas por minuto: la velocidad de giro del tambor |
| IOC | 576 ★ | Índice de cooperación: determina los píxeles por línea |
| Shift | 800 Hz ★ | Desplazamiento de frecuencia entre los tonos de negro y blanco |

### Controles

- **⇔ Auto-align**: activado por defecto. Se sincroniza automáticamente con la señal de fase al principio de cada imagen. Desactívelo solo si tiene problemas de alineación con una señal que sabe que es buena.
- **⇅ Invert**: intercambia blanco y negro. Úselo si la imagen aparece en negativo (zonas blancas donde debería haber negro).
- **↺ Refresh**: borra el lienzo y reinicia el decodificador. Úselo entre transmisiones o si la imagen se rompe o se desplaza.
- **⤓ Save PNG**: guarda el lienzo actual como archivo PNG en su ordenador.

### Indicadores de estado

Bajo la imagen, dos indicadores de tono muestran:

- **300 Hz phasing**: se ilumina en cian cuando se detecta el tono de fase de inicio de imagen.
- **450 Hz stop**: se ilumina en rojo cuando se detecta el tono de parada de fin de imagen.

> **Nota:** la imagen se desplaza hacia arriba; la línea recibida más reciente siempre aparece en la parte inferior del lienzo. Si ve **[PHASING]** en la cabecera, el decodificador se ha enganchado al inicio de una nueva imagen.

---

## 7. NAVTEX

**Qué es:** NAVTEX es el sistema internacional de radiodifusión marítima de información de seguridad costera: avisos a la navegación, previsiones meteorológicas y avisos de búsqueda y rescate. Utiliza FSK a 100 baudios (SITOR-B con FEC) y se recibe en canales dedicados en todo el mundo.

### Canales disponibles

| Canal | Frecuencia | Uso |
|-------|------------|-----|
| Internacional | 518 kHz | En inglés, internacional |
| Nacional | 490 kHz | Emisiones en el idioma nacional |
| HF (×5) | 4209.5 / 6314 / 8416.5 / 12579 / 16806.5 kHz | NAVTEX de HF de largo alcance |

### Configuración

1. Active el decodificador y seleccione **NAVTEX** en el desplegable. El receptor pasa automáticamente a **USB**.
2. Aparece el panel **NAVTEX Receiver**.
3. Seleccione el canal deseado en el desplegable **Station** (p. ej., `International — 518 kHz`).
4. Haga clic en **⇒ Tune & Set IF** para sintonizar automáticamente la cascada y estrechar el paso de banda hasta la ventana de audio correcta. El modo se pone automáticamente en **USB**. El dial se sitúa 500 Hz por debajo del centro del canal, de modo que la señal NAVTEX aparece a 500 Hz en audio.

### Horario de emisiones

La tabla de horarios enumera todas las estaciones conocidas del canal seleccionado con:

- su letra identificadora de la UIT y la bandera del país
- la hora de la próxima emisión en UTC
- una cuenta atrás en directo hasta la próxima transmisión
- **Ámbar ⚡** a menos de 2 minutos / **Rojo ●** a menos de 30 segundos: prepare ya el decodificador

### Lectura de la salida

El texto decodificado aparece en color verde azulado y paso fijo. Los límites de los mensajes están claramente marcados:

```
━━ ZCZC MA12 ━━
... message content ...
━━ NNNN ━━
```

`ZCZC` marca el inicio de un mensaje. Los tres caracteres siguientes identifican la estación (`M`), el tema (`A` = avisos a la navegación) y el número de orden (`12`). `NNNN` marca el final.

Haga clic en **Clear** para borrar el búfer de mensajes.

> **Nota:** NAVTEX funciona en frecuencias de MF y LF (518/490 kHz). El alcance de recepción suele ser de 200 a 400 millas náuticas desde el transmisor. Los canales de HF (4-17 MHz) ofrecen un alcance mucho mayor.

---

## 8. FSK / RTTY

**Qué es:** un decodificador FSK (modulación por desplazamiento de frecuencia) / RTTY de uso general compatible con tres variantes de funcionamiento: FSK marítimo (SITOR), RTTY meteorológico y RTTY de aficionados. Cada variante incluye un preajuste con sus parámetros estándar.

### Variantes y preajustes

| Variante | Centro | Shift | Baudios | Trama | Codificación |
|----------|--------|-------|---------|-------|--------------|
| FSK marítimo / SITOR | 500 Hz | 170 Hz | 100 | 7N1 | CCIR-476 |
| RTTY meteorológico | 1000 Hz | 450 Hz | 50 | 5N1.5 | ITA2 |
| RTTY de aficionados | 1000 Hz | 170 Hz | 45.45 | 5N1.5 | ITA2 |

### Configuración

1. Active el decodificador y seleccione **FSK / RTTY** en el desplegable.
2. Aparece el panel **FSK / RTTY Decoder**.
3. Seleccione la **Variant** (Maritime, Weather o Ham). Los parámetros se actualizan automáticamente.
4. Use el desplegable **Known frequency** para elegir una frecuencia habitual de la variante seleccionada y haga clic en **Tune** para saltar a ella.
5. Afine la frecuencia hasta que el texto decodificado sea estable y legible.

### Frecuencias conocidas por variante

**FSK marítimo / SITOR**
- 518.0 kHz — NAVTEX internacional
- 490.0 kHz — NAVTEX nacional
- 4209.5 / 6314,0 / 8416.5 / 12579,0 / 16806.5 / 22376.0 kHz — SITOR de HF

**RTTY meteorológico**
- 4583,0 / 7646,0 / 10100,8 / 11039,0 / 14467.3 kHz — DWD (Servicio Meteorológico Alemán)

**RTTY de aficionados**
- 3590 kHz (80 m), 7043 kHz (40 m), 10143 kHz (30 m), 14083 kHz (20 m), 21083 kHz (15 m), 28083 kHz (10 m)

### Parámetros

| Parámetro | Descripción |
|-----------|-------------|
| Center audio (Hz) | La frecuencia de audio del punto medio entre mark y space |
| Shift (Hz) | Diferencia de frecuencia entre los tonos mark y space |
| Baud | Velocidad de símbolos |
| Framing | Bits de datos, paridad, bits de parada (p. ej., 7N1 = 7 de datos, sin paridad, 1 de parada) |
| Encoding | Juego de caracteres (CCIR-476, ITA2/Baudot o ASCII) |
| Invert mark / space | Intercambia los tonos mark y space |
| Auto shift detect | Intenta medir el shift automáticamente a partir de la señal entrante |

### Métricas de la señal

La barra de estado muestra mediciones en directo:

- **Mark / Space**: frecuencia de audio medida de cada tono (Hz)
- **SNR**: relación señal/ruido en dB
- **Lock**: calidad de enganche del decodificador en porcentaje
- **Timing**: `LOCKED` cuando el reloj de bit está sincronizado, `SEARCH` mientras sigue buscando

### Controles adicionales

- **⇒ Set IF Band-Pass**: estrecha el paso de banda del receptor para encuadrar ajustadamente la señal FSK según los ajustes actuales de centro y shift. Úselo después de sintonizar para mejorar la selectividad y reducir las interferencias adyacentes.
- **⟳ Auto-tune Center**: lanza un barrido automático para encontrar y engancharse a los tonos mark/space. Útil cuando está cerca de la frecuencia correcta pero los tonos quedan ligeramente desplazados.

> **Nota sobre el modo:** el decodificador FSK toma el control del modo de demodulación y del paso de banda de FI mientras está activo. Ambos se restauran automáticamente al desactivarlo.
>
> **Nota sobre la polaridad:** para RTTY (meteorológico) normalmente hay que marcar **Invert mark / space**. Para FSK marítimo (tipo SITOR/NAVTEX) y RTTY de aficionados, déjelo sin marcar. Si el texto decodificado sale ininteligible, lo primero que debe probar es cambiar esta casilla.

---

## 9. SSTV

**Qué es:** la televisión de barrido lento transmite imágenes fijas por un canal de voz SSB normal, línea a línea, como un tono modulado en frecuencia entre 1500 Hz (negro) y 2300 Hz (blanco). Una imagen completa tarda entre 36 segundos y 4 minutos y medio según el modo.

### Frecuencias recomendadas (USB)

| Banda | Frecuencia | Modo | Notas |
|-------|------------|------|-------|
| 20 m | 14.230 MHz | USB | La principal frecuencia internacional de llamada SSTV, con diferencia la más activa |
| 20 m | 14.233 MHz | USB | Secundaria, se usa cuando 14.230 está ocupada |
| 15 m | 21.340 MHz | USB | |
| 10 m | 28.680 MHz | USB | Activa durante las aperturas de banda |
| 40 m | 7.171 MHz | LSB | |
| 80 m | 3.845 MHz | LSB | Regional, por las tardes |

**La banda lateral se elige por usted.** Al iniciar el decodificador se selecciona **LSB por debajo de 10 MHz** y **USB por encima**, siguiendo la práctica habitual de radioafición. En la banda lateral equivocada la correspondencia de tonos queda invertida y la imagen no se decodificará. Si se encuentra con una estación que ignora la convención, cambie la banda lateral a mano: el decodificador sigue funcionando, borra el cuadro y empieza de nuevo con el nuevo ajuste.

### Configuración

1. Active el decodificador y seleccione **SSTV** en el desplegable. El receptor cambia de banda lateral automáticamente: USB por encima de 10 MHz, LSB por debajo.
2. Sintonice de modo que los tonos de la imagen caigan en el centro del paso de banda. Una señal bien sintonizada tiene sus impulsos de sincronismo a 1200 Hz y el contenido de imagen entre 1500 y 2300 Hz.
3. Deje **Mode** en **Auto** salvo que ya sepa qué se está enviando. La imagen se va formando línea a línea según se recibe.

### Modos

| Ajuste | Imagen | Duración |
|--------|--------|----------|
| **Auto** | Detectado automáticamente | — |
| Martin M1 / M2 | 320×256 color | 114 s / 58 s |
| Scottie S1 / S2 | 320×256 color | 110 s / 71 s |
| Scottie DX | 320×256 color | 269 s |
| Robot 36 / 72 | 320×240 color | 36 s / 72 s |

**Auto** funciona de dos maneras: lee la **cabecera VIS** —el código digital del modo enviado en los primeros 300 ms de una transmisión— y, si se perdió la cabecera (sintonizó tarde o se perdió por QSB), identifica el modo a partir de la temporización de los impulsos de sincronismo. Seleccionar un modo concreto lo fuerza, pero el decodificador sigue verificando el sincronismo antes de dibujar nada, de modo que una elección equivocada no produce imagen en lugar de ruido.

### Lectura de la salida

La línea de estado bajo los controles informa de lo que está haciendo el decodificador:

| Estado | Significado |
|--------|-------------|
| `Waiting for VIS / AUTO lock` | Escuchando; aún no se ha identificado nada |
| `Martin M1? verifying sync…` | Se ha encontrado un candidato y se está confirmando con las líneas siguientes |
| `Martin M1 lock (VIS)` | Enganchado a partir de la cabecera VIS |
| `Martin M1 lock (AUTO)` | Enganchado a partir de la temporización de sincronismo |
| `Martin M1 lock (MANUAL)` | Iniciado con el botón **⏺ Force** |
| `Candidate rejected (no sync)` | El candidato no se confirmó; normal con ruido |
| `— sync lost, resetting` | La señal desapareció a mitad de imagen |
| `Frame complete` | Se recibió la imagen completa |

El modo detectado también aparece en verde junto al título **SSTV**, y el contador de líneas muestra el avance.

### Controles

| Botón | Acción |
|-------|--------|
| **▶ Start** | Arma el decodificador. No dibuja una imagen por sí solo: el enganche debe venir de la cabecera VIS o de la detección de sincronismo. |
| **■ Stop** | Detiene la decodificación. |
| **↺ Reset** | Borra el lienzo y vuelve a armar en el sitio. Úselo entre imágenes o después de resintonizar. |
| **⏺ Force** | Empieza a dibujar **de inmediato** en el modo seleccionado en el desplegable, omitiendo por completo el VIS y la detección de sincronismo. Solo está disponible cuando Mode no está en **Auto**. |
| **💾 Save** | Guarda la imagen actual como PNG. |

**Cuándo usar Force.** Si ve una imagen en la cascada pero el decodificador no consigue engancharse —un modo poco común, una señal demasiado débil o distorsionada para los detectores, o una cabecera que se perdió—, seleccione el modo a mano y pulse **⏺ Force**. El cuadro se ancla en el momento del clic, y la etiqueta de modo muestra `MANUAL` para que lo distinga de un enganche por VIS o AUTO. El decodificador sigue ajustándose a un impulso de sincronismo real si lo encuentra, así que un clic algo adelantado o retrasado se corrige.

Como Force omite todas las comprobaciones de seguridad, pintará ruido sin más si lo pulsa en un canal vacío, y no se detendrá solo: pulse **■ Stop** o **↺ Reset**.

### Notas

- **El ruido no arranca el decodificador.** Antes bastaban los chasquidos atmosféricos, las chispas y el zumbido de la red para disparar una decodificación. Ahora cada etapa de detección comprueba que el tono sea un tono real y confirma el candidato con las líneas siguientes antes de dibujar un solo píxel. Es normal que el decodificador permanezca en silencio en una banda vacía.
- **La imagen se inclina en diagonal si está fuera de frecuencia.** SSTV no perdona los errores de sintonía. Si las líneas se tuercen, ajuste el dial en pequeños pasos y deje que empiece la siguiente imagen.
- El equilibrio de color y la nitidez son fijos; no hay nada que ajustar.

---

## 10. Consejos generales

**Primero hay que activar Decoder: ON.** El desplegable está desactivado (en gris) hasta que hace clic en el botón Decoder.

**Un decodificador cada vez.** Seleccionar un nuevo decodificador en el desplegable detiene automáticamente el que estuviera activo y deshace los cambios de modo o paso de banda que hubiera hecho.

**El modo se gestiona por usted.** El FAX de HF y NAVTEX ponen el receptor en USB en cuanto los selecciona, SSTV elige la banda lateral según la banda (LSB por debajo de 10 MHz, USB por encima) y FAX, NAVTEX y FSK también ajustan el paso de banda al pulsar su botón Tune. Al detener el decodificador se restaura el modo por defecto de la banda.

**Activar un decodificador ya no interrumpe el audio.** Los decodificadores se ejecutan en sus propios hilos, así que no hay huecos, chasquidos ni cortes al iniciar, detener o cambiar de decodificador.

**La precisión del reloj del sistema importa.** FT8, FT4 y WSPR son críticos en el tiempo. Decodifican en ventanas fijas alineadas con UTC. Si el reloj del ordenador se desvía más de 1 o 2 segundos, la tasa de decodificación caerá notablemente. Use un cliente NTP para mantenerlo preciso.

**La calidad de la señal importa más que su fuerza.** La mayoría de estos decodificadores están pensados para señales débiles. Una banda más tranquila y con menos ruido suele ser más productiva que una señal fuerte llena de interferencias. Use la cascada y los controles de paso de banda para identificar y evitar el QRM antes de activar un decodificador.

**Use los botones Refresh o Clear sin reparos.** Las imágenes de FAX se desplazan si la frecuencia de dial está algo desviada, y los decodificadores de texto acumulan caracteres espurios. Empezar de cero tras ajustar la sintonía suele producir una salida mucho más limpia.

---

*PhantomSDR-Plus — fork de sv1btl — [phantomsdr.no-ip.org](http://phantomsdr.no-ip.org:8900)*
