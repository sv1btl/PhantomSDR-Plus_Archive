# PhantomSDR-Plus

**Un servidor WebSDR de código abierto mejorado, con funciones avanzadas y diseño futurista**

PhantomSDR-Plus es un fork de PhantomSDR que ofrece un servidor web de radio definida por software (SDR) de alto rendimiento, capaz de atender a cientos de usuarios simultáneos. Incorpora una interfaz de usuario mejorada, compatibilidad con múltiples decodificadores, visualización del plan de bandas y compatibilidad con diversas plataformas de hardware SDR.

---

## 🌟 Funciones principales

### Rendimiento y escalabilidad
- **Compatibilidad multiusuario**: cientos de usuarios simultáneos según el hardware
- **Alta tasa de muestreo**: admite SDR de hasta 70 MSPS (real) / 35 MSPS (IQ)
- **Aceleración por hardware**: compatibilidad con OpenCL y CUDA para procesamiento acelerado por GPU
- **Transmisión optimizada**: compresión de audio FLAC y Opus de baja latencia

### Interfaz de usuario
- **Diseño futurista**: interfaz web moderna y adaptable
- **Optimizada para móviles**: interfaz móvil mejorada para escuchar en movimiento
- **Visualización del plan de bandas**: cascada interactiva con superposición de bandas de frecuencia
- **Mapas de color personalizables**: varios esquemas de color para la cascada
- **S-metro doble**: a elegir entre indicación de señal analógica o digital

### Procesamiento de señal
- **Múltiples modos de demodulación**: AM, FM, USB, LSB, CW y más
- **Detección de AM síncrona**: mejor calidad de recepción en AM
- **Reducción de ruido**: NR avanzado, NC (cancelación de ruido) y NB (supresor de impulsos)
- **Opciones de AGC**: varios modos de control automático de ganancia
- **Squelch automático**: umbral de squelch automático basado en el ruido

### Funciones avanzadas
- **Decodificadores digitales**: FT8, FT4, FT2, CW, WSPR, FAX de HF, SSTV, NAVTEX, FSK/RTTY y FreeDV RADE, cada uno ejecutándose en su propio hilo en segundo plano para que la decodificación nunca interrumpa el audio (véase [Decodificadores](DECODERS.md))
- **Panel de estadísticas**: estadísticas del servidor y de los usuarios en tiempo real
- **Sistema de marcadores**: importación/exportación de marcadores de frecuencia
- **Atajos de teclado**: navegación y control eficientes
- **Compatibilidad con la rueda del ratón**: sintonía de frecuencia intuitiva
- **Directorio WebSDR**: integración con https://sdr-list.xyz

---

## 📋 Hardware compatible

PhantomSDR-Plus es compatible con una amplia gama de receptores SDR:

| Dispositivo | Tasa de muestreo | Formato | Interfaz |
|-------------|------------------|---------|----------|
| **RX888 MK2** | Hasta 64 MHz | 16 bits | Nativa |
| **RTL-SDR** | Hasta 3.2 MHz | 8 bits | rtl_sdr |
| **HackRF One** | Hasta 20 MHz | 8 bits | hackrf_transfer |
| **Airspy HF+** | Hasta 912 kHz | 16 bits | airspy_rx |
| **Airspy Discovery** | Variable | 16 bits | SoapySDR |
| **SDRplay RSP1A** | Hasta 10 MHz | 16 bits | SoapySDR |
| **Otros dispositivos** | Variable | Varios | SoapySDR/rx_tools |

---

## 🚀 Inicio rápido

### Requisitos del sistema

**Mínimos:**
- Ubuntu 22.04 LTS (recomendado) o Fedora
- CPU de 2 núcleos
- 4 GB de RAM
- 10 GB de espacio en disco

**Recomendados:**
- Ubuntu 24.04 LTS
- CPU de 4 o más núcleos (Ryzen 5 2600 o Intel i5-6500T o superior)
- 8 GB de RAM
- GPU compatible con OpenCL (opcional, pero muy recomendable)
- Almacenamiento SSD

### Instalación

```bash
# Clonar el repositorio
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus

# Hacer ejecutables los scripts
chmod +x *.sh

# Ejecutar la instalación automática
./install.sh
```

**Nota:** después de ejecutar `install.sh`, reinicie el terminal antes de continuar.

Para instrucciones de instalación detalladas, consulte [INSTALLATION.md](INSTALLATION.md).

---

## 📊 Pruebas de rendimiento

| Hardware | Tasa de muestreo | Uso de CPU | Capacidad de usuarios |
|----------|------------------|------------|------------------------|
| Ryzen 5 2600 (todos los núcleos) | 64 MHz (32 MHz IQ) | 38-40 % | Más de 100 usuarios |
| AMD RX 580 (GPU) | 64 MHz (32 MHz IQ) | 28-35 % | Más de 100 usuarios |
| Intel i5-6500T (con OpenCL) | 60 MHz (30 MHz IQ) | 10-12 % | Más de 100 usuarios |

*Nota: la carga adicional de CPU por usuario es mínima (<1 % por usuario) cuando la aceleración por hardware está activada.*

---

## 🎯 Uso

### Funcionamiento básico

1. **Configure su SDR**: edite el archivo de configuración correspondiente (p. ej., `config-rtl.toml`)
2. **Actualice la información del sitio**: edite `frontend/site-information.json`
3. **Inicie el servidor**: ejecute el script de arranque adecuado:
   ```bash
   ./start-rtl.sh      # Para RTL-SDR
   ./start-rsp1a.sh    # Para SDRplay RSP1A
   ./start-airspyhf.sh # Para Airspy HF+
   ./start-rx888mk2.sh # Para RX888 MK2
   ```
   Cada script de arranque es **autónomo**: detiene cualquier instancia en ejecución, lanza el
   receptor + `spectrumserver`, **pasa a segundo plano** (sobrevive al cierre del terminal) y
   ejecuta un **watchdog** que reinicia automáticamente la cadena si esta se cae. El progreso
   se registra en `logwebsdr.txt`: obsérvelo con `tail -f logwebsdr.txt`. Volver a ejecutar un
   script de arranque equivale a un reinicio limpio, y un bloqueo `flock` garantiza que solo
   funcione un receptor a la vez. Opcional: `SPECTRUM_CORES=0-3` para fijar CPU, `RX_ARGS="…"`
   para sustituir los argumentos del receptor sin editar el archivo (`RX888_ARGS` para el RX888).
4. **Acceda a la interfaz**: abra el navegador en `http://localhost:PORT` (el puerto predeterminado varía según la configuración)

### Detener el servidor

Un único script de parada compartido sirve para **todos** los receptores: primero detiene el
watchdog (para que no pueda reiniciar el sistema) y después el receptor y `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## 🔧 Configuración

### Archivos de configuración esenciales

1. **`config-[dispositivo].toml`**: configuración del servidor y del SDR
   - Ajustes del servidor (puerto, hilos, raíz HTML)
   - Ajustes de entrada (tasa de muestreo, tamaño de FFT, frecuencia)
   - Opciones de registro en el directorio WebSDR
   - Ajustes de compresión de audio
   - Tras modificarlo, reinicie el servidor.

2. **`frontend/site-information.json`**: información pública del sitio
   - Datos del operador (indicativo, correo electrónico, ubicación)
   - Información sobre hardware y antena
   - Ajustes de región y ancho de banda
   - Activación/desactivación del chat
   - Tras modificarlo, ejecute recompile.sh en un terminal.

3. **`markers.json`**: marcadores de frecuencia y plan de bandas

4. **`frontend/src/bands-config.js`**: configuración del plan de bandas
   Este archivo se encuentra en frontend/src/bands-config.js y define las bandas que crea el SysOp. <br />
- Verá algo parecido a lo siguiente y puede editarlo a su gusto:
   ```
   - const bands = 
   .....
   - { ITU: 1,
            name: '40m', min: -30, max: 110, initFreq: '7120000', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
	},
	{ ITU: 2,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7300000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7050000 },
              { mode: MODES.LSB, startFreq: 7050000, endFreq: 7300000 }]
	},
	{ ITU: 3,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)',
            modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
   .....
   etc
   ```
   **Donde:** <br />
   - **ITU** es la región en la que se encuentra el servidor,
   - **min y max** son los límites de brillo de la cascada para la banda indicada,
   - **initFreq** es la frecuencia inicial a la que sintonizar cuando se selecciona la banda,
   - **publishBand** determina si la banda se muestra: 1 para bandas de radioaficionado, 2 para bandas de radiodifusión,
   - **startFreq y endFreq** definen los límites de la banda,
   - **stepi** es el paso predeterminado de la rueda del ratón para la banda, y **modes** es el modo predeterminado preferido para la banda.

- Después de realizar cambios, **ejecute recompile.sh en un terminal** desde la carpeta PhantomSDR-Plus.

Para ver ejemplos de configuración, consulte los archivos de muestra incluidos:
- `config-rtl.toml`: configuración de RTL-SDR
- `config-rsp1a.toml`: configuración de SDRplay RSP1A
- `config-airspyhf.toml`: configuración de Airspy HF+
- `config-rx888mk2.toml`: configuración de RX888 MK2

---

## 🎨 Personalización

### Cambiar la imagen de fondo

Sustituya `frontend/src/assets/background.jpg` por la imagen que prefiera (conservando el mismo nombre de archivo).

- Tras modificarla, ejecute recompile.sh en un terminal.


### Selección del códec de audio

Elija entre FLAC y Opus en su configuración `.toml`:
```toml
[input]
audio_compression="opus"  # or "flac"
```
- Tras modificarlo, reinicie el servidor.


### Calibración del S-metro
El S-metro ya está calibrado, pero si desea reajustarlo, haga lo siguiente:
- Para el **S-metro digital**, ajústelo en el archivo .toml que utilice. Busque 'smeter_offset=' en la sección [input], cámbielo y reinicie el servidor.
- Para el **S-metro analógico**, edite 'App__analog_smeter_.svelte' y 'App__v2_analog_smeter_.svelte', ambos en frontend/src. Busque 'const visualGain = ' y cambie el valor para que los S-metros digital y analógico indiquen lo mismo. Después recompile. No es necesario reiniciar el servidor.


### Variantes de la interfaz gráfica

En el directorio frontend hay varias variantes de la interfaz. Para cambiar de una a otra:
- Ejecute recompile.sh en un terminal.

---

## 📚 Documentación

- **[INSTALLATION.md](INSTALLATION.md)**: guía de instalación completa para operadores de sistema
- **[ADMIN_PANEL_SETUP.md](ADMIN_PANEL_SETUP.md)**: guía de instalación para administradores del sistema
- **[USER_GUIDE.md](USER_GUIDE.md)**: guía para el usuario final sobre el manejo del WebSDR
- **[PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)**: estructura de directorios y organización del código

---

## 🌐 Lista de WebSDR en línea

Registre su WebSDR en el directorio oficial: https://sdr-list.xyz

Establezca `register_online=true` en su archivo de configuración `.toml` para registrarlo automáticamente.

---

## 🐛 Resolución de problemas

### Problemas frecuentes

**OpenCL no funciona**
- Asegúrese de que los controladores estén correctamente instalados
- Compruébelo con el comando `clinfo`
- Consulte INSTALLATION.md para la configuración detallada de OpenCL

**Problemas de latencia de audio**
- Pruebe a alternar entre los códecs FLAC y Opus
- Ajuste la configuración del búfer
- Asegúrese de disponer de recursos de CPU/GPU suficientes

**Fallos de compilación**
- Compruebe que todas las dependencias estén instaladas
- Pruebe a limpiar el directorio de compilación: `rm -rf build && meson setup build`
- Busque versiones de bibliotecas en conflicto

---

## 🤝 Contribuir

¡Las contribuciones son bienvenidas! Este es un fork independiente con funciones adicionales. Por favor:

1. Haga un fork del repositorio
2. Cree una rama para la nueva función
3. Confirme sus cambios
4. Envíe la rama al repositorio remoto
5. Cree un Pull Request

---

## 📄 Licencia

Este proyecto se distribuye bajo la Licencia Pública General de GNU v3.0; consulte el archivo [LICENSE](../../LICENSE) para más detalles.

---

## 👥 Autores y créditos

- **SV1BTL y SV2AMK**: desarrollo y mejoras de PhantomSDR-Plus
- Basado en el proyecto original PhantomSDR

---

## 🔗 Enlaces

- **Demostración en directo**: http://phantomsdr.no-ip.org:8900/
- **Directorio WebSDR**: https://sdr-list.xyz
- **Repositorio de GitHub**: https://github.com/sv1btl/PhantomSDR-Plus

---

## 📞 Soporte

- **Incidencias**: informe de errores a través de [GitHub Issues](https://github.com/sv1btl/PhantomSDR-Plus/issues)
- **Correo electrónico**: contacto sv1btl@otenet.gr 

---

## ⚡ Consejos de rendimiento

1. **Active OpenCL/CUDA** para la aceleración por GPU: reduce drásticamente el uso de CPU
2. **Use almacenamiento SSD** para un mejor rendimiento de E/S
3. **Asigne suficiente RAM**: se recomiendan al menos 8 GB
4. **Optimice el tamaño de la FFT**: una FFT mayor = mejor resolución, pero más uso de CPU
5. **Considere una GPU dedicada**: AMD o NVIDIA con compatibilidad OpenCL

---

**73 de SV1BTL & SV2AMK**

*Para instrucciones de configuración detalladas, consulte INSTALLATION.md*
*Para la guía de manejo del usuario final, consulte USER_GUIDE.md*
