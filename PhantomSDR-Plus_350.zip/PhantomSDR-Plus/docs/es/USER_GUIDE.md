# Guía del usuario de PhantomSDR-Plus

¡Bienvenido a PhantomSDR-Plus! Esta guía le ayudará a sacar el máximo partido a su experiencia de escucha con WebSDR.

---

## Índice

1. [Introducción](#introducción)
2. [Primeros pasos](#primeros-pasos)
3. [Descripción de la interfaz](#descripción-de-la-interfaz)
4. [Operaciones básicas](#operaciones-básicas)
5. [Funciones avanzadas](#funciones-avanzadas)
6. [Modos de demodulación](#modos-de-demodulación)
7. [Decodificadores digitales](#decodificadores-digitales)
8. [Atajos de teclado](#atajos-de-teclado)
9. [Marcadores](#marcadores)
10. [Uso en móviles](#uso-en-móviles)
11. [Consejos y buenas prácticas](#consejos-y-buenas-prácticas)
12. [Resolución de problemas](#resolución-de-problemas)
13. [Preguntas frecuentes](#preguntas-frecuentes)

---

## Introducción

### ¿Qué es PhantomSDR-Plus?

PhantomSDR-Plus es una radio definida por software (SDR) basada en web que le permite escuchar señales de radio a través de Internet. No necesita software ni hardware especial por su parte: ¡basta con un navegador web moderno!

### ¿Qué puede escuchar?

Según la configuración del WebSDR, podrá sintonizar:

- **Radioafición**: radioaficionados de todo el mundo
- **Emisoras de radiodifusión**: radio AM/FM, emisiones en onda corta
- **Aviación**: control del tráfico aéreo, comunicaciones aeronáuticas
- **Marítimo**: comunicaciones barco-costa, meteorología marítima
- **Satélites meteorológicos**: NOAA, METEOR-M
- **Modos digitales**: FT8, RTTY, PSK31 y más
- **Estaciones de servicio**: señales horarias, militares, gubernamentales

### Requisitos del sistema

- **Navegador**: Chrome/Edge (recomendado), Firefox, Safari
- **Conexión**: Internet de banda ancha (se recomienda 1 Mbps o más)
- **Audio**: altavoces o auriculares en funcionamiento
- **Opcional**: ratón con rueda para sintonizar con mayor comodidad

---

## Primeros pasos

### 1. Acceda al WebSDR

Abra su navegador y vaya a la dirección del WebSDR que le haya facilitado el operador.

Ejemplo: `http://websdr.example.com:9002`

### 2. Carga inicial de la página

Al cargarse la página verá:
- una cascada de colores que muestra la actividad radioeléctrica
- un panel de control con el indicador de frecuencia y los botones
- un S-metro que indica la intensidad de la señal
- un indicador del número de usuarios

### 3. Empiece a escuchar

1. **Haga clic sobre una señal** en la cascada
2. **El audio comenzará automáticamente**
3. **Ajuste el volumen** con el control del navegador o el deslizador en pantalla
4. **Afine la frecuencia** haciendo clic con precisión sobre la señal

---

## Descripción de la interfaz

### Componentes principales

```
┌─────────────────────────────────────────────────────────┐
│  Station Info Bar                                       │
├─────────────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────────────┐ │
│  │                                                   │ │
│  │           Waterfall Display                       │ │
│  │        (Spectrum Visualization)                   │ │
│  │                                                   │ │
│  └───────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────┤
│  Frequency Display: 7.100.000 MHz          [S-Meter]   │
├─────────────────────────────────────────────────────────┤
│  [AM] [FM] [USB] [LSB] [CW]    Volume: ▓▓▓▓▓▓▓░░░    │
├─────────────────────────────────────────────────────────┤
│  AGC: [Fast] NR: [Off] NB: [Off] SQL: [Auto]          │
├─────────────────────────────────────────────────────────┤
│  Users: 12    Statistics    Chat    Bookmarks          │
└─────────────────────────────────────────────────────────┘
```

### 1. Cascada (waterfall)

La cascada es una representación visual de las señales de radio:

- **Eje horizontal**: la frecuencia
- **Eje vertical**: el tiempo (se desplaza hacia abajo)
- **Colores**: la intensidad de la señal
  - **Azul oscuro/negro**: sin señal (nivel de ruido)
  - **Verde/amarillo**: señales débiles o moderadas
  - **Naranja/rojo**: señales fuertes
  - **Blanco**: señales muy fuertes

### 2. Indicador de frecuencia

Muestra la frecuencia sintonizada en distintos formatos:
- **MHz**: 7.100.000 MHz (bandas de HF)
- **kHz**: 14200 kHz
- **Hz**: 145500000 Hz (VHF/UHF)

### 3. S-metro (analógico o digital)

Muestra la intensidad de la señal:
- **S1-S9**: escala estándar de intensidad de señal
- **+dB**: señales por encima de S9 (p. ej., S9+20dB)
- **Analógico o digital**: según la configuración

### 4. Botones de modo

Seleccione el modo de demodulación:
- **AM**: modulación de amplitud
- **FM**: modulación de frecuencia
- **USB**: banda lateral superior
- **LSB**: banda lateral inferior
- **CW**: código Morse (onda continua)
- **WBFM**: FM de banda ancha (radiodifusión)

### 5. Panel de control

Controles adicionales:
- **AGC**: control automático de ganancia
- **NR**: reducción de ruido
- **NC**: cancelación de ruido
- **NB**: supresor de impulsos
- **SQL**: silenciador (squelch)
- **Zoom**: nivel de ampliación de la cascada

### 6. Superposición del plan de bandas

Barras de color que muestran las atribuciones de frecuencia:
- colores distintos para servicios distintos
- ayuda a identificar qué está permitido en cada frecuencia

---

## Operaciones básicas

### Sintonizar una frecuencia

#### Método 1: hacer clic en la cascada

1. Haga clic directamente sobre una señal de la cascada
2. El receptor sintonizará esa frecuencia
3. Comenzará a reproducirse el audio

#### Método 2: escribir la frecuencia

1. Haga clic en el indicador de frecuencia
2. Escriba la frecuencia deseada
3. Pulse Intro

Ejemplos:
- `7100` → 7.100 MHz
- `14200.0` → 14.200 MHz
- `145.500` → 145.500 MHz

#### Método 3: usar la rueda del ratón

1. Sitúe el puntero sobre el indicador de frecuencia
2. Rueda hacia arriba para aumentar la frecuencia
3. Rueda hacia abajo para reducirla

#### Método 4: botones de paso

1. Utilice los botones **▲** y **▼** junto a la frecuencia
2. El paso varía según el modo:
   - **AM/FM**: pasos de 1 kHz
   - **SSB**: pasos de 100 Hz
   - **CW**: pasos de 10 Hz

### Seleccionar el modo de demodulación

Elija el modo adecuado para la señal:

**Para comunicaciones de voz:**
- **AM**: aviación, radiodifusión en AM, algo de radioafición
- **FM**: repetidores de VHF/UHF, radiodifusión en FM
- **USB**: radioafición en HF (20 m, 17 m, 15 m, 12 m, 10 m)
- **LSB**: radioafición en HF (160 m, 80 m, 40 m, 30 m)

**Para datos/digital:**
- **USB**: la mayoría de los modos digitales (FT8, PSK31, RTTY)
- **LSB**: algunos modos digitales en las bandas bajas de HF

**Para código Morse:**
- **CW**: señales de telegrafía/Morse

### Ajustar el volumen

- **Deslizador en pantalla**: arrastre el control de volumen
- **Volumen del navegador**: use los controles multimedia del navegador
- **Volumen del sistema**: ajuste el volumen del ordenador
- **Teclado**: use las teclas + y - (si están admitidas)

### Uso del S-metro

El S-metro indica la intensidad de la señal:

- **S0-S3**: señal muy débil, difícil de copiar
- **S4-S6**: señal débil o aceptable
- **S7-S9**: señal buena o fuerte
- **S9+**: señal extremadamente fuerte

**Consejo**: para obtener el mejor audio, sintonice señales que marquen S7 o más.

---

## Funciones avanzadas

### Control automático de ganancia (AGC)

El AGC ajusta automáticamente los niveles de audio:

- **Off**: sin ajuste automático de ganancia
- **Slow**: cambios de nivel graduales (ideal para SSB)
- **Medium**: respuesta equilibrada
- **Fast**: ajuste rápido (ideal para AM)

**Recomendación**: empiece con «Fast» para AM y «Slow» para SSB.

### Reducción de ruido (NR)

Reduce el ruido de fondo:

- **Off**: sin reducción de ruido
- **Low**: reducción leve
- **Medium**: reducción moderada
- **High**: reducción agresiva (puede afectar a la calidad del audio)

**Úsela cuando**: oiga estática o ruido blanco detrás de la señal.

### Supresor de impulsos (NB)

Elimina el ruido impulsivo (chasquidos, crujidos):

- **Off**: sin supresión
- **On**: supresión activa

**Úselo cuando**: oiga chasquidos procedentes de líneas eléctricas, motores o interferencias.

### Cancelación de ruido (NC)

Cancela señales interferentes concretas:

- **Off**: sin cancelación
- **On**: cancelación activa

**Úsela cuando**: oiga un tono constante o una interferencia en la frecuencia.

### Silenciador automático (SQL)

Silencia el audio cuando no hay señal:

- **Off**: siempre suena (se oye la estática)
- **Auto**: fija el umbral automáticamente
- **Manual**: ajuste manual del umbral

**Úselo cuando**: vigile una frecuencia a la espera de actividad.

### Función de zoom

Amplía la cascada:

- **1x**: vista normal (cobertura amplia)
- **2x**: ampliación ×2
- **4x**: ampliación ×4
- **8x**: ampliación ×8

**Úsela cuando**: necesite ver las señales con más claridad o sintonizar con precisión.

---

## Modos de demodulación

### AM (modulación de amplitud)

**Se usa para:**
- comunicaciones aeronáuticas
- radiodifusión en AM
- parte de la radioafición
- comunicaciones marítimas

**Características:**
- ancho de banda amplio (normalmente 10 kHz)
- sensible al ruido
- fácil de sintonizar (basta con hacer clic en la señal)

**Buenas prácticas:**
- use AGC rápido
- active el supresor de impulsos si oye chasquidos
- sintonice el pico de la señal en la cascada

### FM (modulación de frecuencia)

**Se usa para:**
- repetidores de radioafición de VHF/UHF
- servicios públicos (policía, bomberos, emergencias)
- radio comercial bidireccional
- algunas comunicaciones por satélite

**Características:**
- ancho de banda estrecho (normalmente 12,5 o 25 kHz)
- excelente inmunidad al ruido
- «efecto captura» (gana la señal más fuerte)

**Buenas prácticas:**
- sintonice con precisión el centro de la señal
- use el silenciador para enmudecer en reposo
- desactive la reducción de ruido (no hace falta)

### USB (banda lateral superior)

**Se usa para:**
- radioafición en HF (por encima de 10 MHz)
- la mayoría de los modos digitales de HF
- comunicaciones marítimas (por encima de 8 MHz)

**Características:**
- ancho de banda estrecho (normalmente 2.4 kHz)
- uso eficiente del espectro
- exige sintonía precisa

**Buenas prácticas:**
- use AGC lento
- sintonice el borde inferior de la señal en la cascada
- active la reducción de ruido si hace falta

### LSB (banda lateral inferior)

**Se usa para:**
- radioafición en HF (por debajo de 10 MHz)
- algunos modos digitales de HF
- comunicaciones marítimas (por debajo de 8 MHz)

**Características:**
- igual que USB pero en imagen especular
- convención: LSB en las bandas bajas de HF

**Buenas prácticas:**
- use AGC lento
- sintonice el borde superior de la señal en la cascada
- active la reducción de ruido si hace falta

### CW (onda continua / código Morse)

**Se usa para:**
- telegrafía de radioaficionados
- radiobalizas de navegación
- estaciones de señales horarias

**Características:**
- ancho de banda muy estrecho (100-500 Hz)
- gran eficiencia
- requiere conocer el código Morse para entenderlo

**Buenas prácticas:**
- use un filtro estrecho (400-500 Hz)
- sintonice con precisión el centro del tono
- active el filtro de audio para obtener mejor tono

### WBFM (FM de banda ancha)

**Se usa para:**
- radiodifusión en FM (88-108 MHz)
- algunos enlaces descendentes de satélite

**Características:**
- ancho de banda muy amplio (200 kHz)
- excelente calidad de audio
- alta fidelidad

**Buenas prácticas:**
- sintonice exactamente la frecuencia central
- no hace falta silenciador para la radiodifusión
- ¡disfrute de un audio de gran calidad!

---

## Decodificadores digitales

PhantomSDR-Plus incluye decodificadores integrados para modos digitales.
Para una guía completa, consulte [Decodificadores](DECODERS.md).

Los decodificadores de SSTV, FAX de HF, NAVTEX, FSK/RTTY y CW se ejecutan cada uno en su propio hilo en segundo plano, de modo que activar o desactivar un decodificador nunca interrumpe el audio y la cascada sigue fluida mientras se decodifica. Reciben audio tomado antes del AGC, la reducción de ruido y el silenciado: puede silenciar el receptor y la decodificación continúa sin verse afectada.

### Decodificador FT8, FT4

**¿Qué son FT8 y FT4?**
- modos digitales muy populares en radioafición
- comunicación con señales débiles
- transmisiones de 15 segundos en FT8 y de 7,5 segundos en FT4

**Cómo se usa:**
1. Sintonice frecuencias de FT8 o FT4
2. Seleccione el modo USB
3. Active el decodificador FT8 desde el menú
4. Observe cómo aparecen los mensajes decodificados

**Frecuencias habituales de FT8 (USB):**
- 160 metros: 1.840 MHz
- 80 metros: 3.573 MHz
- 60 metros: 5.357 MHz
- 40 metros: 7.074 MHz
- 30 metros: 10.136 MHz
- 20 metros: 14.074 MHz
- 17 metros: 18.100 MHz
- 15 metros: 21.074 MHz
- 12 metros: 24.915 MHz
- 10 metros: 28.074 MHz
- 6 metros: 50.313 MHz (50.323 MHz para DX)

**Frecuencias habituales de FT4 (USB):**

- 80 m: 3.575 MHz
- 40 m: 7.0475 MHz
- 30 m: 10.140 MHz
- 20 m: 14.080 MHz
- 17 m: 18.104 MHz
- 15 m: 21.140 MHz
- 12 m: 24.919 MHz
- 10 m: 28.180 MHz
- 6 m: 50.318 MHz

---

### Decodificador de CW
Basta con pulsar el botón CW y aparecerá el texto decodificado. Pulse el botón CW una vez más para limpiar la ventana y reiniciar el decodificador.

---

### WSPR

WSPR (Weak Signal Propagation Reporter, pronunciado «whisper») es un modo baliza de señales ultradébiles que cartografía las trayectorias de propagación en HF por todo el mundo. Cada transmisión dura unos 110 segundos y cabe en una ranura de 200 Hz de ancho. El decodificador espera a una ranura completa de 2 minutos alineada con UTC antes de decodificar. Active el decodificador y seleccione **WSPR** en la lista desplegable.

---

### FAX de HF / WEFAX

El radiofax de HF (también conocido como WEFAX) lo utilizan los servicios de guardacostas y meteorológicos de todo el mundo para difundir mapas del tiempo, cartas del estado del mar y análisis de superficie por onda corta. El decodificador reconstruye la imagen línea a línea a medida que se recibe.

---

### NAVTEX

NAVTEX es el sistema internacional de radiodifusión marítima de información de seguridad costera: avisos a la navegación, previsiones meteorológicas y avisos de búsqueda y rescate.

---

### FSK / RTTY

Un decodificador FSK (modulación por desplazamiento de frecuencia) / RTTY de uso general compatible con tres variantes de funcionamiento: FSK marítimo (SITOR), RTTY meteorológico y RTTY de aficionados.

---

### SSTV

La televisión de barrido lento envía imágenes fijas por un canal SSB normal, línea a línea. Active el decodificador, seleccione **SSTV** y sintonice una frecuencia de SSTV: 14.230 MHz es la principal frecuencia internacional de llamada. Deje **Mode** en **Auto**: el decodificador lee la cabecera VIS de la transmisión y, si sintonizó después de la cabecera, identifica el modo a partir de la temporización de sincronismo. Se admiten los modos Martin, Scottie y Robot, y la imagen se va formando línea a línea según llega.

---

## Atajos de teclado

Atajos de teclado para trabajar más rápido.

---

### Control de frecuencia
- **Flecha arriba/abajo**: cambiar la frecuencia (pasos grandes)
- **Re Pág/Av Pág**: cambiar la frecuencia (pasos pequeños)
- **Rueda del ratón**: sintonía fina de la frecuencia
- **Teclas numéricas**: introducción directa de la frecuencia

---

## Marcadores

Guarde sus frecuencias favoritas para acceder a ellas rápidamente. También puede exportar la lista de marcadores y guardarla localmente, y después importarla en cualquier otro PhantomSDR. 

Cuando los marcadores propios y los del plan de bandas se solapan:

🔵 Los marcadores azules aparecen encima <br />
🟡 Los marcadores amarillos, debajo <br />
✅ Los clics en los marcadores azules tienen prioridad <br />


### Añadir un marcador

1. Sintonice la frecuencia deseada
2. Haga clic en el botón «Bookmarks»
3. Haga clic en «Add Bookmark»
4. Escriba una descripción
5. Haga clic en «Save»

┌──────────────┬────────────────┬────────┐
│ Bookmark name│Label (optional)│ [Add]  │
└──────────────┴────────────────┴────────┘

### Cómo se usa:

**Añadir un marcador:**
- Nombre: «Local News Station»
- Etiqueta: «NEWS»
- Haga clic en Add

**Verlo en la cascada:**
- amplíe hasta que aparezcan los marcadores
- verá un recuadro azul marino con «NEWS» en amarillo y negrita

**Hacer clic en el marcador:**
- sintoniza la frecuencia
- fija el modo de demodulación
- funciona igual que hacer clic en un marcador del plan de bandas

### Gestionar los marcadores
- **Editar**: haga clic en el icono del lápiz junto al marcador
- **Eliminar**: haga clic en el icono de la papelera junto al marcador
- **Exportar**: descargue los marcadores como archivo JSON
- **Importar**: cargue marcadores desde un archivo JSON

### Compartir marcadores

1. Haga clic en «Export Bookmarks»
2. Comparta el archivo JSON con otras personas
3. Los destinatarios hacen clic en «Import Bookmarks»
4. Seleccionan su archivo
---

## Uso en móviles

¡PhantomSDR-Plus funciona de maravilla en dispositivos móviles!

### Funciones específicas para móviles

- **Controles táctiles**: botones y deslizadores grandes
- **Deslizar para sintonizar**: deslice a izquierda/derecha sobre la cascada
- **Pellizcar para ampliar**: pellizque la cascada para acercar o alejar
- **Modo horizontal**: gire el dispositivo para ver mejor

### Consejos para móviles

1. **Use wifi**: la transmisión de audio consume datos
2. **Orientación horizontal**: mejor vista de la cascada
3. **Auriculares**: mejor calidad de audio
4. **Guarde sus favoritas como marcadores**: es más fácil volver a las emisoras
5. **Cierre otras aplicaciones**: garantiza un funcionamiento fluido

### Navegadores móviles recomendados

- **Android**: Chrome o Samsung Internet
- **iOS**: Mozilla
- **Ambos**: asegúrese de que el navegador esté actualizado

---

## Consejos y buenas prácticas

### Para la mejor recepción

1. **Elija señales fuertes**: busque el naranja/rojo en la cascada
2. **Sintonice con precisión**: haga clic justo en el centro de la señal
3. **Seleccione el modo correcto**: adecuado al tipo de señal
4. **Ajuste el AGC**: rápido para AM, lento para SSB
5. **Use NR/NB**: ayudan en condiciones ruidosas

### Encontrar actividad

1. **Observe la cascada**: los colores indican la intensidad de la señal
2. **Escuche en frecuencias populares**:
   - 40 m: 7.100-7.300 MHz (LSB)
   - 20 m: 14.200-14.350 MHz (USB)
   - 2 m: 145.200-145.600 MHz (FM)
3. **Consulte la superposición del plan de bandas**: muestra las atribuciones de frecuencia
4. **Use los marcadores**: acceso rápido a frecuencias activas

### Entender las condiciones de propagación

**HF de día:**
- las bandas altas funcionan mejor (20 m, 15 m, 10 m)
- es posible la comunicación a larga distancia (DX)
- se oyen emisoras de radiodifusión

**HF de noche:**
- las bandas bajas funcionan mejor (80 m, 40 m)
- pautas de propagación distintas
- se oyen emisoras distintas

**VHF/UHF:**
- principalmente con visibilidad directa
- comunicaciones locales
- condiciones más constantes

### Etiqueta

1. **No monopolice el receptor**: otras personas también quieren escuchar
2. **Use el chat con respeto**: sea cortés con los demás usuarios
3. **Informe de los problemas**: ayude al operador a mantener la estación
4. **No pida soporte técnico**: esta es una plataforma de escucha. Envíe un mensaje al SysOp si necesita ayuda.

---

## Resolución de problemas

### No hay audio

**Posibles causas:**
1. Navegador silenciado → compruebe los controles de volumen del navegador
2. Sistema silenciado → compruebe el volumen del ordenador
3. Señal débil → sintonice una señal más fuerte (S7+)
4. Modo incorrecto → pruebe otros modos de demodulación

**Soluciones:**
1. Haga clic en una señal fuerte (naranja/roja en la cascada)
2. Compruebe que el navegador no esté silenciado (icono de silencio en la pestaña)
3. Pruebe otra frecuencia
4. Recargue la página (F5)

### Audio distorsionado

**Posibles causas:**
1. Señal saturada → señal demasiado fuerte
2. Modo incorrecto → señal de AM escuchada en SSB, etc.
3. Interferencias → señales adyacentes que se cuelan

**Soluciones:**
1. Baje el volumen
2. Pruebe otro modo de demodulación
3. Use un filtro más estrecho
4. Aléjese de las señales interferentes

### La cascada no se actualiza

**Posibles causas:**
1. Problema de red → conexión lenta o interrumpida
2. Rendimiento del navegador → demasiadas pestañas abiertas
3. Sobrecarga del servidor → demasiados usuarios

**Soluciones:**
1. Compruebe la conexión a Internet
2. Cierre las pestañas innecesarias
3. Recargue la página (F5)
4. Inténtelo más tarde, cuando haya menos usuarios conectados

### No se puede sintonizar una frecuencia

**Posibles causas:**
1. Frecuencia fuera de rango → el SDR no cubre esa frecuencia
2. Formato de escritura incorrecto → use el formato correcto (p. ej., «14200» y no «14.200.000»)

**Soluciones:**
1. Compruebe la cobertura de frecuencias del SDR (indicada en la página)
2. Use los ejemplos de formato de frecuencia facilitados
3. Haga clic en la cascada en su lugar

### Audio entrecortado

**Posibles causas:**
1. conexión a Internet lenta
2. carga elevada del servidor
3. problemas de rendimiento del navegador

**Soluciones:**
1. Cierre otras aplicaciones que consuman ancho de banda
2. Inténtelo fuera de las horas punta
3. Cierre las pestañas innecesarias
4. Use conexión por cable en lugar de wifi

---

## Preguntas frecuentes

### Preguntas generales

**P: ¿Necesito equipo especial para usar WebSDR?**
R: ¡No! Solo un ordenador o dispositivo móvil con acceso a Internet.

**P: ¿Es gratuito usar WebSDR?**
R: Sí, la mayoría de los WebSDR son gratuitos. Los mantienen voluntarios.

**P: ¿Puedo transmitir con WebSDR?**
R: No, WebSDR es solo de recepción. No se puede transmitir.

**P: ¿Qué frecuencias puedo escuchar?**
R: Depende de la configuración del WebSDR. Consulte la información de la estación.

**P: ¿Puedo grabar el audio?**
R: Algunos navegadores permiten grabar. Compruebe las funciones de su navegador.

### Preguntas técnicas

**P: ¿Qué tasa de muestreo usa el SDR?**
R: Varía según la estación. Consulte la página de información de la estación.

**P: ¿Cuál es la latencia?**
R: Normalmente de 2 a 5 segundos entre la señal de radio y sus altavoces.

**P: ¿Puedo abrir varias instancias?**
R: Normalmente sí, pero puede sobrecargar el servidor. Sea considerado.

**P: ¿Funciona sin conexión?**
R: No, WebSDR requiere conexión a Internet.

**P: ¿Qué navegadores son compatibles?**
R: Chrome, Firefox, Edge y Safari (versiones recientes)

### Preguntas sobre el uso

**P: ¿Cuántas personas pueden escuchar a la vez?**
R: Depende de la capacidad del servidor. A menudo entre 50 y más de 200 usuarios.

**P: ¿Puedo ver qué escuchan los demás?**
R: Si está habilitado, sí. Busque los indicadores de «otros usuarios».

**P: ¿Puedo chatear con otros oyentes?**
R: Si el operador lo ha habilitado. Busque el cuadro de chat.

**P: ¿Por qué algunas frecuencias no muestran nada?**
R: En ese momento no hay señales en esa frecuencia. ¡Pruebe otras!

**P: ¿Qué son las bandas de color de la cascada?**
R: La superposición del plan de bandas, que muestra las atribuciones de frecuencia.

---

## Recursos

### Aprender más sobre radio

- **Planes de bandas**: busque «amateur radio band plan» + su región
- **Propagación**: infórmese sobre la propagación de las ondas de HF
- **Modos digitales**: investigue sobre FT8, PSK31 y RTTY
- **Radioafición**: ¡plantéese obtener una licencia de radioaficionado!

### Encontrar más WebSDR

- **Directorio WebSDR**: http://sdr-list.xyz
- **WebSDR.org**: http://websdr.org
- **KiwiSDR**: http://kiwisdr.com/public/

### Obtener ayuda

1. **Operador de la estación**: consulte los datos de contacto en la página
2. **Chat de usuarios**: pregunte a otros oyentes (si está disponible)
3. **Foros en línea**: busque comunidades de WebSDR
4. **Documentación**: ¡consulte esta guía!

---

## Apéndice: frecuencias habituales

### Bandas de radioafición de HF

| Banda | Margen de frecuencias | Modo | Actividad |
|-------|-----------------------|------|-----------|
| 160 m | 1.800-2.000 MHz | LSB | Noche/local |
| 80 m | 3.500-4.000 MHz | LSB | Noche/regional |
| 40 m | 7.000-7.300 MHz | LSB | Día/noche/DX |
| 30 m | 10.100-10.150 MHz | USB | Solo datos/CW |
| 20 m | 14.000-14.350 MHz | USB | Día/DX |
| 17 m | 18.068-18.168 MHz | USB | Día/DX |
| 15 m | 21.000-21.450 MHz | USB | Día/DX |
| 12 m | 24.890-24.990 MHz | USB | Día/DX |
| 10 m | 28.000-29.700 MHz | USB | Esporádica/DX |

### Bandas de radioafición de VHF/UHF

| Banda | Margen de frecuencias | Modo | Actividad |
|-------|-----------------------|------|-----------|
| 6 m | 50.000-54.000 MHz | USB/FM | Esporádica |
| 2 m | 144.000-148.000 MHz | FM | Muy activa |
| 70 cm | 420.000-450.000 MHz | FM | Activa |

### Bandas de radiodifusión

| Servicio | Margen de frecuencias | Modo |
|----------|-----------------------|------|
| Radio AM | 530-1710 kHz | AM |
| Onda corta | 2.3-26.1 MHz | AM |
| Radio FM | 88-108 MHz | WBFM |

### Aviación

| Servicio | Margen de frecuencias | Modo |
|----------|-----------------------|------|
| Control del tráfico aéreo | 118-137 MHz | AM |
| ACARS (datos) | 130-136 MHz | Datos |

### Marítimo

| Servicio | Margen de frecuencias | Modo |
|----------|-----------------------|------|
| VHF marina | 156-162 MHz | FM |
| HF marina | 2-22 MHz | USB |

---

## Glosario

**AGC**: control automático de ganancia — ajusta los niveles de audio automáticamente

**AM**: modulación de amplitud — modo de voz usado en aviación y radiodifusión

**Ancho de banda**: el margen de frecuencias de una señal

**CW**: onda continua — señales en código Morse

**DX**: comunicación a larga distancia

**FFT**: transformada rápida de Fourier — convierte el dominio del tiempo en el de la frecuencia

**FM**: modulación de frecuencia — modo de voz para VHF/UHF

**HF**: alta frecuencia (3-30 MHz) — bandas de larga distancia

**kHz**: kilohercio (1.000 Hz)

**LSB**: banda lateral inferior — modo de voz para las bandas bajas de HF

**MHz**: megahercio (1.000.000 Hz)

**NB**: supresor de impulsos — elimina el ruido impulsivo

**NR**: reducción de ruido — reduce el ruido de fondo

**PSK**: modulación por desplazamiento de fase — modo digital

**RTTY**: radioteletipo — modo digital de texto

**S-metro**: medidor de intensidad de señal

**SDR**: radio definida por software

**SQL**: silenciador — enmudece el audio cuando no hay señal

**SSB**: banda lateral única (USB o LSB)

**USB**: banda lateral superior — modo de voz para las bandas altas de HF

**VHF**: muy alta frecuencia (30-300 MHz) — visibilidad directa

**UHF**: ultra alta frecuencia (300-3000 MHz) — visibilidad directa

**Cascada**: representación visual del espectro radioeléctrico a lo largo del tiempo

---

**¡Disfrute explorando el espectro radioeléctrico con PhantomSDR-Plus!**

**73 (saludos cordiales) de SV1BTL & SV2AMK**

Para las instrucciones de instalación, consulte [INSTALLATION.md](INSTALLATION.md).
Para los detalles técnicos, consulte [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md).
