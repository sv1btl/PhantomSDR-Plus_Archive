# Vodič za instalaciju PhantomSDR-Plusa za sistemske operatere

Ovaj sveobuhvatni vodič vodi vas kroz instalaciju i konfiguraciju PhantomSDR-Plusa na vašem poslužitelju.

---

## Sadržaj

1. [Sistemski zahtjevi](#sistemski-zahtjevi)
2. [Priprema prije instalacije](#priprema-prije-instalacije)
3. [Instalacija ovisnosti](#instalacija-ovisnosti)
4. [Instalacija Node.js-a i npm-a](#instalacija-nodejs-a-i-npm-a)
5. [Instalacija OpenCL-a (neobavezno, ali preporučeno)](#instalacija-opencl-a-neobavezno-ali-preporučeno)
6. [Instalacija PhantomSDR-Plusa](#instalacija-phantomsdr-plusa)
7. [Instalacija audiokodeka Opus](#instalacija-audiokodeka-opus)
8. [Autorun Spot Reporter (FT8/FT4/WSPR)](#autorun-spot-reporter-ft8ft4wspr)
9. [Konfiguracija](#konfiguracija)
10. [Postavljanje ovisno o SDR uređaju](#postavljanje-ovisno-o-sdr-uređaju)
11. [Testiranje i provjera](#testiranje-i-provjera)
12. [Postavljanje automatskog pokretanja](#postavljanje-automatskog-pokretanja)
13. [Rješavanje problema](#rješavanje-problema)

---

## Sistemski zahtjevi

### Podržani operacijski sustavi

**Primarni (preporučeno):**
- Ubuntu 24.04 LTS (x86_64) (preporučeno)

**Alternativa:**
- Fedora (najnovije stabilno izdanje)

### Hardverski zahtjevi

**Minimalna konfiguracija:**
- Procesor: dvojezgreni (2+ GHz)
- RAM: 4 GB
- Pohrana: 10 GB slobodnog prostora
- Mreža: veza od 100 Mbit/s

**Preporučena konfiguracija:**
- Procesor: četverojezgreni ili bolji (Ryzen 5 2600, Intel i5-6500T ili bolji)
- RAM: 8 GB ili više
- Pohrana: SSD od 20 GB ili više
- GPU: AMD/NVIDIA s podrškom za OpenCL (vrlo preporučljivo)
- Mreža: veza od 1 Gbit/s

**Konfiguracija visokih performansi:**
- Procesor: 6+ jezgri (Ryzen 7, Intel i7 ili bolji)
- RAM: 16 GB ili više
- Pohrana: NVMe SSD
- GPU: namjenski GPU s podrškom za OpenCL/CUDA
- Mreža: 1 Gbit/s ili bolja

---

## Priprema prije instalacije

### 1. Ažurirajte sustav

```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade -y
sudo reboot

# Fedora
sudo dnf update -y
sudo reboot
```

### 2. Provjerite verziju Ubuntua

```bash
lsb_release -a
```

**Očekivani ispis trebao bi pokazati:** Ubuntu 24.04 LTS

### 3. Provjerite slobodan prostor na disku

```bash
df -h
```

Pobrinite se da u svom osobnom direktoriju imate najmanje 10 GB slobodno.

### 4. Provjerite podatke o procesoru

```bash
lscpu
```

Zabilježite broj jezgri/dretvi radi optimizacije konfiguracije.

---

## Instalacija ovisnosti

### Ubuntu 24.04 LTS

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  git \
  psmisc \
  wget \
  curl
```

### Fedora

```bash
sudo dnf install -y \
  g++ \
  meson \
  cmake \
  fftw3-devel \
  websocketpp-devel \
  flac-devel \
  zlib-devel \
  boost-devel \
  libzstd-devel \
  opus-devel \
  liquid-dsp-devel \
  git \
  psmisc \
  wget \
  curl
```

### Provjerite instalaciju

```bash
# Check if key dependencies are installed
pkg-config --modversion fftw3
cmake --version
meson --version
```

---

## Instalacija Node.js-a i npm-a

PhantomSDR-Plus zahtijeva Node.js za izgradnju sučelja. Za instalaciju ćemo koristiti NVM (Node Version Manager).

### 1. Instalirajte NVM

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
```

### 2. Učitajte NVM

**VAŽNO:** zatvorite i ponovno otvorite terminal ili pokrenite:

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

### 3. Provjerite instalaciju NVM-a

```bash
nvm --version
```

Očekivani ispis: `0.39.7` ili slično

### 4. Instalirajte Node.js

```bash
# Install the latest LTS version
nvm install --lts

# Verify installation
node --version
npm --version
```

### 5. Neobavezno: instalirajte dodatne verzije Nodea

```bash
# Install latest version
nvm install node

# Install specific version (if needed)
nvm install 18.10.0

# List installed versions
nvm list

# Use specific version
nvm use --lts
```

---

## Instalacija OpenCL-a (neobavezno, ali preporučeno)

OpenCL dramatično poboljšava performanse prebacivanjem FFT izračuna na GPU. Ovaj odjeljak pokriva integriranu Intel grafiku. Za AMD/NVIDIA GPU pogledajte dokumentaciju proizvođača.

### Intel procesor s integriranom grafikom

#### 1. Instalirajte osnovne OpenCL komponente

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  libclfft-dev \
  ocl-icd-opencl-dev \
  clinfo
```

#### 2. Preuzmite Intel Compute Runtime

```bash
mkdir -p ~/neo
cd ~/neo

wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
```

#### 3. Instalirajte Intel OpenCL Runtime

```bash
sudo dpkg -i *.deb
```

Ako se pojave pogreške ovisnosti:

```bash
sudo apt --fix-broken install
```

#### 4. Instalirajte OpenCL ICD učitavač

```bash
sudo apt update
sudo apt install intel-opencl-icd
```

Ako se pojave pogreške:

```bash
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
```

#### 5. Provjerite instalaciju OpenCL-a

```bash
sudo clinfo
```

Trebali biste vidjeti podatke o svojoj OpenCL platformi i uređajima. Potražite:
- Broj platformi: 1 (ili više)
- Naziv platforme: Intel(R) OpenCL (ili slično)
- Vrstu uređaja: GPU ili CPU

#### 6. Ponovno pokrenite računalo

```bash
sudo reboot
```

### OpenCL na AMD GPU-u

Za AMD GPU instalirajte ROCm:

```bash
# Add ROCm repository
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list

# Install ROCm
sudo apt update
sudo apt install rocm-opencl rocm-clinfo

# Add user to video group
sudo usermod -a -G video $USER

# Reboot
sudo reboot

# Verify
clinfo
```

### OpenCL na NVIDIA GPU-u

Za NVIDIA GPU instalirajte CUDA-u:

```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-525

# Install CUDA toolkit
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt update
sudo apt install cuda

# Reboot
sudo reboot

# Verify
nvidia-smi
clinfo
```

---

## Instalacija PhantomSDR-Plusa

### Kloniranje repozitorija, postavljanje skripti kao izvršnih, automatska instalacija

```bash
cd ~
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```
**⚠️ VAŽNO:** nakon što `install.sh` završi, **ponovno pokrenite terminal** prije nastavka.

### 4. Opcija B: ručna instalacija

Ako želite ručnu instalaciju ili ako automatska ne uspije:

#### Izgradnja backenda

```bash
# Clean any previous builds, Configure build with optimization, Compile
rm -rf build
meson setup build --buildtype=release --optimization=3
meson compile -C build

# Verify binary was created
ls -lh build/spectrumserver
```

#### Izgradnja frontenda

```bash
cd frontend

# Install dependencies, Fix any vulnerabilities, Build the frontend
npm install
npm audit fix
npm run build

# Return to project root
cd ..
```

### Provjerite instalaciju

```bash
# Check if binary exists
ls -lh build/spectrumserver

# Check if frontend was built
ls -lh frontend/dist/

# List important files
ls -lh *.sh *.toml
```

---

## Instalacija audiokodeka Opus

Opus daje bolju kvalitetu zvuka i manju latenciju od FLAC-a.

### 1. Instalirajte sistemsku biblioteku libopus

```bash
sudo apt-get update
sudo apt-get install -y libopus0 libopus-dev
```

### 2. Instalirajte Opus dekoder za sučelje

```bash
cd PhantomSDR-Plus/frontend

# Install npm dependencies if not already done, Install Opus WASM decoder, Fix any vulnerabilities, Rebuild frontend
npm install
npm install @wasm-audio-decoders/opus-ml
npm audit fix
npm run build

# Return to project root
cd ..
```

### 3. Provjerite instalaciju Opusa

```bash
# Check if Opus system library is installed
pkg-config --modversion opus

# Check if Opus npm package is installed
cd frontend
npm list @wasm-audio-decoders/opus-ml
cd ..
```

---

## Autorun Spot Reporter (FT8/FT4/WSPR)

PhantomSDR-Plus dolazi s neobaveznim **autorun spot reporterom** (u direktoriju `autorun/`).
Dekodira FT8/FT4/WSPR na poslužiteljskoj strani izravno s prijamnika i šalje spotove u mreže
za prijavu:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

Upravlja se u cijelosti s kartice **administratorska ploča → „Spot Reporting"**, a
**prijavljivanje je prema zadanom ISKLJUČENO** — ništa se ne odašilje ni ne šalje dok to ondje
ne uključite. Dekoder radi kao zaseban Node.js daemon i lokalno preuzima zvuk prijamnika, pa
ne dodaje nikakav dodatni RF hardver.

### Preduvjeti

| Preduvjet | Napomene |
|-----------|----------|
| **Node.js 22+** | Isto radno okruženje koje već treba izgradnja sučelja — instalira se u [koraku Node.js](#instalacija-nodejs-a-i-npm-a). |
| **npm paketi `ws` + `cbor-x`** | Razrješavaju se preko `autorun/node_modules`, simboličke poveznice na `node_modules` sučelja (oba su paketa navedena u `frontend/package.json`). |
| **`util-linux`** (`taskset`) | Gumb „Start" u administraciji veže daemon uz E-jezgre pomoću naredbe `taskset`. Prisutan je u gotovo svakoj distribuciji; instalacijske skripte dodaju ga izričito. |
| **Pozivni znak + lokator** | Čitaju se iz `frontend/site_information.json` (`siteSysop` / `siteGridSquare`), osim ako se ne promijene na administratorskoj kartici. Spotovi se šalju pod tim pozivnim znakom. |

> ⚠️ **Prijavljujte samo ono što doista primate.** Spotovi se šalju u javne mreže pod vašim
> pozivnim znakom — uključite samo pojaseve/načine rada koje vaš prijamnik stvarno čuje i
> koristite ispravan lokator.

### Automatska instalacija

`install.sh` (i inačice po distribucijama: `install-Deb12.sh`, `install_arch.sh`,
`install_fedora.sh`, `install_opensuse.sh`) obavljaju sve umjesto vas: instaliraju Node.js 22
i `util-linux`, pokreću `npm install` za sučelje i zatim automatski stvaraju simboličku
poveznicu `autorun/node_modules`. Nisu potrebni dodatni koraci — značajka je spremna čim
`install.sh` završi.

### Ručna instalacija

Ako ste instalirali ručno (opcija B), sami stvorite simboličku poveznicu nakon `npm install`
za sučelje kako bi daemon mogao razriješiti svoje ovisnosti:

```bash
cd ~/PhantomSDR-Plus

# 1. Frontend deps must be installed first (ws + cbor-x live there)
cd frontend && npm install && cd ..

# 2. Link the autorun daemon to the frontend's node_modules
ln -sfn ../frontend/node_modules autorun/node_modules

# 3. Ensure taskset is available (Debian/Ubuntu shown; use your package manager)
sudo apt install -y util-linux
```

> **Napomena:** `autorun/node_modules` git zanemaruje, pa ga svježi `git clone` nikad ne
> sadrži — poveznicu treba (ponovno) stvoriti nakon svakog čistog preuzimanja. Instalacijske
> skripte to rade umjesto vas; gornja naredba odnosi se samo na ručna postavljanja.

### Provjera

```bash
# The symlink should point at ../frontend/node_modules
ls -l autorun/node_modules

# ws + cbor-x must resolve
ls -d frontend/node_modules/ws frontend/node_modules/cbor-x

# taskset must be on PATH
command -v taskset
```

Zatim otvorite administratorsku ploču, idite na karticu **Spot Reporting**, postavite svoj
identitet, označite pojaseve/načine rada za dekodiranje, uključite odredišta i pritisnite
**Start**. Oznaka „📶 REPORTING" pojavljuje se na glavnom slapu dok je prijavljivanje
aktivno. (PSK Reporter šalje skupno svakih 5 minuta, a wsprnet svake 2 minute, pa svježe
pokrenut daemon prvih nekoliko minuta pokazuje „0 sent" — to je normalno.)

> **Port poslužitelja otkriva se automatski.** Daemon se spaja izravno na `[server] port`
> samog spectrumservera (petlja + token, zaobilazeći proxy). Taj port čita iz konfiguracijske
> datoteke s kojom je pokrenut spectrumserver koji radi, pa funkcionira na bilo kojem portu
> bez konfiguracije — redak `[autorun] tap backend: …` u `autorun.log` pokazuje što je
> razriješio. Ako vaš poslužitelj nije radio kada je daemon pokrenut ili imate neobičnu
> postavu, zadajte ga u `autorun.json`:
> ```json
> "server": { "host": "127.0.0.1", "port": 9002 }
> ```
> Pogrešan port očituje se kao `504` / `tap closed 1006` u `autorun.log`, uz `decodes`
> zaglavljen na 0.

---

## Konfiguracija

### 1. Odaberite konfiguracijsku datoteku

Odaberite odgovarajuću konfiguracijsku datoteku za svoj SDR:

- `config-rtl.toml` – RTL-SDR uređaji
- `config-rsp1a.toml` – SDRplay RSP1A
- `config-airspyhf.toml` – Airspy HF+ Discovery
- `config-rx888mk2.toml` – RX888 MK2
- `config.example.hackrf.toml` – HackRF One

U ovom primjeru koristit ćemo RTL-SDR.

### 2. Uredite konfiguracijsku datoteku

```bash
nano config-rtl.toml
```

#### Ključne postavke

```toml
[server]
port = 9002                      # Web interface port (or everything else)
html_root = "frontend/dist/"     # Frontend location
otherusers = 1                   # Show other users (1=yes, 0=no)
threads = 2                      # Number of server threads

[websdr]
register_online = true           # Register on sdr-list.xyz (true/false)
name = "Your WebSDR Name"        # Display name
antenna = "Your Antenna Type"    # e.g., "Vertical", "Loop", "Dipole"
grid_locator = "AB12cd"          # Your Maidenhead grid square
hostname = "your.domain.com"     # Your domain or IP address

[input]
sps = 2048000                    # Sample rate (adjust for your coverage)
fft_size = 131072                # FFT size (higher = better resolution)
brightness_offset = -10          # Waterfall brightness adjustment
frequency = 145000000            # Base frequency in Hz (145 MHz for 2m)
signal = "iq"                    # "iq" for complex, "real" for real sampling
fft_threads = 2                  # FFT processing threads
accelerator = "opencl"           # "none", "cuda", or "opencl"
audio_sps = 12000                # Audio sample rate (keep at 12000)
audio_compression = "opus"       # "flac" or "opus"
smeter_offset = -2               # S-meter calibration
waterfall_size = 1024            # Waterfall FFT size
waterfall_compression = "zstd"   # Waterfall compression

[input.driver]
name = "stdin"                   # Input driver
format = "u8"                    # Sample format for RTL-SDR

[input.defaults]
frequency = 145500000            # Default tuning frequency
modulation = "FM"                # Default modulation mode
```

#### Smjernice za frekvenciju uzorkovanja

| Pokrivenost | Frekvencija uzorkovanja | Veličina FFT-a |
|-------------|--------------------------|-----------------|
| 2 MHz | 2048000 | 131072 |
| 3.2 MHz | 3200000 | 131072 |
| 10 MHz | 10000000 | 1048576 |
| 30 MHz | 30000000 | 2097152 |
| 60 MHz | 60000000 | 8388608 |

### 3. Postavite podatke o lokaciji

```bash
nano frontend/site-information.json
```

Uredite sljedeća polja:

```json
{
  "siteSysop": "YourCallsign",
  "siteSysopEmailAddress": "your@email.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "Your City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Computer specifications",
  "siteSoftware": "PhantomSDR-Plus v1.6.1",
  "siteReceiver": "Your SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional information",
  "siteIP": "http://your.domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

**IARU regije:**
- **1**: Europa, Afrika, Bliski istok, sjeverna Azija
- **2**: Amerike (Sjeverna, Srednja, Južna), Karibi
- **3**: Azija i Pacifik, Oceanija

### 4. Prilagodite frekvencijske oznake (neobavezno)

```bash
nano markers.json
```

Dodajte svoje omiljene frekvencije, repetitore i radiodifuzijske postaje.

### 5. Uredite početnu skriptu

```bash
nano start-rtl.sh
```

Početna skripta samostalan je pokretač s watchdogom. Uredite samo blok
**RECEIVER CONFIGURATION** pri vrhu kako bi argumenti prijamnika odgovarali vašoj postavi:

```bash
# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═══
RX_LABEL="RTL-SDR"
RX_COMM="rtl_sdr"                       # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rtl.toml"    # your .toml
FIFO="$PHANTOMDIR/rtl.fifo"
RX_ARGS="${RX_ARGS:--f 145000000 -s 2048000 -}"   # receiver args (edit these)
```

Parametri unutar `RX_ARGS`:
- `-f 145000000`: središnja frekvencija (145 MHz)
- `-s 2048000`: frekvencija uzorkovanja (2,048 MSPS)

`CONFIG` pokazuje na vašu `.toml` datoteku. Ništa drugo u skripti **ne** morate mijenjati —
logika pokretanja/ponovnog pokretanja/watchdoga/zapisivanja je općenita. Argumente prijamnika
možete zamijeniti i pri pokretanju, bez uređivanja datoteke:
`RX_ARGS="-f 145000000 -s 2048000 -" ./start-rtl.sh`
(`RX888_ARGS` za `start-rx888mk2.sh`).

---

## Postavljanje ovisno o SDR uređaju

### RTL-SDR

#### Instalirajte RTL-SDR alate

```bash
sudo apt install -y rtl-sdr
```

#### Testirajte RTL-SDR

```bash
rtl_test
```

Pritisnite Ctrl+C za prekid. Trebali biste vidjeti podatke o frekvenciji uzorkovanja.

#### Uredite konfiguraciju

```bash
nano config-rtl.toml
```

Uobičajene postavke za RTL-SDR:
```toml
sps = 2048000
frequency = 145000000
signal = "iq"
format = "u8"
```

### SDRplay RSP1A

#### Instalirajte SoapySDR i podršku za SDRplay

```bash
# Install SoapySDR
sudo apt install -y soapysdr-tools

# Download SDRplay API
cd ~/Downloads
wget https://www.sdrplay.com/software/SDRplay_RSP_API-Linux-3.07.1.run
chmod +x SDRplay_RSP_API-Linux-3.07.1.run
sudo ./SDRplay_RSP_API-Linux-3.07.1.run

# Install SoapySDRPlay
git clone https://github.com/pothosware/SoapySDRPlay.git
cd SoapySDRPlay
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig
```

#### Testirajte SDRplay

```bash
SoapySDRUtil --find="driver=sdrplay"
```

#### Dodatne upute

Pogledajte priloženu datoteku: `instractions-for-rsp1a`

### Airspy HF+

#### Instalirajte Airspy alate

```bash
sudo apt install -y airspy
```

#### Testirajte Airspy

```bash
airspy_info
```

#### Dodatne upute

Pogledajte priloženu datoteku: `instractions-for-airspy`

### RX888 MK2

#### Instalirajte RX888 alate

```bash
# Install rx_tools
git clone https://github.com/rxseger/rx_tools.git
cd rx_tools
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig

# Install RX888 firmware and support
# Follow manufacturer instructions
```

#### Pokretanje rx888_stream bez sudo (udev pravila)

Prema zadanom, USB uređaj Cypress FX3 na RX-888 dostupan je samo rootu, pa bi `rx888_stream`
trebao `sudo`. Pokrenite jednom priloženi pomoćni skript kako biste instalirali udev pravila i
dodali se u grupu `plugdev`:

```bash
./setup-rx888-udev.sh          # re-runs itself with sudo automatically
```

Skripta zapisuje `/etc/udev/rules.d/99-rx888.rules` za sva tri identifikatora proizvoda
Cypress FX3 (`04b4:00f1`/`00f3` bootloader i `04b4:8613` s učitanim firmverom), ponovno
učitava udev i stvara stabilnu poveznicu `/dev/rx888`. **Odjavite se i ponovno prijavite**
(zbog promjene grupe) i jednom **ponovno priključite uređaj**; nakon toga `rx888_stream` — i
pokretač `start-rx888mk2.sh` — rade bez `sudo`. Skripta je idempotentna pa ju je sigurno
ponovno pokrenuti. Za drugi korisnički račun: `RX888_USER=<ime> ./setup-rx888-udev.sh`.

#### Uredite konfiguraciju

```bash
nano config-rx888mk2.toml
```

Uobičajene postavke za RX888:
```toml
sps = 60000000
frequency = 0
signal = "real"
format = "s16"
fft_size = 8388608
```

### HackRF One

#### Instalirajte HackRF alate

```bash
sudo apt install -y hackrf
```

#### Testirajte HackRF

```bash
hackrf_info
```

---

## Testiranje i provjera

### 1. Probno pokretanje

```bash
# For RTL-SDR
./start-rtl.sh
```

Time se poslužitelj pokreće **u pozadini** (odvaja se i odmah vraća upravljanje) i počinje
zapisivati u `logwebsdr.txt`.

### 2. Provjerite ima li pogrešaka

Skripta bilježi napredak u `logwebsdr.txt` — pratite ga uživo:

```bash
tail -f logwebsdr.txt
```

Potražite:
- ✅ `Starting the initialization script of the PhantomSDR Server`
- ✅ `<receiver> running (PID …)`
- ✅ `Server started normally`
- ❌ `Server … FAILED …` ili `ERROR: receiver binary '…' not found` (ispravite argumente
  prijamnika ili `.toml`, ili instalirajte alat prijamnika, pa ponovno pokrenite skriptu)

### 3. Pristupite web-sučelju

Otvorite preglednik na:
```
http://localhost:9002
```

(Zamijenite broj porta svojim konfiguriranim portom)

### 4. Provjerite funkcionalnost

- Slap se mora prikazivati
- Zvuk se mora reproducirati pri kliku na signale
- S-metar mora reagirati na signale
- Brojač korisnika mora pokazivati „1"

### 5. Testirajte s drugog uređaja

S drugog računala u svojoj mreži:
```
http://YOUR_SERVER_IP:9002
```

### 6. Provjerite potrošnju resursa

```bash
# Monitor CPU usage
htop

# Monitor GPU usage (if OpenCL/CUDA enabled)
nvidia-smi  # For NVIDIA
radeontop   # For AMD

# Monitor network usage
iftop
```

### 7. Zaustavite poslužitelj

Poslužitelj radi u pozadini pod watchdogom, pa ga **Ctrl+C neće zaustaviti** (a watchdog bi ga
ionako ponovno pokrenuo). Koristite zajedničku skriptu za zaustavljanje, koja radi za svaki
prijamnik — prvo zaustavlja watchdog, zatim prijamnik i `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## Postavljanje automatskog pokretanja

### Pomoću systemd (preporučeno)

#### 1. Stvorite datoteku usluge

```bash
sudo nano /etc/systemd/system/phantomsdr.service
```

Dodajte sljedeći sadržaj (prilagodite putanje i korisnika):

```ini
[Unit]
Description=PhantomSDR-Plus WebSDR Server
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/PhantomSDR-Plus
# Run the watchdog in the FOREGROUND (note the --watchdog flag) so systemd can
# track it. Do NOT use the plain "./start-rtl.sh" here — that form detaches into
# the background and exits, which systemd would treat as the service stopping.
ExecStart=/home/youruser/PhantomSDR-Plus/start-rtl.sh --watchdog
ExecStop=/home/youruser/PhantomSDR-Plus/stop-websdr.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

> Proces `--watchdog` već sam ponovno pokreće prijamnik i `spectrumserver`; `Restart=always`
> tek je sigurnosna mreža za rijedak slučaj da sam watchdog završi. Budući da ovdje systemd
> nadzire poslužitelj, umjesto ručnog pokretanja skripti možete koristiti
> `systemctl start/stop/restart` i `journalctl -u phantomsdr -f`.

#### 2. Omogućite i pokrenite uslugu

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable phantomsdr.service

# Start service now
sudo systemctl start phantomsdr.service

# Check status
sudo systemctl status phantomsdr.service
```

#### 3. Upravljanje uslugom

```bash
# Start
sudo systemctl start phantomsdr

# Stop
sudo systemctl stop phantomsdr

# Restart
sudo systemctl restart phantomsdr

# View logs
sudo journalctl -u phantomsdr -f
```

### Pomoću Screena (alternativa)

> Obično nepotrebno: `./start-rtl.sh` već se odvaja u pozadinu (putem `setsid`) i nastavlja
> raditi nakon odjave, s vlastitim watchdogom. Screen je koristan samo ako izričito želite
> interaktivnu sesiju za pokretanje inačice u prednjem planu `./start-rtl.sh --watchdog`.

#### 1. Instalirajte Screen

```bash
sudo apt install -y screen
```

#### 2. Pokrenite u Screen sesiji

```bash
screen -S phantomsdr
./start-rtl.sh
```

Pritisnite Ctrl+A, zatim D za odvajanje.

#### 3. Vratite se u sesiju

```bash
screen -r phantomsdr
```

---

## Rješavanje problema

### Pogreške pri izgradnji

#### Problemi s ovisnostima

```bash
# Ubuntu: Install missing dependencies
sudo apt install --fix-broken

# Fedora: Install missing dependencies
sudo dnf install <package-name>
```

#### Neuspjela konfiguracija Mesona

```bash
# Clean and reconfigure
rm -rf build
meson setup build --buildtype=release
```

### Pogreške pri izvođenju

#### Port je već zauzet

```bash
# Find process using port
sudo lsof -i :9002

# Kill process
sudo kill -9 <PID>
```

#### Pristup SDR-u odbijen

```bash
# Add user to plugdev group
sudo usermod -a -G plugdev $USER

# Reload groups (or log out and back in)
newgrp plugdev
```

Za **RX-888 MkII** to samo po sebi nije dovoljno — uređaj Cypress FX3 traži i udev pravila.
Pokrenite priloženi pomoćni skript (instalira pravila *i* dodaje vas u `plugdev`), zatim se
odjavite i prijavite te ponovno priključite uređaj:

```bash
./setup-rx888-udev.sh
```

#### Problemi sa zvukom

```bash
# Try different codec
# Edit config file and change:
audio_compression = "flac"  # or "opus"

# Rebuild
cd frontend && npm run build && cd ..
```

### Problemi s OpenCL-om

#### clinfo ne prikazuje uređaje

```bash
# Verify drivers are loaded
sudo clinfo

# Check OpenCL ICD files
ls /etc/OpenCL/vendors/

# Reinstall drivers (Intel example)
sudo apt remove --purge intel-opencl-icd
sudo apt install intel-opencl-icd
```

#### Performanse se nisu poboljšale

```bash
# Verify OpenCL is enabled in config
accelerator = "opencl"

# Try different device
# Add to config file:
[input.opencl]
device_id = 0  # Try 0, 1, 2, etc.
```

### Mrežni problemi

#### Nema pristupa s drugih uređaja

```bash
# Check firewall
sudo ufw status
sudo ufw allow 9002/tcp

# Or disable firewall temporarily for testing
sudo ufw disable
```

#### Velika latencija

```bash
# Reduce waterfall size in config
waterfall_size = 512

# Increase buffer size
buffer_size = 16384

# Use Opus instead of FLAC
audio_compression = "opus"
```

### Problemi sa SDR uređajem

#### RTL-SDR nije pronađen

```bash
# Check if device is recognized
lsusb | grep Realtek

# Test with rtl_test
rtl_test

# Try blacklisting DVB-T drivers
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo rmmod dvb_usb_rtl28xxu
```

#### SDRplay nije pronađen

```bash
# Check API installation
systemctl status sdrplay

# Restart API
sudo systemctl restart sdrplay

# Test with SoapySDR
SoapySDRUtil --find
```

---

## Optimizacija performansi

### Optimizacija procesora

```toml
# Adjust thread counts based on CPU cores
[server]
threads = 4  # Set to number of cores

[input]
fft_threads = 4  # Set to number of cores
```

### Optimizacija memorije

```toml
# Reduce memory usage
[input]
waterfall_size = 512  # Lower value = less memory
fft_size = 65536      # Lower value = less memory
```

### Optimizacija mreže

```toml
# Optimize for limited bandwidth
[input]
audio_compression = "opus"  # More efficient than FLAC
waterfall_compression = "zstd"  # Efficient compression
```

---

## Ažuriranje PhantomSDR-Plusa

### Ručno ažuriranje

```bash
cd PhantomSDR-Plus

# Backup your configuration
cp config-rtl.toml config-rtl.toml.backup
cp frontend/site-information.json frontend/site-information.json.backup

# Pull latest changes
git pull origin main
git submodule update --init --recursive

# Rebuild
meson compile -C build
cd frontend && npm install && npm run build && cd ..
```

### Skripta za automatsko ažuriranje

Stvorite `update.sh`:

```bash
#!/bin/bash
cd ~/PhantomSDR-Plus
./stop-websdr.sh
git pull origin main
git submodule update --init --recursive
meson compile -C build
cd frontend && npm install && npm run build && cd ..
./start-rtl.sh
```

---

## Sigurnosna kopija i vraćanje

### Datoteke koje treba sigurnosno kopirati

- Konfiguracijske datoteke: `*.toml`
- Podaci o lokaciji: `frontend/site-information.json`
- Oznake: `markers.json`
- Vlastite skripte: `start-*.sh`, `stop-*.sh`
- Povijest razgovora: `chat_history.txt`
- Pozadinska slika: `frontend/src/assets/background.jpg`

### Naredba za sigurnosnu kopiju

```bash
cd ~/PhantomSDR-Plus
tar -czf phantomsdr-backup-$(date +%Y%m%d).tar.gz \
  *.toml \
  *.sh \
  markers.json \
  chat_history.txt \
  frontend/site-information.json \
  frontend/src/assets/background.jpg
```

### Naredba za vraćanje

```bash
tar -xzf phantomsdr-backup-YYYYMMDD.tar.gz
```

---

## Sigurnosna razmatranja

### Konfiguracija vatrozida

```bash
# Allow only necessary ports
sudo ufw allow 9002/tcp
sudo ufw enable
```

### Obratni proxy (neobavezno)

Razmislite o korištenju nginxa ili Apachea kao obratnog proxyja za:
- SSL/TLS enkripciju
- pridruživanje naziva domene
- raspodjelu opterećenja
- kontrolu pristupa

### Ograničenja korisnika

Uredite `config.toml`:
```toml
[server]
max_users = 100  # Limit concurrent users
```

---

## Kako doći do pomoći

### Izvori

- **Dokumentacija**: ovaj vodič, README.md, USER_GUIDE.md
- **GitHub Issues**: https://github.com/sv1btl/PhantomSDR-Plus/issues
- **Demonstracija uživo**: http://phantomsdr.no-ip.org:8900/

### Prijava problema

Kada prijavljujete problem, navedite:
1. operacijski sustav i verziju
2. model SDR uređaja
3. sadržaj konfiguracijske datoteke
4. poruke o pogreškama
5. potrošnju sistemskih resursa (CPU, RAM, GPU)

### Podrška zajednice

- Prije otvaranja novih, provjerite postojeće GitHub issue prijave
- Navedite detaljne podatke o svojoj postavi
- Priložite zapise i poruke o pogreškama
- Budite strpljivi i pristojni

---

## Dodatak A: potpuni popis ovisnosti

### Popis paketa za Ubuntu 24.04

```
build-essential
cmake
pkg-config
meson
libfftw3-dev
libwebsocketpp-dev
libflac++-dev
zlib1g-dev
libzstd-dev
libboost-all-dev
libopus-dev
libliquid-dev
git
util-linux (taskset — for the autorun spot reporter)
psmisc
wget
curl
rtl-sdr (for RTL-SDR)
airspy (for Airspy)
hackrf (for HackRF)
libclfft-dev (for OpenCL)
ocl-icd-opencl-dev (for OpenCL)
clinfo (for OpenCL)
```

---

## Dodatak B: primjeri konfiguracije

### Primjer 1: RTL-SDR za VHF/UHF

```toml
[input]
sps = 2048000
frequency = 145000000
signal = "iq"

[input.driver]
format = "u8"

[input.defaults]
frequency = 145500000
modulation = "FM"
```

### Primjer 2: RX888 za KV (0-30 MHz)

```toml
[input]
sps = 60000000
frequency = 0
signal = "real"
fft_size = 8388608

[input.driver]
format = "s16"

[input.defaults]
frequency = 7100000
modulation = "LSB"
```

### Primjer 3: HackRF za širokopojasni FM

```toml
[input]
sps = 10000000
frequency = 100900000
signal = "iq"

[input.driver]
format = "s8"

[input.defaults]
frequency = 100900000
modulation = "WBFM"
```

---

**Instalacija je gotova! Sada biste trebali imati potpuno funkcionalan PhantomSDR-Plus poslužitelj.**

**73 de SV1BTL & SV2AMK**
