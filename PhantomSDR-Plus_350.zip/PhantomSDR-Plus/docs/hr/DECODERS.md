# PhantomSDR-Plus — Korisnički priručnik za dekodere

Ovaj vodič obuhvaća sve ugrađene dekodere dostupne u PhantomSDR-Plusu. Svi se dekoderi uključuju na isti način, opisan u nastavku, nakon čega slijede upute za postavljanje svakog pojedinog dekodera.

---

## Sadržaj

1. [Kako pokrenuti dekoder](#1-kako-pokrenuti-dekoder)
2. [FT8](#2-ft8)
3. [FT4-FT2](#3-ft4-ft2)
4. [CW — Morseov kod](#4-cw--morseov-kod)
5. [WSPR](#5-wspr)
6. [HF FAX / WEFAX](#6-hf-fax--wefax)
7. [NAVTEX](#7-navtex)
8. [FSK / RTTY](#8-fsk--rtty)
9. [SSTV](#9-sstv)
10. [Opći savjeti](#10-opći-savjeti)

---

## 1. Kako pokrenuti dekoder

Svim se dekoderima pristupa iz odjeljka **Decoder Options**, smještenog ispod kontrola audiospektrograma na glavnoj ploči.

**Koraci:**

1. Kliknite gumb **Decoder: OFF** da biste ga prebacili u **Decoder: ON** (kad je aktivan, postaje plav).
2. Otvorite padajući izbornik koji se pojavljuje desno od gumba i odaberite željeni dekoder.
3. Ploča odabranog dekodera pojavit će se ispod kontrola — slijedite upute za taj dekoder u odgovarajućem odjeljku ovog vodiča.
4. Da biste zaustavili dekodiranje, odaberite **— Select decoder —** iz padajućeg izbornika ili kliknite gumb **Decoder: ON** da ga vratite na OFF.

> Istodobno može biti aktivan samo jedan dekoder. Prelazak na drugi dekoder automatski zaustavlja prethodni.

**Dekodiranje se odvija u pozadini.** SSTV, HF FAX, NAVTEX, FSK/RTTY i CW rade svaki u zasebnoj dretvi Web Workera, pa se dekodiranje nikada ne natječe s reprodukcijom zvuka ni sa slapom. Pokretanje ili zaustavljanje dekodera ne prekida zvuk, a sučelje ostaje odzivno dok se prima slika ili stranica. Svi dekoderi dobivaju sirovi zvuk uzet *prije* AGC-a, smanjenja šuma i utišavanja — utišavanje prijamnika ili prilagodba tih postavki vlastitom uhu stoga ne utječe na dekodiranje.

---

## 2. FT8

**Što je to:** FT8 je popularan digitalni način rada za slabe signale koji radioamateri koriste diljem svijeta. Emisije traju točno 15 sekundi, a protokol može primiti signale do 20–25 dB ispod razine šuma. To je najčešće korišten način rada za veze na velike udaljenosti (DX).

### Preporučene frekvencije (USB)

| Pojas | Frekvencija |
|-------|-------------|
| 160 m | 1.840 MHz |
| 80 m  | 3.573 MHz |
| 40 m  | 7.074 MHz |
| 30 m  | 10.136 MHz |
| 20 m  | 14.074 MHz |
| 17 m  | 18.100 MHz |
| 15 m  | 21.074 MHz |
| 12 m  | 24.915 MHz |
| 10 m  | 28.074 MHz |

### Postavljanje

1. Ugodite se na jednu od gore navedenih FT8 frekvencija i postavite način rada na **USB**.
2. Uključite dekoder i iz padajućeg izbornika odaberite **FT8**.
3. Ploča **FT8 Messages** automatski se pojavljuje ispod.

### Čitanje ispisa

Popis poruka prikazuje dekodirane emisije kako pristižu. Svaki ciklus od 15 sekundi donosi novu skupinu poruka. Polje **Farthest** (gore desno na ploči) pokazuje najveću udaljenost dekodiranu u trenutačnoj sesiji, u kilometrima.

Tipičan oblik poruke: `CQ DX AA1BB FN31` — CQ poziv pozivnog znaka AA1BB smještenog u polju FN31.

> **Savjet:** FT8 je usko vremenski sinkroniziran. Vaš preglednik koristi sat vašeg računala; ako sat sustava odstupa više od nekoliko sekundi, dekodiranje neće uspjeti. Držite vrijeme sustava usklađeno putem NTP-a.

---

## 3. FT4-FT2

**Što je to:** FT4 je brža inačica FT8-a namijenjena radu u natjecanjima. Svaki ciklus emitiranja traje 7,5 sekundi (polovica FT8-a), zbog čega je dvostruko brži, ali traži nešto jači signal.
FT2 je još brža inačica FT8-a. Riječ je o iznimno brzom 77-bitnom načinu rada s TR razdobljima od 3,75 sekundi (= polovica FT4) — još je eksperimentalan.

### Preporučene frekvencije (USB)

| Pojas | Frekvencija FT4|
|-------|-----------|
| 80 m  | 3.575 MHz |
| 40 m  | 7.047 MHz |
| 30 m  | 10.140 MHz |
| 20 m  | 14.080 MHz |
| 15 m  | 21.140 MHz |
| 10 m  | 28.180 MHz |

| Pojas | Frekvencija FT2|
|-------|-----------|
|160 m | 1.843 do 1.846 |
|80 m   | 3.578 do 3.581 |
|60 m   | 5.360 (provjerite lokalne regionalne propise) |
|40 m   | 7.052 do 7.062 |
|30 m   | 10.144 |
|20 m   | 14.084 |
|17 m   | 18.108 |
|15 m   | 21.144 |
|12 m   | 24.923 |
|10 m   | 28.184 |

### Postavljanje

1. Ugodite se na FT4 frekvenciju i postavite način rada na **USB**.
2. Uključite dekoder i iz padajućeg izbornika odaberite **FT4** ili **FT2**.
3. Ploča **FT4 Messages** ili **FT2 Messages** pojavljuje se ispod, istog rasporeda kao FT8 ploča.

> **Napomena:** FT4 i FT8 koriste različite spektralne formate i nisu zamjenjivi. Pri korištenju ovog dekodera pobrinite se da ste na FT4 frekvenciji.

---

## 4. CW — Morseov kod

**Što je to:** CW dekoder osluškuje signale Morseova koda (neprekinuti val) i pretvara ih u tekst u stvarnom vremenu. Automatski prati frekvenciju signala i prilagođava se brzini odašiljanja operatera.

### Preporučene frekvencije

CW je aktivan na svim amaterskim pojasevima, obično u njihovu donjem dijelu. Uobičajena mjesta:

| Pojas | Segment |
|-------|---------|
| 40 m  | 7.000–7.040 MHz |
| 20 m  | 14.000–14.070 MHz |
| 15 m  | 21.000–21.080 MHz |

### Postavljanje

1. Ugodite se na CW signal koristeći način demodulacije **CW** ili **CW-L**, ovisno o situaciji.
2. Uključite dekoder i iz padajućeg izbornika odaberite **CW**.
3. Ploča **CW Decoder** pojavljuje se ispod.

### Čitanje ispisa

- Zaglavlje ploče prikazuje otkrivenu frekvenciju signala u Hz (npr. `≈ 700 Hz`) i procijenjenu brzinu odašiljanja u riječima u minuti (npr. `· 22 WPM`).
- Ako signal nije otkriven, zaglavlje prikazuje **scanning…**
- Dekodirani tekst kliže u jantarnom fontu jednolike širine. Trepćući pokazivač (▋) označava mjesto na kojem se tekst trenutačno ispisuje.
- Kliknite **Clear** da izbrišete međuspremnik ispisa.

> **Savjeti:**
> - Centrirajte propusni pojas na CW ton. Dekoder radi najbolje kada CW signal leži otprilike između 400 i 900 Hz u audiospektru.
> - Vrlo brzo ili vrlo sporo odašiljanje te izrazito ručno tipkani (nepravilan) Morse mogu smanjiti točnost.
> - Dekoder daje najbolje rezultate na jednom čistom signalu. Jak QRM od obližnjih signala na istom pojasu može ga zbuniti.

---

## 5. WSPR

**Što je to:** WSPR (Weak Signal Propagation Reporter, izgovara se „whisper") način je rada svjetionika s iznimno slabim signalima koji kartira putove KV prostiranja diljem svijeta. Svaka emisija traje otprilike 110 sekundi i stane u kanal širine 200 Hz. Dekoder čeka potpuni dvominutni interval usklađen s UTC-om prije dekodiranja.

### Preporučene frekvencije (USB, prikazane)

| Pojas | Prikazana frekvencija |
|-------|------------------------|
| 160 m | 1.836.600 MHz |
| 80 m  | 3.568.600 MHz |
| 40 m  | 7.038.600 MHz |
| 30 m  | 10.138.700 MHz |
| 20 m  | 14.095.600 MHz |
| 17 m  | 18.104.600 MHz |
| 15 m  | 21.094.600 MHz |

### Postavljanje

1. Ugodite se na jednu od gore navedenih prikazanih WSPR frekvencija i postavite način rada na **USB**.
2. WSPR signal zauzima audiopodručje 1400–1600 Hz. Propusni pojas nije potrebno dodatno podešavati.
3. Uključite dekoder i iz padajućeg izbornika odaberite **WSPR**.
4. Ploča **WSPR-2 Decoder** pojavljuje se ispod.

### Čitanje ispisa

Ploča prikazuje traku napretka za trenutačni dvominutni interval:

- **Cijan traka se puni** — prikupljaju se podaci signala (0–116 s unutar intervala).
- **Jantarna traka pulsira** — dekodiranje je u tijeku (posljednjih ~4 s intervala).
- **Prazna traka** — čeka se sljedeća parna UTC minuta.

Svaki uspješno dekodirani spot prikazuje se u tablici sa sljedećim stupcima:

| Stupac | Značenje |
|--------|----------|
| UTC | Vrijeme spota (parna minuta) |
| Callsign | Postaja koja je odašiljala |
| Grid | Maidenhead lokator odašiljača |
| Power | Snaga odašiljanja u dBm |
| Freq | Točna audiofrekvencija (Hz) unutar WSPR propusnog pojasa |
| SNR | Omjer signala i šuma u dB |

Kliknite **Clear** da izbrišete popis spotova.

> **Savjet:** WSPR dekodiranje zahtijeva vrlo točno vrijeme sustava (unutar ±1 sekunde od UTC-a). Prvi interval nakon uključivanja dekodera počet će u sljedećoj parnoj UTC minuti — kratko je čekanje uobičajeno.

---

## 6. HF FAX / WEFAX

**Što je to:** HF radiofaks (poznat i kao WEFAX) koriste obalne straže i meteorološke službe diljem svijeta za emitiranje vremenskih karata, karata stanja mora i prizemnih analiza na kratkim valovima. Dekoder rekonstruira sliku redak po redak kako je prima.

### Postavljanje

1. Uključite dekoder i iz padajućeg izbornika odaberite **HF FAX / WEFAX**.
2. Ploča **HF FAX / WEFAX Receiver** pojavljuje se ispod.
3. **Odaberite postaju** iz padajućeg izbornika Station. Dostupno je više od 20 postaja koje pokrivaju Europu, Aziju, Oceaniju i Ameriku (npr. DDH3/DDK3 Njemačka, SVJ4/GR Grčka, JMH Japan, NMG SAD New Orleans).
4. Ako postaja emitira na više frekvencija, odaberite željenu iz podizbornika **Frequency**.
5. Kliknite **▶ Tune** da automatski ugodite slap na tu postaju.
6. Način rada automatski se postavlja na **USB**.

### Raspored emitiranja

Kada je postaja odabrana, pojavljuje se tablica odbrojavanja **Next Transmissions** koja prikazuje sljedeće 4 zakazane emisije u UTC-u, uz odbrojavanje u stvarnom vremenu:

- Uobičajeno (sivo/zeleno) — emisija predstoji.
- **Jantarno ⚡** — emisija počinje za manje od 3 minute; odmah pripremite dekoder.
- **Crveno ●** — emisija počinje za manje od 30 sekundi; prijam samo što nije počeo.

### Parametri

Većina postaja koristi standardne zadane vrijednosti (označene s ★). Mijenjajte ih samo ako znate da postaja koristi nestandardne postavke.

| Parametar | Zadano | Opis |
|-----------|--------|------|
| LPM | 120 ★ | Redaka u minuti — brzina vrtnje bubnja |
| IOC | 576 ★ | Indeks suradnje — određuje broj piksela po retku |
| Shift | 800 Hz ★ | Frekvencijski pomak između tonova crnog i bijelog |

### Kontrole

- **⇔ Auto-align** — uključeno prema zadanom. Automatski se sinkronizira s faznim signalom na početku svake slike. Isključite ga samo ako imate problema s poravnanjem na signalu za koji znate da je dobar.
- **⇅ Invert** — zamjenjuje crno i bijelo. Koristite ako slika izgleda kao negativ (bijela područja ondje gdje bi trebalo biti crno).
- **↺ Refresh** — čisti platno i vraća dekoder na početak. Koristite ga između emisija ili ako se slika trga ili pomiče.
- **⤓ Save PNG** — sprema trenutačno platno kao PNG datoteku na vaše računalo.

### Pokazatelji stanja

Na dnu slike dva pokazatelja tona prikazuju:

- **300 Hz phasing** — svijetli cijan kada je otkriven fazni ton početka slike.
- **450 Hz stop** — svijetli crveno kada je otkriven ton završetka slike.

> **Napomena:** slika klizi prema gore — najnoviji primljeni redak uvijek je na dnu platna. Ako u zaglavlju vidite **[PHASING]**, dekoder se uhvatio za početak nove slike.

---

## 7. NAVTEX

**Što je to:** NAVTEX je međunarodni pomorski sustav emitiranja obavijesti o sigurnosti u priobalju — navigacijskih upozorenja, vremenskih prognoza te obavijesti o traganju i spašavanju. Koristi FSK od 100 bauda (SITOR-B s FEC-om) i prima se na namjenskim kanalima diljem svijeta.

### Dostupni kanali

| Kanal | Frekvencija | Namjena |
|-------|-------------|---------|
| Međunarodni | 518 kHz | Na engleskom, međunarodni |
| Nacionalni | 490 kHz | Emisije na nacionalnom jeziku |
| KV (×5) | 4209.5 / 6314 / 8416.5 / 12579 / 16806.5 kHz | KV NAVTEX velikog dometa |

### Postavljanje

1. Uključite dekoder i iz padajućeg izbornika odaberite **NAVTEX**. Prijamnik automatski prelazi na **USB**.
2. Pojavljuje se ploča **NAVTEX Receiver**.
3. Odaberite željeni kanal iz izbornika **Station** (npr. `International — 518 kHz`).
4. Kliknite **⇒ Tune & Set IF** da automatski ugodite slap i suzite propusni pojas na ispravan audioprozor. Način rada automatski se postavlja na **USB**. Prikazana frekvencija postavlja se 500 Hz ispod središta kanala, pa se NAVTEX signal pojavljuje na 500 Hz u zvuku.

### Raspored emitiranja

Tablica rasporeda navodi sve poznate postaje na odabranom kanalu s:

- njihovim ITU identifikacijskim slovom i zastavom države
- vremenom sljedeće emisije u UTC-u
- odbrojavanjem u stvarnom vremenu do sljedeće emisije
- **Jantarno ⚡** unutar 2 minute / **Crveno ●** unutar 30 sekundi — odmah pripremite dekoder

### Čitanje ispisa

Dekodirani tekst pojavljuje se u tirkiznom fontu jednolike širine. Granice poruka jasno su označene:

```
━━ ZCZC MA12 ━━
... message content ...
━━ NNNN ━━
```

`ZCZC` označava početak poruke. Tri znaka iza njega označavaju postaju (`M`), temu (`A` = navigacijska upozorenja) i redni broj (`12`). `NNNN` označava kraj.

Kliknite **Clear** da izbrišete međuspremnik poruka.

> **Napomena:** NAVTEX radi na srednjim i dugim valovima (518/490 kHz). Domet prijama obično iznosi 200–400 nautičkih milja od odašiljača. KV kanali (4–17 MHz) pružaju znatno veći domet.

---

## 8. FSK / RTTY

**Što je to:** univerzalni FSK (frekvencijsko pomično ključanje) / RTTY dekoder koji podržava tri radne inačice: pomorski FSK (SITOR), meteorološki RTTY i amaterski RTTY. Svaka inačica dolazi s postavkom prilagođenom njezinim standardnim parametrima.

### Inačice i unaprijed zadane postavke

| Inačica | Središte | Pomak | Baud | Okvir | Kodiranje |
|---------|----------|-------|------|-------|-----------|
| Pomorski FSK / SITOR | 500 Hz | 170 Hz | 100 | 7N1 | CCIR-476 |
| Meteorološki RTTY | 1000 Hz | 450 Hz | 50 | 5N1.5 | ITA2 |
| Amaterski RTTY | 1000 Hz | 170 Hz | 45.45 | 5N1.5 | ITA2 |

### Postavljanje

1. Uključite dekoder i iz padajućeg izbornika odaberite **FSK / RTTY**.
2. Pojavljuje se ploča **FSK / RTTY Decoder**.
3. Odaberite **Variant** (Maritime, Weather ili Ham). Parametri se automatski ažuriraju.
4. Iz izbornika **Known frequency** odaberite uobičajenu frekvenciju za odabranu inačicu, zatim kliknite **Tune** da skočite na nju.
5. Fino ugađajte frekvenciju dok dekodirani tekst ne postane stabilan i čitljiv.

### Poznate frekvencije po inačici

**Pomorski FSK / SITOR**
- 518.0 kHz — međunarodni NAVTEX
- 490.0 kHz — nacionalni NAVTEX
- 4209.5 / 6314,0 / 8416.5 / 12579,0 / 16806.5 / 22376.0 kHz — KV SITOR

**Meteorološki RTTY**
- 4583,0 / 7646,0 / 10100,8 / 11039,0 / 14467.3 kHz — DWD (njemačka meteorološka služba)

**Amaterski RTTY**
- 3590 kHz (80 m), 7043 kHz (40 m), 10143 kHz (30 m), 14083 kHz (20 m), 21083 kHz (15 m), 28083 kHz (10 m)

### Parametri

| Parametar | Opis |
|-----------|------|
| Center audio (Hz) | Audiofrekvencija sredine između mark i space |
| Shift (Hz) | Razlika frekvencija između tonova mark i space |
| Baud | Brzina simbola |
| Framing | Podatkovni bitovi, parnost, stop bitovi (npr. 7N1 = 7 podatkovnih, bez parnosti, 1 stop) |
| Encoding | Skup znakova (CCIR-476, ITA2/Baudot ili ASCII) |
| Invert mark / space | Zamjenjuje tonove mark i space |
| Auto shift detect | Pokušava automatski izmjeriti pomak iz dolaznog signala |

### Mjerenja signala

Statusna traka prikazuje mjerenja u stvarnom vremenu:

- **Mark / Space** — izmjerena audiofrekvencija svakog tona (Hz)
- **SNR** — omjer signala i šuma u dB
- **Lock** — kvaliteta zaključavanja dekodera u postocima
- **Timing** — `LOCKED` kada je bitni takt sinkroniziran, `SEARCH` dok još traži

### Dodatne kontrole

- **⇒ Set IF Band-Pass** — sužava propusni pojas prijamnika tako da tijesno obuhvati FSK signal prema trenutačnim postavkama središta i pomaka. Koristite nakon ugađanja radi bolje selektivnosti i manjih smetnji sa susjednih kanala.
- **⟳ Auto-tune Center** — pokreće automatsko pretraživanje kako bi se pronašli i zaključali tonovi mark/space. Korisno kada ste blizu ispravne frekvencije, ali su tonovi malo pomaknuti.

> **Napomena o načinu rada:** dok je aktivan, FSK dekoder preuzima nadzor nad načinom demodulacije i propusnim pojasom MF-a. Oboje se automatski vraća kada isključite dekoder.
>
> **Napomena o polaritetu:** za RTTY (meteorološki) obično je potrebno označiti **Invert mark / space**. Za pomorski FSK (tipa SITOR/NAVTEX) i amaterski RTTY ostavite ga neoznačenim. Ako je dekodirani tekst besmislen, prebacivanje ovog potvrdnog okvira prvo je što treba pokušati.

---

## 9. SSTV

**Što je to:** televizija sporog raščlanjivanja prenosi nepomične slike običnim govornim SSB kanalom, redak po redak, kao frekvencijski moduliran ton između 1500 Hz (crno) i 2300 Hz (bijelo). Puna slika traje između 36 sekundi i 4 i pol minute, ovisno o načinu rada.

### Preporučene frekvencije (USB)

| Pojas | Frekvencija | Način rada | Napomene |
|-------|-------------|------------|----------|
| 20 m | 14.230 MHz | USB | Glavna međunarodna pozivna frekvencija za SSTV — daleko najaktivnija |
| 20 m | 14.233 MHz | USB | Pričuvna, kada je 14.230 zauzeta |
| 15 m | 21.340 MHz | USB | |
| 10 m | 28.680 MHz | USB | Aktivna tijekom otvaranja pojasa |
| 40 m | 7.171 MHz | LSB | |
| 80 m | 3.845 MHz | LSB | Regionalna, navečer |

**Bočni pojas bira se umjesto vas.** Pokretanjem dekodera odabire se **LSB ispod 10 MHz** i **USB iznad**, prema uobičajenoj amaterskoj praksi. Na pogrešnom bočnom pojasu preslikavanje tonova je obrnuto i slika se neće dekodirati. Ako naiđete na postaju koja zanemaruje konvenciju, jednostavno ručno promijenite bočni pojas — dekoder nastavlja raditi, briše okvir i kreće iznova s novom postavkom.

### Postavljanje

1. Uključite dekoder i iz padajućeg izbornika odaberite **SSTV**. Prijamnik automatski mijenja bočni pojas — USB iznad 10 MHz, LSB ispod.
2. Ugodite se tako da tonovi slike padnu u sredinu propusnog pojasa. Ispravno ugođen signal ima sinkroimpulse na 1200 Hz, a sadržaj slike između 1500 i 2300 Hz.
3. Ostavite **Mode** na **Auto** osim ako već znate što se šalje. Slika se gradi redak po redak kako pristiže.

### Načini rada

| Postavka | Slika | Trajanje |
|----------|-------|----------|
| **Auto** | Otkriva se automatski | — |
| Martin M1 / M2 | 320×256 u boji | 114 s / 58 s |
| Scottie S1 / S2 | 320×256 u boji | 110 s / 71 s |
| Scottie DX | 320×256 u boji | 269 s |
| Robot 36 / 72 | 320×240 u boji | 36 s / 72 s |

**Auto** radi na dva načina: čita **VIS zaglavlje** — digitalni kod načina rada poslan u prvih 300 ms emisije — a ako je zaglavlje propušteno (ugodili ste se prekasno ili se izgubilo u QSB-u), način rada prepoznaje prema vremenskim odnosima sinkroimpulsa. Odabir određenog načina rada nameće taj način, ali dekoder i dalje provjerava sinkronizaciju prije nego što išta nacrta, pa pogrešan odabir daje izostanak slike umjesto šuma.

### Čitanje ispisa

Statusni redak ispod kontrola pokazuje što dekoder radi:

| Stanje | Značenje |
|--------|----------|
| `Waiting for VIS / AUTO lock` | Osluškuje; još ništa nije prepoznato |
| `Martin M1? verifying sync…` | Pronađen je kandidat i potvrđuje se prema sljedećim recima |
| `Martin M1 lock (VIS)` | Zaključano prema VIS zaglavlju |
| `Martin M1 lock (AUTO)` | Zaključano prema vremenskim odnosima sinkroimpulsa |
| `Martin M1 lock (MANUAL)` | Pokrenuto gumbom **⏺ Force** |
| `Candidate rejected (no sync)` | Kandidat nije potvrđen — uobičajeno na šumu |
| `— sync lost, resetting` | Signal je nestao usred slike |
| `Frame complete` | Primljena je cijela slika |

Prepoznati način rada pojavljuje se i zelenom bojom uz naslov **SSTV**, a brojač redaka pokazuje napredak.

### Kontrole

| Gumb | Radnja |
|------|--------|
| **▶ Start** | Priprema dekoder. Sam po sebi ne crta sliku — zaključavanje i dalje mora doći iz VIS zaglavlja ili iz otkrivanja sinkronizacije. |
| **■ Stop** | Zaustavlja dekodiranje. |
| **↺ Reset** | Čisti platno i ponovno priprema dekoder na mjestu. Koristite ga između slika ili nakon ponovnog ugađanja. |
| **⏺ Force** | Počinje crtati **odmah** u načinu odabranom u izborniku, potpuno preskačući VIS i otkrivanje sinkronizacije. Dostupno samo kada Mode nije **Auto**. |
| **💾 Save** | Sprema trenutačnu sliku kao PNG. |

**Kada koristiti Force.** Ako u slapu vidite sliku, ali se dekoder ne može zaključati na nju — neuobičajen način rada, signal preslab ili previše izobličen za detektore, ili propušteno zaglavlje — odaberite način rada ručno i pritisnite **⏺ Force**. Okvir se usidruje u trenutku klika, a oznaka načina rada prikazuje `MANUAL` kako biste ga razlikovali od VIS ili AUTO zaključavanja. Dekoder se i dalje poravnava prema stvarnom sinkroimpulsu ako ga pronađe, pa se klik koji je malo preran ili prekasan ispravlja.

Budući da Force preskače svaku sigurnosnu provjeru, rado će nacrtati šum ako ga pritisnete na praznom kanalu i neće se sam zaustaviti — pritisnite **■ Stop** ili **↺ Reset**.

### Napomene

- **Šum ne pokreće dekoder.** Nekoć su atmosferski praskovi, iskre i mrežne smetnje bili dovoljni da pokrenu dekodiranje. Svaki stupanj otkrivanja sada provjerava je li ton doista ton i potvrđuje kandidata prema sljedećim recima prije nego što se nacrta i jedan piksel. Očekujte da će dekoder mirovati na praznom pojasu.
- **Slika se kosi dijagonalno ako niste na frekvenciji.** SSTV ne oprašta pogreške u ugađanju. Ako se reci naginju, podesite frekvenciju u malim koracima i pustite da počne sljedeća slika.
- Ravnoteža boja i oštrina su fiksne; nema se što podešavati.

---

## 10. Opći savjeti

**Prvo se mora uključiti Decoder: ON.** Padajući je izbornik onemogućen (zasivljen) dok ne kliknete gumb Decoder.

**Jedan dekoder istodobno.** Odabir novog dekodera iz izbornika automatski zaustavlja prethodno aktivni i poništava sve promjene načina rada ili propusnog pojasa koje je napravio.

**Načinom rada upravlja se umjesto vas.** HF FAX i NAVTEX prebacuju prijamnik na USB čim ih odaberete, SSTV bira bočni pojas prema pojasu (LSB ispod 10 MHz, USB iznad), a FAX, NAVTEX i FSK usto podešavaju propusni pojas kada kliknete njihov gumb Tune. Kada zaustavite dekoder, vraća se zadani način rada za taj pojas.

**Uključivanje dekodera više ne prekida zvuk.** Dekoderi rade u vlastitim dretvama, pa nema praznine, klika ni ispada kada se koji pokrene, zaustavi ili zamijeni drugim.

**Točnost sata sustava je važna.** FT8, FT4 i WSPR vremenski su kritični. Dekodiraju u fiksnim prozorima usklađenima s UTC-om. Ako sat vašeg računala odstupa više od 1–2 sekunde, stopa dekodiranja znatno će pasti. Koristite NTP klijent kako bi sat bio točan.

**Kvaliteta signala važnija je od njegove jakosti.** Većina je ovih dekodera namijenjena slabim signalima. Mirniji pojas s manje šuma često je plodonosniji od glasnog signala punog smetnji. Prije uključivanja dekodera koristite slap i kontrole propusnog pojasa kako biste prepoznali i izbjegli QRM.

**Slobodno koristite gumbe Refresh i Clear.** Slike FAX-a se pomiču ako je prikazana frekvencija malo pomaknuta, a tekstualni dekoderi nakupljaju šumne znakove. Novi početak nakon podešavanja ugađanja često daje mnogo čišći ispis.

---

*PhantomSDR-Plus — sv1btl fork — [phantomsdr.no-ip.org](http://phantomsdr.no-ip.org:8900)*
