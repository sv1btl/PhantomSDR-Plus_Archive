# Digitalni glas RADE v1 za PhantomSDR-Plus

**RADE** (Radio AutoencoDEr) vodeći je FreeDV-ov način rada digitalnog glasa na kratkim
valovima. Koristi hibrid strojnog učenja i DSP-a (neuronski vokoder FARGAN) i pruža govor
visoke kvalitete na KV-u pri omjerima signal/šum do −2 dB, u tek 1500 Hz RF širine pojasa —
uže od SSB signala.

Ovaj dokument obrađuje potpunu integraciju prijama RADE v1 u PhantomSDR-Plus, izvedenu kao
sidecar proces u Pythonu (`rade_helper.py`) koji povezuje preglednik s lancem dekodiranja
`radae_rxe.py` + `lpcnet_demo`.

- **[Ručna instalacija RADE-a na Linuxu](RADE_General_INSTALL_MANUAL_LINUX.md)** - Potpuni vodič za korištenje WebSDR-a
- **[Ručna instalacija RADE-a na Pi/Debian Bookworm (ARM64)](RADE_Pi_INSTALL_MANUAL.md)** - Potpuni vodič za korištenje WebSDR-a

---

## Sadržaj

1. [Kako to radi](#kako-to-radi)
2. [Pregled arhitekture](#pregled-arhitekture)
3. [RADEL naspram RADEU](#radel-naspram-radeu)
4. [Prije instalacije — sistemski zahtjevi](#prije-instalacije--sistemski-zahtjevi)
5. [Korak 1 — Kloniranje i izgradnja repozitorija radae](#korak-1--kloniranje-i-izgradnja-repozitorija-radae)
6. [Korak 2 — Instalacija Python ovisnosti](#korak-2--instalacija-python-ovisnosti)
7. [Korak 3 — Provjera lanca dekodiranja](#korak-3--provjera-lanca-dekodiranja)
8. [Korak 4 — Postavljanje zakrpanih datoteka](#korak-4--postavljanje-zakrpanih-datoteka)
9. [Korak 5 — Izgradnja sučelja](#korak-5--izgradnja-sučelja)
10. [Korak 6 — Instalacija upravljačke skripte rade.sh](#korak-6--instalacija-upravljačke-skripte-radesh)
11. [Korak 7 — Otvaranje porta 8074](#korak-7--otvaranje-porta-8074)
12. [Korak 8 — Pokretanje poslužitelja](#korak-8--pokretanje-poslužitelja)
13. [Korak 9 — Ručno pokretanje RADE-a](#korak-9--ručno-pokretanje-rade-a)
14. [Korak 10 — Korištenje RADE-a u pregledniku](#korak-10--korištenje-rade-a-u-pregledniku)
15. [Provjera i otklanjanje pogrešaka](#provjera-i-otklanjanje-pogrešaka)
16. [Varijable okruženja](#varijable-okruženja)
17. [Promijenjene datoteke](#promijenjene-datoteke)
18. [Sažetak toka signala](#sažetak-toka-signala)
19. [Rješavanje problema](#rješavanje-problema)
20. [Mjerenje istodobnosti na vlastitom hardveru](#mjerenje-istodobnosti-na-vlastitom-hardveru)
21. [Ažuriranje RADE v1](#ažuriranje-rade-v1)

---

## Kako to radi

RADE v1 ne može raditi u pregledniku — traži PyTorch i neuronski vokoder FARGAN, koji su
preveliki za WASM. Rješenje je sidecar proces u Pythonu (`rade_helper.py`) koji radi na istom
poslužitelju kao PhantomSDR-Plus.

> **Važno:** `freedv_rx` iz repozitorija codec2 **ne** podržava RADEV1.
> Lanac dekodiranja RADE u cijelosti se nalazi u zasebnom repozitoriju `radae` Davida Rowea
> (VK5DGR). Nemojte pokušavati koristiti codec2-ov `freedv_rx` za RADE.

Kada u pregledniku odaberete RADE:

1. Sučelje postavlja osnovnu demodulaciju na USB ili LSB — poslužitelj u C++-u demodulira SSB
   signal na uobičajen način.
2. Sirovi demodulirani PCM preuzima se u `audio.js` **prije** bilo kakvog utišavanja ili
   squelch vrata — `radae_rxe.py` treba neprekidan ulaz da bi održao sinkronizaciju okvira.
3. Svaki blok PCM-a dopunjava se nulama iz realnog f32 u kompleksni f32 (realni + 0.0
   imaginarni) — upravo to `radae_rxe.py` očekuje na standardnom ulazu.
4. Sidecar te uzorke prosljeđuje u `radae_rxe.py`, koji ispisuje značajke vokodera.
5. `lpcnet_demo -fargan-synthesis` pretvara značajke u govor s16 pri 16000 Hz.
6. Sidecar pretvara s16 → f32 i vraća to pregledniku kao binarne WebSocket okvire.
7. Preglednik reproducira dekodirani govor putem Web Audio API-ja pri 16000 Hz.

Poslužitelj u C++-u (`spectrumserver.cpp`) uopće se ne mijenja.

---

## Pregled arhitekture

```
┌────────────────────────────────────────────────────────────────────┐
│  Browser                                                           │
│                                                                    │
│  Decoder → "RADE v1 — RADEL (LSB)" / "RADEU (USB)"               │
│       │                                                            │
│  audio.js ── demod cmd (LSB/USB) ──────────► C++ spectrumserver   │
│       │                                              │             │
│       │  raw SSB PCM @ audioOutputSps ◄─────────────┘             │
│       │  (tapped before mute gate, zero-padded to complex f32)     │
│       │                                                            │
│       │  binary WebSocket ──► ws://host:8074                       │
│       ▼                                                            │
├────────────────────────────────────────────────────────────────────┤
│  rade_helper.py  (port 8074)                                       │
│                                                                    │
│  resample to 8000 Hz if needed                                     │
│  zero-pad real f32 → complex f32 pairs                             │
│       │ stdin pipe                                                  │
│       ▼                                                            │
│  radae_rxe.py  --model_name model19_check3/.../checkpoint_100.pth  │
│       │ stdout pipe (vocoder features f32)                         │
│       ▼                                                            │
│  lpcnet_demo  -fargan-synthesis  -  -                              │
│       │ stdout (s16 PCM @ 16000 Hz)                                │
│       │ converted → f32 by sidecar                                 │
│       │ binary WebSocket frames ──► browser                        │
│       ▼                                                            │
├────────────────────────────────────────────────────────────────────┤
│  Browser                                                           │
│                                                                    │
│  _radePlayPCM() → AudioContext.createBuffer(16000 Hz) → speaker   │
└────────────────────────────────────────────────────────────────────┘
```

---

## RADEL naspram RADEU

RADE v1 uvijek se prenosi putem SSB-a. Prema konvenciji:

| Način rada | Bočni pojas | Koristiti na pojasevima                  |
|------------|-------------|------------------------------------------|
| RADEL      | LSB         | 160 m, 80 m, 40 m  (≤ 10 MHz)           |
| RADEU      | USB         | 20 m, 17 m, 15 m, 12 m, 10 m (> 10 MHz) |

---

## Preduvjeti

| Zahtjev | Verzija | Napomene |
|---|---|---|
| PhantomSDR-Plus | bilo koja | s Vite/Svelte sučeljem |
| Linux | Ubuntu 24.04+ / Debian Bookworm+ | testirano |
| Python | 3.8+ | za `rade_helper.py` i `radae_rxe.py` |
| repozitorij radae | najnoviji master | daje `radae_rxe.py` i `lpcnet_demo` |
| cmake | 3.10+ | za izgradnju `lpcnet_demo` iz radae |
| PyTorch | 2.0+ | traži ga `radae_rxe.py` |
| Node.js | 16+ | za `npm run build` |
| websockets (Python) | 10–16+ | `pip3 install websockets` — podržane sve verzije |
| matplotlib | bilo koja | traži ga `radae_rxe.py` pri uvozu |
| numpy | 1.23+ | obavezan; omogućuje i ponovno uzorkovanje |
| scipy | bilo koja | neobavezno, omogućuje precizno ponovno uzorkovanje |

---

## Prije instalacije — sistemski zahtjevi

Prije kloniranja repozitorija PhantomSDR-Plus ili bilo kakve izgradnje, instalirajte sve
sistemske ovisnosti na svom Ubuntu/Debian poslužitelju.

### Sistemski paketi

```bash
sudo apt update
sudo apt install -y \
    build-essential cmake git \
    python3 python3-pip \
    nodejs npm \
    aplay alsa-utils
```

### Node.js (ako je sistemska verzija prestara — treba 16+)

```bash
node --version   # check current version
# If below 16.x:
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### Python paketi

```bash
pip3 install websockets matplotlib torch numpy scipy
```

> **Napomena o verziji websocketsa:** podržana je svaka verzija od 10.x do 16.x+.
> `rade_helper.py` automatski prepoznaje verziju API-ja.

### Provjera Python paketa

```bash
python3 -c "import websockets, matplotlib, torch, numpy, scipy; print('All OK')"
```

---

## Korak 1 — Kloniranje i izgradnja repozitorija radae

RADE dekoder **nije** dio codec2. Nalazi se u zasebnom repozitoriju i mora se izgraditi iz
izvornog koda kako bi se dobila binarna datoteka `lpcnet_demo`.

```bash
# 1a. Install build dependencies
sudo apt install build-essential cmake git python3-pip

# 1b. Clone the radae repository
git clone https://github.com/drowe67/radae.git ~/radae
cd ~/radae

# 1c. Build (produces lpcnet_demo and other binaries)
mkdir build && cd build
cmake ..
make -j$(nproc)

# 1d. Verify lpcnet_demo was built
ls -la ~/radae/build/src/lpcnet_demo
```

Trebali biste vidjeti `lpcnet_demo` na putanji `~/radae/build/src/lpcnet_demo`.

**Unaprijed istrenirane težine modela** već su uključene u repozitorij:

```bash
# Verify model19_check3 weights are present (this is the correct model)
ls ~/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
```

---

## Korak 2 — Instalacija Python ovisnosti

```bash
# Required
pip3 install websockets matplotlib torch numpy

# Recommended (enables accurate resampling when audioOutputSps > 8000)
pip3 install scipy
```

> **Zašto matplotlib?** `radae_rxe.py` uvozi matplotlib na vrhu datoteke čak i kad se ne
> generiraju grafikoni. Mora biti instaliran, inače skripta odmah pada uz
> `ModuleNotFoundError: No module named 'matplotlib'`.

> **Zašto torch?** `radae_rxe.py` koristi PyTorch za zaključivanje neuronskog vokodera.

---

## Korak 3 — Provjera lanca dekodiranja

Prije nego što sve povežete, provjerite radi li puni lanac samostalno. Ovaj korak iz WAV
datoteke generira ispitni signal RADE i dekodira ga na zvučnike.

```bash
cd ~/radae

# Step 3a — Generate a RADE-encoded test signal
# Note: --auxdata is required for model19_check3 when using inference.sh
./inference.sh model19_check3/checkpoints/checkpoint_epoch_100.pth \
    wav/brian_g8sez.wav /dev/null \
    --rate_Fs --pilots --pilot_eq --eq_ls --cp 0.004 \
    --write_rx rx.f32 --auxdata
```

Pričekajte da završi. Ispisuje statistiku koja završava ovako:
```
loss: 0.741 Auxdata BER: 0.012
```

Zatim dekodirajte i reproducirajte:

```bash
# Step 3b — Decode and play
cat rx.f32 \
    | python3 radae_rxe.py --model_name model19_check3/checkpoints/checkpoint_epoch_100.pth \
    | ./build/src/lpcnet_demo -fargan-synthesis - - \
    | aplay -f S16_LE -r 16000
```

Trebali biste čuti glas. Ispis prikazuje uspostavu sinkronizacije:
```
  1 state: search     ...
  5 state: sync       ... SNRdB:  4.03 uw_err: 0
Playing raw data 'stdin' : Signed 16 bit Little Endian, Rate 16000 Hz, Mono
```

Poruke `underrun!!!` tijekom ovog izvanmrežnog testa očekivane su — `radae_rxe.py` obrađuje
sporije od datotečnog U/I-ja. **Ne** pojavljuju se pri prijamu uživo jer preglednik dovodi zvuk
u stvarnom vremenu.

> **Ključne činjenice o `radae_rxe.py`:**
> - Putanja modela predaje se kao `--model_name <putanja>`, a **ne** kao pozicijski argument
> - `--auxdata` je **uključen prema zadanom** — nemojte ga predavati kao zastavicu
> - `--noauxdata` koristite samo ako ga trebate isključiti

```bash
# Step 3c — Verify the sidecar starts correctly
python3 ~/PhantomSDR-Plus/rade_helper.py
```

Očekivani ispis (bez WARNING redaka):
```
[RADE] helper starting on ws://0.0.0.0:8074
[RADE] radae_rx.py    : /home/sv1btl/radae/radae_rxe.py
[RADE] model          : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
[RADE] lpcnet_demo    : /home/sv1btl/radae/build/src/lpcnet_demo
[RADE] auxdata        : ON (default)
[RADE] torch threads  : 1 per instance (RADE_TORCH_THREADS to override)
[RADE] architecture   : per-connection (each user tunes independently)
[RADE] listening — waiting for PhantomSDR-Plus clients
```

Pritisnite Ctrl+C za prekid.

---

## Korak 4 — Postavljanje zakrpanih datoteka

Kopirajte sljedeće datoteke iz skupa zakrpa u svoj repozitorij PhantomSDR-Plus.

### Nova datoteka — stavite je u korijen repozitorija, uz početnu skriptu koju koristite:

```
rade_helper.py
```

### Zakrpane datoteke sučelja — stavite ih u `frontend/src/`:

```
audio.js
App.svelte
App__analog_smeter_.svelte
App__digital_smeter_.svelte
App__v2_analog_smeter_.svelte
App__v2_digital_smeter_.svelte
```

### Što zakrpe rade

**`audio.js`** — 5 izmjena:
- Konstruktor: 5 novih polja stanja za RADE (`decodeRADE`, `_radeSideband`, `_radeSocket`,
  `_radeCallback`, `_radeReady`, `_radeNextTime`)
- Spremanje PCM-a prije pojačanja: `pcmArrayPreBoost` sprema se prije 300× FLAC pojačanja kako
  bi RADE dobio izvornu amplitudu (pojačanje bi zasitilo `radae_rxe.py`)
- `playAudio()`: preuzimanje PCM-a za RADE pomoću zvuka prije pojačanja, prije vrata
  utišavanja/squelcha
- `playAudio()`: zaštita `if (this.decodeRADE) return` — potiskuje reprodukciju sirovog SSB-a
  dok svira govor koji je dekodirao RADE
- Nove metode: `setRADEDecoding()`, `setRADECallback()`, `_radePlayPCM()` s planiranom
  reprodukcijom bez praznina pomoću sata `_radeNextTime`
  (reproducira na **16000 Hz** — izlaznoj frekvenciji `lpcnet_demo`)

**Svaka Svelte inačica** — 6 izmjena:
- `demodulationDefaults`: RADEL `{type:'LSB', offsets:[2200,-700]}`,
  RADEU `{type:'USB', offsets:[-700,2200]}` — propusni pojas počinje 700 Hz od nosioca i širok
  je 1500 Hz
- Varijable stanja: `radeEnabled`, `radeConnected`, `radeSynced`, `radeSnr`,
  `_radeDeactivate()`
- `_radeDeactivate()`: zaustavlja dekoder i **vraća zadani način rada za pojas** iz
  `bands-config.js` — ponašanje identično isključivanju FAX-a, NAVTEX-a i FSK-a
- `_deactivateAll()`: redak za čišćenje RADE-a
- `activateSelectedDecoder()`: grane `radel` i `radeu`
- Padajući izbornik dekodera: dvije nove stavke `<option>`
- Ploča stanja: točka povezanosti, stanje sinkronizacije/SNR-a, traka pogreške

### Početne skripte

Glavne početne skripte poslužitelja (`go.sh`, `kill.sh`, `start-rx888mk2.sh`,
`stop-websdr.sh`) **ne** mijenjaju se. RADE se nezavisno vodi putem `rade.sh` (vidi Korak 6).

---

## Korak 5 — Izgradnja sučelja

```bash
cd ~/PhantomSDR-Plus/frontend
npm install       # only if node_modules is missing
npm run build
```

Pripazite na pogreške Vite/acorn raščlanjivača. Zakrpani kod namjerno izbjegava `?.`, `??` i
prazne `catch {}` kako bi zadovoljio ograničenje acorna.

---

## Korak 6 — Instalacija upravljačke skripte rade.sh

`rade.sh` je namjenska skripta za upravljanje RADE sidecarom. Glavne početne skripte
poslužitelja (`go.sh`, `kill.sh`, `start-rx888mk2.sh`, `stop-websdr.sh`) **ne** mijenjaju se —
RADE se pokreće i zaustavlja neovisno.

Kopirajte `rade.sh` u svoj PhantomSDR-Plus direktorij i postavite ga kao izvršnu datoteku:

```bash
cp rade.sh ~/PhantomSDR-Plus/
chmod +x ~/PhantomSDR-Plus/rade.sh
```

Dostupne naredbe:

```bash
./rade.sh start      # start sidecar with self-restarting watchdog
./rade.sh stop       # stop sidecar + watchdog + lpcnet_demo children
./rade.sh restart    # stop then start cleanly
./rade.sh status     # show running / stopped + process info
```

Aktivnost sidecara bilježi se u `~/PhantomSDR-Plus/rade.log`:

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

> **Zašto to ne ugraditi u početne skripte?**
> Držanje RADE-a odvojenim znači da poslužitelj može raditi i bez RADE-a (štedeći CPU kada ga
> nitko ne koristi), a RADE se može neovisno ponovno pokrenuti bez diranja glavnog procesa
> poslužitelja.

---

## Korak 7 — Otvaranje porta 8074

Sidecar sluša na portu **8074**. Preglednik se spaja izravno na taj port.
Port 8074 mora biti dostupan izvana.

### Provjera trenutačnog stanja

```bash
# Is sidecar listening?
ss -tlnp | grep 8074

# Test from outside (not from the server itself — NAT hairpin will give false results)
# Use: https://portchecker.co  →  your-hostname  →  port 8074
```

> **Upozorenje o NAT hairpinu:** testiranje naredbom `curl` s poslužitelja prema njegovu
> vlastitom javnom nazivu često vraća `Connection refused` čak i kad je port otvoren — mnogi
> usmjerivači blokiraju povratnu petlju. Uvijek testirajte s vanjskog računala ili putem
> portchecker.co.

### Otvaranje u iptablesu

```bash
sudo iptables -I INPUT -p tcp --dport 8074 -j ACCEPT

# Make permanent across reboots:
sudo apt install iptables-persistent
sudo netfilter-persistent save
```

### Otvaranje u ufw-u

```bash
sudo ufw allow 8074/tcp && sudo ufw reload
```

### Prosljeđivanje na usmjerivaču

Dodajte pravilo NAT-a / prosljeđivanja porta: `TCP port 8074 → LAN IP poslužitelja : 8074`

### Alternativa: proxy kroz postojeći javni port pomoću Nginxa

Ako port 8074 nije moguće otvoriti (blokada pružatelja i sl.), proslijedite WebSocket kroz
svoj postojeći javni port pomoću Nginxa:

```nginx
# Add inside your existing server {} block
location /rade {
    proxy_pass         http://127.0.0.1:8074;
    proxy_http_version 1.1;
    proxy_set_header   Upgrade    $http_upgrade;
    proxy_set_header   Connection "upgrade";
    proxy_set_header   Host       $host;
    proxy_read_timeout 3600s;
}
```

```bash
sudo nginx -t && sudo nginx -s reload
```

Zatim promijenite URI sidecara u `audio.js`, unutar funkcije `setRADEDecoding()`:

```js
// Find:
var helperUri = uri || ('ws://' + window.location.hostname + ':8074');

// Change to:
var helperUri = uri || ('ws://' + window.location.host + '/rade');
```

Nakon te izmjene ponovno izgradite sučelje.

---

## Korak 8 — Pokretanje poslužitelja

Pokrenite PhantomSDR-Plus kao i obično — RADE se **ne** pokreće automatski:

```bash
cd ~/PhantomSDR-Plus
./start-rx888mk2.sh      # or start-airspyhf.sh,
                         # start-rtl.sh, start-rsp1a.sh
```

Poslužitelj se pokreće bez RADE sidecara. Prijeđite na Korak 9 da aktivirate RADE.

---

## Korak 9 — Ručno pokretanje RADE-a

Kada poslužitelj PhantomSDR-Plus radi, zasebno pokrenite RADE sidecar:

```bash
cd ~/PhantomSDR-Plus
./rade.sh start
```

Provjerite radi li:

```bash
./rade.sh status
```

Očekivani ispis:
```
[RADE] Running
$USER  python3 /home/sv1btl/PhantomSDR-Plus/rade_helper.py ...
```

Pratite zapisnik pokretanja:

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

Očekivani redci zapisnika:
```
[RADE] sidecar starting at ...
[RADE] helper starting on ws://0.0.0.0:8074
[RADE] radae_rx.py    : /home/sv1btl/radae/radae_rxe.py
[RADE] model          : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
[RADE] lpcnet_demo    : /home/sv1btl/radae/build/src/lpcnet_demo
[RADE] auxdata        : ON (default)
[RADE] torch threads  : 1 per instance
[RADE] architecture   : per-connection (each user tunes independently)
[RADE] listening — waiting for PhantomSDR-Plus clients
```

Za zaustavljanje RADE-a bez zaustavljanja poslužitelja:

```bash
./rade.sh stop
```

Za ponovno pokretanje RADE-a (npr. nakon ažuriranja `rade_helper.py`):

```bash
./rade.sh restart
```

> **Napomena:** sam `pkill -f rade_helper.py` nije dovoljan — `rade.sh` pokreće watchdog petlju
> koja se sama ponovno pokreće i koja će proces oživjeti unutar 3 sekunde. Za potpun prekid
> uvijek koristite `./rade.sh stop`.

---

## Korak 10 — Korištenje RADE-a u pregledniku

1. Otvorite svoje web-sučelje PhantomSDR-Plusa
2. Aktivne postaje potražite na **[qso.freedv.org](https://qso.freedv.org)**
3. Ugodite se na prikazanu frekvenciju postaje
4. U **Decoder Options** odaberite:
   - **RADE v1 — RADEL (LSB)** za 40 m / 80 m / 160 m
   - **RADE v1 — RADEU (USB)** za 20 m / 17 m / 15 m / 12 m / 10 m
5. Kliknite **Decoder: ON**

### Stanja pokazatelja na ploči

| Pokazatelj | Značenje |
|---|---|
| 🔴 Crveno — „Connecting to sidecar…" | Port 8074 nedostupan ili sidecar ne radi |
| 🟡 Žuto — „Searching for signal…" | Sidecar spojen, RADE okvir još nije otkriven |
| 🟢 Zeleno — „Synced · SNR x.x dB" | Dekodiranje — govor se reproducira |

### Kada isključite dekoder

Način rada i propusni pojas automatski se vraćaju na ispravnu zadanu vrijednost za trenutačnu
frekvenciju, kako je određeno u `bands-config.js` — jednako kao kod FAX-a, NAVTEX-a i FSK-a.

---

## Provjera i otklanjanje pogrešaka

### Radi li sidecar?

```bash
ps aux | grep rade_helper | grep -v grep
ss -tlnp | grep 8074
```

### Praćenje aktivnosti uživo

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

Kada se preglednik spoji:
```
[RADE] client connected: x.x.x.x:XXXXX
[RADE] x.x.x.x:XXXXX  sps=12000 sideband=LSB
[RADE] x.x.x.x:XXXXX spawning pipeline (torch_threads=1)
```

### Brza provjera WebSocketa

```bash
python3 - << 'EOF'
import asyncio, websockets, json

async def test():
    async with websockets.connect('ws://localhost:8074') as ws:
        await ws.send(json.dumps({'type': 'init', 'sps': 8000, 'sideband': 'LSB'}))
        print(await ws.recv())   # expect: {"type": "status", "connected": true}

asyncio.run(test())
EOF
```

### Konzola preglednika (F12)

```
[RADE] ▶ ENABLED LSB @ 12000 Hz → helper ws://localhost:8074
```
Dobro — WebSocket je otvoren. Vrijednost u Hz odgovara `audioOutputSps` vašeg poslužitelja (obično 8000–12000 Hz).

```
[RADE] sidecar socket error
```
Port 8074 nije dostupan — provjerite vatrozid i NAT pravilo usmjerivača.

---

## Varijable okruženja

| Varijabla | Zadano | Opis |
|---|---|---|
| `RADE_HELPER_PORT` | `8074` | TCP port na kojem sluša sidecar |
| `RADE_HELPER_HOST` | `0.0.0.0` | Adresa vezanja (`127.0.0.1` iza proxyja) |
| `RADAE_DIR` | `~/radae` | Korijen repozitorija radae |
| `RADE_MODEL` | `RADAE_DIR/model19_check3/checkpoints/checkpoint_epoch_100.pth` | Težine modela |
| `LPCNET_DEMO` | `RADAE_DIR/build/src/lpcnet_demo` | Binarna datoteka lpcnet_demo |
| `RADE_AUXDATA` | `1` | Postavite na `0` da se `radae_rxe.py` proslijedi `--noauxdata` |
| `RADE_TORCH_THREADS` | `1` | PyTorch/OpenBLAS dretve po instanci `radae_rxe.py` — ograničava potrošnju CPU-a |
| `RADE_PIN_CORES` | `1` | Veže svaki lanac dekodiranja uz vlastiti skup jezgri; `0` isključuje vezanje |
| `RADE_CORES_PER_CLIENT` | `2` | Jezgri dodijeljenih po klijentu kada je vezanje uključeno |

---

## Promijenjene datoteke

| Datoteka | Vrsta | Napomene |
|---|---|---|
| `rade_helper.py` | **Nova** | Python sidecar: WebSocket poslužitelj + dvoprocesni lanac dekodiranja |
| `frontend/src/audio.js` | Izmijenjena | 4 zakrpe |
| `frontend/src/App.svelte` | Izmijenjena | 6 zakrpa |
| `frontend/src/App__analog_smeter_.svelte` | Izmijenjena | 6 zakrpa |
| `frontend/src/App__digital_smeter_.svelte` | Izmijenjena | 6 zakrpa |
| `frontend/src/App__v2_analog_smeter_.svelte` | Izmijenjena | 6 zakrpa |
| `frontend/src/App__v2_digital_smeter_.svelte` | Izmijenjena | 6 zakrpa |
| `rade.sh` | **Nova** | Upravljačka skripta RADE sidecara (start/stop/restart/status) |
| `go.sh` | **Nepromijenjena** | RADE se vodi zasebno putem rade.sh |
| `kill.sh` | **Nepromijenjena** | RADE se vodi zasebno putem rade.sh |
| `start-rx888mk2.sh` | **Nepromijenjena** | RADE se vodi zasebno putem rade.sh |
| `stop-websdr.sh` | **Nepromijenjena** | RADE se vodi zasebno putem rade.sh |
| `spectrumserver.cpp` | **Nepromijenjena** | Nisu potrebne izmjene u C++-u |

---

## Sažetak toka signala

```
Antenna → RX-888 MK2 → PhantomSDR-Plus C++ server
                              │
                    FFT + DDC + SSB demodulation
                    (USB or LSB — set by RADEL/RADEU)
                              │
                    Opus/FLAC encode → WebSocket → Browser
                              │
                         audio.js decode()
                              │
                         playAudio(pcmArray)
                              │
               ┌──────────────┴────────────────────────────┐
               │  rawPcm tap (before mute gate)             │
               │  real f32 → zero-padded complex f32 pairs  │
               └──────────────┬────────────────────────────┘
                              │ WebSocket binary → ws://host:8074
                              ▼
                       rade_helper.py
                              │ resample to 8000 Hz if needed
                              │ stdin pipe
                              ▼
          radae_rxe.py  --model_name model19_check3/.../checkpoint_epoch_100.pth
          (PyTorch FARGAN neural vocoder, auxdata ON by default)
                              │ stdout pipe (vocoder features f32)
                              ▼
          lpcnet_demo  -fargan-synthesis  -  -
                              │ stdout: s16 PCM @ 16000 Hz
                              │ sidecar converts s16 → f32
                              │ WebSocket binary frames → browser
                              ▼
                  audio.js  _radePlayPCM()
                  AudioContext.createBuffer(16000 Hz)
                              │
                           Speaker 🔊
```

---

## Rješavanje problema

### Crvena traka — „Sidecar not reachable"

```bash
# Is sidecar running?
ps aux | grep rade_helper | grep -v grep

# Start it manually for testing
python3 ~/PhantomSDR-Plus/rade_helper.py &

# Check port is open externally — use portchecker.co NOT curl from the server
# (curl from the server uses NAT loopback and gives false "Connection refused")
```

---

### Port 8074 prikazuje se zatvorenim na portchecker.co unatoč iptables pravilu

Možda pružatelj filtrira port ili nedostaje NAT pravilo na usmjerivaču. Mogućnosti:

1. Isprobajte drugi port: `RADE_HELPER_PORT=8080 python3 rade_helper.py`
2. Proslijedite kroz postojeći javni port pomoću Nginxa (vidi Korak 7)

---

### `radae_rxe.py: error: unrecognized arguments: model_path`

Putanja modela mora se predati kroz `--model_name`, a ne kao pozicijski argument:

```bash
# WRONG — positional argument
python3 radae_rxe.py model19_check3/checkpoints/checkpoint_epoch_100.pth

# CORRECT — named argument
python3 radae_rxe.py --model_name model19_check3/checkpoints/checkpoint_epoch_100.pth
```

---

### `ModuleNotFoundError: No module named 'matplotlib'`

```bash
pip3 install matplotlib
```

`radae_rxe.py` bezuvjetno uvozi matplotlib na vrhu datoteke.

---

### `ModuleNotFoundError: No module named 'torch'`

```bash
pip3 install torch
```

---

### `lpcnet_demo: No such file or directory`

Izgradnja radae nije dovršena. Izgradite ponovno:

```bash
cd ~/radae/build
cmake .. && make -j$(nproc)
ls src/lpcnet_demo     # should exist now
```

---

### Pogreška `size mismatch` u `inference.sh`

`model19_check3` traži `--auxdata` pri kodiranju pomoću `inference.sh`:

```bash
./inference.sh model19_check3/checkpoints/checkpoint_epoch_100.pth \
    wav/brian_g8sez.wav /dev/null \
    --rate_Fs --pilots --pilot_eq --eq_ls --cp 0.004 \
    --write_rx rx.f32 --auxdata    # ← required for model19_check3
```

Napomena: pri **dekodiranju** pomoću `radae_rxe.py` `--auxdata` je zadan — nemojte ga predavati.

---

### Žuti pokazatelj — „Searching for signal" — nikad se ne sinkronizira

- Potvrdite ispravan bočni pojas: RADEL za ≤ 10 MHz, RADEU za > 10 MHz
- Provjerite na [qso.freedv.org](https://qso.freedv.org) odašilje li neka postaja u tom trenutku
- RADE v1 koristi 30 nosilaca u 1500 Hz širine — u slapu se pojavljuje kao zbijena skupina
- Predvidite do 1,5 sekunde za uspostavu

---

### `underrun!!!` iz aplaya tijekom testa lanca (Korak 3)

Očekivano samo pri izvanmrežnom testiranju s datotekama. `radae_rxe.py` obrađuje sporije od
datotečnog U/I-ja, pa audio međuspremnik ostaje prazan. Pri prijamu uživo to se ne događa jer
preglednik dovodi zvuk u stvarnom vremenu.

---

### `ConnectionClosedError: received 1011 (internal error)`

Sidecar je prihvatio WebSocket vezu, ali se interno srušio prije nego što je odgovorio. Uzrok je
nekompatibilna verzija `rade_helper.py` — starija je verzija pokušavala predati asyncio
`StreamReader` kao standardni ulaz podprocesa, što tiho ne uspijeva i zatvara vezu s pogreškom
1011.

**Rješenje:** zamijenite `rade_helper.py` aktualnom verzijom iz skupa zakrpa. Aktualna verzija
koristi `os.pipe()` za međuprocesnu cijev i kompatibilna je s websocketsom od 10.x do 16.x+.

---

### Više istodobnih korisnika

Svaka veza preglednika pokreće vlastiti neovisni par `radae_rxe.py` + `lpcnet_demo`, pa se svaki
korisnik može slobodno ugoditi na drugu frekvenciju.

Prema zadanom, `radae_rxe.py` koristi **sve dostupne CPU jezgre** za matrične operacije
PyTorcha, uzrokujući potrošnju CPU-a od ~900 % po instanci. `rade_helper.py` to ograničava s
dvije optimizacije:

1. `OMP_NUM_THREADS=1` (i odgovarajuće MKL/OpenBLAS varijable) — ograničava PyTorch na 1 dretvu
2. Funkcije pretvorbe zvuka vektorizirane numpyjem — uklanjaju trošak Python petlji

Rezultat: svaka instanca troši otprilike **8–10 %** jedne jezgre, dovoljno za dekodiranje RADE-a
u stvarnom vremenu. Ako čujete ispade zvuka, povećajte na 2 dretve:

```bash
RADE_TORCH_THREADS=2 ./rade.sh restart
```

| Istodobnih korisnika RADE-a | Približno opterećenje CPU-a |
|---|---|
| 1 | ~9 % |
| 5 | ~45 % |
| 10 | ~90 % |
| 20 | ~180 % |

Na i5-12450H (12 dretvi), gdje spectrumserver troši ~42 %, a rx888_stream ~11 %, imate otprilike
**1000 % rezerve** — dovoljno za **20 i više istodobnih** korisnika RADE-a prije nego što CPU
postane problem.

> **Gornja tablica pretpostavlja da trošak CPU-a raste linearno s brojem korisnika. Mjerenje
> govori da nije tako.** Pokretanje `rade_loadtest.py` na tom istom i5-12450H pokazalo je trošak
> CPU-a po slušatelju znatno ispod ove tablice do ~24 slušatelja, a zatim oštar rast, pri čemu
> je računalo zaustavljeno **temperaturom kućišta procesora pri 32 slušatelja** — ne CPU-om ni
> propusnošću. Te brojke uzmite tek kao grubu smjernicu za male brojeve i izmjerite vlastito
> računalo: vidi
> [Mjerenje istodobnosti na vlastitom hardveru](#mjerenje-istodobnosti-na-vlastitom-hardveru).
> Imajte na umu da test opterećenja lanac hrani šumom, a ne stvarnim RADE signalom, pa apsolutna
> potrošnja CPU-a uz stvaran promet može biti drukčija; pouzdan je *oblik* krivulje.

---

## Mjerenje istodobnosti na vlastitom hardveru

Gornje brojke potječu s jednog određenog računala. `rade_loadtest.py` (u korijenu repozitorija)
mjeri isto na **vašem** — u koracima povećava broj sintetičkih RADE slušatelja prema sidecaru i
javlja posljednji broj slušatelja koji je vaše računalo izdržalo prije nego što je nešto popustilo.

Nakon svakog koraka pusti računalo da se smiri, zatim uzorkuje temperaturu kućišta procesora,
ukupni CPU, dostupni RAM, swap i zbrojeni RSS svih procesa `radae_rxe.py` i `lpcnet_demo`.
Zaustavlja se na prvom **koljenu** — koje god ograničenje prvo bude prekoračeno — i ispisuje
posljednji stabilan broj.

### Preduvjeti

```bash
sudo apt install python3-websockets python3-psutil
```

Pokrenite ga **na računalu sa SDR-om** (čita lokalne senzore i memoriju procesa), uz već
pokrenute spectrumserver i RADE sidecar:

```bash
cd ~/PhantomSDR-Plus
python3 rade_loadtest.py
```

Ctrl-C u svakom trenutku uredno zatvara sve veze.

### Prije prvog pokretanja

Otvorite datoteku i provjerite dva bloka na vrhu:

- **`CONFIG`** — `WS_URL` je prema zadanom `ws://127.0.0.1:8074`; promijenite ga ako ste sidecar
  premjestili sa zadanog porta. `RADE_SPS` (12000) i `RADE_SIDEBAND` (`USB`) trebaju odgovarati
  onome što javlja vaše sučelje.
- **`handshake_messages()`** — jedini `init` okvir koji šalje mora odgovarati inicijalizaciji
  RADE-a u `frontend/src/audio.js`. Ako se to rukovanje razišlo, svaki se slušatelj ne uspije
  spojiti i test odmah završava neuspjelim vezama.

### Pragovi koljena

Podesite ih u `CONFIG` po želji — namjerno su konzervativni:

| Prag | Zadano | Zaustavlja kada |
|---|---|---|
| `TEMP_KNEE_C` | `85.0` | Temperatura kućišta procesora dosegne tu granicu |
| `MIN_AVAIL_MB` | `800` | Dostupni RAM padne ispod te vrijednosti |
| `SWAP_GROWTH_MB` | `50` | Swap naraste iznad polazne vrijednosti uzete pri pokretanju |
| `FAIL_LIMIT` | `3` | Toliko se slušatelja ne uspije spojiti u jednom koraku |
| `MAX_LISTENERS` | `60` | Tvrdo zaustavljanje čak i ako koljeno nikad ne nastupi |

Oblik porasta određuju `STEP` (slušatelja dodanih po koraku, zadano 2), `SETTLE_S` (25 s
smirivanja prije uzorkovanja — to omogućuje nakupljanje topline) i `SAMPLE_S` (petosekundni
prozor usrednjavanja CPU-a). Potpuni prolaz do zadane granice od 60 slušatelja traje stoga
otprilike 15 minuta.

### Čitanje rezultata

Svaki korak ispisuje redak i dodaje zapis u `rade_loadtest.csv`:

| Stupac | Značenje |
|---|---|
| `listeners` | Sintetički slušatelji spojeni u ovom koraku |
| `connect_fails` | Slušatelji koji nisu uspjeli uspostaviti ili zadržati vezu |
| `pkg_c` | Temperatura kućišta procesora, medijan 5 uzoraka (otporan na skokove) |
| `cpu_pct` | Postotak CPU-a **cijelog sustava**, ne po slušatelju |
| `avail_mb` | Dostupni RAM |
| `swap_mb` | Zauzeti swap |
| `dec_rss_mb` | Zbrojeni RSS svih procesa dekodiranja |
| `dec_procs` | Broj procesa dekodiranja — očekujte **2 po slušatelju** (`radae_rxe.py` + `lpcnet_demo`) |

#### Izmjereni prolaz

Na gore spomenutom i5-12450H potpuni je prolaz završio ovako:

```
KNEE at n=32: temp 91.0°C ≥ 85.0
Last stable concurrency: 30 RADE listeners
```

**Toplina je bila ograničavajući čimbenik**, i to uvjerljivo. Na koljenu je još bilo 7004 MB
dostupnog RAM-a — 6,2 GB iznad granice `MIN_AVAIL_MB` — i nula neuspjelih veza u svakom koraku.

Dva stupca vrijedi pažljivo pročitati:

**`dec_rss_mb` precjenjuje stvarni trošak memorije.** Raste vrlo ravnomjerno, 295 MB po
slušatelju (292, 294, 294 … 295 kroz svih 16 koraka), ali *dostupni* RAM pada samo oko
**202 MB po slušatelju**. Dva procesa iza svakog slušatelja dijele stranice biblioteka, a RSS
te stranice broji jednom po procesu. Ekstrapolacijom nagiba `avail_mb`, memorijsko bi koljeno
nastupilo blizu **63 slušatelja** — iza tvrdog zaustavljanja na 60, pa se na ovom računalu nikad
ne može aktivirati. Memoriju dimenzionirajte prema `avail_mb`, a ne prema `dec_rss_mb`.

**`cpu_pct` je ravan — dok odjednom nije.** Do 24 slušatelja stoji na ~5,3 % cijelog računala, a
zatim postaje nadlinearan:

| Slušatelja | 24 | 26 | 28 | 30 | 32 |
|---|---|---|---|---|---|
| `cpu_pct` | 6,7 % | 18,4 % | 30,1 % | 49,6 % | 65,2 % |

To je deseterostruki porast CPU-a dok broj slušatelja raste za trećinu. Točka pregiba
reproducira se na istom mjestu kroz više prolaza, pa je tretirajte kao svojstvo računala, a ne
kao šum — trošak CPU-a po slušatelju iznosi otprilike 3,4 % jedne jezgre ispod pregiba i oko
20 % iznad njega. Nemojte ekstrapolirati vrijednost CPU-a po korisniku izmjerenu pri malom broju
slušatelja.

> **Test nema koljeno po CPU-u.** Četiri su granice temperatura, dostupni RAM, rast swapa i
> neuspjele veze — CPU se bilježi, ali nikad ne prekida prolaz. U gornjem je prolazu CPU dosegao
> 65 % i nastavio bi rasti da nije prva okinula temperatura. Ako vam je važna gornja granica
> CPU-a, sami pratite taj stupac ili dodajte prag.

> **Što ovo dokazuje, a što ne.** Svaki sintetički slušatelj šalje slučajan šum male amplitude,
> a ne stvaran RADE signal. To je dovoljno da cijeli lanac dekodiranja radi i troši resurse, pa
> su brojke o resursima smislene — ali test ništa ne govori o *kvaliteti* dekodiranja ni o
> neprekidnosti zvuka pod opterećenjem. To potvrdite sa stvarnim slušateljima na stvarnom signalu.

### Ako se jezgre zasite prije koljena

RADE čvrsto veže jednu dretvu po instanci, pa pojedinačne jezgre mogu doseći ~90 °C dok ukupni
CPU još izgleda neopterećeno. `rade_helper.py` lance raspoređuje po jezgrama kružno kako bi to
ublažio. Ako prolaz pokazuje rana toplinska koljena, proširite dodjelu jezgri po klijentu:

```bash
RADE_CORES_PER_CLIENT=3 ./rade.sh restart
```

Nije potrebno uređivati datoteke — riječ je o varijabli okruženja (vidi
[Varijable okruženja](#varijable-okruženja)); `RADE_PIN_CORES=0` posve isključuje vezanje.

---

## Ažuriranje RADE v1

Integracija s PhantomSDR-Plusom (`rade_helper.py`, zakrpe sučelja) samo je most — sva logika
dekodiranja RADE-a nalazi se u repozitoriju `radae`. Ažuriranja su stoga gotovo uvijek
jednostavan `git pull` uz ponovnu izgradnju, bez ikakvih izmjena u samom PhantomSDR-Plusu.

### Uobičajeno ažuriranje (novi kod, isti model)

```bash
# 1. Pull latest radae code
cd ~/radae
git pull

# 2. Rebuild lpcnet_demo (in case C code changed)
cd build
cmake ..
make -j$(nproc)

# 3. Restart the sidecar — no server restart needed
cd ~/PhantomSDR-Plus
./rade.sh restart
```

To je sve. Bez ponovne izgradnje sučelja, bez ponovnog pokretanja poslužitelja i bez uređivanja
datoteka.

### Samo nove težine modela

Ako izađe nova kontrolna točka (npr. `model20`) bez izmjena koda, usmjerite sidecar na nove
težine putem varijable okruženja — uređivanje datoteka nije potrebno:

```bash
# One-off: start with new model
RADE_MODEL=~/radae/model20/checkpoints/checkpoint_epoch_100.pth ./rade.sh start

# Or permanently — add to your shell profile (~/.bashrc):
export RADE_MODEL=~/radae/model20/checkpoints/checkpoint_epoch_100.pth
```

### Što koja vrsta promjene zahtijeva

| Što se promijenilo u radae | Potrebna radnja |
|---|---|
| Nove težine modela (nova `.pth` datoteka) | Postaviti varijablu `RADE_MODEL`, `./rade.sh restart` |
| Izmjena koda u `radae_rxe.py` | `git pull`, `./rade.sh restart` |
| Promijenjen C kod `lpcnet_demo` | `git pull`, ponovna izgradnja, `./rade.sh restart` |
| `radae_rxe.py` preimenovan ili premješten | Ažurirati putanju `RADAE_RX` u `rade_helper.py` (jedan redak) |
| Argument `--model_name` preimenovan | Ažurirati `radae_cmd` u `rade_helper.py` (jedan redak) |
| Nova izlazna frekvencija uzorkovanja (≠ 16000 Hz) | Ažurirati `SPS_OUT` u `rade_helper.py` i `createBuffer()` u `audio.js` |
| RADE v2 koristi drugu binarnu datoteku | Ažurirati `RADAE_RX` u `rade_helper.py` (jedan redak) |

### Provjera je li ažuriranje uspjelo

Nakon ponovnog pokretanja provjerite radi li novi kod:

```bash
# Check sidecar picked up new radae_rxe.py
./rade.sh status

# Tail log to see startup lines
tail -20 ~/PhantomSDR-Plus/rade.log
```

Zapisnik bi trebao prikazivati očekivanu putanju modela:
```
[RADE] model : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
```

### Kako pratiti novosti

Pretplatite se na stranicu izdanja repozitorija radae kako biste primali obavijesti o novim
modelima i ažuriranjima koda:

```
https://github.com/drowe67/radae/releases
```

Pratite FreeDV blog za najave novih RADE valnih oblika i modela:

```
https://freedv.org/blog/
```

---

*Razvijeno i testirano na PhantomSDR-Plusu (fork sv1btl/PhantomSDR-Plus) s RX-888 MK2 na
Ubuntuu 24.04. Poslužitelj u C++-u nije mijenjan.*

*RADE razvijaju David Rowe VK5DGR i FreeDV tim.*
*Vidi [freedv.org/radio-autoencoder](https://freedv.org/radio-autoencoder).*

---

### Potpuna deinstalacija i čista ponovna instalacija

Evo potpunog uklanjanja prije ponovnog pokretanja install_rade.sh:
1. Zaustavite sidecar
cd ~/PhantomSDR-Plus && ./rade.sh stop
2. Uklonite repozitorij radae i izgradnju
rm -rf ~/radae
3. Uklonite torch (instaliran u korisničkom direktoriju)
pip3 uninstall -y torch
rm -rf ~/.local/lib/python3.11/site-packages/torch*
4. Uklonite Python pakete iz apta (neobavezno — preskočite ako ih koristi nešto drugo)
sudo apt-get remove -y python3-numpy python3-scipy python3-matplotlib python3-websockets
sudo apt-get autoremove -y
5. Provjerite je li sve uklonjeno
python3 -c "import torch" 2>&1        # should say ModuleNotFoundError
ls ~/radae 2>&1                        # should say No such file or directory
6. Čista instalacija
chmod +x ~/PhantomSDR-Plus/install_rade.sh
~/PhantomSDR-Plus/install_rade.sh
