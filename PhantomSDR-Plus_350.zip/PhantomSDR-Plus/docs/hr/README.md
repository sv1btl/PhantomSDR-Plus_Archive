# PhantomSDR-Plus

**Unaprijeđeni WebSDR poslužitelj otvorenog koda s naprednim mogućnostima i futurističkim dizajnom**

PhantomSDR-Plus je fork projekta PhantomSDR koji pruža web-poslužitelj softverski definiranog radija (SDR) visokih performansi, sposoban posluživati stotine istodobnih korisnika. Nudi poboljšano korisničko sučelje, podršku za više dekodera, prikaz plana pojaseva i kompatibilnost s raznim SDR hardverskim platformama.

---

## 🌟 Ključne značajke

### Performanse i skalabilnost
- **Podrška za više korisnika**: stotine istodobnih korisnika, ovisno o hardveru
- **Visoka frekvencija uzorkovanja**: podrška za SDR uređaje do 70 MSPS (realno) / 35 MSPS (IQ)
- **Hardversko ubrzanje**: podrška za OpenCL i CUDA za obradu ubrzanu GPU-om
- **Optimizirano emitiranje**: FLAC i Opus audiokompresija niske latencije

### Korisničko sučelje
- **Futuristički dizajn**: moderno, prilagodljivo web-sučelje
- **Optimizirano za mobilne uređaje**: poboljšano mobilno sučelje za slušanje u pokretu
- **Prikaz plana pojaseva**: interaktivni slap (waterfall) s preklopima frekvencijskih pojaseva
- **Prilagodljive palete boja**: više shema boja za slap
- **Dvostruki S-metar**: izbor između analognog i digitalnog prikaza signala

### Obrada signala
- **Više načina demodulacije**: AM, FM, USB, LSB, CW i drugi
- **Sinkrona AM detekcija**: bolja kvaliteta AM prijema
- **Smanjenje šuma**: napredni NR, NC (poništavanje šuma) i NB (prigušivač impulsnog šuma)
- **AGC mogućnosti**: više načina automatske regulacije pojačanja
- **Automatski squelch**: automatski prag squelcha na temelju šuma

### Napredne značajke
- **Digitalni dekoderi**: FT8, FT4, FT2, CW, WSPR, HF FAX, SSTV, NAVTEX, FSK/RTTY i FreeDV RADE, svaki radi u vlastitoj pozadinskoj dretvi pa dekodiranje nikada ne prekida zvuk (vidi [Dekoderi](DECODERS.md))
- **Nadzorna ploča statistike**: statistika poslužitelja i korisnika u stvarnom vremenu
- **Sustav oznaka**: uvoz/izvoz frekvencijskih oznaka
- **Tipkovni prečaci**: učinkovita navigacija i upravljanje
- **Podrška za kotačić miša**: intuitivno ugađanje frekvencije
- **WebSDR imenik**: integracija s https://sdr-list.xyz

---

## 📋 Podržani hardver

PhantomSDR-Plus podržava širok raspon SDR prijamnika:

| Uređaj | Frekvencija uzorkovanja | Format | Sučelje |
|--------|--------------------------|--------|---------|
| **RX888 MK2** | Do 64 MHz | 16-bitni | Izvorno |
| **RTL-SDR** | Do 3.2 MHz | 8-bitni | rtl_sdr |
| **HackRF One** | Do 20 MHz | 8-bitni | hackrf_transfer |
| **Airspy HF+** | Do 912 kHz | 16-bitni | airspy_rx |
| **Airspy Discovery** | Promjenjivo | 16-bitni | SoapySDR |
| **SDRplay RSP1A** | Do 10 MHz | 16-bitni | SoapySDR |
| **Ostali uređaji** | Promjenjivo | Razno | SoapySDR/rx_tools |

---

## 🚀 Brzi početak

### Sistemski zahtjevi

**Minimalni:**
- Ubuntu 22.04 LTS (preporučeno) ili Fedora
- Dvojezgreni procesor
- 4 GB RAM-a
- 10 GB prostora na disku

**Preporučeni:**
- Ubuntu 24.04 LTS
- Procesor s 4+ jezgre (Ryzen 5 2600 ili Intel i5-6500T ili bolji)
- 8 GB RAM-a
- GPU s podrškom za OpenCL (nije obavezno, ali je vrlo preporučljivo)
- SSD pohrana

### Instalacija

```bash
# Kloniranje repozitorija
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus

# Postavljanje skripti kao izvršnih
chmod +x *.sh

# Pokretanje automatske instalacije
./install.sh
```

**Napomena:** nakon pokretanja `install.sh` ponovno pokrenite terminal prije nastavka.

Za detaljne upute o instalaciji pogledajte [INSTALLATION.md](INSTALLATION.md).

---

## 📊 Mjerenja performansi

| Hardver | Frekvencija uzorkovanja | Opterećenje CPU-a | Kapacitet korisnika |
|---------|--------------------------|-------------------|----------------------|
| Ryzen 5 2600 (sve jezgre) | 64 MHz (32 MHz IQ) | 38-40 % | 100+ korisnika |
| AMD RX 580 (GPU) | 64 MHz (32 MHz IQ) | 28-35 % | 100+ korisnika |
| Intel i5-6500T (s OpenCL) | 60 MHz (30 MHz IQ) | 10-12 % | 100+ korisnika |

*Napomena: dodatno opterećenje CPU-a po korisniku minimalno je (<1 % po korisniku) kada je omogućeno hardversko ubrzanje.*

---

## 🎯 Upotreba

### Osnovni rad

1. **Konfigurirajte svoj SDR**: uredite odgovarajuću konfiguracijsku datoteku (npr. `config-rtl.toml`)
2. **Ažurirajte podatke o lokaciji**: uredite `frontend/site-information.json`
3. **Pokrenite poslužitelj**: pokrenite odgovarajuću početnu skriptu:
   ```bash
   ./start-rtl.sh      # Za RTL-SDR
   ./start-rsp1a.sh    # Za SDRplay RSP1A
   ./start-airspyhf.sh # Za Airspy HF+
   ./start-rx888mk2.sh # Za RX888 MK2
   ```
   Svaka početna skripta je **samostalna**: zaustavlja svaku pokrenutu instancu, pokreće
   prijamnik + `spectrumserver`, **odvaja se u pozadinu** (preživljava zatvaranje terminala) i
   pokreće **watchdog** koji automatski ponovno pokreće lanac ako se on ugasi. Napredak se
   bilježi u `logwebsdr.txt` — pratite ga naredbom `tail -f logwebsdr.txt`. Ponovno pokretanje
   početne skripte znači čisto ponovno pokretanje, a `flock` zaključavanje osigurava da
   istodobno radi samo jedan prijamnik. Neobavezno: `SPECTRUM_CORES=0-3` za vezanje uz
   određene CPU jezgre, `RX_ARGS="…"` za zamjenu argumenata prijamnika bez uređivanja datoteke
   (`RX888_ARGS` za RX888).
4. **Pristupite sučelju**: otvorite preglednik na `http://localhost:PORT` (zadani port ovisi o konfiguraciji)

### Zaustavljanje poslužitelja

Jedna zajednička skripta za zaustavljanje radi za **svaki** prijamnik — prvo zaustavlja
watchdog (kako se ne bi automatski ponovno pokrenuo), zatim prijamnik i `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## 🔧 Konfiguracija

### Osnovne konfiguracijske datoteke

1. **`config-[uređaj].toml`** – konfiguracija poslužitelja i SDR-a
   - Postavke poslužitelja (port, dretve, HTML korijen)
   - Ulazne postavke (frekvencija uzorkovanja, veličina FFT-a, frekvencija)
   - Mogućnosti registracije u WebSDR imenik
   - Postavke audiokompresije
   - Nakon izmjene ponovno pokrenite poslužitelj.

2. **`frontend/site-information.json`** – javni podaci o lokaciji
   - Podaci o operateru (pozivni znak, e-pošta, lokacija)
   - Podaci o hardveru i anteni
   - Postavke regije i širine pojasa
   - Uključivanje/isključivanje razgovora (chat)
   - Nakon izmjene pokrenite recompile.sh u terminalu.

3. **`markers.json`** – frekvencijske oznake i plan pojaseva

4. **`frontend/src/bands-config.js`** – konfiguracija plana pojaseva
   Ta se datoteka nalazi u frontend/src/bands-config.js i definira pojaseve koje stvara SysOp. <br />
- Vidjet ćete nešto poput sljedećeg i slobodno to uredite po želji:
   ```
   - const bands = 
   .....
   - { ITU: 1,
            name: '40m', min: -30, max: 110, initFreq: '7120000', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
	},
	{ ITU: 2,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7300000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)', 
	    modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7050000 },
              { mode: MODES.LSB, startFreq: 7050000, endFreq: 7300000 }]
	},
	{ ITU: 3,
            name: '40m', min: -30, max: 110, initFreq: '', publishBand: '1', startFreq: 7000000, endFreq: 7200000,  stepi: 1000, color: 'rgba(50, 168, 72, 0.6)',
            modes: [
              { mode: MODES.CW, startFreq: 7000000, endFreq: 7040000 },
              { mode: MODES.LSB, startFreq: 7040000, endFreq: 7200000 }]
   .....
   etc
   ```
   **Pri čemu:** <br />
   - **ITU** je regija u kojoj se poslužitelj nalazi,
   - **min i max** su granice svjetline slapa za zadani pojas,
   - **initFreq** je početna frekvencija na koju se ugađa kada se odabere pojas,
   - **publishBand** određuje prikazuje li se pojas: 1 za amaterske pojaseve, 2 za radiodifuzijske,
   - **startFreq i endFreq** određuju granice pojasa,
   - **stepi** je zadani korak kotačića miša za pojas, a **modes** je preferirani zadani način rada za pojas.

- Nakon izmjena **pokrenite recompile.sh u terminalu** iz mape PhantomSDR-Plus.

Za primjere konfiguracije pogledajte priložene ogledne datoteke:
- `config-rtl.toml` – konfiguracija za RTL-SDR
- `config-rsp1a.toml` – konfiguracija za SDRplay RSP1A
- `config-airspyhf.toml` – konfiguracija za Airspy HF+
- `config-rx888mk2.toml` – konfiguracija za RX888 MK2

---

## 🎨 Prilagodba

### Promjena pozadinske slike

Zamijenite `frontend/src/assets/background.jpg` slikom po želji (zadržite isti naziv datoteke).

- Nakon izmjene pokrenite recompile.sh u terminalu.


### Odabir audiokodeka

Odaberite između FLAC-a i Opusa u svojoj `.toml` konfiguraciji:
```toml
[input]
audio_compression="opus"  # or "flac"
```
- Nakon izmjene ponovno pokrenite poslužitelj.


### Kalibracija S-metra
S-metar je već kalibriran, no ako ga želite ponovno podesiti, učinite sljedeće:
- Za **digitalni S-metar** podesite ga u .toml datoteci koju koristite. Pronađite 'smeter_offset=' u odjeljku [input], promijenite vrijednost i ponovno pokrenite poslužitelj.
- Za **analogni S-metar** uredite 'App__analog_smeter_.svelte' i 'App__v2_analog_smeter_.svelte', oba u frontend/src. Potražite 'const visualGain = ' i promijenite vrijednost tako da digitalni i analogni S-metar pokazuju isto. Zatim ponovno prevedite. Ponovno pokretanje poslužitelja nije potrebno.


### Varijante grafičkog sučelja

U direktoriju frontend dostupno je više varijanti sučelja. Za prebacivanje:
- Pokrenite recompile.sh u terminalu.

---

## 📚 Dokumentacija

- **[INSTALLATION.md](INSTALLATION.md)** – potpuni vodič za instalaciju za sistemske operatere
- **[ADMIN_PANEL_SETUP.md](ADMIN_PANEL_SETUP.md)** – vodič za instalaciju administratorske ploče
- **[USER_GUIDE.md](USER_GUIDE.md)** – vodič za krajnje korisnike o radu s WebSDR-om
- **[PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)** – struktura direktorija i organizacija koda

---

## 🌐 Mrežni popis WebSDR-ova

Registrirajte svoj WebSDR u službenom imeniku: https://sdr-list.xyz

Postavite `register_online=true` u svojoj `.toml` konfiguracijskoj datoteci za automatsku registraciju.

---

## 🐛 Rješavanje problema

### Česti problemi

**OpenCL ne radi**
- Provjerite jesu li upravljački programi ispravno instalirani
- Provjerite naredbom `clinfo`
- Za detaljno postavljanje OpenCL-a vidi INSTALLATION.md

**Problemi s latencijom zvuka**
- Pokušajte prebaciti između kodeka FLAC i Opus
- Prilagodite postavke međuspremnika u konfiguraciji
- Osigurajte dostatne CPU/GPU resurse

**Neuspjeli build**
- Provjerite jesu li instalirane sve ovisnosti
- Pokušajte očistiti direktorij za izgradnju: `rm -rf build && meson setup build`
- Provjerite ima li sukobljenih verzija biblioteka

---

## 🤝 Doprinosi

Doprinosi su dobrodošli! Ovo je nezavisni fork s dodatnim mogućnostima. Molimo:

1. Napravite fork repozitorija
2. Stvorite granu za novu značajku
3. Predajte (commit) svoje izmjene
4. Pošaljite granu na udaljeni repozitorij
5. Otvorite Pull Request

---

## 📄 Licenca

Ovaj projekt licenciran je pod GNU General Public License v3.0 – pojedinosti potražite u datoteci [LICENSE](../../LICENSE).

---

## 👥 Autori i zasluge

- **SV1BTL i SV2AMK** – razvoj i poboljšanja projekta PhantomSDR-Plus
- Temeljeno na izvornom projektu PhantomSDR

---

## 🔗 Poveznice

- **Demonstracija uživo**: http://phantomsdr.no-ip.org:8900/
- **WebSDR imenik**: https://sdr-list.xyz
- **GitHub repozitorij**: https://github.com/sv1btl/PhantomSDR-Plus

---

## 📞 Podrška

- **Problemi**: prijavite pogreške putem [GitHub Issues](https://github.com/sv1btl/PhantomSDR-Plus/issues)
- **E-pošta**: kontakt sv1btl@otenet.gr 

---

## ⚡ Savjeti za performanse

1. **Omogućite OpenCL/CUDA** za GPU ubrzanje – dramatično smanjuje opterećenje CPU-a
2. **Koristite SSD pohranu** za bolje U/I performanse
3. **Dodijelite dovoljno RAM-a** – preporučuje se najmanje 8 GB
4. **Optimizirajte veličinu FFT-a** – veći FFT = bolja razlučivost, ali veće opterećenje CPU-a
5. **Razmislite o namjenskom GPU-u** – AMD ili NVIDIA s podrškom za OpenCL

---

**73 de SV1BTL & SV2AMK**

*Za detaljne upute o postavljanju vidi INSTALLATION.md*
*Za vodič za rad namijenjen krajnjem korisniku vidi USER_GUIDE.md*
