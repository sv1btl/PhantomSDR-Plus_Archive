# Guide de l'utilisateur PhantomSDR-Plus

Bienvenue dans PhantomSDR-Plus ! Ce guide vous aidera à tirer le meilleur parti de votre écoute WebSDR.

---

## Table des matières

1. [Introduction](#introduction)
2. [Premiers pas](#premiers-pas)
3. [Vue d'ensemble de l'interface](#vue-densemble-de-linterface)
4. [Opérations de base](#opérations-de-base)
5. [Fonctions avancées](#fonctions-avancées)
6. [Modes de démodulation](#modes-de-démodulation)
7. [Décodeurs numériques](#décodeurs-numériques)
8. [Raccourcis clavier](#raccourcis-clavier)
9. [Favoris](#favoris)
10. [Utilisation sur mobile](#utilisation-sur-mobile)
11. [Conseils et bonnes pratiques](#conseils-et-bonnes-pratiques)
12. [Dépannage](#dépannage)
13. [Foire aux questions](#foire-aux-questions)

---

## Introduction

### Qu'est-ce que PhantomSDR-Plus ?

PhantomSDR-Plus est une radio logicielle (SDR) accessible par le web qui vous permet d'écouter des signaux radio via Internet. Aucun logiciel ni matériel particulier n'est requis de votre côté — il suffit d'un navigateur web moderne !

### Que pouvez-vous écouter ?

Selon la configuration du WebSDR, vous pouvez vous accorder sur :

- **Radioamateurs** : opérateurs radioamateurs du monde entier
- **Stations de radiodiffusion** : radio AM/FM, radiodiffusion en ondes courtes
- **Aviation** : contrôle aérien, communications aéronautiques
- **Maritime** : liaisons navire-côte, météo maritime
- **Satellites météo** : NOAA, METEOR-M
- **Modes numériques** : FT8, RTTY, PSK31 et davantage
- **Stations utilitaires** : signaux horaires, militaires, gouvernementaux

### Configuration requise

- **Navigateur** : Chrome/Edge (recommandé), Firefox, Safari
- **Connexion** : Internet haut débit (1 Mbit/s ou plus recommandé)
- **Audio** : haut-parleurs ou écouteurs fonctionnels
- **Facultatif** : souris à molette pour un accord plus facile

---

## Premiers pas

### 1. Accéder au WebSDR

Ouvrez votre navigateur et rendez-vous à l'adresse du WebSDR fournie par l'opérateur.

Exemple : `http://websdr.example.com:9002`

### 2. Chargement initial de la page

Au chargement de la page, vous verrez :
- un affichage en cascade coloré montrant l'activité radio
- un panneau de commande avec l'affichage de fréquence et des boutons
- un S-mètre indiquant la force du signal
- un indicateur du nombre d'utilisateurs

### 3. Commencer à écouter

1. **Cliquez sur un signal** dans l'affichage en cascade
2. **L'audio démarre automatiquement**
3. **Réglez le volume** avec la commande de volume de votre navigateur ou le curseur à l'écran
4. **Affinez la fréquence** en cliquant précisément sur le signal

---

## Vue d'ensemble de l'interface

### Composants principaux

```
┌─────────────────────────────────────────────────────────┐
│  Station Info Bar                                       │
├─────────────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────────────┐ │
│  │                                                   │ │
│  │           Waterfall Display                       │ │
│  │        (Spectrum Visualization)                   │ │
│  │                                                   │ │
│  └───────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────┤
│  Frequency Display: 7.100.000 MHz          [S-Meter]   │
├─────────────────────────────────────────────────────────┤
│  [AM] [FM] [USB] [LSB] [CW]    Volume: ▓▓▓▓▓▓▓░░░    │
├─────────────────────────────────────────────────────────┤
│  AGC: [Fast] NR: [Off] NB: [Off] SQL: [Auto]          │
├─────────────────────────────────────────────────────────┤
│  Users: 12    Statistics    Chat    Bookmarks          │
└─────────────────────────────────────────────────────────┘
```

### 1. Affichage en cascade

La cascade est une représentation visuelle des signaux radio :

- **Axe horizontal** : la fréquence
- **Axe vertical** : le temps (défile vers le bas)
- **Couleurs** : la force du signal
  - **Bleu foncé/noir** : aucun signal (plancher de bruit)
  - **Vert/jaune** : signaux faibles à moyens
  - **Orange/rouge** : signaux forts
  - **Blanc** : signaux très forts

### 2. Affichage de la fréquence

Indique la fréquence actuellement accordée dans divers formats :
- **MHz** : 7.100.000 MHz (bandes HF)
- **kHz** : 14200 kHz
- **Hz** : 145500000 Hz (VHF/UHF)

### 3. S-mètre (analogique ou numérique)

Affiche la force du signal :
- **S1-S9** : échelle standard de force de signal
- **+dB** : signaux au-dessus de S9 (p. ex. S9+20dB)
- **Analogique ou numérique** : selon la configuration

### 4. Boutons de mode

Sélectionnez le mode de démodulation :
- **AM** : modulation d'amplitude
- **FM** : modulation de fréquence
- **USB** : bande latérale supérieure
- **LSB** : bande latérale inférieure
- **CW** : code Morse (onde entretenue)
- **WBFM** : FM à large bande (radiodiffusion)

### 5. Panneau de commande

Commandes supplémentaires :
- **AGC** : contrôle automatique de gain
- **NR** : réduction de bruit
- **NC** : annulation de bruit
- **NB** : silencieux d'impulsions
- **SQL** : squelch
- **Zoom** : niveau de zoom de la cascade

### 6. Superposition du plan de bandes

Barres colorées indiquant les attributions de fréquences :
- des couleurs différentes pour différents services
- aide à identifier ce qui est autorisé sur chaque fréquence

---

## Opérations de base

### S'accorder sur une fréquence

#### Méthode 1 : cliquer sur la cascade

1. Cliquez directement sur un signal dans la cascade
2. Le récepteur s'accorde sur cette fréquence
3. L'audio démarre

#### Méthode 2 : saisir la fréquence

1. Cliquez sur l'affichage de la fréquence
2. Tapez la fréquence souhaitée
3. Appuyez sur Entrée

Exemples :
- `7100` → 7.100 MHz
- `14200.0` → 14.200 MHz
- `145.500` → 145.500 MHz

#### Méthode 3 : utiliser la molette de la souris

1. Placez le pointeur sur l'affichage de la fréquence
2. Molette vers le haut pour augmenter la fréquence
3. Molette vers le bas pour la diminuer

#### Méthode 4 : boutons de pas

1. Utilisez les boutons **▲** et **▼** à côté de la fréquence
2. Le pas varie selon le mode :
   - **AM/FM** : pas de 1 kHz
   - **BLU** : pas de 100 Hz
   - **CW** : pas de 10 Hz

### Choisir le mode de démodulation

Choisissez le mode adapté au signal :

**Pour les communications vocales :**
- **AM** : aviation, radiodiffusion AM, certains trafics amateurs
- **FM** : relais VHF/UHF, radiodiffusion FM
- **USB** : radioamateur HF (20 m, 17 m, 15 m, 12 m, 10 m)
- **LSB** : radioamateur HF (160 m, 80 m, 40 m, 30 m)

**Pour les données / le numérique :**
- **USB** : la plupart des modes numériques (FT8, PSK31, RTTY)
- **LSB** : certains modes numériques sur les bandes HF basses

**Pour le code Morse :**
- **CW** : signaux télégraphiques / Morse

### Régler le volume

- **Curseur à l'écran** : faites glisser le curseur de volume
- **Volume du navigateur** : utilisez les commandes multimédias du navigateur
- **Volume système** : ajustez le volume de votre ordinateur
- **Clavier** : utilisez les touches + et - (si prises en charge)

### Utiliser le S-mètre

Le S-mètre indique la force du signal :

- **S0-S3** : signal très faible, difficile à copier
- **S4-S6** : signal faible à moyen
- **S7-S9** : signal bon à fort
- **S9+** : signal extrêmement fort

**Astuce** : pour un meilleur son, accordez-vous sur des signaux affichant S7 ou plus.

---

## Fonctions avancées

### Contrôle automatique de gain (AGC)

L'AGC ajuste automatiquement les niveaux audio :

- **Off** : aucun réglage automatique du gain
- **Slow** : variations de niveau progressives (idéal pour la BLU)
- **Medium** : réponse équilibrée
- **Fast** : ajustement rapide (idéal pour l'AM)

**Recommandation** : commencez par « Fast » pour l'AM, « Slow » pour la BLU.

### Réduction de bruit (NR)

Réduit le bruit de fond :

- **Off** : aucune réduction de bruit
- **Low** : réduction légère
- **Medium** : réduction modérée
- **High** : réduction agressive (peut altérer la qualité audio)

**À utiliser quand** : vous entendez du souffle ou du bruit blanc derrière le signal.

### Silencieux d'impulsions (NB)

Supprime le bruit impulsionnel (clics, craquements) :

- **Off** : aucune suppression
- **On** : suppression active

**À utiliser quand** : vous entendez des clics provenant de lignes électriques, de moteurs ou de perturbations.

### Annulation de bruit (NC)

Annule des signaux perturbateurs spécifiques :

- **Off** : aucune annulation
- **On** : annulation active

**À utiliser quand** : vous entendez une tonalité continue ou une interférence sur la fréquence.

### Squelch automatique (SQL)

Coupe l'audio en l'absence de signal :

- **Off** : audio permanent (souffle audible)
- **Auto** : seuil défini automatiquement
- **Manual** : réglage manuel du seuil

**À utiliser quand** : vous surveillez une fréquence en attendant du trafic.

### Fonction de zoom

Agrandit l'affichage en cascade :

- **1x** : vue normale (large couverture)
- **2x** : grossissement ×2
- **4x** : grossissement ×4
- **8x** : grossissement ×8

**À utiliser quand** : vous devez mieux voir les signaux ou vous accorder finement.

---

## Modes de démodulation

### AM (modulation d'amplitude)

**Utilisé pour :**
- les communications aéronautiques
- la radiodiffusion AM
- certains trafics radioamateurs
- les communications maritimes

**Caractéristiques :**
- large bande passante (typiquement 10 kHz)
- sensible au bruit
- facile à accorder (il suffit de cliquer sur le signal)

**Bonnes pratiques :**
- utilisez l'AGC rapide (Fast)
- activez le silencieux d'impulsions si vous entendez des clics
- accordez-vous sur le maximum du signal dans la cascade

### FM (modulation de fréquence)

**Utilisé pour :**
- les relais radioamateurs VHF/UHF
- les services publics (police, pompiers, secours)
- la radio professionnelle bidirectionnelle
- certaines communications par satellite

**Caractéristiques :**
- bande passante étroite (typiquement 12,5 ou 25 kHz)
- excellente immunité au bruit
- « effet de capture » (le signal le plus fort l'emporte)

**Bonnes pratiques :**
- accordez-vous précisément au centre du signal
- utilisez le squelch pour couper l'audio au repos
- désactivez la réduction de bruit (inutile)

### USB (bande latérale supérieure)

**Utilisé pour :**
- le radioamateurisme HF (au-dessus de 10 MHz)
- la plupart des modes numériques HF
- les communications maritimes (au-dessus de 8 MHz)

**Caractéristiques :**
- bande passante étroite (typiquement 2.4 kHz)
- utilisation efficace du spectre
- exige un accord précis

**Bonnes pratiques :**
- utilisez l'AGC lente (Slow)
- accordez-vous sur le bord inférieur du signal dans la cascade
- activez la réduction de bruit si nécessaire

### LSB (bande latérale inférieure)

**Utilisé pour :**
- le radioamateurisme HF (en dessous de 10 MHz)
- certains modes numériques HF
- les communications maritimes (en dessous de 8 MHz)

**Caractéristiques :**
- identique à l'USB mais en image miroir
- convention : LSB sur les bandes HF basses

**Bonnes pratiques :**
- utilisez l'AGC lente (Slow)
- accordez-vous sur le bord supérieur du signal dans la cascade
- activez la réduction de bruit si nécessaire

### CW (onde entretenue / code Morse)

**Utilisé pour :**
- la télégraphie radioamateur
- les balises de radionavigation
- les stations de signaux horaires

**Caractéristiques :**
- bande passante très étroite (100-500 Hz)
- grande efficacité
- nécessite d'apprendre le code Morse pour être compris

**Bonnes pratiques :**
- utilisez un filtre étroit (400-500 Hz)
- accordez-vous précisément sur le centre de la tonalité
- activez le filtre audio pour une meilleure tonalité

### WBFM (FM à large bande)

**Utilisé pour :**
- la radiodiffusion FM (88-108 MHz)
- certaines liaisons descendantes satellite

**Caractéristiques :**
- bande passante très large (200 kHz)
- excellente qualité audio
- haute fidélité

**Bonnes pratiques :**
- accordez-vous exactement sur la fréquence centrale
- aucun squelch nécessaire pour la radiodiffusion
- profitez d'un son de haute qualité !

---

## Décodeurs numériques

PhantomSDR-Plus intègre des décodeurs pour les modes numériques.
Pour un guide complet, voir [Décodeurs](DECODERS.md).

Les décodeurs SSTV, FAX HF, NAVTEX, FSK/RTTY et CW s'exécutent chacun sur leur propre thread d'arrière-plan : activer ou désactiver un décodeur n'interrompt jamais l'audio, et la cascade reste fluide pendant le décodage. Ils reçoivent l'audio prélevé avant l'AGC, la réduction de bruit et la coupure du son — vous pouvez couper le son du récepteur, le décodage se poursuit sans être affecté.

### Décodeur FT8, FT4

**Qu'est-ce que FT8, FT4 ?**
- mode numérique radioamateur très répandu
- communication à signaux faibles
- transmissions de 15 secondes pour FT8, de 7,5 secondes pour FT4

**Comment l'utiliser :**
1. Accordez-vous sur les fréquences FT8 ou FT4
2. Sélectionnez le mode USB
3. Activez le décodeur FT8 depuis le menu
4. Observez l'apparition des messages décodés

**Fréquences FT8 courantes (USB) :**
- 160 mètres : 1.840 MHz
- 80 mètres : 3.573 MHz
- 60 mètres : 5.357 MHz
- 40 mètres : 7.074 MHz
- 30 mètres : 10.136 MHz
- 20 mètres : 14.074 MHz
- 17 mètres : 18.100 MHz
- 15 mètres : 21.074 MHz
- 12 mètres : 24.915 MHz
- 10 mètres : 28.074 MHz
- 6 mètres : 50.313 MHz (50.323 MHz pour le DX)

**Fréquences FT4 courantes (USB) :**

- 80 m : 3.575 MHz
- 40 m : 7.0475 MHz
- 30 m : 10.140 MHz
- 20 m : 14.080 MHz
- 17 m : 18.104 MHz
- 15 m : 21.140 MHz
- 12 m : 24.919 MHz
- 10 m : 28.180 MHz
- 6 m : 50.318 MHz

---

### Décodeur CW
Appuyez simplement sur le bouton CW et le texte décodé apparaîtra. Appuyez de nouveau sur le bouton CW pour effacer la fenêtre et redémarrer le décodeur.

---

### WSPR

WSPR (Weak Signal Propagation Reporter, prononcé « whisper ») est un mode balise à signaux ultra-faibles qui cartographie les chemins de propagation HF dans le monde entier. Chaque transmission dure environ 110 secondes et tient dans un créneau de 200 Hz de large. Le décodeur attend un créneau complet de 2 minutes aligné sur l'UTC avant de décoder. Activez le décodeur et sélectionnez **WSPR** dans la liste déroulante.

---

### FAX HF / WEFAX

Le radiofax HF (également appelé WEFAX) est utilisé par les garde-côtes et les services météorologiques du monde entier pour diffuser des cartes météo, des cartes d'état de la mer et des analyses de surface en ondes courtes. Le décodeur reconstitue l'image ligne par ligne au fur et à mesure de sa réception.

---

### NAVTEX

NAVTEX est le système international de diffusion maritime des informations de sécurité côtière — avertissements de navigation, prévisions météorologiques et avis de recherche et de sauvetage.

---

### FSK / RTTY

Un décodeur FSK (Frequency-Shift Keying) / RTTY polyvalent prenant en charge trois variantes de fonctionnement : FSK maritime (SITOR), RTTY météo et RTTY amateur.

---

### SSTV

La télévision à balayage lent transmet des images fixes sur un canal BLU ordinaire, une ligne à la fois. Activez le décodeur, sélectionnez **SSTV** et accordez-vous sur une fréquence SSTV — 14.230 MHz est la principale fréquence d'appel internationale. Laissez **Mode** sur **Auto** : le décodeur lit l'en-tête VIS de la transmission et, si vous vous êtes accordé après l'en-tête, identifie le mode d'après la synchronisation. Les modes Martin, Scottie et Robot sont pris en charge, et l'image se construit ligne par ligne à mesure qu'elle arrive.

---

## Raccourcis clavier

Raccourcis clavier pour une utilisation plus rapide.

---

### Commande de fréquence
- **Flèche haut/bas** : changer de fréquence (grands pas)
- **Page haut/bas** : changer de fréquence (petits pas)
- **Molette de la souris** : accord fin de la fréquence
- **Touches numériques** : saisie directe de la fréquence

---

## Favoris

Enregistrez vos fréquences préférées pour y accéder rapidement. Vous pouvez aussi exporter la liste des favoris et la sauvegarder localement, puis l'importer dans n'importe quel autre PhantomSDR. 

Lorsque favoris et marqueurs se chevauchent :

🔵 Les favoris bleus apparaissent au-dessus <br />
🟡 Les marqueurs jaunes apparaissent en dessous <br />
✅ Les clics sur les favoris sont prioritaires <br />


### Ajouter un favori

1. Accordez-vous sur la fréquence souhaitée
2. Cliquez sur le bouton « Bookmarks »
3. Cliquez sur « Add Bookmark »
4. Saisissez une description
5. Cliquez sur « Save »

┌──────────────┬────────────────┬────────┐
│ Bookmark name│Label (optional)│ [Add]  │
└──────────────┴────────────────┴────────┘

### Comment l'utiliser :

**Ajouter un favori :**
- Nom : « Local News Station »
- Étiquette : « NEWS »
- Cliquez sur Add

**Affichage dans la cascade :**
- zoomez jusqu'à ce que les marqueurs apparaissent
- vous verrez un cadre bleu marine avec « NEWS » en jaune gras

**Cliquer sur un favori :**
- s'accorde sur la fréquence
- règle le mode de démodulation
- fonctionne exactement comme un clic sur un marqueur

### Gérer les favoris
- **Modifier** : cliquez sur l'icône crayon à côté du favori
- **Supprimer** : cliquez sur l'icône corbeille à côté du favori
- **Exporter** : téléchargez les favoris sous forme de fichier JSON
- **Importer** : envoyez des favoris depuis un fichier JSON

### Partager des favoris

1. Cliquez sur « Export Bookmarks »
2. Partagez le fichier JSON avec d'autres personnes
3. Les destinataires cliquent sur « Import Bookmarks »
4. Ils sélectionnent votre fichier
---

## Utilisation sur mobile

PhantomSDR-Plus fonctionne très bien sur les appareils mobiles !

### Fonctions propres au mobile

- **Commandes tactiles** : grands boutons et curseurs
- **Balayage pour s'accorder** : balayez vers la gauche/droite sur la cascade
- **Pincement pour zoomer** : pincez la cascade pour zoomer/dézoomer
- **Mode paysage** : tournez l'appareil pour une meilleure vue

### Conseils pour mobile

1. **Utilisez le Wi-Fi** : la diffusion audio consomme des données
2. **Orientation paysage** : meilleure vue de la cascade
3. **Écouteurs** : meilleure qualité audio
4. **Enregistrez vos favoris** : plus facile de revenir sur des stations
5. **Fermez les autres applications** : garantit des performances fluides

### Navigateurs mobiles recommandés

- **Android** : Chrome ou Samsung Internet
- **iOS** : Mozilla
- **Les deux** : veillez à ce que le navigateur soit à jour

---

## Conseils et bonnes pratiques

### Pour une réception optimale

1. **Choisissez des signaux forts** : cherchez l'orange/rouge dans la cascade
2. **Accordez-vous précisément** : cliquez au centre du signal
3. **Sélectionnez le bon mode** : adaptez-le au type de signal
4. **Réglez l'AGC** : rapide pour l'AM, lente pour la BLU
5. **Utilisez NR/NB** : utile en conditions bruyantes

### Trouver de l'activité

1. **Observez la cascade** : les couleurs indiquent la force des signaux
2. **Écoutez sur les fréquences populaires** :
   - 40 m : 7.100-7.300 MHz (LSB)
   - 20 m : 14.200-14.350 MHz (USB)
   - 2 m : 145.200-145.600 MHz (FM)
3. **Consultez la superposition du plan de bandes** : elle montre les attributions de fréquences
4. **Utilisez les favoris** : accès rapide aux fréquences actives

### Comprendre les conditions de propagation

**HF de jour (hautes fréquences) :**
- les bandes hautes fonctionnent mieux (20 m, 15 m, 10 m)
- communications à longue distance (DX) possibles
- stations de radiodiffusion audibles

**HF de nuit :**
- les bandes basses fonctionnent mieux (80 m, 40 m)
- schémas de propagation différents
- stations différentes audibles

**VHF/UHF :**
- principalement à vue directe
- communications locales
- conditions plus stables

### Savoir-vivre

1. **Ne monopolisez pas le récepteur** : d'autres veulent aussi écouter
2. **Utilisez le chat avec respect** : soyez courtois envers les autres utilisateurs
3. **Signalez les problèmes** : aidez l'opérateur à entretenir la station
4. **Ne demandez pas d'assistance technique** : c'est une plateforme d'écoute. Envoyez un message au SysOp pour obtenir de l'aide.

---

## Dépannage

### Aucun son

**Causes possibles :**
1. Navigateur en sourdine → vérifiez les commandes de volume du navigateur
2. Système en sourdine → vérifiez le volume de l'ordinateur
3. Signal faible → accordez-vous sur un signal plus fort (S7+)
4. Mauvais mode → essayez d'autres modes de démodulation

**Solutions :**
1. Cliquez sur un signal fort (orange/rouge dans la cascade)
2. Vérifiez que le navigateur n'est pas en sourdine (icône de coupure dans l'onglet)
3. Essayez une autre fréquence
4. Rechargez la page (F5)

### Son déformé

**Causes possibles :**
1. Signal saturé → signal trop fort
2. Mauvais mode → signal AM écouté en BLU, etc.
3. Interférences → signaux adjacents qui débordent

**Solutions :**
1. Baissez le volume
2. Essayez un autre mode de démodulation
3. Utilisez un filtre plus étroit
4. Éloignez-vous des signaux perturbateurs

### La cascade ne se met pas à jour

**Causes possibles :**
1. Problème réseau → connexion lente ou interrompue
2. Performances du navigateur → trop d'onglets ouverts
3. Serveur surchargé → trop d'utilisateurs

**Solutions :**
1. Vérifiez votre connexion Internet
2. Fermez les onglets inutiles
3. Rechargez la page (F5)
4. Réessayez plus tard, quand il y a moins d'utilisateurs

### Impossible de s'accorder sur une fréquence

**Causes possibles :**
1. Fréquence hors plage → le SDR ne couvre pas cette fréquence
2. Format de saisie incorrect → utilisez le bon format (p. ex. « 14200 » et non « 14.200.000 »)

**Solutions :**
1. Vérifiez la couverture en fréquence du SDR (indiquée sur la page)
2. Utilisez les exemples de format de fréquence fournis
3. Cliquez plutôt dans la cascade

### Son haché ou saccadé

**Causes possibles :**
1. connexion Internet lente
2. charge élevée du serveur
3. problèmes de performances du navigateur

**Solutions :**
1. Fermez les autres applications qui consomment de la bande passante
2. Réessayez en dehors des heures de pointe
3. Fermez les onglets inutiles
4. Utilisez une connexion filaire plutôt que le Wi-Fi

---

## Foire aux questions

### Questions générales

**Q : Ai-je besoin d'un équipement spécial pour utiliser un WebSDR ?**
R : Non ! Juste un ordinateur ou un appareil mobile connecté à Internet.

**Q : L'utilisation du WebSDR est-elle gratuite ?**
R : Oui, la plupart des WebSDR sont gratuits. Ils sont exploités par des bénévoles.

**Q : Puis-je émettre avec un WebSDR ?**
R : Non, le WebSDR est uniquement en réception. Vous ne pouvez pas émettre.

**Q : Quelles fréquences puis-je écouter ?**
R : Cela dépend de la configuration du WebSDR. Consultez les informations de la station.

**Q : Puis-je enregistrer l'audio ?**
R : Certains navigateurs permettent l'enregistrement. Vérifiez les fonctions de votre navigateur.

### Questions techniques

**Q : Quel taux d'échantillonnage le SDR utilise-t-il ?**
R : Cela varie selon la station. Consultez la page d'informations de la station.

**Q : Quelle est la latence ?**
R : Généralement 2 à 5 secondes entre le signal radio et vos haut-parleurs.

**Q : Puis-je ouvrir plusieurs instances ?**
R : En général oui, mais cela peut solliciter le serveur. Soyez prévenant.

**Q : Cela fonctionne-t-il hors ligne ?**
R : Non, le WebSDR nécessite une connexion Internet.

**Q : Quels navigateurs sont pris en charge ?**
R : Chrome, Firefox, Edge, Safari (toutes versions récentes)

### Questions d'utilisation

**Q : Combien de personnes peuvent écouter en même temps ?**
R : Cela dépend de la capacité du serveur. Souvent 50 à 200 utilisateurs ou plus.

**Q : Puis-je voir ce que les autres écoutent ?**
R : Si la fonction est activée, oui. Cherchez les indicateurs « autres utilisateurs ».

**Q : Puis-je discuter avec les autres auditeurs ?**
R : Si l'opérateur a activé le chat. Cherchez la fenêtre de discussion.

**Q : Pourquoi certaines fréquences n'affichent-elles rien ?**
R : Aucun signal sur cette fréquence pour le moment. Essayez-en d'autres !

**Q : Que sont les bandes colorées sur la cascade ?**
R : La superposition du plan de bandes, qui montre les attributions de fréquences.

---

## Ressources

### Pour en savoir plus sur la radio

- **Plans de bandes** : recherchez « amateur radio band plan » + votre région
- **Propagation** : renseignez-vous sur la propagation des ondes HF
- **Modes numériques** : documentez-vous sur FT8, PSK31, RTTY
- **Radioamateurisme** : pensez à passer une licence radioamateur !

### Trouver d'autres WebSDR

- **Annuaire WebSDR** : http://sdr-list.xyz
- **WebSDR.org** : http://websdr.org
- **KiwiSDR** : http://kiwisdr.com/public/

### Obtenir de l'aide

1. **Opérateur de la station** : coordonnées indiquées sur la page
2. **Chat des utilisateurs** : demandez aux autres auditeurs (si disponible)
3. **Forums en ligne** : cherchez des communautés WebSDR
4. **Documentation** : reportez-vous à ce guide !

---

## Annexe : fréquences courantes

### Bandes radioamateurs HF

| Bande | Plage de fréquences | Mode | Activité |
|-------|---------------------|------|----------|
| 160 m | 1.800-2.000 MHz | LSB | Nuit/local |
| 80 m | 3.500-4.000 MHz | LSB | Nuit/régional |
| 40 m | 7.000-7.300 MHz | LSB | Jour/nuit/DX |
| 30 m | 10.100-10.150 MHz | USB | Données/CW uniquement |
| 20 m | 14.000-14.350 MHz | USB | Jour/DX |
| 17 m | 18.068-18.168 MHz | USB | Jour/DX |
| 15 m | 21.000-21.450 MHz | USB | Jour/DX |
| 12 m | 24.890-24.990 MHz | USB | Jour/DX |
| 10 m | 28.000-29.700 MHz | USB | Sporadique/DX |

### Bandes radioamateurs VHF/UHF

| Bande | Plage de fréquences | Mode | Activité |
|-------|---------------------|------|----------|
| 6 m | 50.000-54.000 MHz | USB/FM | Sporadique |
| 2 m | 144.000-148.000 MHz | FM | Très active |
| 70 cm | 420.000-450.000 MHz | FM | Active |

### Bandes de radiodiffusion

| Service | Plage de fréquences | Mode |
|---------|---------------------|------|
| Radio AM | 530-1710 kHz | AM |
| Ondes courtes | 2.3-26.1 MHz | AM |
| Radio FM | 88-108 MHz | WBFM |

### Aviation

| Service | Plage de fréquences | Mode |
|---------|---------------------|------|
| Contrôle du trafic aérien | 118-137 MHz | AM |
| ACARS (données) | 130-136 MHz | Données |

### Maritime

| Service | Plage de fréquences | Mode |
|---------|---------------------|------|
| VHF marine | 156-162 MHz | FM |
| HF marine | 2-22 MHz | USB |

---

## Glossaire

**AGC** : contrôle automatique de gain — ajuste automatiquement les niveaux audio

**AM** : modulation d'amplitude — mode phonie utilisé en aviation et en radiodiffusion

**Bande passante** : la plage de fréquences occupée par un signal

**CW** : onde entretenue — signaux en code Morse

**DX** : communication à longue distance

**FFT** : transformée de Fourier rapide — convertit le domaine temporel en domaine fréquentiel

**FM** : modulation de fréquence — mode phonie pour la VHF/UHF

**HF** : hautes fréquences (3-30 MHz) — bandes à longue portée

**kHz** : kilohertz (1 000 Hz)

**LSB** : bande latérale inférieure — mode phonie pour les bandes HF basses

**MHz** : mégahertz (1 000 000 Hz)

**NB** : silencieux d'impulsions — supprime le bruit impulsionnel

**NR** : réduction de bruit — atténue le bruit de fond

**PSK** : modulation par déplacement de phase — mode numérique

**RTTY** : télétype radio — mode texte numérique

**S-mètre** : indicateur de force du signal

**SDR** : radio logicielle

**SQL** : squelch — coupe l'audio en l'absence de signal

**BLU (SSB)** : bande latérale unique (USB ou LSB)

**USB** : bande latérale supérieure — mode phonie pour les bandes HF hautes

**VHF** : très hautes fréquences (30-300 MHz) — propagation à vue directe

**UHF** : ultra hautes fréquences (300-3000 MHz) — propagation à vue directe

**Cascade** : affichage visuel du spectre radio au fil du temps

---

**Bonne exploration du spectre radio avec PhantomSDR-Plus !**

**73 (meilleures salutations) de SV1BTL & SV2AMK**

Pour les instructions d'installation, voir [INSTALLATION.md](INSTALLATION.md).
Pour les détails techniques, voir [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md).
