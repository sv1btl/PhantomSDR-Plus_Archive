# PhantomSDR-Plus — Manuel d'utilisation des décodeurs

Ce guide couvre tous les décodeurs intégrés à PhantomSDR-Plus. Tous les décodeurs partagent la même procédure d'activation, décrite ci-dessous, suivie des instructions de configuration propres à chacun.

---

## Table des matières

1. [Comment démarrer un décodeur](#1-comment-démarrer-un-décodeur)
2. [FT8](#2-ft8)
3. [FT4-FT2](#3-ft4-ft2)
4. [CW — code Morse](#4-cw--code-morse)
5. [WSPR](#5-wspr)
6. [FAX HF / WEFAX](#6-fax-hf--wefax)
7. [NAVTEX](#7-navtex)
8. [FSK / RTTY](#8-fsk--rtty)
9. [SSTV](#9-sstv)
10. [Conseils généraux](#10-conseils-généraux)

---

## 1. Comment démarrer un décodeur

Tous les décodeurs se trouvent dans la section **Decoder Options**, située sous les commandes du spectrogramme audio, sur le panneau principal.

**Étapes :**

1. Cliquez sur le bouton **Decoder: OFF** pour le faire passer à **Decoder: ON** (il devient bleu lorsqu'il est actif).
2. Ouvrez le menu déroulant qui apparaît à droite du bouton et sélectionnez le décodeur souhaité.
3. Le panneau du décodeur choisi apparaît sous les commandes — suivez les instructions propres à ce décodeur dans la section correspondante de ce guide.
4. Pour arrêter le décodage, sélectionnez **— Select decoder —** dans le menu déroulant, ou cliquez sur le bouton **Decoder: ON** pour le remettre sur OFF.

> Un seul décodeur peut être actif à la fois. Passer à un autre décodeur arrête automatiquement le précédent.

**Le décodage s'exécute en arrière-plan.** SSTV, FAX HF, NAVTEX, FSK/RTTY et CW s'exécutent chacun dans un Web Worker distinct : le travail de décodage n'entre jamais en concurrence avec la lecture audio ou la cascade. Démarrer ou arrêter un décodeur n'interrompt pas l'audio, et l'interface reste réactive pendant la réception d'une image ou d'une page. Tous les décodeurs reçoivent l'audio brut prélevé *avant* l'AGC, la réduction de bruit et la coupure du son — couper le son du récepteur, ou modifier ces réglages selon votre confort d'écoute, n'affecte donc pas le décodage.

---

## 2. FT8

**De quoi s'agit-il :** FT8 est un mode numérique à signaux faibles très répandu chez les radioamateurs du monde entier. Les transmissions durent exactement 15 secondes et le protocole peut copier des signaux jusqu'à 20-25 dB sous le plancher de bruit. C'est le mode le plus utilisé pour les contacts à longue distance (DX).

### Fréquences recommandées (USB)

| Bande | Fréquence |
|-------|-----------|
| 160 m | 1.840 MHz |
| 80 m  | 3.573 MHz |
| 40 m  | 7.074 MHz |
| 30 m  | 10.136 MHz |
| 20 m  | 14.074 MHz |
| 17 m  | 18.100 MHz |
| 15 m  | 21.074 MHz |
| 12 m  | 24.915 MHz |
| 10 m  | 28.074 MHz |

### Configuration

1. Accordez-vous sur une fréquence FT8 listée ci-dessus et réglez le mode sur **USB**.
2. Activez le décodeur et sélectionnez **FT8** dans le menu déroulant.
3. Le panneau **FT8 Messages** apparaît automatiquement en dessous.

### Lecture des résultats

La liste des messages affiche les transmissions décodées à mesure qu'elles arrivent. Chaque cycle de 15 secondes produit un nouveau lot de messages. Le champ **Farthest** (en haut à droite du panneau) indique la plus grande distance décodée durant la session en cours, en kilomètres.

Format de message typique : `CQ DX AA1BB FN31` — un appel CQ de l'indicatif AA1BB situé dans le carré locator FN31.

> **Astuce :** FT8 est étroitement synchronisé dans le temps. Votre navigateur utilise l'horloge de votre ordinateur ; si celle-ci dérive de plus de quelques secondes, le décodage échouera. Gardez l'heure système synchronisée sur NTP.

---

## 3. FT4-FT2

**De quoi s'agit-il :** FT4 est une variante plus rapide de FT8, conçue pour l'exploitation en concours. Chaque cycle de transmission dure 7,5 secondes (la moitié de FT8), ce qui le rend deux fois plus rapide mais exige un signal légèrement plus fort.
FT2 est une variante encore plus rapide de FT8. C'est un mode ultrarapide à 77 bits avec des périodes T/R de 3,75 secondes (= la moitié de FT4) — encore expérimental.

### Fréquences recommandées (USB)

| Bande | Fréquence FT4|
|-------|-----------|
| 80 m  | 3.575 MHz |
| 40 m  | 7.047 MHz |
| 30 m  | 10.140 MHz |
| 20 m  | 14.080 MHz |
| 15 m  | 21.140 MHz |
| 10 m  | 28.180 MHz |

| Bande | Fréquence FT2|
|-------|-----------|
|160 m | 1.843 à 1.846 |
|80 m   | 3.578 à 3.581 |
|60 m   | 5.360 (vérifiez la réglementation régionale locale) |
|40 m   | 7.052 à 7.062 |
|30 m   | 10.144 |
|20 m   | 14.084 |
|17 m   | 18.108 |
|15 m   | 21.144 |
|12 m   | 24.923 |
|10 m   | 28.184 |

### Configuration

1. Accordez-vous sur une fréquence FT4 et réglez le mode sur **USB**.
2. Activez le décodeur et sélectionnez **FT4** ou **FT2** dans le menu déroulant.
3. Le panneau **FT4 Messages** ou **FT2 Messages** apparaît en dessous, avec la même disposition que le panneau FT8.

> **Remarque :** FT4 et FT8 utilisent des formats spectraux différents et ne sont pas interchangeables. Assurez-vous d'être sur une fréquence FT4 lorsque vous utilisez ce décodeur.

---

## 4. CW — code Morse

**De quoi s'agit-il :** le décodeur CW écoute les signaux en code Morse (onde entretenue) et les convertit en texte en temps réel. Il suit automatiquement la fréquence du signal et s'adapte à la vitesse de manipulation de l'opérateur.

### Fréquences recommandées

La CW est active sur toutes les bandes amateurs, généralement dans la partie basse de chaque bande. Endroits courants :

| Bande | Segment |
|-------|---------|
| 40 m  | 7.000–7.040 MHz |
| 20 m  | 14.000–14.070 MHz |
| 15 m  | 21.000–21.080 MHz |

### Configuration

1. Accordez-vous sur un signal CW en utilisant le mode de démodulation **CW** ou **CW-L** selon le cas.
2. Activez le décodeur et sélectionnez **CW** dans le menu déroulant.
3. Le panneau **CW Decoder** apparaît en dessous.

### Lecture des résultats

- L'en-tête du panneau indique la fréquence détectée du signal en Hz (p. ex. `≈ 700 Hz`) et la vitesse de manipulation estimée en mots par minute (p. ex. `· 22 WPM`).
- Si aucun signal n'est détecté, l'en-tête affiche **scanning…**
- Le texte décodé défile en caractères ambrés à chasse fixe. Le curseur clignotant (▋) marque l'endroit où le texte s'écrit actuellement.
- Cliquez sur **Clear** pour effacer la mémoire tampon de sortie.

> **Astuces :**
> - Centrez votre bande passante sur la tonalité CW. Le décodeur fonctionne au mieux lorsque le signal CW se situe entre environ 400 et 900 Hz dans le spectre audio.
> - Une manipulation très rapide ou très lente, ainsi qu'un Morse fortement manipulé à la main (irrégulier), peuvent réduire la précision.
> - Le décodeur donne ses meilleurs résultats sur un signal unique et propre. Un QRM fort provenant de signaux voisins sur la même bande peut le perturber.

---

## 5. WSPR

**De quoi s'agit-il :** WSPR (Weak Signal Propagation Reporter, prononcé « whisper ») est un mode balise à signaux ultra-faibles qui cartographie les chemins de propagation HF dans le monde entier. Chaque transmission dure environ 110 secondes et tient dans un créneau de 200 Hz de large. Le décodeur attend un créneau complet de 2 minutes aligné sur l'UTC avant de décoder.

### Fréquences recommandées (USB, affichée)

| Bande | Fréquence affichée |
|-------|---------------|
| 160 m | 1.836.600 MHz |
| 80 m  | 3.568.600 MHz |
| 40 m  | 7.038.600 MHz |
| 30 m  | 10.138.700 MHz |
| 20 m  | 14.095.600 MHz |
| 17 m  | 18.104.600 MHz |
| 15 m  | 21.094.600 MHz |

### Configuration

1. Accordez-vous sur une fréquence affichée WSPR ci-dessus et réglez le mode sur **USB**.
2. Le signal WSPR occupe la plage audio 1400-1600 Hz. Il n'est pas nécessaire d'ajuster davantage la bande passante.
3. Activez le décodeur et sélectionnez **WSPR** dans le menu déroulant.
4. Le panneau **WSPR-2 Decoder** apparaît en dessous.

### Lecture des résultats

Le panneau affiche une barre de progression pour le créneau de 2 minutes en cours :

- **Barre cyan qui se remplit** — collecte des données du signal (de 0 à 116 s dans le créneau).
- **Barre ambrée qui pulse** — décodage en cours (les ~4 dernières secondes du créneau).
- **Barre vide** — attente de la prochaine minute UTC paire.

Chaque spot décodé avec succès est affiché dans un tableau avec les colonnes suivantes :

| Colonne | Signification |
|---------|---------------|
| UTC | Heure du spot (minute paire) |
| Callsign | La station qui a émis |
| Grid | Locator Maidenhead de l'émetteur |
| Power | Puissance émise en dBm |
| Freq | Fréquence audio exacte (Hz) dans la bande passante WSPR |
| SNR | Rapport signal/bruit en dB |

Cliquez sur **Clear** pour effacer la liste des spots.

> **Astuce :** le décodage WSPR exige une heure système très précise (à ±1 seconde de l'UTC). Le premier créneau après l'activation du décodeur commencera à la prochaine minute UTC paire — une courte attente est normale.

---

## 6. FAX HF / WEFAX

**De quoi s'agit-il :** le radiofax HF (également appelé WEFAX) est utilisé par les garde-côtes et les services météorologiques du monde entier pour diffuser des cartes météo, des cartes d'état de la mer et des analyses de surface en ondes courtes. Le décodeur reconstitue l'image ligne par ligne au fur et à mesure de sa réception.

### Configuration

1. Activez le décodeur et sélectionnez **HF FAX / WEFAX** dans le menu déroulant.
2. Le panneau **HF FAX / WEFAX Receiver** apparaît en dessous.
3. **Sélectionnez une station** dans la liste déroulante Station. Plus de 20 stations sont disponibles, couvrant l'Europe, l'Asie, l'Océanie et les Amériques (p. ex. DDH3/DDK3 Allemagne, SVJ4/GR Grèce, JMH Japon, NMG États-Unis La Nouvelle-Orléans).
4. Si la station émet sur plusieurs fréquences, sélectionnez la fréquence souhaitée dans le sous-menu **Frequency**.
5. Cliquez sur **▶ Tune** pour accorder automatiquement la cascade sur cette station.
6. Le mode est automatiquement forcé sur **USB**.

### Horaires de diffusion

Lorsqu'une station est sélectionnée, un tableau de compte à rebours **Next Transmissions** apparaît, indiquant les 4 prochaines diffusions programmées en UTC, avec un décompte en direct :

- Normal (gris/vert) — la transmission est à venir.
- **Ambre ⚡** — la transmission commence dans moins de 3 minutes ; armez le décodeur maintenant.
- **Rouge ●** — la transmission commence dans moins de 30 secondes ; la réception est imminente.

### Paramètres

La plupart des stations utilisent les valeurs par défaut standard (marquées ★). Ne les modifiez que si vous savez que la station emploie des réglages non standard.

| Paramètre | Défaut | Description |
|-----------|--------|-------------|
| LPM | 120 ★ | Lignes par minute — la vitesse de rotation du tambour |
| IOC | 576 ★ | Indice de coopération — détermine le nombre de pixels par ligne |
| Shift | 800 Hz ★ | Écart de fréquence entre les tonalités noir et blanc |

### Commandes

- **⇔ Auto-align** — activé par défaut. Se synchronise automatiquement sur le signal de phasage au début de chaque image. Ne le désactivez que si vous rencontrez des problèmes d'alignement sur un signal connu comme bon.
- **⇅ Invert** — inverse le noir et le blanc. À utiliser si l'image apparaît en négatif (zones blanches là où le noir devrait être).
- **↺ Refresh** — efface le canevas et réinitialise le décodeur. À utiliser entre deux transmissions ou si l'image se déchire ou dérive.
- **⤓ Save PNG** — enregistre le canevas actuel sous forme de fichier PNG sur votre ordinateur.

### Indicateurs d'état

En bas de l'image, deux indicateurs de tonalité montrent :

- **300 Hz phasing** — s'allume en cyan lorsque la tonalité de phasage de début d'image est détectée.
- **450 Hz stop** — s'allume en rouge lorsque la tonalité d'arrêt de fin d'image est détectée.

> **Remarque :** l'image défile vers le haut — la ligne reçue la plus récente apparaît toujours en bas du canevas. Si vous voyez **[PHASING]** dans l'en-tête, le décodeur s'est verrouillé sur un nouveau début d'image.

---

## 7. NAVTEX

**De quoi s'agit-il :** NAVTEX est le système international de diffusion maritime des informations de sécurité côtière — avertissements de navigation, prévisions météorologiques et avis de recherche et de sauvetage. Il utilise le FSK à 100 bauds (SITOR-B avec FEC) et est reçu sur des canaux dédiés dans le monde entier.

### Canaux disponibles

| Canal | Fréquence | Usage |
|-------|-----------|-------|
| International | 518 kHz | En anglais, international |
| National | 490 kHz | Diffusions en langue nationale |
| HF (×5) | 4209.5 / 6314 / 8416.5 / 12579 / 16806.5 kHz | NAVTEX HF longue portée |

### Configuration

1. Activez le décodeur et sélectionnez **NAVTEX** dans le menu déroulant. Le récepteur passe automatiquement en **USB**.
2. Le panneau **NAVTEX Receiver** apparaît.
3. Sélectionnez le canal souhaité dans la liste **Station** (p. ex. `International — 518 kHz`).
4. Cliquez sur **⇒ Tune & Set IF** pour accorder automatiquement la cascade et resserrer la bande passante sur la bonne fenêtre audio. Le mode est réglé automatiquement sur **USB**. La fréquence affichée est placée 500 Hz sous le centre du canal, de sorte que le signal NAVTEX apparaît à 500 Hz en audio.

### Horaires de diffusion

Le tableau des horaires liste toutes les stations connues sur le canal sélectionné avec :

- leur lettre d'identification UIT et le drapeau du pays
- l'heure de la prochaine diffusion en UTC
- un décompte en direct jusqu'à la prochaine transmission
- **Ambre ⚡** à moins de 2 minutes / **Rouge ●** à moins de 30 secondes — armez le décodeur maintenant

### Lecture des résultats

Le texte décodé apparaît en caractères sarcelle à chasse fixe. Les limites des messages sont clairement marquées :

```
━━ ZCZC MA12 ━━
... message content ...
━━ NNNN ━━
```

`ZCZC` marque le début d'un message. Les trois caractères qui suivent identifient la station (`M`), le sujet (`A` = avertissements de navigation) et le numéro d'ordre (`12`). `NNNN` marque la fin.

Cliquez sur **Clear** pour effacer la mémoire tampon des messages.

> **Remarque :** NAVTEX fonctionne sur des fréquences MF et LF (518/490 kHz). La portée de réception est généralement de 200 à 400 milles marins depuis l'émetteur. Les canaux HF (4-17 MHz) offrent une portée bien supérieure.

---

## 8. FSK / RTTY

**De quoi s'agit-il :** un décodeur FSK (Frequency-Shift Keying) / RTTY polyvalent prenant en charge trois variantes de fonctionnement : FSK maritime (SITOR), RTTY météo et RTTY amateur. Chaque variante est fournie avec un préréglage adapté à ses paramètres standard.

### Variantes et préréglages

| Variante | Centre | Shift | Bauds | Trame | Codage |
|----------|--------|-------|-------|-------|--------|
| FSK maritime / SITOR | 500 Hz | 170 Hz | 100 | 7N1 | CCIR-476 |
| RTTY météo | 1000 Hz | 450 Hz | 50 | 5N1.5 | ITA2 |
| RTTY amateur | 1000 Hz | 170 Hz | 45.45 | 5N1.5 | ITA2 |

### Configuration

1. Activez le décodeur et sélectionnez **FSK / RTTY** dans le menu déroulant.
2. Le panneau **FSK / RTTY Decoder** apparaît.
3. Sélectionnez la **Variant** (Maritime, Weather ou Ham). Les paramètres se mettent à jour automatiquement.
4. Utilisez la liste **Known frequency** pour choisir une fréquence courante de la variante retenue, puis cliquez sur **Tune** pour vous y rendre.
5. Affinez la fréquence jusqu'à ce que le texte décodé devienne stable et lisible.

### Fréquences connues par variante

**FSK maritime / SITOR**
- 518.0 kHz — NAVTEX international
- 490.0 kHz — NAVTEX national
- 4209.5 / 6314,0 / 8416.5 / 12579,0 / 16806.5 / 22376.0 kHz — SITOR HF

**RTTY météo**
- 4583,0 / 7646,0 / 10100,8 / 11039,0 / 14467.3 kHz — DWD (service météorologique allemand)

**RTTY amateur**
- 3590 kHz (80 m), 7043 kHz (40 m), 10143 kHz (30 m), 14083 kHz (20 m), 21083 kHz (15 m), 28083 kHz (10 m)

### Paramètres

| Paramètre | Description |
|-----------|-------------|
| Center audio (Hz) | La fréquence audio du point médian mark/space |
| Shift (Hz) | Écart de fréquence entre les tonalités mark et space |
| Baud | Débit de symboles |
| Framing | Bits de données, parité, bits d'arrêt (p. ex. 7N1 = 7 données, sans parité, 1 stop) |
| Encoding | Jeu de caractères (CCIR-476, ITA2/Baudot ou ASCII) |
| Invert mark / space | Intervertit les tonalités mark et space |
| Auto shift detect | Tente de mesurer automatiquement le shift à partir du signal reçu |

### Mesures du signal

La barre d'état affiche des mesures en direct :

- **Mark / Space** — fréquence audio mesurée de chaque tonalité (Hz)
- **SNR** — rapport signal/bruit en dB
- **Lock** — qualité de verrouillage du décodeur en pourcentage
- **Timing** — `LOCKED` lorsque l'horloge bit est synchronisée, `SEARCH` pendant la recherche

### Commandes supplémentaires

- **⇒ Set IF Band-Pass** — resserre la bande passante du récepteur pour encadrer étroitement le signal FSK d'après les réglages actuels de centre et de shift. À utiliser après l'accord pour améliorer la sélectivité et réduire les interférences adjacentes.
- **⟳ Auto-tune Center** — déclenche un balayage automatique pour trouver et verrouiller les tonalités mark/space. Utile lorsque vous êtes proche de la bonne fréquence mais que les tonalités sont légèrement décalées.

> **Remarque sur le mode :** le décodeur FSK prend le contrôle du mode de démodulation et de la bande passante FI pendant qu'il est actif. Les deux sont restaurés automatiquement lorsque vous désactivez le décodeur.
>
> **Remarque sur la polarité :** pour le RTTY (météo), vous devez généralement cocher **Invert mark / space**. Pour le FSK maritime (de type SITOR/NAVTEX) et le RTTY amateur, laissez la case décochée. Si le texte décodé est incompréhensible, basculer cette case est la première chose à essayer.

---

## 9. SSTV

**De quoi s'agit-il :** la télévision à balayage lent transmet des images fixes sur un canal phonie SSB ordinaire, une ligne à la fois, sous forme d'une tonalité modulée en fréquence entre 1500 Hz (noir) et 2300 Hz (blanc). Une image complète prend entre 36 secondes et 4 minutes 30 selon le mode.

### Fréquences recommandées (USB)

| Bande | Fréquence | Mode | Remarques |
|-------|-----------|------|-----------|
| 20 m | 14.230 MHz | USB | La principale fréquence d'appel SSTV internationale — de loin la plus active |
| 20 m | 14.233 MHz | USB | Secondaire, utilisée quand 14.230 est occupée |
| 15 m | 21.340 MHz | USB | |
| 10 m | 28.680 MHz | USB | Active pendant les ouvertures de bande |
| 40 m | 7.171 MHz | LSB | |
| 80 m | 3.845 MHz | LSB | Régionale, en soirée |

**La bande latérale est choisie pour vous.** Le démarrage du décodeur sélectionne la **LSB en dessous de 10 MHz** et l'**USB au-dessus**, selon l'usage amateur habituel. Sur la mauvaise bande latérale, la correspondance des tonalités est inversée et l'image ne sera pas décodée. Si vous rencontrez une station qui ignore la convention, changez simplement la bande latérale à la main — le décodeur reste actif, efface l'image et repart à zéro avec le nouveau réglage.

### Configuration

1. Activez le décodeur et sélectionnez **SSTV** dans le menu déroulant. Le récepteur change automatiquement de bande latérale — USB au-dessus de 10 MHz, LSB en dessous.
2. Accordez-vous de sorte que les tonalités de l'image tombent au milieu de la bande passante. Un signal correctement accordé a ses impulsions de synchronisation à 1200 Hz et le contenu de l'image entre 1500 et 2300 Hz.
3. Laissez **Mode** sur **Auto**, sauf si vous savez déjà ce qui est transmis. L'image se construit ligne par ligne au fur et à mesure de la réception.

### Modes

| Réglage | Image | Durée |
|---------|-------|-------|
| **Auto** | Détecté automatiquement | — |
| Martin M1 / M2 | 320×256 couleur | 114 s / 58 s |
| Scottie S1 / S2 | 320×256 couleur | 110 s / 71 s |
| Scottie DX | 320×256 couleur | 269 s |
| Robot 36 / 72 | 320×240 couleur | 36 s / 72 s |

**Auto** fonctionne de deux façons : il lit l'**en-tête VIS** — le code numérique du mode envoyé dans les 300 premières millisecondes d'une transmission — et, si l'en-tête a été manqué (vous vous êtes accordé trop tard, ou il a été perdu dans le QSB), il identifie le mode d'après la synchronisation des impulsions. Sélectionner un mode précis force ce mode, mais le décodeur vérifie tout de même la synchronisation avant de dessiner quoi que ce soit : un mauvais choix ne produit donc aucune image plutôt que du bruit.

### Lecture des résultats

La ligne d'état sous les commandes indique ce que fait le décodeur :

| État | Signification |
|------|---------------|
| `Waiting for VIS / AUTO lock` | À l'écoute ; rien d'identifié pour l'instant |
| `Martin M1? verifying sync…` | Un candidat a été trouvé et est confirmé sur les lignes suivantes |
| `Martin M1 lock (VIS)` | Verrouillé d'après l'en-tête VIS |
| `Martin M1 lock (AUTO)` | Verrouillé d'après la synchronisation |
| `Martin M1 lock (MANUAL)` | Démarré par le bouton **⏺ Force** |
| `Candidate rejected (no sync)` | Le candidat n'a pas été confirmé — normal sur du bruit |
| `— sync lost, resetting` | Le signal a disparu en cours d'image |
| `Frame complete` | L'image complète a été reçue |

Le mode détecté apparaît aussi en vert à côté du titre **SSTV**, et le compteur de lignes indique la progression.

### Commandes

| Bouton | Action |
|--------|--------|
| **▶ Start** | Arme le décodeur. Il ne dessine pas d'image de lui-même — un verrouillage doit encore provenir de l'en-tête VIS ou de la détection de synchronisation. |
| **■ Stop** | Arrête le décodage. |
| **↺ Reset** | Efface le canevas et réarme sur place. À utiliser entre deux images ou après un réaccord. |
| **⏺ Force** | Commence à dessiner **immédiatement** dans le mode sélectionné dans la liste, en sautant entièrement le VIS et la détection de synchronisation. Disponible uniquement quand Mode n'est pas sur **Auto**. |
| **💾 Save** | Enregistre l'image actuelle au format PNG. |

**Quand utiliser Force.** Si vous voyez une image dans la cascade mais que le décodeur ne parvient pas à s'y verrouiller — mode inhabituel, signal trop faible ou trop déformé pour les détecteurs, ou en-tête manqué — sélectionnez le mode à la main et appuyez sur **⏺ Force**. L'image est calée au moment du clic, et le badge de mode affiche `MANUAL` pour que vous puissiez la distinguer d'un verrouillage VIS ou AUTO. Le décodeur se recale tout de même sur une véritable impulsion de synchronisation s'il en trouve une : un clic légèrement en avance ou en retard est donc corrigé.

Comme Force contourne toutes les vérifications de sécurité, il peindra volontiers du bruit si vous l'actionnez sur un canal vide, et il ne s'arrêtera pas tout seul — appuyez sur **■ Stop** ou **↺ Reset**.

### Remarques

- **Le bruit ne déclenche pas le décodeur.** Les parasites atmosphériques, les étincelles et le bruit du secteur suffisaient autrefois à déclencher un décodage. Chaque étape de détection vérifie désormais que la tonalité est bien une tonalité, et confirme le candidat sur les lignes suivantes avant de dessiner le moindre pixel. Attendez-vous à ce que le décodeur reste silencieux sur une bande vide.
- **L'image dérive en diagonale si vous êtes décalé en fréquence.** La SSTV ne pardonne pas les erreurs d'accord. Si les lignes penchent, ajustez la fréquence par petits pas et laissez l'image suivante démarrer.
- L'équilibre des couleurs et la netteté sont fixes ; il n'y a aucun réglage à faire.

---

## 10. Conseils généraux

**Decoder: ON doit être activé en premier.** Le menu déroulant est désactivé (grisé) tant que vous n'avez pas cliqué sur le bouton Decoder pour l'activer.

**Un décodeur à la fois.** Sélectionner un nouveau décodeur dans le menu arrête automatiquement celui qui était actif et annule les changements de mode ou de bande passante qu'il avait effectués.

**Le mode est géré pour vous.** Le FAX HF et NAVTEX basculent le récepteur en USB dès que vous les sélectionnez, la SSTV choisit la bande latérale d'après la bande (LSB sous 10 MHz, USB au-dessus), et FAX, NAVTEX et FSK ajustent aussi la bande passante lorsque vous cliquez sur leur bouton Tune. Lorsque vous arrêtez le décodeur, le mode par défaut de la bande est restauré.

**Activer un décodeur n'interrompt plus l'audio.** Les décodeurs s'exécutent sur leurs propres threads : il n'y a donc ni blanc, ni clic, ni coupure lorsque l'un démarre, s'arrête ou est remplacé par un autre.

**La précision de l'horloge système compte.** FT8, FT4 et WSPR sont critiques en temps. Ils décodent dans des fenêtres fixes alignées sur l'UTC. Si l'horloge de votre ordinateur est décalée de plus de 1 à 2 secondes, les taux de décodage chuteront nettement. Utilisez un client NTP pour garder votre horloge précise.

**La qualité du signal prime sur sa force.** La plupart de ces décodeurs sont conçus pour les signaux faibles. Une bande plus calme avec moins de bruit est souvent plus productive qu'un signal fort noyé dans les interférences. Utilisez la cascade et les commandes de bande passante pour repérer et éviter le QRM avant d'activer un décodeur.

**Utilisez les boutons Refresh ou Clear sans hésiter.** Les images FAX dérivent si la fréquence affichée est légèrement décalée, et les décodeurs de texte accumulent des caractères parasites. Un nouveau départ après des ajustements d'accord produit souvent un résultat beaucoup plus propre.

---

*PhantomSDR-Plus — fork sv1btl — [phantomsdr.no-ip.org](http://phantomsdr.no-ip.org:8900)*
