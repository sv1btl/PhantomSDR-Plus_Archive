# Цифровой голос RADE v1 для PhantomSDR-Plus

**RADE** (Radio AutoencoDEr) — флагманский КВ-режим цифрового голоса от FreeDV. Он использует
гибрид машинного обучения и ЦОС (нейронный вокодер FARGAN), обеспечивая качественную речь на
КВ при отношении сигнал/шум вплоть до −2 дБ в полосе всего 1500 Гц — уже, чем сигнал SSB.

Этот документ описывает полную интеграцию приёма RADE v1 в PhantomSDR-Plus, реализованную в
виде sidecar-процесса на Python (`rade_helper.py`), который связывает браузер с цепочкой
декодирования `radae_rxe.py` + `lpcnet_demo`.

- **[Ручная установка RADE в Linux](RADE_General_INSTALL_MANUAL_LINUX.md)** - Полное руководство по использованию WebSDR
- **[Ручная установка RADE на Pi/Debian Bookworm (ARM64)](RADE_Pi_INSTALL_MANUAL.md)** - Полное руководство по использованию WebSDR

---

## Содержание

1. [Как это работает](#как-это-работает)
2. [Обзор архитектуры](#обзор-архитектуры)
3. [RADEL против RADEU](#radel-против-radeu)
4. [Перед установкой — системные требования](#перед-установкой--системные-требования)
5. [Шаг 1 — Клонирование и сборка репозитория radae](#шаг-1--клонирование-и-сборка-репозитория-radae)
6. [Шаг 2 — Установка зависимостей Python](#шаг-2--установка-зависимостей-python)
7. [Шаг 3 — Проверка цепочки декодирования](#шаг-3--проверка-цепочки-декодирования)
8. [Шаг 4 — Размещение исправленных файлов](#шаг-4--размещение-исправленных-файлов)
9. [Шаг 5 — Сборка веб-интерфейса](#шаг-5--сборка-веб-интерфейса)
10. [Шаг 6 — Установка управляющего скрипта rade.sh](#шаг-6--установка-управляющего-скрипта-radesh)
11. [Шаг 7 — Открытие порта 8074](#шаг-7--открытие-порта-8074)
12. [Шаг 8 — Запуск сервера](#шаг-8--запуск-сервера)
13. [Шаг 9 — Ручной запуск RADE](#шаг-9--ручной-запуск-rade)
14. [Шаг 10 — Использование RADE в браузере](#шаг-10--использование-rade-в-браузере)
15. [Проверка и отладка](#проверка-и-отладка)
16. [Переменные окружения](#переменные-окружения)
17. [Изменённые файлы](#изменённые-файлы)
18. [Сводка прохождения сигнала](#сводка-прохождения-сигнала)
19. [Устранение неполадок](#устранение-неполадок)
20. [Измерение параллелизма на своём оборудовании](#измерение-параллелизма-на-своём-оборудовании)
21. [Обновление RADE v1](#обновление-rade-v1)

---

## Как это работает

RADE v1 не может работать в браузере — ему нужны PyTorch и нейронный вокодер FARGAN, слишком
большие для WASM. Решение — sidecar-процесс на Python (`rade_helper.py`), работающий на том же
сервере, что и PhantomSDR-Plus.

> **Важно:** `freedv_rx` из репозитория codec2 **не** поддерживает RADEV1.
> Цепочка декодирования RADE целиком находится в отдельном репозитории `radae`
> Дэвида Роу (VK5DGR). Не пытайтесь использовать `freedv_rx` из codec2 для RADE.

Когда вы выбираете RADE в браузере:

1. Веб-интерфейс задаёт базовую демодуляцию USB или LSB — сервер на C++ демодулирует сигнал
   SSB как обычно.
2. Необработанный демодулированный PCM снимается в `audio.js` **до** любого отключения звука
   или шумоподавителя — `radae_rxe.py` нужен непрерывный входной поток, чтобы удерживать
   кадровую синхронизацию.
3. Каждый блок PCM дополняется нулями из вещественного f32 в комплексный f32 (вещественная
   часть + 0.0 мнимой) — именно этого `radae_rxe.py` ожидает на стандартном входе.
4. Sidecar передаёт эти отсчёты в `radae_rxe.py`, который выдаёт признаки вокодера.
5. `lpcnet_demo -fargan-synthesis` преобразует признаки в речь s16 с частотой 16000 Гц.
6. Sidecar преобразует s16 → f32 и отправляет результат обратно в браузер двоичными кадрами
   WebSocket.
7. Браузер воспроизводит декодированную речь через Web Audio API на 16000 Гц.

Сервер на C++ (`spectrumserver.cpp`) при этом вообще не изменяется.

---

## Обзор архитектуры

```
┌────────────────────────────────────────────────────────────────────┐
│  Browser                                                           │
│                                                                    │
│  Decoder → "RADE v1 — RADEL (LSB)" / "RADEU (USB)"               │
│       │                                                            │
│  audio.js ── demod cmd (LSB/USB) ──────────► C++ spectrumserver   │
│       │                                              │             │
│       │  raw SSB PCM @ audioOutputSps ◄─────────────┘             │
│       │  (tapped before mute gate, zero-padded to complex f32)     │
│       │                                                            │
│       │  binary WebSocket ──► ws://host:8074                       │
│       ▼                                                            │
├────────────────────────────────────────────────────────────────────┤
│  rade_helper.py  (port 8074)                                       │
│                                                                    │
│  resample to 8000 Hz if needed                                     │
│  zero-pad real f32 → complex f32 pairs                             │
│       │ stdin pipe                                                  │
│       ▼                                                            │
│  radae_rxe.py  --model_name model19_check3/.../checkpoint_100.pth  │
│       │ stdout pipe (vocoder features f32)                         │
│       ▼                                                            │
│  lpcnet_demo  -fargan-synthesis  -  -                              │
│       │ stdout (s16 PCM @ 16000 Hz)                                │
│       │ converted → f32 by sidecar                                 │
│       │ binary WebSocket frames ──► browser                        │
│       ▼                                                            │
├────────────────────────────────────────────────────────────────────┤
│  Browser                                                           │
│                                                                    │
│  _radePlayPCM() → AudioContext.createBuffer(16000 Hz) → speaker   │
└────────────────────────────────────────────────────────────────────┘
```

---

## RADEL против RADEU

RADE v1 всегда передаётся по SSB. По соглашению:

| Режим | Боковая полоса | Использовать на диапазонах                |
|-------|----------------|-------------------------------------------|
| RADEL | LSB            | 160 м, 80 м, 40 м  (≤ 10 МГц)            |
| RADEU | USB            | 20 м, 17 м, 15 м, 12 м, 10 м (> 10 МГц)  |

---

## Предварительные требования

| Требование | Версия | Примечания |
|---|---|---|
| PhantomSDR-Plus | любая | с веб-интерфейсом Vite/Svelte |
| Linux | Ubuntu 24.04+ / Debian Bookworm+ | проверено |
| Python | 3.8+ | для `rade_helper.py` и `radae_rxe.py` |
| репозиторий radae | последний master | даёт `radae_rxe.py` и `lpcnet_demo` |
| cmake | 3.10+ | для сборки `lpcnet_demo` из radae |
| PyTorch | 2.0+ | требуется для `radae_rxe.py` |
| Node.js | 16+ | для `npm run build` |
| websockets (Python) | 10–16+ | `pip3 install websockets` — поддерживаются все версии |
| matplotlib | любая | требуется `radae_rxe.py` при импорте |
| numpy | 1.23+ | обязателен; также обеспечивает передискретизацию |
| scipy | любая | необязательно, обеспечивает точную передискретизацию |

---

## Перед установкой — системные требования

Прежде чем клонировать репозиторий PhantomSDR-Plus или что-либо собирать, установите все
системные зависимости на вашем сервере Ubuntu/Debian.

### Системные пакеты

```bash
sudo apt update
sudo apt install -y \
    build-essential cmake git \
    python3 python3-pip \
    nodejs npm \
    aplay alsa-utils
```

### Node.js (если системная версия слишком старая — нужна 16+)

```bash
node --version   # check current version
# If below 16.x:
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### Пакеты Python

```bash
pip3 install websockets matplotlib torch numpy scipy
```

> **О версии websockets:** поддерживается любая версия от 10.x до 16.x+.
> `rade_helper.py` определяет версию API автоматически.

### Проверка пакетов Python

```bash
python3 -c "import websockets, matplotlib, torch, numpy, scipy; print('All OK')"
```

---

## Шаг 1 — Клонирование и сборка репозитория radae

Декодер RADE **не** входит в codec2. Он расположен в отдельном репозитории, и его нужно
собрать из исходников, чтобы получить исполняемый файл `lpcnet_demo`.

```bash
# 1a. Install build dependencies
sudo apt install build-essential cmake git python3-pip

# 1b. Clone the radae repository
git clone https://github.com/drowe67/radae.git ~/radae
cd ~/radae

# 1c. Build (produces lpcnet_demo and other binaries)
mkdir build && cd build
cmake ..
make -j$(nproc)

# 1d. Verify lpcnet_demo was built
ls -la ~/radae/build/src/lpcnet_demo
```

Вы должны увидеть `lpcnet_demo` по пути `~/radae/build/src/lpcnet_demo`.

**Предобученные веса модели** уже включены в репозиторий:

```bash
# Verify model19_check3 weights are present (this is the correct model)
ls ~/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
```

---

## Шаг 2 — Установка зависимостей Python

```bash
# Required
pip3 install websockets matplotlib torch numpy

# Recommended (enables accurate resampling when audioOutputSps > 8000)
pip3 install scipy
```

> **Зачем matplotlib?** `radae_rxe.py` импортирует matplotlib в начале файла, даже если
> графики не строятся. Он должен быть установлен, иначе скрипт немедленно завершится с
> `ModuleNotFoundError: No module named 'matplotlib'`.

> **Зачем torch?** `radae_rxe.py` использует PyTorch для вывода нейронного вокодера.

---

## Шаг 3 — Проверка цепочки декодирования

Прежде чем связывать всё воедино, убедитесь, что полная цепочка работает автономно. На этом
шаге из файла WAV формируется тестовый сигнал RADE и декодируется на динамики.

```bash
cd ~/radae

# Step 3a — Generate a RADE-encoded test signal
# Note: --auxdata is required for model19_check3 when using inference.sh
./inference.sh model19_check3/checkpoints/checkpoint_epoch_100.pth \
    wav/brian_g8sez.wav /dev/null \
    --rate_Fs --pilots --pilot_eq --eq_ls --cp 0.004 \
    --write_rx rx.f32 --auxdata
```

Дождитесь завершения. Программа выводит статистику, заканчивающуюся так:
```
loss: 0.741 Auxdata BER: 0.012
```

Затем декодируйте и прослушайте:

```bash
# Step 3b — Decode and play
cat rx.f32 \
    | python3 radae_rxe.py --model_name model19_check3/checkpoints/checkpoint_epoch_100.pth \
    | ./build/src/lpcnet_demo -fargan-synthesis - - \
    | aplay -f S16_LE -r 16000
```

Вы должны услышать голос. Вывод показывает захват синхронизации:
```
  1 state: search     ...
  5 state: sync       ... SNRdB:  4.03 uw_err: 0
Playing raw data 'stdin' : Signed 16 bit Little Endian, Rate 16000 Hz, Mono
```

Сообщения `underrun!!!` во время этой автономной проверки ожидаемы — `radae_rxe.py`
обрабатывает медленнее, чем идёт файловый ввод-вывод. При живом приёме они **не** появляются,
так как браузер подаёт звук в реальном времени.

> **Ключевые факты о `radae_rxe.py`:**
> - Путь к модели передаётся как `--model_name <путь>`, а **не** позиционным аргументом
> - `--auxdata` **включён по умолчанию** — не передавайте его как флаг
> - Используйте `--noauxdata`, только если нужно его отключить

```bash
# Step 3c — Verify the sidecar starts correctly
python3 ~/PhantomSDR-Plus/rade_helper.py
```

Ожидаемый вывод (без строк WARNING):
```
[RADE] helper starting on ws://0.0.0.0:8074
[RADE] radae_rx.py    : /home/sv1btl/radae/radae_rxe.py
[RADE] model          : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
[RADE] lpcnet_demo    : /home/sv1btl/radae/build/src/lpcnet_demo
[RADE] auxdata        : ON (default)
[RADE] torch threads  : 1 per instance (RADE_TORCH_THREADS to override)
[RADE] architecture   : per-connection (each user tunes independently)
[RADE] listening — waiting for PhantomSDR-Plus clients
```

Нажмите Ctrl+C для остановки.

---

## Шаг 4 — Размещение исправленных файлов

Скопируйте следующие файлы из набора исправлений в свой репозиторий PhantomSDR-Plus.

### Новый файл — поместите в корень репозитория, рядом со скриптом запуска, которым пользуетесь:

```
rade_helper.py
```

### Исправленные файлы веб-интерфейса — поместите в `frontend/src/`:

```
audio.js
App.svelte
App__analog_smeter_.svelte
App__digital_smeter_.svelte
App__v2_analog_smeter_.svelte
App__v2_digital_smeter_.svelte
```

### Что делают исправления

**`audio.js`** — 5 изменений:
- Конструктор: 5 новых полей состояния RADE (`decodeRADE`, `_radeSideband`, `_radeSocket`,
  `_radeCallback`, `_radeReady`, `_radeNextTime`)
- Сохранение PCM до усиления: `pcmArrayPreBoost` сохраняется до 300-кратного усиления FLAC,
  чтобы RADE получал исходную амплитуду (усиление привело бы к перегрузке `radae_rxe.py`)
- `playAudio()`: отвод PCM для RADE с использованием звука до усиления, перед фильтром
  отключения/шумоподавителя
- `playAudio()`: защита `if (this.decodeRADE) return` — подавляет воспроизведение исходного
  SSB, пока звучит декодированная RADE речь
- Новые методы: `setRADEDecoding()`, `setRADECallback()`, `_radePlayPCM()` с планируемым
  воспроизведением без разрывов по часам `_radeNextTime`
  (воспроизведение на **16000 Гц** — выходная частота `lpcnet_demo`)

**Каждый вариант Svelte** — 6 изменений:
- `demodulationDefaults`: RADEL `{type:'LSB', offsets:[2200,-700]}`,
  RADEU `{type:'USB', offsets:[-700,2200]}` — полоса начинается в 700 Гц от несущей, ширина
  1500 Гц
- Переменные состояния: `radeEnabled`, `radeConnected`, `radeSynced`, `radeSnr`,
  `_radeDeactivate()`
- `_radeDeactivate()`: останавливает декодер и **восстанавливает режим диапазона по
  умолчанию** из `bands-config.js` — поведение идентично отключению FAX, NAVTEX, FSK
- `_deactivateAll()`: строка очистки RADE
- `activateSelectedDecoder()`: ветви `radel` и `radeu`
- Выпадающий список декодеров: две новые записи `<option>`
- Панель состояния: индикатор соединения, состояние синхронизации/SNR, баннер ошибки

### Скрипты запуска

Основные скрипты запуска сервера (`go.sh`, `kill.sh`, `start-rx888mk2.sh`, `stop-websdr.sh`)
**не** изменяются. RADE управляется независимо через `rade.sh` (см. шаг 6).

---

## Шаг 5 — Сборка веб-интерфейса

```bash
cd ~/PhantomSDR-Plus/frontend
npm install       # only if node_modules is missing
npm run build
```

Следите за ошибками парсера Vite/acorn. Исправленный код намеренно избегает `?.`, `??` и
пустых `catch {}`, чтобы соответствовать ограничению acorn.

---

## Шаг 6 — Установка управляющего скрипта rade.sh

`rade.sh` — специальный скрипт для управления sidecar-процессом RADE. Основные скрипты запуска
сервера (`go.sh`, `kill.sh`, `start-rx888mk2.sh`, `stop-websdr.sh`) **не** изменяются — RADE
запускается и останавливается независимо.

Скопируйте `rade.sh` в каталог PhantomSDR-Plus и сделайте его исполняемым:

```bash
cp rade.sh ~/PhantomSDR-Plus/
chmod +x ~/PhantomSDR-Plus/rade.sh
```

Доступные команды:

```bash
./rade.sh start      # start sidecar with self-restarting watchdog
./rade.sh stop       # stop sidecar + watchdog + lpcnet_demo children
./rade.sh restart    # stop then start cleanly
./rade.sh status     # show running / stopped + process info
```

Активность sidecar записывается в `~/PhantomSDR-Plus/rade.log`:

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

> **Почему не встроить это в скрипты запуска?**
> Держать RADE отдельно означает, что сервер может работать без RADE (экономя ЦП, когда им
> никто не пользуется), а RADE можно перезапускать независимо, не трогая основной процесс
> сервера.

---

## Шаг 7 — Открытие порта 8074

Sidecar слушает порт **8074**. Браузер подключается напрямую к этому порту.
Порт 8074 должен быть доступен снаружи.

### Проверка текущего состояния

```bash
# Is sidecar listening?
ss -tlnp | grep 8074

# Test from outside (not from the server itself — NAT hairpin will give false results)
# Use: https://portchecker.co  →  your-hostname  →  port 8074
```

> **Предупреждение о NAT hairpin:** проверка с помощью `curl` с сервера на его же публичное
> имя часто возвращает `Connection refused`, даже когда порт открыт, — многие маршрутизаторы
> блокируют петлю. Всегда проверяйте с внешней машины или через portchecker.co.

### Открыть в iptables

```bash
sudo iptables -I INPUT -p tcp --dport 8074 -j ACCEPT

# Make permanent across reboots:
sudo apt install iptables-persistent
sudo netfilter-persistent save
```

### Открыть в ufw

```bash
sudo ufw allow 8074/tcp && sudo ufw reload
```

### Проброс на маршрутизаторе

Добавьте правило NAT/проброса порта: `TCP-порт 8074 → локальный IP сервера : 8074`

### Альтернатива: проксирование через существующий публичный порт с помощью Nginx

Если порт 8074 открыть невозможно (блокировка провайдером и т. п.), проксируйте WebSocket
через существующий публичный порт с помощью Nginx:

```nginx
# Add inside your existing server {} block
location /rade {
    proxy_pass         http://127.0.0.1:8074;
    proxy_http_version 1.1;
    proxy_set_header   Upgrade    $http_upgrade;
    proxy_set_header   Connection "upgrade";
    proxy_set_header   Host       $host;
    proxy_read_timeout 3600s;
}
```

```bash
sudo nginx -t && sudo nginx -s reload
```

Затем измените URI sidecar в `audio.js`, внутри `setRADEDecoding()`:

```js
// Find:
var helperUri = uri || ('ws://' + window.location.hostname + ':8074');

// Change to:
var helperUri = uri || ('ws://' + window.location.host + '/rade');
```

После этой правки пересоберите веб-интерфейс.

---

## Шаг 8 — Запуск сервера

Запустите PhantomSDR-Plus как обычно — RADE **не** запускается автоматически:

```bash
cd ~/PhantomSDR-Plus
./start-rx888mk2.sh      # or start-airspyhf.sh,
                         # start-rtl.sh, start-rsp1a.sh
```

Сервер запускается без sidecar RADE. Перейдите к шагу 9, чтобы активировать RADE.

---

## Шаг 9 — Ручной запуск RADE

Когда сервер PhantomSDR-Plus уже работает, запустите sidecar RADE отдельно:

```bash
cd ~/PhantomSDR-Plus
./rade.sh start
```

Убедитесь, что он работает:

```bash
./rade.sh status
```

Ожидаемый вывод:
```
[RADE] Running
$USER  python3 /home/sv1btl/PhantomSDR-Plus/rade_helper.py ...
```

Следите за журналом запуска:

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

Ожидаемые строки журнала:
```
[RADE] sidecar starting at ...
[RADE] helper starting on ws://0.0.0.0:8074
[RADE] radae_rx.py    : /home/sv1btl/radae/radae_rxe.py
[RADE] model          : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
[RADE] lpcnet_demo    : /home/sv1btl/radae/build/src/lpcnet_demo
[RADE] auxdata        : ON (default)
[RADE] torch threads  : 1 per instance
[RADE] architecture   : per-connection (each user tunes independently)
[RADE] listening — waiting for PhantomSDR-Plus clients
```

Чтобы остановить RADE, не останавливая сервер:

```bash
./rade.sh stop
```

Чтобы перезапустить RADE (например, после обновления `rade_helper.py`):

```bash
./rade.sh restart
```

> **Примечание:** одной команды `pkill -f rade_helper.py` недостаточно — `rade.sh` выполняет
> самоперезапускающийся цикл сторожевого процесса, который воссоздаст процесс в течение
> 3 секунд. Для полного завершения всегда используйте `./rade.sh stop`.

---

## Шаг 10 — Использование RADE в браузере

1. Откройте веб-интерфейс PhantomSDR-Plus
2. Найдите активные станции на **[qso.freedv.org](https://qso.freedv.org)**
3. Настройтесь на частоту станции по шкале
4. В **Decoder Options** выберите:
   - **RADE v1 — RADEL (LSB)** для 40 м / 80 м / 160 м
   - **RADE v1 — RADEU (USB)** для 20 м / 17 м / 15 м / 12 м / 10 м
5. Нажмите **Decoder: ON**

### Состояния индикатора панели

| Индикатор | Значение |
|---|---|
| 🔴 Красный — «Connecting to sidecar…» | Порт 8074 недоступен или sidecar не запущен |
| 🟡 Жёлтый — «Searching for signal…» | Sidecar подключён, кадр RADE ещё не обнаружен |
| 🟢 Зелёный — «Synced · SNR x.x dB» | Идёт декодирование — воспроизводится речь |

### Когда вы выключаете декодер

Режим и полоса автоматически возвращаются к правильному значению по умолчанию для текущей
частоты, заданному в `bands-config.js`, — точно так же, как у FAX, NAVTEX, FSK.

---

## Проверка и отладка

### Работает ли sidecar?

```bash
ps aux | grep rade_helper | grep -v grep
ss -tlnp | grep 8074
```

### Наблюдение за активностью в реальном времени

```bash
tail -f ~/PhantomSDR-Plus/rade.log
```

При подключении браузера:
```
[RADE] client connected: x.x.x.x:XXXXX
[RADE] x.x.x.x:XXXXX  sps=12000 sideband=LSB
[RADE] x.x.x.x:XXXXX spawning pipeline (torch_threads=1)
```

### Быстрая проверка WebSocket

```bash
python3 - << 'EOF'
import asyncio, websockets, json

async def test():
    async with websockets.connect('ws://localhost:8074') as ws:
        await ws.send(json.dumps({'type': 'init', 'sps': 8000, 'sideband': 'LSB'}))
        print(await ws.recv())   # expect: {"type": "status", "connected": true}

asyncio.run(test())
EOF
```

### Консоль браузера (F12)

```
[RADE] ▶ ENABLED LSB @ 12000 Hz → helper ws://localhost:8074
```
Хорошо — WebSocket открыт. Значение в Гц соответствует `audioOutputSps` вашего сервера (обычно 8000–12000 Гц).

```
[RADE] sidecar socket error
```
Порт 8074 недоступен — проверьте межсетевой экран и правило NAT на маршрутизаторе.

---

## Переменные окружения

| Переменная | По умолчанию | Описание |
|---|---|---|
| `RADE_HELPER_PORT` | `8074` | TCP-порт, который слушает sidecar |
| `RADE_HELPER_HOST` | `0.0.0.0` | Адрес привязки (`127.0.0.1` за прокси) |
| `RADAE_DIR` | `~/radae` | Корень репозитория radae |
| `RADE_MODEL` | `RADAE_DIR/model19_check3/checkpoints/checkpoint_epoch_100.pth` | Веса модели |
| `LPCNET_DEMO` | `RADAE_DIR/build/src/lpcnet_demo` | Исполняемый файл lpcnet_demo |
| `RADE_AUXDATA` | `1` | Установите `0`, чтобы передать `--noauxdata` в `radae_rxe.py` |
| `RADE_TORCH_THREADS` | `1` | Потоки PyTorch/OpenBLAS на экземпляр `radae_rxe.py` — ограничивает нагрузку на ЦП |
| `RADE_PIN_CORES` | `1` | Привязывает каждую цепочку декодирования к своему набору ядер; `0` отключает привязку |
| `RADE_CORES_PER_CLIENT` | `2` | Ядер на клиента при включённой привязке |

---

## Изменённые файлы

| Файл | Тип | Примечания |
|---|---|---|
| `rade_helper.py` | **Новый** | Sidecar на Python: сервер WebSocket + двухпроцессная цепочка декодирования |
| `frontend/src/audio.js` | Изменён | 4 исправления |
| `frontend/src/App.svelte` | Изменён | 6 исправлений |
| `frontend/src/App__analog_smeter_.svelte` | Изменён | 6 исправлений |
| `frontend/src/App__digital_smeter_.svelte` | Изменён | 6 исправлений |
| `frontend/src/App__v2_analog_smeter_.svelte` | Изменён | 6 исправлений |
| `frontend/src/App__v2_digital_smeter_.svelte` | Изменён | 6 исправлений |
| `rade.sh` | **Новый** | Управляющий скрипт sidecar RADE (start/stop/restart/status) |
| `go.sh` | **Без изменений** | RADE управляется отдельно через rade.sh |
| `kill.sh` | **Без изменений** | RADE управляется отдельно через rade.sh |
| `start-rx888mk2.sh` | **Без изменений** | RADE управляется отдельно через rade.sh |
| `stop-websdr.sh` | **Без изменений** | RADE управляется отдельно через rade.sh |
| `spectrumserver.cpp` | **Без изменений** | Изменения в C++ не требуются |

---

## Сводка прохождения сигнала

```
Antenna → RX-888 MK2 → PhantomSDR-Plus C++ server
                              │
                    FFT + DDC + SSB demodulation
                    (USB or LSB — set by RADEL/RADEU)
                              │
                    Opus/FLAC encode → WebSocket → Browser
                              │
                         audio.js decode()
                              │
                         playAudio(pcmArray)
                              │
               ┌──────────────┴────────────────────────────┐
               │  rawPcm tap (before mute gate)             │
               │  real f32 → zero-padded complex f32 pairs  │
               └──────────────┬────────────────────────────┘
                              │ WebSocket binary → ws://host:8074
                              ▼
                       rade_helper.py
                              │ resample to 8000 Hz if needed
                              │ stdin pipe
                              ▼
          radae_rxe.py  --model_name model19_check3/.../checkpoint_epoch_100.pth
          (PyTorch FARGAN neural vocoder, auxdata ON by default)
                              │ stdout pipe (vocoder features f32)
                              ▼
          lpcnet_demo  -fargan-synthesis  -  -
                              │ stdout: s16 PCM @ 16000 Hz
                              │ sidecar converts s16 → f32
                              │ WebSocket binary frames → browser
                              ▼
                  audio.js  _radePlayPCM()
                  AudioContext.createBuffer(16000 Hz)
                              │
                           Speaker 🔊
```

---

## Устранение неполадок

### Красный баннер — «Sidecar not reachable»

```bash
# Is sidecar running?
ps aux | grep rade_helper | grep -v grep

# Start it manually for testing
python3 ~/PhantomSDR-Plus/rade_helper.py &

# Check port is open externally — use portchecker.co NOT curl from the server
# (curl from the server uses NAT loopback and gives false "Connection refused")
```

---

### Порт 8074 закрыт по данным portchecker.co, несмотря на правило iptables

Возможно, провайдер фильтрует порт, либо отсутствует правило NAT на маршрутизаторе. Варианты:

1. Попробуйте другой порт: `RADE_HELPER_PORT=8080 python3 rade_helper.py`
2. Проксируйте через существующий публичный порт с помощью Nginx (см. шаг 7)

---

### `radae_rxe.py: error: unrecognized arguments: model_path`

Путь к модели нужно передавать через `--model_name`, а не позиционным аргументом:

```bash
# WRONG — positional argument
python3 radae_rxe.py model19_check3/checkpoints/checkpoint_epoch_100.pth

# CORRECT — named argument
python3 radae_rxe.py --model_name model19_check3/checkpoints/checkpoint_epoch_100.pth
```

---

### `ModuleNotFoundError: No module named 'matplotlib'`

```bash
pip3 install matplotlib
```

`radae_rxe.py` импортирует matplotlib безусловно в начале файла.

---

### `ModuleNotFoundError: No module named 'torch'`

```bash
pip3 install torch
```

---

### `lpcnet_demo: No such file or directory`

Сборка radae не завершилась. Соберите заново:

```bash
cd ~/radae/build
cmake .. && make -j$(nproc)
ls src/lpcnet_demo     # should exist now
```

---

### Ошибка `size mismatch` в `inference.sh`

`model19_check3` требует `--auxdata` при кодировании через `inference.sh`:

```bash
./inference.sh model19_check3/checkpoints/checkpoint_epoch_100.pth \
    wav/brian_g8sez.wav /dev/null \
    --rate_Fs --pilots --pilot_eq --eq_ls --cp 0.004 \
    --write_rx rx.f32 --auxdata    # ← required for model19_check3
```

Обратите внимание: при **декодировании** с помощью `radae_rxe.py` `--auxdata` включён по
умолчанию — передавать его не нужно.

---

### Жёлтый индикатор — «Searching for signal» — синхронизация не наступает

- Убедитесь в правильной боковой полосе: RADEL для ≤ 10 МГц, RADEU для > 10 МГц
- Проверьте на [qso.freedv.org](https://qso.freedv.org), что станция сейчас передаёт
- RADE v1 использует 30 несущих в полосе 1500 Гц — на водопаде выглядит компактной группой
- Дайте до 1,5 секунды на захват

---

### `underrun!!!` от aplay во время проверки цепочки (шаг 3)

Ожидаемо только при автономной проверке с файлами. `radae_rxe.py` обрабатывает медленнее, чем
идёт файловый ввод-вывод, из-за чего звуковой буфер опустошается. При живом приёме этого не
происходит, так как браузер подаёт звук в реальном времени.

---

### `ConnectionClosedError: received 1011 (internal error)`

Sidecar принял соединение WebSocket, но аварийно завершился внутри до ответа. Причина —
несовместимая версия `rade_helper.py`: более старая версия пыталась передать asyncio
`StreamReader` в качестве стандартного ввода подпроцесса, что тихо не срабатывает и приводит
к закрытию с ошибкой 1011.

**Решение:** замените `rade_helper.py` текущей версией из набора исправлений. Текущая версия
использует `os.pipe()` для межпроцессного канала и совместима с websockets от 10.x до 16.x+.

---

### Несколько одновременных пользователей

Каждое подключение браузера порождает собственную независимую пару `radae_rxe.py` +
`lpcnet_demo`, поэтому каждый пользователь может свободно настраиваться на свою частоту.

По умолчанию `radae_rxe.py` использует **все доступные ядра ЦП** для матричных операций
PyTorch, из-за чего нагрузка достигает ~900 % на экземпляр. `rade_helper.py` ограничивает это
двумя оптимизациями:

1. `OMP_NUM_THREADS=1` (и аналоги для MKL/OpenBLAS) — ограничивает PyTorch одним потоком
2. Векторизованные с помощью numpy функции преобразования звука — убирают накладные расходы
   циклов Python

Результат: каждый экземпляр использует примерно **8–10 %** одного ядра, чего достаточно для
декодирования RADE в реальном времени. Если слышны выпадения звука, увеличьте до 2 потоков:

```bash
RADE_TORCH_THREADS=2 ./rade.sh restart
```

| Одновременных пользователей RADE | Примерная нагрузка на ЦП |
|---|---|
| 1 | ~9 % |
| 5 | ~45 % |
| 10 | ~90 % |
| 20 | ~180 % |

На i5-12450H (12 потоков), где spectrumserver занимает ~42 %, а rx888_stream ~11 %, у вас
остаётся около **1000 % запаса** — этого хватит на **20 и более одновременных** пользователей
RADE, прежде чем ЦП станет проблемой.

> **Таблица выше исходит из того, что затраты ЦП растут линейно с числом пользователей.
> Измерения говорят об обратном.** Запуск `rade_loadtest.py` на том же i5-12450H показал
> нагрузку на слушателя заметно ниже этой таблицы вплоть до ~24 слушателей, а затем резкий
> рост, причём машина остановилась по **температуре корпуса процессора на 32 слушателях** — не
> по ЦП и не по полосе пропускания. Считайте эти цифры лишь грубым ориентиром для малых чисел
> и измеряйте собственную машину: см.
> [Измерение параллелизма на своём оборудовании](#измерение-параллелизма-на-своём-оборудовании).
> Учтите, что нагрузочный тест подаёт в цепочку шум, а не настоящий сигнал RADE, поэтому
> абсолютная нагрузка при реальном трафике может отличаться; надёжна именно *форма* кривой.

---

## Измерение параллелизма на своём оборудовании

Приведённые выше числа получены на одной конкретной машине. `rade_loadtest.py` (в корне
репозитория) измеряет то же самое на **вашей** — он ступенчато наращивает число синтетических
слушателей RADE к sidecar и сообщает последнее число слушателей, которое ваша машина выдержала
до того, как что-то сдало.

После каждого шага он даёт машине устояться, затем измеряет температуру корпуса процессора,
общую загрузку ЦП, доступную ОЗУ, swap и суммарный RSS всех процессов `radae_rxe.py` и
`lpcnet_demo`. Он останавливается на первом **изломе** — по тому пределу, который нарушен
первым — и печатает последнее устойчивое число.

### Требования

```bash
sudo apt install python3-websockets python3-psutil
```

Запускайте его **на самом хосте SDR** (он читает локальные датчики и память процессов), когда
spectrumserver и sidecar RADE уже работают:

```bash
cd ~/PhantomSDR-Plus
python3 rade_loadtest.py
```

Ctrl-C в любой момент аккуратно закрывает все соединения.

### Перед первым запуском

Откройте файл и проверьте два блока в начале:

- **`CONFIG`** — `WS_URL` по умолчанию `ws://127.0.0.1:8074`; измените его, если перенесли
  sidecar с порта по умолчанию. `RADE_SPS` (12000) и `RADE_SIDEBAND` (`USB`) должны совпадать
  с тем, что сообщает ваш веб-интерфейс.
- **`handshake_messages()`** — единственный отправляемый кадр `init` должен совпадать с
  инициализацией RADE в `frontend/src/audio.js`. Если это рукопожатие разошлось, каждый
  слушатель не сможет подключиться и тест сразу завершится ошибками соединения.

### Пороги излома

Настройте их в `CONFIG` по вкусу — они намеренно консервативны:

| Порог | По умолчанию | Останавливает, когда |
|---|---|---|
| `TEMP_KNEE_C` | `85.0` | Температура корпуса процессора достигает этого потолка |
| `MIN_AVAIL_MB` | `800` | Доступная ОЗУ опускается ниже этого значения |
| `SWAP_GROWTH_MB` | `50` | Swap вырастает сверх базового уровня, снятого при запуске |
| `FAIL_LIMIT` | `3` | Столько слушателей не смогли подключиться за один шаг |
| `MAX_LISTENERS` | `60` | Жёсткая остановка, даже если излом так и не достигнут |

Форму нарастания задают `STEP` (слушателей добавляется за шаг, по умолчанию 2), `SETTLE_S`
(25 с на устаканивание перед измерением — именно это позволяет накопиться теплу) и `SAMPLE_S`
(окно усреднения ЦП 5 с). Полный прогон до потолка в 60 слушателей занимает поэтому около
15 минут.

### Чтение результатов

Каждый шаг печатает строку и добавляет запись в `rade_loadtest.csv`:

| Столбец | Значение |
|---|---|
| `listeners` | Синтетических слушателей, подключённых на этом шаге |
| `connect_fails` | Слушатели, не сумевшие установить или удержать соединение |
| `pkg_c` | Температура корпуса процессора, медиана 5 измерений (устойчива к всплескам) |
| `cpu_pct` | Загрузка ЦП **всей системы**, а не на слушателя |
| `avail_mb` | Доступная ОЗУ |
| `swap_mb` | Используемый swap |
| `dec_rss_mb` | Суммарный RSS всех процессов декодирования |
| `dec_procs` | Число процессов декодирования — ожидается **2 на слушателя** (`radae_rxe.py` + `lpcnet_demo`) |

#### Реальный прогон

На упомянутом выше i5-12450H полный прогон завершился так:

```
KNEE at n=32: temp 91.0°C ≥ 85.0
Last stable concurrency: 30 RADE listeners
```

**Ограничивающим фактором оказалась температура**, причём с большим отрывом. На изломе ещё
оставалось 7004 МБ доступной ОЗУ — на 6,2 ГБ выше порога `MIN_AVAIL_MB` — и ноль отказов
соединения на каждом шаге.

Два столбца стоит читать внимательно:

**`dec_rss_mb` завышает реальные затраты памяти.** Он растёт очень ровно, на 295 МБ на
слушателя (292, 294, 294 … 295 на всех 16 шагах), но *доступная* ОЗУ убывает лишь примерно на
**202 МБ на слушателя**. Два процесса каждого слушателя разделяют страницы библиотек, а RSS
считает эти страницы по разу для каждого процесса. Экстраполируя наклон `avail_mb`, излом по
памяти пришёлся бы примерно на **63 слушателя** — за жёсткой остановкой в 60 слушателей, так
что на этой машине он никогда не сработает. Оценивайте память по `avail_mb`, а не по
`dec_rss_mb`.

**`cpu_pct` держится ровно — а потом нет.** Он остаётся около 5,3 % от всей машины до
24 слушателей, а затем растёт сверхлинейно:

| Слушателей | 24 | 26 | 28 | 30 | 32 |
|---|---|---|---|---|---|
| `cpu_pct` | 6,7 % | 18,4 % | 30,1 % | 49,6 % | 65,2 % |

Это десятикратный рост нагрузки при увеличении числа слушателей на треть. Точка перегиба
воспроизводится в одном и том же месте от прогона к прогону, поэтому считайте её свойством
машины, а не шумом: до перегиба затраты ЦП на слушателя составляют около 3,4 % ядра, а после —
около 20 %. Не экстраполируйте показатель ЦП на пользователя, снятый при малом числе
слушателей.

> **У теста нет излома по ЦП.** Четыре ограничителя — температура, доступная ОЗУ, рост swap и
> отказы соединений; загрузка ЦП фиксируется, но никогда не завершает прогон. В приведённом
> прогоне ЦП достиг 65 % и продолжал бы расти, если бы первой не сработала температура. Если
> вам важен потолок по ЦП, следите за столбцом сами либо добавьте порог.

> **Что это доказывает, а что нет.** Каждый синтетический слушатель передаёт случайный шум
> малой амплитуды, а не настоящий сигнал RADE. Этого достаточно, чтобы вся цепочка
> декодирования работала и потребляла ресурсы, поэтому цифры по ресурсам осмысленны — но тест
> ничего не говорит о *качестве* декодирования или непрерывности звука под нагрузкой.
> Проверяйте это на реальных слушателях с реальным сигналом.

### Если ядра насыщаются раньше излома

RADE жёстко закрепляет по одному потоку на экземпляр, поэтому отдельные ядра могут доходить до
~90 °C, пока общая загрузка ЦП выглядит низкой. `rade_helper.py` распределяет цепочки по ядрам
по кругу, чтобы этому противодействовать. Если прогон показывает ранние тепловые изломы,
расширьте выделение ядер на клиента:

```bash
RADE_CORES_PER_CLIENT=3 ./rade.sh restart
```

Править файлы не нужно — это переменная окружения (см.
[Переменные окружения](#переменные-окружения)); `RADE_PIN_CORES=0` полностью отключает
привязку.

---

## Обновление RADE v1

Интеграция с PhantomSDR-Plus (`rade_helper.py`, исправления веб-интерфейса) — это только мост;
вся логика декодирования RADE находится в репозитории `radae`. Поэтому обновления почти всегда
сводятся к простому `git pull` и пересборке, без изменений в самом PhantomSDR-Plus.

### Обычное обновление (новый код, та же модель)

```bash
# 1. Pull latest radae code
cd ~/radae
git pull

# 2. Rebuild lpcnet_demo (in case C code changed)
cd build
cmake ..
make -j$(nproc)

# 3. Restart the sidecar — no server restart needed
cd ~/PhantomSDR-Plus
./rade.sh restart
```

Это всё. Ни пересборки веб-интерфейса, ни перезапуска сервера, ни правки файлов.

### Только новые веса модели

Если вышел новый чекпойнт (например, `model20`) без изменений кода, укажите sidecar новые веса
через переменную окружения — править файлы не нужно:

```bash
# One-off: start with new model
RADE_MODEL=~/radae/model20/checkpoints/checkpoint_epoch_100.pth ./rade.sh start

# Or permanently — add to your shell profile (~/.bashrc):
export RADE_MODEL=~/radae/model20/checkpoints/checkpoint_epoch_100.pth
```

### Что требуется при каждом виде изменений

| Что изменилось в radae | Требуемое действие |
|---|---|
| Новые веса модели (новый файл `.pth`) | Задать переменную `RADE_MODEL`, `./rade.sh restart` |
| Изменение кода в `radae_rxe.py` | `git pull`, `./rade.sh restart` |
| Изменился код C в `lpcnet_demo` | `git pull`, пересборка, `./rade.sh restart` |
| `radae_rxe.py` переименован или перемещён | Обновить путь `RADAE_RX` в `rade_helper.py` (одна строка) |
| Аргумент `--model_name` переименован | Обновить `radae_cmd` в `rade_helper.py` (одна строка) |
| Новая выходная частота дискретизации (≠ 16000 Гц) | Обновить `SPS_OUT` в `rade_helper.py` + `createBuffer()` в `audio.js` |
| RADE v2 использует другой исполняемый файл | Обновить `RADAE_RX` в `rade_helper.py` (одна строка) |

### Проверка, что обновление сработало

После перезапуска убедитесь, что работает новый код:

```bash
# Check sidecar picked up new radae_rxe.py
./rade.sh status

# Tail log to see startup lines
tail -20 ~/PhantomSDR-Plus/rade.log
```

В журнале должен быть ожидаемый путь к модели:
```
[RADE] model : /home/sv1btl/radae/model19_check3/checkpoints/checkpoint_epoch_100.pth
```

### Как быть в курсе обновлений

Подпишитесь на страницу выпусков репозитория radae, чтобы получать уведомления о новых
моделях и обновлениях кода:

```
https://github.com/drowe67/radae/releases
```

Следите за блогом FreeDV для анонсов новых сигналов и моделей RADE:

```
https://freedv.org/blog/
```

---

*Разработано и проверено на PhantomSDR-Plus (форк sv1btl/PhantomSDR-Plus) с RX-888 MK2 на
Ubuntu 24.04. Сервер на C++ не изменяется.*

*RADE разрабатывают David Rowe VK5DGR и команда FreeDV.*
*См. [freedv.org/radio-autoencoder](https://freedv.org/radio-autoencoder).*

---

### Полное удаление и чистая переустановка

Вот полный демонтаж перед повторным запуском install_rade.sh:
1. Остановите sidecar
cd ~/PhantomSDR-Plus && ./rade.sh stop
2. Удалите репозиторий radae и сборку
rm -rf ~/radae
3. Удалите torch (установлен в локальный каталог пользователя)
pip3 uninstall -y torch
rm -rf ~/.local/lib/python3.11/site-packages/torch*
4. Удалите пакеты Python из apt (необязательно — пропустите, если их используют другие программы)
sudo apt-get remove -y python3-numpy python3-scipy python3-matplotlib python3-websockets
sudo apt-get autoremove -y
5. Убедитесь, что всё удалено
python3 -c "import torch" 2>&1        # should say ModuleNotFoundError
ls ~/radae 2>&1                        # should say No such file or directory
6. Чистая установка
chmod +x ~/PhantomSDR-Plus/install_rade.sh
~/PhantomSDR-Plus/install_rade.sh
