# Структура проекта PhantomSDR-Plus

Этот документ даёт полный обзор структуры каталогов PhantomSDR-Plus, организации файлов и связей между компонентами.

---

## Содержание

1. [Дерево каталогов](#дерево-каталогов)
2. [Корневой каталог](#корневой-каталог)
3. [Исходный код (`src/`)](#исходный-код-src)
4. [Веб-интерфейс (`frontend/`)](#веб-интерфейс-frontend)
5. [Списки частот (`frequencylist/`)](#списки-частот-frequencylist)
6. [Файлы конфигурации](#файлы-конфигурации)
7. [Система сборки](#система-сборки)

---

## Дерево каталогов
```
PhantomSDR-Plus
├── admin_config.json
├── admin_server.py
├── autorun
│   ├── audiotap.js
│   ├── bandplan.js
│   ├── decodeworker.js
│   ├── index.js
│   ├── manager.js
│   ├── package.json
│   ├── pool.js
│   ├── probe-ft8.js
│   ├── pskreporter.js
│   ├── spotparse.js
│   ├── wasm-shim.js
│   └── wsprnet.js
├── chat_history.txt
├── config-airspyhf.toml
├── config.example.hackrf.toml
├── config.example.rtlsdr.toml
├── config-rsp1a.toml
├── config-rtl.toml
├── config-rx888mk2.toml
├── config.toml
├── connection_impl.hpp
├── docs
│   ├── ADMIN_PANEL_SETUP.md
│   ├── DECODERS.md
│   ├── INSTALLATION.md
│   ├── PROJECT_STRUCTURE.md
│   ├── RADE_General_INSTALL_MANUAL_LINUX.md
│   ├── RADE_Pi_INSTALL_MANUAL.md
│   ├── RADE_README.md
│   ├── README.md
│   ├── sdr-stats
│   │   ├── install-stats-server.sh
│   │   ├── package.json
│   │   ├── README.md
│   │   └── system-stats-server.js
│   ├── USER_GUIDE.md
│   ├── websdr2.png
│   └── websdr.png
├── favicon.ico
├── fftw_wisdom
├── fix_local_geo.py
├── frequencylist
│   ├── 0.TXT
│   ├── A26all00.TXT
│   ├── a26allx2.zip
│   ├── admin.txt
│   ├── antenna.txt
│   ├── broadcas.txt
│   ├── curl-output.txt
│   ├── currentUpdateFile.txt
│   ├── fmorg.txt
│   ├── generate-current-shortwave.py
│   ├── language.txt
│   ├── mymarkers.json
│   ├── README.md
│   ├── shortwavestations.json
│   ├── site.txt
│   └── update-markers.sh
├── frontend
│   ├── build-all.sh
│   ├── build-analog.sh
│   ├── build-default.sh
│   ├── build-digital.sh
│   ├── build-v2-analog.sh
│   ├── build-v2-digital.sh
│   ├── debug-title.sh
│   ├── favicon.ico
│   ├── fix-title-python.py
│   ├── index.html
│   ├── jsconfig.json
│   ├── LICENSE
│   ├── package.json
│   ├── package-lock.json
│   ├── pnpm-lock.yaml
│   ├── postcss.config.cjs
│   ├── public
│   │   ├── analyze_users.py
│   │   ├── decoders
│   │   │   └── ft8_lib.wasm
│   │   ├── logo.jpg
│   │   ├── stats.html
│   │   ├── users.html
│   │   └── wf-message.json
│   ├── README.md
│   ├── site_information.json
│   ├── src
│   │   ├── App__analog_smeter_.svelte
│   │   ├── app.css
│   │   ├── App__digital_smeter_.svelte
│   │   ├── App.svelte
│   │   ├── App__v2_analog_smeter_.svelte
│   │   ├── App__v2_digital_smeter_.svelte
│   │   ├── assets
│   │   │   ├── amateurfrequencies.json
│   │   │   ├── background.jpg
│   │   │   ├── shortwavestations.json
│   │   │   └── svelte.png
│   │   ├── audio.js
│   │   ├── audio-stream-worklet.js
│   │   ├── bands-config.js
│   │   ├── cwDecoder.js
│   │   ├── cw.worker.js
│   │   ├── cwWorkerProxy.js
│   │   ├── decoder.worker.js
│   │   ├── eventBus.js
│   │   ├── events.js
│   │   ├── fax.js
│   │   ├── fax.worker.js
│   │   ├── faxWorkerProxy.js
│   │   ├── fft.js
│   │   ├── fsk.js
│   │   ├── fsk.worker.js
│   │   ├── fskWorkerProxy.js
│   │   ├── lib
│   │   │   ├── backend.js
│   │   │   ├── CheckButton.svelte
│   │   │   ├── colormaps.js
│   │   │   ├── Counter.svelte
│   │   │   ├── fftRadix2.js
│   │   │   ├── freedv-reporter.js
│   │   │   ├── FreeDVReporter.svelte
│   │   │   ├── FrequencyInput.svelte
│   │   │   ├── FrequencyMarkers.svelte
│   │   │   ├── FtxSpectrum.svelte
│   │   │   ├── hammeractions.js
│   │   │   ├── LineThroughButton.svelte
│   │   │   ├── Logger.svelte
│   │   │   ├── MagicEyeIndicator.svelte
│   │   │   ├── opusMlDecoder.js
│   │   │   ├── PassbandTuner.svelte
│   │   │   ├── Popover.svelte
│   │   │   ├── Spectrogram.svelte
│   │   │   ├── storage.js
│   │   │   ├── Tooltip.svelte
│   │   │   ├── VersionSelector.svelte
│   │   │   ├── VersionSelector.svelte.backup
│   │   │   ├── VideoAreaSelector.svelte
│   │   │   └── wrappers.js
│   │   ├── main.js
│   │   ├── modules
│   │   │   ├── decode.wasm
│   │   │   ├── encode.wasm
│   │   │   ├── ft4.js
│   │   │   ├── ft8.js
│   │   │   ├── package.json
│   │   │   ├── phantomsdrdsp_bg_fallback.js
│   │   │   ├── phantomsdrdsp_bg.js
│   │   │   ├── phantomsdrdsp_bg.wasm
│   │   │   ├── phantomsdrdsp_bg.wasm.d.ts
│   │   │   ├── phantomsdrdsp.d.ts
│   │   │   ├── phantomsdrdsp.js
│   │   │   ├── phantomsdrdsp_router.js
│   │   │   ├── README.md
│   │   │   └── wspr.js
│   │   ├── sstv.js
│   │   ├── sstv.worker.js
│   │   ├── sstvWorkerProxy.js
│   │   ├── unused
│   │   │   ├── AudioProcessor.js
│   │   │   ├── decoder.js
│   │   │   ├── decoding.js
│   │   │   ├── modules-emscripten
│   │   │   │   ├── dav1d.js
│   │   │   │   ├── dav1dnoWasm.js
│   │   │   │   ├── dav1dnoWasm.js.mem
│   │   │   │   ├── dav1d.wasm
│   │   │   │   ├── decode_ft8.js
│   │   │   │   ├── decode_ft8.wasm
│   │   │   │   ├── FoxenFlac.js
│   │   │   │   ├── jsDSP.js
│   │   │   │   ├── jsDSPnoWasm.js
│   │   │   │   ├── jsDSPnoWasm.js.mem
│   │   │   │   ├── jsDSPnoWasm.wasm
│   │   │   │   ├── jsDSP.wasm
│   │   │   │   ├── libzstd.js
│   │   │   │   ├── LiquidDSP.js
│   │   │   │   ├── opus.js
│   │   │   │   ├── opusnoWasm.js
│   │   │   │   ├── opusnoWasm.js.mem
│   │   │   │   ├── opus.wasm
│   │   │   │   ├── redsea.js
│   │   │   │   └── redsea.wasm
│   │   │   ├── unused.js
│   │   │   └── wrappers.js
│   │   ├── videoRecorder.js
│   │   ├── vite-env.d.ts
│   │   └── waterfall.js
│   ├── stats.html
│   ├── svelte.config.js
│   ├── switch-version.sh
│   ├── tailwind.config.cjs
│   └── vite.config.js
├── install_arch.sh
├── install-Deb12.sh
├── install_fedora.sh
├── install_opensuse.sh
├── install_rade.sh
├── install_rade_ubuntu22.sh
├── install.sh
├── install-stats-server.sh
├── instructions-for-airspy
├── instructions-for-rsp1a
├── jsdsp
│   ├── compilejs.sh
│   ├── configureredsea.sh
│   ├── extract_EXPORTED_FUNCTIONS.js
│   ├── include
│   │   ├── avif
│   │   │   ├── avif.h
│   │   │   └── internal.h
│   │   └── liquid
│   │       └── liquid.h
│   ├── lib
│   │   ├── ANR.c
│   │   ├── arm_funcs.h
│   │   ├── CMSIS_DSP
│   │   │   ├── BUILDING.txt
│   │   │   └── LICENSE.txt
│   │   ├── dav1d.cpp
│   │   ├── NB.c
│   │   ├── NR_spectral.c
│   │   └── types.h
│   ├── redsea.js
│   ├── redsea.wasm
│   └── src
│       ├── index.js
│       ├── libzstd.js
│       ├── LiquidDSP.js
│       ├── NoiseProcessing.js
│       └── wbfmpll.cpp
├── LICENSE
├── logrotate
│   └── phantomsdr             # logrotate config for proxy.log + admin.log (edit paths before installing)
├── manage_admin.sh
├── markers.json
├── meson.build
├── meson_options.txt
├── phantom_fftw_wisdom
├── proxy.py
├── rade_helper.py
├── rade_loadtest.csv          # output of rade_loadtest.py (one row per ramp step)
├── rade_loadtest.py           # RADE concurrency knee test — see docs/RADE_README.md
├── rade.sh
├── README.md
├── recompile.sh
├── request.hpp
├── setup_admin.sh
├── src
│   ├── audio.cpp
│   ├── audio.h
│   ├── chat.cpp
│   ├── chat.h
│   ├── client.cpp
│   ├── client.h
│   ├── compression.cpp
│   ├── compression.h
│   ├── crash_handler.cpp
│   ├── crash_handler.h
│   ├── events.cpp
│   ├── events.h
│   ├── fft.cpp
│   ├── fft_cuda.cu
│   ├── fft.h
│   ├── fft_impl.cpp
│   ├── fft_mkl.cpp
│   ├── http.cpp
│   ├── listing
│   │   ├── software_info.cpp
│   │   └── software_info.h
│   ├── samplereader.cpp
│   ├── samplereader.h
│   ├── signal.cpp
│   ├── signal.h
│   ├── spectrumserver.cpp
│   ├── spectrumserver.h
│   ├── utils
│   │   ├── audioprocessing.cpp
│   │   ├── audioprocessing.h
│   │   ├── dsp.cpp
│   │   └── dsp.h
│   ├── utils.cpp
│   ├── utils.h
│   ├── waterfallcompression.cpp
│   ├── waterfallcompression.h
│   ├── waterfall.cpp
│   ├── waterfall.h
│   ├── websocket.cpp
│   └── websocket.h
├── start-airspyhf.sh
├── start-all-websdr.sh
├── start-rsp1a.sh
├── start-rtl.sh
├── start-rx888mk2.sh
├── stop-websdr.sh
├── setup-rx888-udev.sh
└── subprojects
    ├── fftw3.wrap
    ├── flac.wrap
    ├── glaze.wrap
    ├── libcds.wrap
    ├── libflac.wrap
    ├── libvolk.wrap
    ├── ogg.wrap
    ├── opus.wrap
    ├── tomlplusplus-3.4.0
    │   ├── CHANGELOG.md
    │   ├── cmake
    │   │   ├── install-rules.cmake
    │   │   ├── project-is-top-level.cmake
    │   │   ├── tomlplusplusConfig.cmake
    │   │   ├── tomlplusplusConfig.cmake.meson.in
    │   │   ├── tomlplusplusConfigVersion.cmake.meson.in
    │   │   └── variables.cmake
    │   ├── CMakeLists.txt
    │   ├── CODE_OF_CONDUCT.md
    │   ├── CONTRIBUTING.md
    │   ├── cpp.hint
    │   ├── docs
    │   │   ├── images
    │   │   │   ├── badge-awesome.svg
    │   │   │   ├── badge-C++17.svg
    │   │   │   ├── badge-gitter.svg
    │   │   │   ├── badge-license-MIT.svg
    │   │   │   ├── badge-TOML.svg
    │   │   │   ├── banner.ai
    │   │   │   ├── banner.png
    │   │   │   ├── banner.svg
    │   │   │   ├── favicon.ico
    │   │   │   ├── logo.ai
    │   │   │   └── logo.svg
    │   │   ├── pages
    │   │   │   └── main_page.md
    │   │   └── poxy.toml
    │   ├── examples
    │   │   ├── benchmark_data.toml
    │   │   ├── CMakeLists.txt
    │   │   ├── error_printer.cpp
    │   │   ├── error_printer.vcxproj
    │   │   ├── examples.hpp
    │   │   ├── example.toml
    │   │   ├── merge_base.toml
    │   │   ├── merge_overrides.toml
    │   │   ├── meson.build
    │   │   ├── parse_benchmark.cpp
    │   │   ├── parse_benchmark.vcxproj
    │   │   ├── simple_parser.cpp
    │   │   ├── simple_parser.vcxproj
    │   │   ├── toml_generator.cpp
    │   │   ├── toml_generator.vcxproj
    │   │   ├── toml_merger.cpp
    │   │   ├── toml_merger.vcxproj
    │   │   ├── toml_to_json_transcoder.cpp
    │   │   └── toml_to_json_transcoder.vcxproj
    │   ├── include
    │   │   ├── meson.build
    │   │   └── toml++
    │   │       ├── impl
    │   │       │   ├── array.hpp
    │   │       │   ├── array.inl
    │   │       │   ├── at_path.hpp
    │   │       │   ├── at_path.inl
    │   │       │   ├── date_time.hpp
    │   │       │   ├── formatter.hpp
    │   │       │   ├── formatter.inl
    │   │       │   ├── forward_declarations.hpp
    │   │       │   ├── header_end.hpp
    │   │       │   ├── header_start.hpp
    │   │       │   ├── json_formatter.hpp
    │   │       │   ├── json_formatter.inl
    │   │       │   ├── key.hpp
    │   │       │   ├── make_node.hpp
    │   │       │   ├── node.hpp
    │   │       │   ├── node.inl
    │   │       │   ├── node_view.hpp
    │   │       │   ├── parse_error.hpp
    │   │       │   ├── parse_result.hpp
    │   │       │   ├── parser.hpp
    │   │       │   ├── parser.inl
    │   │       │   ├── path.hpp
    │   │       │   ├── path.inl
    │   │       │   ├── preprocessor.hpp
    │   │       │   ├── print_to_stream.hpp
    │   │       │   ├── print_to_stream.inl
    │   │       │   ├── simd.hpp
    │   │       │   ├── source_region.hpp
    │   │       │   ├── std_except.hpp
    │   │       │   ├── std_initializer_list.hpp
    │   │       │   ├── std_map.hpp
    │   │       │   ├── std_new.hpp
    │   │       │   ├── std_optional.hpp
    │   │       │   ├── std_string.hpp
    │   │       │   ├── std_string.inl
    │   │       │   ├── std_utility.hpp
    │   │       │   ├── std_variant.hpp
    │   │       │   ├── std_vector.hpp
    │   │       │   ├── table.hpp
    │   │       │   ├── table.inl
    │   │       │   ├── toml_formatter.hpp
    │   │       │   ├── toml_formatter.inl
    │   │       │   ├── unicode_autogenerated.hpp
    │   │       │   ├── unicode.hpp
    │   │       │   ├── unicode.inl
    │   │       │   ├── value.hpp
    │   │       │   ├── version.hpp
    │   │       │   ├── yaml_formatter.hpp
    │   │       │   └── yaml_formatter.inl
    │   │       ├── toml.h
    │   │       └── toml.hpp
    │   ├── LICENSE
    │   ├── meson.build
    │   ├── meson_options.txt
    │   ├── README.md
    │   ├── src
    │   │   ├── meson.build
    │   │   └── toml.cpp
    │   ├── tests
    │   │   ├── at_path.cpp
    │   │   ├── conformance_burntsushi_invalid.cpp
    │   │   ├── conformance_burntsushi_valid.cpp
    │   │   ├── conformance_iarna_invalid.cpp
    │   │   ├── conformance_iarna_valid.cpp
    │   │   ├── cpp.hint
    │   │   ├── for_each.cpp
    │   │   ├── formatters.cpp
    │   │   ├── impl_toml.cpp
    │   │   ├── leakproof.hpp
    │   │   ├── lib_catch2.hpp
    │   │   ├── main.cpp
    │   │   ├── manipulating_arrays.cpp
    │   │   ├── manipulating_parse_result.cpp
    │   │   ├── manipulating_tables.cpp
    │   │   ├── manipulating_values.cpp
    │   │   ├── meson.build
    │   │   ├── odr_test_1.cpp
    │   │   ├── odr_test_2.cpp
    │   │   ├── parsing_arrays.cpp
    │   │   ├── parsing_booleans.cpp
    │   │   ├── parsing_comments.cpp
    │   │   ├── parsing_dates_and_times.cpp
    │   │   ├── parsing_floats.cpp
    │   │   ├── parsing_integers.cpp
    │   │   ├── parsing_key_value_pairs.cpp
    │   │   ├── parsing_spec_example.cpp
    │   │   ├── parsing_strings.cpp
    │   │   ├── parsing_tables.cpp
    │   │   ├── path.cpp
    │   │   ├── settings.hpp
    │   │   ├── tests.cpp
    │   │   ├── tests.hpp
    │   │   ├── user_feedback.cpp
    │   │   ├── using_iterators.cpp
    │   │   ├── visit.cpp
    │   │   ├── vs
    │   │   │   ├── odr_test.vcxproj
    │   │   │   ├── test_debug_x64_cpplatest_noexcept_unrel.vcxproj
    │   │   │   ├── test_debug_x64_cpplatest_noexcept.vcxproj
    │   │   │   ├── test_debug_x64_cpplatest_unrel.vcxproj
    │   │   │   ├── test_debug_x64_cpplatest.vcxproj
    │   │   │   ├── test_debug_x64_noexcept_unrel.vcxproj
    │   │   │   ├── test_debug_x64_noexcept.vcxproj
    │   │   │   ├── test_debug_x64_unrel.vcxproj
    │   │   │   ├── test_debug_x64.vcxproj
    │   │   │   ├── test_debug_x86_cpplatest_noexcept_unrel.vcxproj
    │   │   │   ├── test_debug_x86_cpplatest_noexcept.vcxproj
    │   │   │   ├── test_debug_x86_cpplatest_unrel.vcxproj
    │   │   │   ├── test_debug_x86_cpplatest.vcxproj
    │   │   │   ├── test_debug_x86_noexcept_unrel.vcxproj
    │   │   │   ├── test_debug_x86_noexcept.vcxproj
    │   │   │   ├── test_debug_x86_unrel.vcxproj
    │   │   │   ├── test_debug_x86.vcxproj
    │   │   │   ├── test_release_x64_cpplatest_noexcept_unrel.vcxproj
    │   │   │   ├── test_release_x64_cpplatest_noexcept.vcxproj
    │   │   │   ├── test_release_x64_cpplatest_unrel.vcxproj
    │   │   │   ├── test_release_x64_cpplatest.vcxproj
    │   │   │   ├── test_release_x64_noexcept_unrel.vcxproj
    │   │   │   ├── test_release_x64_noexcept.vcxproj
    │   │   │   ├── test_release_x64_unrel.vcxproj
    │   │   │   ├── test_release_x64.vcxproj
    │   │   │   ├── test_release_x86_cpplatest_noexcept_unrel.vcxproj
    │   │   │   ├── test_release_x86_cpplatest_noexcept.vcxproj
    │   │   │   ├── test_release_x86_cpplatest_unrel.vcxproj
    │   │   │   ├── test_release_x86_cpplatest.vcxproj
    │   │   │   ├── test_release_x86_noexcept_unrel.vcxproj
    │   │   │   ├── test_release_x86_noexcept.vcxproj
    │   │   │   ├── test_release_x86_unrel.vcxproj
    │   │   │   └── test_release_x86.vcxproj
    │   │   └── windows_compat.cpp
    │   ├── toml++.code-workspace
    │   ├── toml.hpp
    │   ├── toml++.natvis
    │   ├── toml++.props
    │   ├── toml++.sln
    │   ├── toml-test
    │   │   ├── meson.build
    │   │   ├── README.md
    │   │   ├── tt_decoder.cpp
    │   │   ├── tt_decoder.vcxproj
    │   │   ├── tt_encoder.cpp
    │   │   ├── tt_encoder.vcxproj
    │   │   └── tt.hpp
    │   ├── toml++.vcxproj
    │   ├── toml++.vcxproj.filters
    │   ├── tools
    │   │   ├── ci_single_header_check.py
    │   │   ├── clang_format.bat
    │   │   ├── generate_conformance_tests.py
    │   │   ├── generate_single_header.bat
    │   │   ├── generate_single_header.py
    │   │   ├── generate_windows_test_targets.py
    │   │   ├── requirements.txt
    │   │   ├── utils.py
    │   │   └── version.py
    │   └── vendor
    │       ├── catch.hpp
    │       ├── json.hpp
    │       └── README.md
    ├── tomlplusplus.wrap
    ├── websocketpp.wrap
    ├── zlib.wrap
    └── zstd.wrap


```
---

## Корневой каталог

### Файлы конфигурации

| Файл | Назначение | Когда изменять |
|------|------------|----------------|
| `config.toml` | Конфигурация по умолчанию | Первичная настройка, тесты |
| `config-rtl.toml` | Конфигурация для RTL-SDR | При использовании RTL-SDR |
| `config-rsp1a.toml` | Конфигурация SDRplay RSP1A | При использовании RSP1A |
| `config-airspyhf.toml` | Конфигурация Airspy HF+ | При использовании Airspy |
| `config-rx888mk2.toml` | Конфигурация RX888 MK2 | При использовании RX888 |
| `config.example.hackrf.toml` | Пример для HackRF One | При использовании HackRF |

### Скрипты запуска и остановки

Каждый из приведённых ниже `start-*.sh` — это **самодостаточный лаунчер + сторожевой процесс
+ журналирование**: он останавливает запущенный экземпляр, поднимает приёмник +
`spectrumserver`, уходит в фоновый режим, автоматически перезапускает цепочку при её
завершении и ведёт журнал в `logwebsdr.txt`. У них общий скрипт остановки и единая блокировка
`flock` (одновременно работает только один приёмник). Правьте только блок
**RECEIVER CONFIGURATION** в начале каждого (аргументы приёмника / конфигурация / имя процесса).

| Скрипт | Назначение |
|--------|------------|
| `install.sh` | Автоматизированная установка и сборка |
| `start-rtl.sh` | Запуск + сторожевой процесс сервера с RTL-SDR (`rtl_sdr`) |
| `start-rsp1a.sh` | Запуск + сторожевой процесс сервера с SDRplay RSP1A (`rx_sdr`) |
| `start-airspyhf.sh` | Запуск + сторожевой процесс сервера с Airspy HF+ (`rx_sdr`) |
| `start-rx888mk2.sh` | Запуск + сторожевой процесс сервера с RX888 MK2 (`rx888_stream`) |
| `start-all-websdr.sh` | Запуск нескольких экземпляров (простая утилита, без сторожа) |
| `stop-websdr.sh` | Остановка сервера и его сторожевого процесса — общий для всех приёмников |
| `setup-rx888-udev.sh` | Устанавливает правила udev, чтобы `rx888_stream` для RX-888 работал без sudo |

### Файлы данных

| Файл | Назначение | Формат |
|------|------------|--------|
| `markers.json` | Частотные закладки и маркеры | JSON |
| `chat_history.txt` | Сообщения чата пользователей | Обычный текст |
| `favicon.ico` | Значок сайта | Изображение ICO |
| `fftw_wisdom` | Данные оптимизации FFT | Двоичный формат FFTW |
| `phantom_fftw_wisdom` | Дополнительная оптимизация FFT | Двоичный формат FFTW |

### Файлы системы сборки

| Файл | Назначение |
|------|------------|
| `meson.build` | Основная конфигурация сборки |
| `meson_options.txt` | Настраиваемые параметры сборки |
| `.gitattributes` | Атрибуты репозитория Git |

---

## Исходный код (`src/`)

Каталог `src/` содержит реализацию серверной части на C++.

### Ключевые компоненты

#### 1. Основное приложение (`main.cpp`)
- Разбирает аргументы командной строки
- Загружает файл конфигурации
- Инициализирует компоненты сервера
- Запускает цикл событий

#### 2. Сервер спектра (`spectrumserver.cpp`)
- Координирует все компоненты
- Управляет подключениями пользователей
- Раздаёт данные спектра
- Обрабатывает запросы пользователей

#### 3. Драйверы SDR (`drivers/`)
- Абстрактный интерфейс для оборудования SDR
- Чтение и форматирование данных отсчётов
- Обработка особенностей конкретных устройств

#### 4. Движок ЦОС (`dsp/`)
- Расчёт FFT (с ускорением на ЦП/GPU)
- Демодуляция (AM, FM, SSB, CW и др.)
- Фильтрация и передискретизация звука
- АРУ и шумоподавление

#### 5. Веб-сервер (`server/`)
- Обмен по WebSocket
- Раздача статических файлов по HTTP
- Управление сеансами пользователей
- Потоковая передача данных в реальном времени

#### 6. Кодирование звука (`audio/`)
- Сжатие FLAC
- Сжатие Opus
- Оптимизация потоковой передачи

---

## Веб-интерфейс (`frontend/`)

Веб-интерфейс пользователя, построенный на Svelte и Vite.


#### 1. Основное приложение (`App.svelte`)
- Компонент верхнего уровня
- Структура компоновки
- Оркестрация компонентов

#### 2. Отображение водопада (`Waterfall.svelte`)
- Визуализация спектра на canvas
- Интерактивная настройка
- Наложение band plan

#### 3. Органы управления (`Controls.svelte`)
- Ввод/отображение частоты
- Выбор режима (AM/FM/SSB/CW)
- Полоса пропускания фильтра
- Органы управления АРУ/NR/NB

#### 4. Аудиосистема (`audio.js`)
- Аудиопоток по WebSocket
- Декодирование FLAC/Opus
- Управление воспроизведением звука
- Раздаёт исходный PCM (снятый до АРУ, шумоподавления и отключения звука) декодерам режимов

#### 4a. Декодеры режимов и их воркеры

Каждый из тяжёлых декодеров режимов работает в собственном Web Worker, поэтому декодирование никогда не блокирует воспроизведение звука и водопад. Все они следуют общей схеме — по три файла на декодер:

| Декодер | Движок | Воркер | Прокси в основном потоке |
|---------|--------|--------|---------------------------|
| SSTV | `sstv.js` | `sstv.worker.js` | `sstvWorkerProxy.js` |
| HF FAX | `fax.js` | `fax.worker.js` | `faxWorkerProxy.js` |
| NAVTEX + FSK/RTTY | `fsk.js` | `fsk.worker.js` | `fskWorkerProxy.js` |
| CW | `cwDecoder.js` | `cw.worker.js` | `cwWorkerProxy.js` |

- **Движок** — это чистый код ЦОС, ничего не знающий о воркерах, поэтому его можно запускать и напрямую (модульные тесты или запасной режим в основном потоке).
- **Воркер** держит один экземпляр движка и дословно пересылает его события.
- **Прокси** повторяет набор методов движка, так что `audio.js` вызывает его точно так же, как вызывал бы сам декодер. Он создаёт воркер лениво, при первом включении, и переходит к работе в основном потоке, если воркеры недоступны.

Две детали здесь принципиальны: PCM **копируется** в новый буфер перед передачей воркеру (передача представления на аудионакопитель отсоединила бы его и остановила воспроизведение), а сообщение `init` воркера повторно применяет конфигурацию к уже работающему движку, а не предполагает создание нового.

`fsk.js` обслуживает и NAVTEX, и FSK/RTTY из одного движка, выбор задаётся для каждого экземпляра полем `role`; у каждого экземпляра своё состояние, поэтому оба могут работать независимо.

#### 5. Управление состоянием (`stores/`)
- Реактивные хранилища данных
- Общее состояние приложения
- Обработка событий

---

### Ключевые возможности

- Обработка звука в реальном времени
- Декодирование цифровых видов связи (FT8, RTTY и др.)
- Фильтрация звука
- Спектральный анализ

---


## Списки частот (`frequencylist/`)

Файлы базы данных с распределением частот и сведениями о станциях.

```
frequencylist/
├── stations.csv              # Station database
├── repeaters.csv             # Repeater frequencies
├── broadcast.csv             # Broadcast stations
└── ...                       # Additional lists
```

### Пример формата (`stations.csv`)

```csv
Frequency,Mode,Description,Band
7100000,LSB,40m Phone,40m
14200000,USB,20m Phone,20m
145500000,FM,2m Calling,2m
```

---

## Файлы конфигурации

### Конфигурация сервера (файлы `.toml`)

Структура файлов конфигурации:

```toml
[server]
# Web server settings
port = 9002
html_root = "frontend/dist/"
threads = 2
otherusers = 1

[websdr]
# Online registration
register_online = true
name = "WebSDR Name"
antenna = "Antenna Type"
grid_locator = "AB12cd"
hostname = "domain.com"

[input]
# SDR input settings
sps = 2048000           # Sample rate
fft_size = 131072       # FFT size
frequency = 145000000   # Base frequency
signal = "iq"           # Signal type: "iq" or "real"
audio_sps = 12000       # Audio sample rate
audio_compression = "opus"  # "flac" or "opus"
accelerator = "opencl"  # "none", "cuda", "opencl"

[input.driver]
# Driver settings
name = "stdin"
format = "u8"           # Sample format

[input.defaults]
# User interface defaults
frequency = 145500000
modulation = "FM"
```

### Сведения о площадке (`site-information.json`)

```json
{
  "siteSysop": "Operator Callsign",
  "siteSysopEmailAddress": "email@example.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Hardware specs",
  "siteSoftware": "Software version",
  "siteReceiver": "SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional notes",
  "siteIP": "http://domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

---

## Система сборки

### Конфигурация сборки Meson

#### `meson.build` (корень)

Определяет:
- Метаданные проекта
- Зависимости
- Параметры компилятора
- Списки исходных файлов
- Цели сборки

#### `meson_options.txt`

Доступные параметры:
```
option('opencl', type: 'boolean', value: false, description: 'Enable OpenCL support')
option('cuda', type: 'boolean', value: false, description: 'Enable CUDA support')
option('optimization', type: 'string', value: '3', description: 'Optimization level')
```

---

## Зависимости файлов

### Зависимости сборки серверной части

```
spectrumserver binary depends on:
├── C++ source files (src/**/*.cpp)
├── External libraries:
│   ├── FFTW3
│   ├── WebSocket++
│   ├── FLAC
│   ├── Opus
│   ├── Liquid-DSP
│   ├── Boost
│   ├── zlib
│   ├── zstd
│   └── OpenCL/CUDA (optional)
└── Subproject headers:
    ├── nlohmann/json
    └── toml11
```

### Зависимости сборки веб-интерфейса

```
frontend/dist/ depends on:
├── Source files (frontend/src/**)
├── npm packages (node_modules/):
│   ├── Svelte
│   ├── Vite
│   ├── @wasm-audio-decoders/opus-ml
│   └── ...
└── Static assets (frontend/public/)
```

---

## Поток данных

### Порядок работы сервера

```
1. SDR Hardware → rtl_sdr/hackrf_transfer/etc.
                ↓
2. Sample Stream → stdin → spectrumserver
                ↓
3. spectrumserver:
   - FFT calculation (waterfall)
   - Demodulation (audio)
   - Compression (FLAC/Opus)
                ↓
4. WebSocket → Browser Client
                ↓
5. Browser:
   - Render waterfall
   - Decode and play audio
   - Display controls
```

### Порядок взаимодействия с пользователем

```
1. User clicks on waterfall
                ↓
2. JavaScript sends frequency change request
                ↓
3. WebSocket → spectrumserver
                ↓
4. spectrumserver:
   - Updates demodulator frequency
   - Sends new audio stream
                ↓
5. Browser receives and plays new audio
```

---

## Руководство по изменению файлов

### Когда вы изменяете код серверной части (`src/**`):

```bash
cd PhantomSDR-Plus
meson compile -C build
# Server restart required
```

### Когда вы изменяете код веб-интерфейса (`frontend/src/**`):

```bash
cd PhantomSDR-Plus/frontend
npm run build
cd ..
# Server restart required (for static files)
```

### Когда вы изменяете конфигурацию (`.toml`, `.json`):

```bash
# Restart server
./stop-websdr.sh
./start-rtl.sh  # (or appropriate start script)
```

### Когда вы изменяете маркеры (`markers.json`):

```bash
# Reload page in browser
# No server restart needed
```

---

## Важные пути

### Пути времени выполнения

- **Конфигурация**: `./config-*.toml`
- **Корень HTML**: `./frontend/dist/`
- **Маркеры**: `./markers.json`
- **История чата**: `./chat_history.txt`
- **FFTW wisdom**: `./fftw_wisdom`, `./phantom_fftw_wisdom`

### Пути сборки

- **Готовый исполняемый файл**: `./build/spectrumserver`
- **Результат сборки веб-интерфейса**: `./frontend/dist/`
- **Модули Node**: `./frontend/node_modules/`

### Пути исходного кода

- **Исходники серверной части**: `./src/`
- **Исходники веб-интерфейса**: `./frontend/src/`
- **Библиотеки ЦОС**: `./jsdsp/`

---

## Типичные операции с файлами

### Добавление новой конфигурации SDR

1. Скопируйте существующую конфигурацию: `cp config-rtl.toml config-mydevice.toml`
2. Отредактируйте параметры: `nano config-mydevice.toml`
3. Создайте скрипт запуска: `cp start-rtl.sh start-mydevice.sh`
4. Отредактируйте скрипт запуска: `nano start-mydevice.sh` — меняйте только блок
   **RECEIVER CONFIGURATION** в начале (`RX_LABEL`, `RX_COMM` — имя процесса приёмника,
   `RX_ARGS`, `CONFIG`, `FIFO`, а также хук `prestart`, если он нужен устройству). Логика
   запуска/сторожа/журналирования ниже универсальна и правок не требует.
5. Сделайте его исполняемым: `chmod +x start-mydevice.sh`

> `stop-websdr.sh` уже останавливает любой `start-*.sh --watchdog`; если ваш приёмник
> использует имя процесса, отличное от `rx888_stream`/`rx_sdr`/`rtl_sdr`, добавьте туда
> строку `killall -9 <имя>` и для него.

### Настройка веб-интерфейса под себя

1. Измените исходный код: `nano frontend/src/App.svelte`
2. Пересоберите: `cd frontend && npm run build && cd ..`
3. Перезапустите сервер: `./stop-websdr.sh && ./start-rtl.sh`

### Добавление собственных маркеров

1. Отредактируйте файл маркеров: `nano markers.json`
2. Формат:
   ```json
   {
     "markers": [
       {
         "frequency": 145500000,
         "label": "2m Calling",
         "mode": "FM"
       }
     ]
   }
   ```
3. Перезагрузите страницу в браузере (перезапуск сервера не нужен)

---

## Контроль версий

### Файлы, отслеживаемые в Git

- Исходный код (`src/`, `frontend/src/`, `jsdsp/`)
- Примеры конфигурации (`config.example.*.toml`)
- Система сборки (`meson.build`, `meson_options.txt`)
- Документация (`*.md`, `docs/`)
- Скрипты (`*.sh`)

### Файлы, которые следует игнорировать (`.gitignore`)

- Результаты сборки (`build/`, `frontend/dist/`)
- Зависимости (`frontend/node_modules/`)
- Пользовательские данные (`chat_history.txt`)
- Личные конфигурации (`config-rtl.toml`, если он изменён)
- Двоичные данные (`*.o`, `*.so`)

---

**Это описание структуры поможет вам ориентироваться в кодовой базе PhantomSDR-Plus и понимать её.**

Инструкции по установке см. в [INSTALLATION.md](INSTALLATION.md).
Сведения об использовании см. в [USER_GUIDE.md](USER_GUIDE.md).

**73 de SV1BTL & SV2AMK**
