#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  PhantomSDR-Plus  –  start-rx888mk2.sh
#  Universal launcher + watchdog for an RX-888 (MkII) front end.
#
#  One self-contained script that STARTS, RESTARTS, WATCHDOGS (auto-restarts on
#  failure) and LOGS the server. It derives its own directory, so it works from
#  wherever the repo is cloned — no hard-coded paths or user-specific files.
#
#  Usage:
#    ./start-rx888mk2.sh            start (or restart) the server in the background
#    ./stop-websdr.sh              stop the server + watchdog (separate script)
#
#  Env overrides (all optional):
#    SPECTRUM_CORES=0-3            pin spectrumserver to these CPUs (taskset list)
#    SPECTRUM_CORES=none          do not pin at all
#    RX888_ARGS="…"               override the rx888_stream argument string
#
#  Internal (spawned detached by the launcher — do not call by hand):
#    ./start-rx888mk2.sh --watchdog
# ─────────────────────────────────────────────────────────────────────────────

# Resolve this script's own directory (the repo root) — no absolute paths.
PHANTOMDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SELF="$PHANTOMDIR/$(basename "${BASH_SOURCE[0]}")"

# Paths, all relative to the repo root.
LOG="$PHANTOMDIR/logwebsdr.txt"
FIFO="$PHANTOMDIR/rx888.fifo"
CONFIG="$PHANTOMDIR/config-rx888mk2.toml"
SPECTRUM="$PHANTOMDIR/build/spectrumserver"
RX888="$PHANTOMDIR/rx888_stream/target/release/rx888_stream"
RX888_IMG="$PHANTOMDIR/rx888_stream/SDDC_FX3.img"
STOP="$PHANTOMDIR/stop-websdr.sh"

# rx888_stream tuning (override with RX888_ARGS if your hardware needs it).
RX888_ARGS="${RX888_ARGS:--f $RX888_IMG -s 60000000 -g 40 -a 0 -m low --pga -d -r -o -}"

# Runtime state (children we own, so we can reap them).
SS_PID=""
RX_PID=""
SS_TASKSET=()

# ── logging helpers ─────────────────────────────────────────────────────────
log()   { echo "$*"          >> "$LOG"; }
stamp() { date --rfc-email   >> "$LOG"; }

# ── is a process alive (by exact command name), excluding zombies? ───────────
# $1 = process command name (e.g. spectrumserver, rx888_stream)
is_running() {
    local pid stat
    for pid in $(pgrep -x "$1" 2>/dev/null); do
        stat=$(awk '{print $3}' "/proc/$pid/stat" 2>/dev/null)
        case "$stat" in Z) ;; "") ;; *) return 0 ;; esac   # any non-zombie => running
    done
    return 1
}

# ── kill only the receiver/server processes (never the watchdog) ─────────────
# Writer (rx888_stream) first, then reader (spectrumserver): killing the reader
# first would hand the writer a Broken-Pipe panic on the FIFO.
kill_receivers() {
    killall -KILL rx888_stream 2>/dev/null
    sleep 1
    killall -KILL spectrumserver 2>/dev/null
    sleep 2
    # Reap any zombie children we own so is_running sees a clean slate.
    [ -n "$RX_PID" ] && wait "$RX_PID" 2>/dev/null; RX_PID=""
    [ -n "$SS_PID" ] && wait "$SS_PID" 2>/dev/null; SS_PID=""
}

# ── derive an optional CPU pin for spectrumserver ────────────────────────────
# On boxes with >4 cores, pin the FFT/audio threads to the lower cores and keep
# the top few free (reduces waterfall/audio jitter, heat-neutral). Fully generic
# via nproc; SPECTRUM_CORES overrides (a list to pin, or none/off to disable).
compute_taskset() {
    SS_TASKSET=()
    command -v taskset >/dev/null 2>&1 || return
    local override nproc reserve hi
    case "$(printf '%s' "${SPECTRUM_CORES:-}" | tr '[:upper:]' '[:lower:]')" in
        "")                override="" ;;              # unset -> auto-derive
        none|off|unpinned) return ;;                   # explicit: do not pin
        *[!0-9,-]*)        override="" ;;              # invalid -> auto-derive
        *)                 override="$SPECTRUM_CORES" ;;
    esac
    if [ -n "$override" ]; then
        SS_TASKSET=(taskset -c "$override")
        return
    fi
    nproc=$(nproc 2>/dev/null || echo 0)
    if [ "$nproc" -gt 4 ]; then
        if [ "$nproc" -ge 12 ]; then reserve=4; else reserve=$(( nproc / 4 )); [ "$reserve" -lt 1 ] && reserve=1; fi
        hi=$(( nproc - reserve - 1 ))
        SS_TASKSET=(taskset -c "0-$hi")
    fi
}

# ── start rx888_stream (with FIFO pre-open + retry) ──────────────────────────
# bash blocks on opening a FIFO for write until a reader exists, which hides a
# failed rx888_stream behind a blocked shell fork. Pre-opening the FIFO O_RDWR
# on fd 8 provides that reader, so rx888_stream execs immediately and kill -0
# then tests the real process. fd 8 is closed once spectrumserver holds the
# read end (see start_spectrumserver). Returns 0 if rx888_stream stays up.
start_rx888() {
    local attempt
    for attempt in 1 2 3; do
        log "Starting rx888_stream (attempt $attempt/3)..."
        rm -f "$FIFO"
        mkfifo "$FIFO"
        exec 8<>"$FIFO"
        # shellcheck disable=SC2086
        "$RX888" $RX888_ARGS > "$FIFO" &
        RX_PID=$!
        sleep 5
        if kill -0 "$RX_PID" 2>/dev/null; then
            log "rx888_stream running (PID $RX_PID)"
            return 0
        fi
        exec 8>&-           # close pre-opened fd before retrying
        RX_PID=""
        sleep 5
    done
    return 1
}

# ── start spectrumserver, then release the pre-opened FIFO fd ─────────────────
start_spectrumserver() {
    "${SS_TASKSET[@]}" "$SPECTRUM" --config "$CONFIG" < "$FIFO" &
    SS_PID=$!
    sleep 2
    exec 8>&-               # spectrumserver holds the read end now; drop our fd
    sleep 3
}

# ── bring the whole chain up and confirm it (polls, no fixed sleep) ──────────
# $1 = "initial" | "restart" (only changes the log wording)
bring_up() {
    local kind="$1" i failed=""
    kill_receivers
    if ! start_rx888; then
        stamp; log "Server ${kind} FAILED — rx888_stream did not start"; log " "
        return 1
    fi
    start_spectrumserver

    # Poll up to ~120s: bring-up time varies (rx888 USB retries add ~10s each),
    # so succeed the moment BOTH processes are confirmed up.
    for i in $(seq 1 24); do
        if is_running spectrumserver && is_running rx888_stream; then
            stamp
            [ "$kind" = "initial" ] && log "Server started normally" || log "Server restarted normally"
            log " "
            return 0
        fi
        sleep 5
    done

    is_running spectrumserver || failed="spectrumserver"
    is_running rx888_stream   || failed="${failed:+$failed + }rx888_stream"
    stamp; log "Server ${kind} FAILED — ${failed:-processes} did not come up"; log " "
    return 1
}

# ── watchdog loop: restart in place whenever a process dies ──────────────────
watchdog_loop() {
    local reason
    while true; do
        sleep 5
        reason=""
        is_running spectrumserver || reason="spectrumserver"
        is_running rx888_stream   || reason="${reason:+$reason + }rx888_stream"
        if [ -n "$reason" ]; then
            stamp
            log "PhantomSDR Server Broken: $reason — performing restart"
            log " "
            bring_up "restart"
        fi
    done
}

# ── watchdog entry point (the detached process) ──────────────────────────────
watchdog_main() {
    # Singleton guard: only one watchdog may ever run. Hold an exclusive lock on
    # fd 9 for our whole lifetime; a second watchdog can't get it and exits. This
    # makes duplicate watchdogs (and the racing double bring-up they cause)
    # impossible even if one is started by hand.
    exec 9>"$PHANTOMDIR/.watchdog.lock"
    if command -v flock >/dev/null 2>&1 && ! flock -n 9; then
        echo "start-rx888mk2.sh: another watchdog is already running — exiting" >&2
        exit 0
    fi

    stamp
    log "Starting the initialization script of the PhantomSDR Server"
    log " "
    compute_taskset
    bring_up "initial"
    watchdog_loop
}

# ── launcher entry point (what the user runs) ────────────────────────────────
# Stop any existing instance, then spawn the watchdog fully detached so it
# survives the terminal closing. Running this again == a clean restart.
launch() {
    [ -x "$STOP" ] && "$STOP" >/dev/null 2>&1
    sleep 5                        # let the USB device fully release after a kill
    echo "PhantomSDR-Plus (RX-888 MkII) starting in the background."
    echo "Progress is logged to: $LOG"
    if command -v setsid >/dev/null 2>&1; then
        setsid "$SELF" --watchdog >/dev/null 2>&1 &
    else
        nohup "$SELF" --watchdog >/dev/null 2>&1 &
    fi
    disown 2>/dev/null
    exit 0
}

case "${1:-}" in
    --watchdog)          watchdog_main ;;
    ""|start|restart)    launch ;;
    *) echo "usage: $(basename "$0") [start|restart]" >&2; exit 1 ;;
esac
