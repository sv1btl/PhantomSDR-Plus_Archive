#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  PhantomSDR-Plus  –  configure-station.sh
#  The station wizard: a handful of questions, and every file that has to
#  agree with every other one is written from the same answers.
#
#  Before it, the receiver's frequency and sample rate had to be typed into
#  three places by hand (the .toml, the start script and
#  site_information.json), the ports into three more, and one wrong number
#  showed up only as a waterfall on the wrong frequencies. Now the answers are
#  kept in ONE file, station.conf, and everything else is derived from it:
#
#    station.conf                    the answers (start scripts and proxy.py
#                                    read it directly)
#    config-<receiver>.toml          port, sample rate, frequency, directory
#                                    listings, websdr.org registration
#    frontend/site_information.json  what visitors see, and where the page
#                                    finds RADE, statistics and the relay
#    websdr_relay.json               the relay's port (if the relay is on)
#
#  Only the keys the wizard owns are changed. Anything else in those files —
#  a hand-tuned fft_size, an extra comment — is left exactly as it was, and
#  each file is copied to <name>.bak-<date> before it is touched.
#
#  Usage:
#    bash configure-station.sh            ask, save station.conf, write the files
#    bash configure-station.sh --ask      ask and save station.conf only
#    bash configure-station.sh --apply    write the files from station.conf only
#    bash configure-station.sh --show     print the current answers
#
#  Run it again at any time: the previous answers are the defaults, so ENTER
#  through everything keeps them. On an installed station it then carries a
#  change everywhere it is needed — new ports into admin_config.json and the
#  statistics service, a new receiver into start at boot — and, after one
#  question, rebuilds the page and restarts what runs. Changing a port is
#  therefore this one command.
#
#  install.sh runs --ask before it installs anything and --apply once Python
#  is there, so a new station answers every question in the first two minutes
#  and is left alone after that.
#
#  UNATTENDED USE
#  Every answer can be given in the environment instead (same names as in
#  station.conf, e.g. STATION_RECEIVER=rtl STATION_CALLSIGN=SV1XYZ), and with
#  PHANTOM_NONINTERACTIVE=1 — assumed when stdin is not a terminal — every
#  question takes its default without asking. PHANTOM_PUT_NOW=y also rebuilds
#  and restarts after such a run (unattended, the default is not to).
#
#  PORTS (a new station)
#    9000  the ONE public port: proxy.py, which serves the receiver page and
#          carries /admin, /rade, /stats and /relay to the services below
#    9001  spectrumserver            9010  admin panel   9011  statistics
#    9012  RADE sidecar              9013  WebSDR relay
#  A port already taken on this computer is skipped for the next free one.
#  The public port must be 1024 or more (the proxy does not run as root); to
#  be reached on port 80, forward the router's port 80 to 9000 instead.
# ─────────────────────────────────────────────────────────────────────────────

if [ -z "${BASH_VERSINFO[0]}" ] || [ "${BASH_VERSINFO[0]}" -lt 4 ]; then
    echo "This script needs bash 4 or newer — run it as: bash configure-station.sh" >&2
    exit 1
fi

PHANTOMDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATION_CONF="$PHANTOMDIR/station.conf"

MODE="all"
case "${1:-}" in
    "")       MODE="all" ;;
    --ask)    MODE="ask" ;;
    --apply)  MODE="apply" ;;
    --show)   MODE="show" ;;
    -h|--help)
        n=0
        while IFS= read -r line; do
            n=$((n + 1))
            [ "$n" -le 2 ] && continue
            [[ $line == "# ─"* ]] && break
            line="${line#\#}"; line="${line# }"; line="${line# }"
            printf '%s\n' "$line"
        done < "$0"
        exit 0 ;;
    *)  echo "Unknown option: $1 (try --help)" >&2; exit 1 ;;
esac

# ── output helpers ───────────────────────────────────────────────────────────
if [ -t 1 ]; then
    B=$'\033[1m'; DIM=$'\033[90m'; G=$'\033[1;32m'; Y=$'\033[1;33m'; R=$'\033[1;31m'; C=$'\033[1;36m'; N=$'\033[0m'
else
    B=""; DIM=""; G=""; Y=""; R=""; C=""; N=""
fi
say()  { printf '%s\n' "$*"; }
ok()   { printf '  %s✔%s %s\n' "$G" "$N" "$*"; }
warn() { printf '  %s!%s %s\n' "$Y" "$N" "$*"; }
die()  { printf '  %s✖%s %s\n' "$R" "$N" "$*" >&2; exit 1; }
title() { printf '\n%s── %s %s\n' "$C" "$*" "$N"; }

PHANTOM_NONINTERACTIVE="${PHANTOM_NONINTERACTIVE:-0}"
if [ "$PHANTOM_NONINTERACTIVE" != "1" ] && [ ! -t 0 ]; then
    PHANTOM_NONINTERACTIVE=1
fi

# ── the answers: environment > station.conf > built-in default ───────────────
# Everything the wizard asks lives in these variables. Values given in the
# environment are remembered before station.conf is read, so they win.
VARS=(STATION_RECEIVER STATION_LAUNCHER STATION_CONFIG STATION_RTL_V4
      STATION_PRESET STATION_FREQ STATION_SPS STATION_DEFAULT_FREQ STATION_MODULATION
      STATION_CALLSIGN STATION_NAME STATION_EMAIL STATION_LOCATOR STATION_CITY
      STATION_ANTENNA STATION_HARDWARE STATION_REGION
      STATION_PUBLIC_HOST STATION_SDR_LIST STATION_WEBSDR_ORG
      PORT_PUBLIC PORT_SDR PORT_ADMIN PORT_STATS PORT_RADE PORT_RELAY PORT_DRM
      STATION_ADMIN STATION_RADE STATION_DRM STATION_STATS STATION_RELAY STATION_AUTOSTART
      STATION_ACCELERATOR STATION_HTTPS PORT_TLS)
declare -A FROM_ENV=()
for v in "${VARS[@]}"; do
    [ -n "${!v+x}" ] && FROM_ENV[$v]="${!v}"
done
if [ -f "$STATION_CONF" ]; then
    # shellcheck disable=SC1090
    . "$STATION_CONF"
fi
SAVED_RECEIVER="${STATION_RECEIVER:-}"      # before the environment overrides it
SAVED_LAUNCHER="${STATION_LAUNCHER:-}"
SAVED_HTTPS="${STATION_HTTPS:-n}"
SAVED_TLS="${PORT_TLS:-}"
SAVED_HOST="${STATION_PUBLIC_HOST:-}"
# The ports this station runs on now, to tell afterwards whether they moved.
SAVED_PORTS=""
[ -f "$STATION_CONF" ] && SAVED_PORTS="${PORT_PUBLIC:-} ${PORT_SDR:-} ${PORT_ADMIN:-} ${PORT_STATS:-} ${PORT_RADE:-} ${PORT_RELAY:-} ${PORT_DRM:-}"
for v in "${!FROM_ENV[@]}"; do
    printf -v "$v" '%s' "${FROM_ENV[$v]}"
done

if [ "$MODE" = "show" ]; then
    [ -f "$STATION_CONF" ] || die "no station.conf yet — run: bash configure-station.sh"
    while IFS= read -r line; do
        [[ $line =~ ^[[:space:]]*(#|$) ]] || printf '%s\n' "$line"
    done < "$STATION_CONF"
    exit 0
fi

# ── receivers ────────────────────────────────────────────────────────────────
# id | menu label | launcher | config | signal | USB ids (for detection)
RX_IDS=(rx888mk2 rtl rsp1a airspyhf hackrf fobos fobos-hf)
declare -A RX_LABEL=(
    [rx888mk2]="RX888 MkII / RX888"
    [rtl]="RTL-SDR (incl. RTL-SDR Blog V4)"
    [rsp1a]="SDRplay RSP1A"
    [airspyhf]="Airspy HF+"
    [hackrf]="HackRF One"
    [fobos]="RigExpert Fobos SDR — RF (50 MHz – 6 GHz)"
    [fobos-hf]="RigExpert Fobos SDR — HF direct sampling (0 – 25 MHz)"
)
declare -A RX_NAME=(
    [rx888mk2]="RX888 MkII" [rtl]="RTL-SDR" [rsp1a]="SDRplay RSP1A"
    [airspyhf]="Airspy HF+" [hackrf]="HackRF One" [fobos]="RigExpert Fobos SDR"
    [fobos-hf]="RigExpert Fobos SDR"
)
declare -A RX_SIGNAL=(
    [rx888mk2]=real [rtl]=iq [rsp1a]=iq [airspyhf]=iq [hackrf]=iq [fobos]=iq [fobos-hf]=real
)
declare -A RX_USB=(
    [rx888mk2]="04b4:00f1 04b4:00f3"
    [rtl]="0bda:2838 0bda:2832"
    [rsp1a]="1df7:3000 1df7:2500 1df7:3010"
    [airspyhf]="03eb:800c"
    [hackrf]="1d50:6089 1d50:604b 1d50:cc15"
    [fobos]="16d0:132e"
)

# Band presets per receiver:  label | centre Hz | sample rate | start freq | mode
# For a real-sampling receiver (RX888, Fobos HF) the centre is 0 and the page
# covers 0 … sample rate / 2.
presets_for() {
    case "$1" in
        rx888mk2) printf '%s\n' \
            "HF 0 – 30 MHz (60 Msps, the usual RX888 setup)|0|60000000|7120000|LSB" ;;
        fobos-hf) printf '%s\n' \
            "HF 0 – 25 MHz (50 Msps direct sampling)|0|50000000|7100000|LSB" ;;
        rtl) printf '%s\n' \
            "2 m amateur band (144 – 146 MHz)|145000000|2048000|145500000|FM" \
            "70 cm amateur band (433 – 435 MHz)|434000000|2048000|433500000|FM" \
            "Medium wave broadcast (direct sampling, around 1.2 MHz)|1242000|2048000|1170000|AM" ;;
        rsp1a) printf '%s\n' \
            "160 m – 40 m (0 – 8 MHz)|4000000|8000000|3645000|LSB" \
            "40 m – 20 m (7 – 15 MHz)|11000000|8000000|7100000|LSB" \
            "20 m – 10 m (21 – 29 MHz)|25000000|8000000|28500000|USB" ;;
        airspyhf) printf '%s\n' \
            "40 m (6.6 – 7.6 MHz)|7100000|912000|7100000|LSB" \
            "80 m (3.2 – 4.1 MHz)|3650000|912000|3650000|LSB" \
            "Medium wave broadcast (0.5 – 1.5 MHz)|1000000|912000|648000|AM" ;;
        hackrf|fobos) printf '%s\n' \
            "FM broadcast (88 – 108 MHz)|98000000|20000000|92400000|WBFM" \
            "Air band + 2 m (127 – 147 MHz)|137000000|20000000|145500000|FM" ;;
    esac
}

# ── asking ───────────────────────────────────────────────────────────────────
# Every question shows its default; ENTER takes it. Unattended, the default is
# taken without asking.
ask() {           # ask <VAR> <question> [default]
    local var="$1" q="$2" def="${3-}" ans
    [ -n "${!var:-}" ] && def="${!var}"
    if [ -n "${FROM_ENV[$var]+x}" ] || [ "$PHANTOM_NONINTERACTIVE" = "1" ]; then
        printf -v "$var" '%s' "$def"
        printf '  %s %s→ %s%s\n' "$q" "$DIM" "${def:-(empty)}" "$N"
        return
    fi
    if [ -n "$def" ]; then
        read -r -p "  $q [$def]: " ans
    else
        read -r -p "  $q: " ans
    fi
    ans="${ans#"${ans%%[![:space:]]*}"}"; ans="${ans%"${ans##*[![:space:]]}"}"
    printf -v "$var" '%s' "${ans:-$def}"
}

ask_yn() {        # ask_yn <VAR> <question> <default y|n>
    local var="$1" q="$2" def="$3" ans hint
    [ -n "${!var:-}" ] && def="${!var}"
    if [ -n "${FROM_ENV[$var]+x}" ] || [ "$PHANTOM_NONINTERACTIVE" = "1" ]; then
        [[ $def =~ ^[Yy] ]] && def=y || def=n
        printf -v "$var" '%s' "$def"
        printf '  %s %s→ %s%s\n' "$q" "$DIM" "$([ "$def" = y ] && echo Yes || echo No)" "$N"
        return
    fi
    if [[ $def =~ ^[Yy] ]]; then hint="${G}Y${N}/n"; else hint="y/${R}N${N}"; fi
    while true; do
        printf '  %s [%s]: ' "$q" "$hint"
        read -r ans
        ans="${ans:-$def}"
        case "$ans" in
            [Yy]*) printf -v "$var" y; return ;;
            [Nn]*) printf -v "$var" n; return ;;
        esac
    done
}

ask_menu() {      # ask_menu <VAR> <question> <default number> <count>
    local var="$1" q="$2" def="$3" count="$4" ans
    if [ -n "${FROM_ENV[$var]+x}" ] || [ "$PHANTOM_NONINTERACTIVE" = "1" ]; then
        printf -v "$var" '%s' "$def"
        printf '  %s %s→ %s%s\n' "$q" "$DIM" "$def" "$N"
        return
    fi
    while true; do
        read -r -p "  $q [$def]: " ans
        ans="${ans:-$def}"
        if [[ $ans =~ ^[0-9]+$ ]] && [ "$ans" -ge 1 ] && [ "$ans" -le "$count" ]; then
            printf -v "$var" '%s' "$ans"; return
        fi
        warn "Please answer with a number from 1 to $count."
    done
}

# A frequency typed as 7.1M, 7100k, 7100000 or 7.1 (MHz when it has a point
# and is small) → Hz. Prints nothing for something it cannot read.
to_hz() {
    local v="${1// /}" mul=1 num
    v="${v,,}"; v="${v%hz}"
    case "$v" in
        *g) mul=1000000000; v="${v%g}" ;;
        *m) mul=1000000;    v="${v%m}" ;;
        *k) mul=1000;       v="${v%k}" ;;
    esac
    [[ $v =~ ^[0-9]+(\.[0-9]+)?$ ]] || return 0
    if [ "$mul" = 1 ] && [[ $v == *.* ]]; then mul=1000000; fi
    # Pure bash (the wizard runs before any package is installed, and a bare
    # openSUSE has no awk): shift the decimal point by the multiplier's zeros.
    local int="${v%%.*}" frac="" zeros="${mul#1}"
    [[ $v == *.* ]] && frac="${v#*.}"
    while [ "${#frac}" -lt "${#zeros}" ]; do frac="${frac}0"; done
    frac="${frac:0:${#zeros}}"                # anything below 1 Hz is dropped
    num="${int}${frac}"
    num="${num#"${num%%[!0]*}"}"
    printf '%s' "${num:-0}"
}

port_busy() {     # 0 = something already listens on 127.0.0.1:$1
    (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null
}

# The first port from $1 upwards that is free and not already handed out.
declare -A TAKEN=()
next_free_port() {
    local p="$1"
    while [ "$p" -le 65535 ]; do
        if [ -z "${TAKEN[$p]:-}" ] && ! port_busy "$p"; then
            printf '%s' "$p"; return
        fi
        p=$((p + 1))
    done
}

# Just the host: "http://my.host:8900/" → "my.host". The page, the directories
# and the relay add the scheme and port themselves.
clean_host() {
    local h="${1//[[:space:]]/}"
    h="${h#*://}"; h="${h%%/*}"
    case "$h" in
        \[*\]*) h="${h%%]*}]" ;;   # [IPv6]:port → [IPv6]
        *:*:*) ;;                  # bare IPv6: leave it alone
        *:*) h="${h%%:*}" ;;       # host:port → host
    esac
    printf '%s' "$h"
}

# Suggest a port: the saved one is kept (even while our own service holds it),
# otherwise the first free one from the map's default upwards.
suggest_port() {  # suggest_port <VAR> <map default>
    local var="$1" def="$2" p
    p="${!var:-}"
    if [ -z "$p" ] || [ -n "${TAKEN[$p]:-}" ]; then
        p="$(next_free_port "$def")"
    fi
    TAKEN[$p]=1
    printf -v "$var" '%s' "$p"
}

detect_receiver() {
    command -v lsusb >/dev/null 2>&1 || return 0
    local ids id rx
    local -A present=()
    local _bus _b _dev _d _id idv _rest
    while read -r _bus _b _dev _d _id idv _rest; do
        [ -n "${idv:-}" ] && present[${idv,,}]=1
    done < <(lsusb 2>/dev/null)
    for rx in rx888mk2 rtl rsp1a airspyhf hackrf fobos; do
        for id in ${RX_USB[$rx]}; do
            if [ -n "${present[$id]:-}" ]; then printf '%s' "$rx"; return; fi
        done
    done
}

# Maidenhead locator → ITU region (1 Europe/Africa/Middle East/Russia,
# 2 the Americas, 3 Asia-Pacific). Only a suggestion; the sysop confirms it.
region_from_locator() {
    local loc="${1^^}" lon lat
    [[ $loc =~ ^[A-R][A-R][0-9][0-9] ]] || { printf 1; return; }
    lon=$(( ( $(printf '%d' "'${loc:0:1}") - 65 ) * 20 + ${loc:2:1} * 2 - 180 ))
    lat=$(( ( $(printf '%d' "'${loc:1:1}") - 65 ) * 10 + ${loc:3:1} - 90 ))
    if [ "$lon" -lt -30 ]; then printf 2
    elif [ "$lon" -ge 60 ] && [ "$lat" -lt 50 ]; then printf 3
    elif [ "$lon" -ge 100 ]; then printf 3
    else printf 1
    fi
}

# ── save ─────────────────────────────────────────────────────────────────────
q() {             # a value as a double-quoted shell word
    local v="$1"
    v="${v//\\/\\\\}"; v="${v//\"/\\\"}"; v="${v//\$/\\\$}"; v="${v//\`/\\\`}"
    printf '"%s"' "$v"
}

save_conf() {
    local tmp="$STATION_CONF.tmp.$$"
    {
        echo "# PhantomSDR-Plus station settings — written by configure-station.sh"
        echo "# on $(date '+%Y-%m-%d %H:%M'). Run 'bash configure-station.sh' to change"
        echo "# them; editing by hand works too, then run it with --apply."
        echo "# The start scripts and proxy.py read this file directly."
        echo ""
        echo "# Receiver"
        echo "STATION_RECEIVER=$(q "$STATION_RECEIVER")"
        echo "STATION_LAUNCHER=$(q "$STATION_LAUNCHER")"
        echo "STATION_CONFIG=$(q "$STATION_CONFIG")"
        echo "STATION_RTL_V4=$(q "${STATION_RTL_V4:-n}")"
        echo "STATION_PRESET=$(q "$STATION_PRESET")"
        echo "STATION_FREQ=$(q "$STATION_FREQ")              # Hz, centre (0 = real sampling)"
        echo "STATION_SPS=$(q "$STATION_SPS")                # samples per second"
        echo "STATION_DEFAULT_FREQ=$(q "$STATION_DEFAULT_FREQ")  # where a new visitor starts"
        echo "STATION_MODULATION=$(q "$STATION_MODULATION")"
        echo ""
        echo "# Station"
        echo "STATION_CALLSIGN=$(q "$STATION_CALLSIGN")"
        echo "STATION_NAME=$(q "$STATION_NAME")"
        echo "STATION_EMAIL=$(q "$STATION_EMAIL")"
        echo "STATION_LOCATOR=$(q "$STATION_LOCATOR")"
        echo "STATION_CITY=$(q "$STATION_CITY")"
        echo "STATION_ANTENNA=$(q "$STATION_ANTENNA")"
        echo "STATION_HARDWARE=$(q "$STATION_HARDWARE")"
        echo "STATION_REGION=$(q "$STATION_REGION")"
        echo ""
        echo "# Internet"
        echo "STATION_PUBLIC_HOST=$(q "$STATION_PUBLIC_HOST")"
        echo "STATION_SDR_LIST=$(q "$STATION_SDR_LIST")"
        echo "STATION_WEBSDR_ORG=$(q "$STATION_WEBSDR_ORG")"
        echo ""
        echo "# Ports — only PORT_PUBLIC has to be open on the router"
        echo "PORT_PUBLIC=$PORT_PUBLIC"
        echo "PORT_SDR=$PORT_SDR"
        echo "PORT_ADMIN=$PORT_ADMIN"
        echo "PORT_STATS=$PORT_STATS"
        echo "PORT_RADE=$PORT_RADE"
        echo "PORT_DRM=$PORT_DRM"
        echo "PORT_RELAY=$PORT_RELAY"
        echo ""
        echo "# https:// through Caddy on port 443 (setup-https.sh): y, lan or n"
        echo "STATION_HTTPS=$(q "${STATION_HTTPS:-n}")"
        if [ "${STATION_HTTPS:-n}" != n ]; then
            echo "PORT_TLS=$PORT_TLS          # loopback port Caddy hands visitors to"
        else
            echo "# PORT_TLS=$PORT_TLS"
        fi
        echo ""
        echo "# Extras (y/n)"
        echo "STATION_ADMIN=$(q "$STATION_ADMIN")"
        echo "STATION_RADE=$(q "$STATION_RADE")"
        echo "STATION_DRM=$(q "$STATION_DRM")"
        echo "STATION_STATS=$(q "$STATION_STATS")"
        echo "STATION_RELAY=$(q "$STATION_RELAY")"
        echo "STATION_AUTOSTART=$(q "$STATION_AUTOSTART")"
        if [ -n "${STATION_ACCELERATOR:-}" ]; then
            echo ""
            echo "# Set by the installer from what this computer has (opencl or none)"
            echo "STATION_ACCELERATOR=$(q "$STATION_ACCELERATOR")"
        fi
    } > "$tmp" && mv "$tmp" "$STATION_CONF" || die "could not write $STATION_CONF"
}

# ═════════════════════════════════════════════════════════════════════════════
#  THE QUESTIONS
# ═════════════════════════════════════════════════════════════════════════════
ask_everything() {
    say ""
    say "${B}PhantomSDR-Plus — station setup${N}"
    say "A few questions about your receiver and your station. ENTER takes the"
    say "value in [brackets]; you can run this again at any time to change them."

    # ── 1. receiver ──────────────────────────────────────────────────────────
    title "1/5  Receiver"
    local found def_n i n=0 choice
    found="$(detect_receiver)"
    def_n=2
    for i in "${!RX_IDS[@]}"; do
        n=$((i + 1))
        local mark=""
        if [ "${RX_IDS[$i]}" = "${STATION_RECEIVER:-}" ]; then def_n=$n
        elif [ -z "${STATION_RECEIVER:-}" ] && [ "${RX_IDS[$i]}" = "$found" ]; then def_n=$n
        fi
        [ "${RX_IDS[$i]}" = "$found" ] && mark="  ${G}← plugged in${N}"
        printf '   %d) %s%s\n' "$n" "${RX_LABEL[${RX_IDS[$i]}]}" "$mark"
    done
    if [ -n "${FROM_ENV[STATION_RECEIVER]+x}" ]; then
        for i in "${!RX_IDS[@]}"; do
            [ "${RX_IDS[$i]}" = "$STATION_RECEIVER" ] && def_n=$((i + 1))
        done
        FROM_ENV[RX_CHOICE]=1
    fi
    RX_CHOICE=""
    ask_menu RX_CHOICE "Which receiver?" "$def_n" "${#RX_IDS[@]}"
    choice="${RX_IDS[$((RX_CHOICE - 1))]}"
    if [ "$choice" != "$SAVED_RECEIVER" ]; then
        # Another receiver: the old band and rate do not apply to it (but
        # anything given in the environment for this run still does).
        local v
        for v in STATION_PRESET STATION_FREQ STATION_SPS STATION_DEFAULT_FREQ STATION_MODULATION; do
            [ -n "${FROM_ENV[$v]+x}" ] || printf -v "$v" '%s' ""
        done
    fi
    STATION_RECEIVER="$choice"
    STATION_LAUNCHER="start-$choice.sh"
    STATION_CONFIG="config-$choice.toml"
    if [ "$choice" = rtl ]; then
        ask_yn STATION_RTL_V4 "Is it an RTL-SDR Blog V4 (needs its own driver)?" n
    else
        STATION_RTL_V4=n
    fi

    # ── 2. band ──────────────────────────────────────────────────────────────
    title "2/5  What to receive"
    local -a P=()
    mapfile -t P < <(presets_for "$STATION_RECEIVER")
    local custom=$(( ${#P[@]} + 1 )) def_p=1
    for i in "${!P[@]}"; do
        printf '   %d) %s\n' $((i + 1)) "${P[$i]%%|*}"
        [ "${P[$i]%%|*}" = "${STATION_PRESET:-}" ] && def_p=$((i + 1))
    done
    printf '   %d) Something else — I will type the frequency and sample rate\n' "$custom"
    [ "${STATION_PRESET:-}" = "custom" ] && def_p=$custom
    [ -n "${FROM_ENV[STATION_PRESET]+x}" ] && FROM_ENV[BAND_CHOICE]=1
    if [ -n "${FROM_ENV[STATION_FREQ]+x}${FROM_ENV[STATION_SPS]+x}" ] && [ -z "${FROM_ENV[STATION_PRESET]+x}" ]; then
        def_p=$custom; FROM_ENV[BAND_CHOICE]=1
    fi
    BAND_CHOICE=""
    ask_menu BAND_CHOICE "Which band?" "$def_p" "$custom"
    if [ "$BAND_CHOICE" -lt "$custom" ]; then
        IFS='|' read -r STATION_PRESET STATION_FREQ STATION_SPS STATION_DEFAULT_FREQ STATION_MODULATION \
            <<<"${P[$((BAND_CHOICE - 1))]}"
    else
        STATION_PRESET="custom"
        local f
        if [ "${RX_SIGNAL[$STATION_RECEIVER]}" = real ]; then
            STATION_FREQ=0
        else
            while true; do
                ask STATION_FREQ "Centre frequency (e.g. 145000000, 145M or 145.0)" "${STATION_FREQ:-}"
                f="$(to_hz "$STATION_FREQ")"
                [ -n "$f" ] && [ "$f" -gt 0 ] && { STATION_FREQ="$f"; break; }
                warn "Could not read that as a frequency."; STATION_FREQ=""
                [ "$PHANTOM_NONINTERACTIVE" = "1" ] && die "STATION_FREQ is not a frequency"
            done
        fi
        while true; do
            ask STATION_SPS "Sample rate in samples per second (e.g. 2048000 or 2.048M)" "${STATION_SPS:-}"
            f="$(to_hz "$STATION_SPS")"
            [ -n "$f" ] && [ "$f" -gt 0 ] && { STATION_SPS="$f"; break; }
            warn "Could not read that as a sample rate."; STATION_SPS=""
            [ "$PHANTOM_NONINTERACTIVE" = "1" ] && die "STATION_SPS is not a sample rate"
        done
        local start_def="$STATION_FREQ"
        [ "$start_def" = 0 ] && start_def=7100000
        ask STATION_DEFAULT_FREQ "Frequency a new visitor starts on" "${STATION_DEFAULT_FREQ:-$start_def}"
        f="$(to_hz "$STATION_DEFAULT_FREQ")"; [ -n "$f" ] && STATION_DEFAULT_FREQ="$f"
        ask STATION_MODULATION "Mode a new visitor starts in (AM, FM, WBFM, LSB, USB, CW)" "${STATION_MODULATION:-AM}"
        STATION_MODULATION="${STATION_MODULATION^^}"
    fi

    # ── 3. station ───────────────────────────────────────────────────────────
    title "3/5  Your station (shown to visitors)"
    ask STATION_CALLSIGN "Callsign" ""
    STATION_CALLSIGN="${STATION_CALLSIGN^^}"
    ask STATION_NAME "Your name (optional)" ""
    ask STATION_EMAIL "E-mail address" ""
    while true; do
        ask STATION_LOCATOR "QTH locator (e.g. KM18ux)" ""
        [ -z "$STATION_LOCATOR" ] && break
        if [[ ${STATION_LOCATOR^^} =~ ^[A-R]{2}[0-9]{2}([A-X]{2})?$ ]]; then
            local loc="${STATION_LOCATOR^^}"
            local sub="${loc:4:2}"
            STATION_LOCATOR="${loc:0:4}${sub,,}"     # KM18ux: field upper, subsquare lower
            break
        fi
        warn "A locator looks like KM18 or KM18ux."; STATION_LOCATOR=""
        [ "$PHANTOM_NONINTERACTIVE" = "1" ] && break
    done
    ask STATION_CITY "City and country" ""
    ask STATION_ANTENNA "Antenna" ""
    ask STATION_HARDWARE "Computer (optional, e.g. Intel NUC i5)" ""
    ask STATION_REGION "ITU region (1 Europe/Africa, 2 Americas, 3 Asia-Pacific)" \
        "$(region_from_locator "$STATION_LOCATOR")"

    # ── 4. internet ──────────────────────────────────────────────────────────
    title "4/5  Internet"
    say "  The address listeners type to reach you: your public IP address or a"
    say "  DNS name (e.g. myname.ddns.net). Leave it empty if you do not know yet."
    while true; do
        ask STATION_PUBLIC_HOST "Public address" ""
        STATION_PUBLIC_HOST="$(clean_host "$STATION_PUBLIC_HOST")"
        # The port is asked for in step 5; a bare number here is a port typed
        # in the wrong place, and it would end up as the host name everywhere
        # (sdr-list, websdr.org, the page's own links).
        if [[ $STATION_PUBLIC_HOST =~ ^[0-9]+$ ]]; then
            warn "\"$STATION_PUBLIC_HOST\" looks like a port, not an address — the port comes in step 5."
            say "    Type a DNS name (myname.ddns.net) or an IP address, or leave it empty."
            STATION_PUBLIC_HOST=""
            [ "$PHANTOM_NONINTERACTIVE" = "1" ] && break
            continue
        fi
        break
    done
    local list_def=n
    [ -n "$STATION_PUBLIC_HOST" ] && list_def=y
    ask_yn STATION_SDR_LIST "List the receiver on sdr-list.xyz?" "$list_def"
    ask_yn STATION_WEBSDR_ORG "Register it on the websdr.org map?" "$list_def"
    if [ -z "$STATION_PUBLIC_HOST" ] && { [ "$STATION_SDR_LIST" = y ] || [ "$STATION_WEBSDR_ORG" = y ]; }; then
        warn "Both need the public address — they stay off until you set it."
        STATION_SDR_LIST=n; STATION_WEBSDR_ORG=n
    fi
    # https needs a certificate, and Let's Encrypt issues one for a name, not
    # for a bare IP address. "lan" (setup-https.sh --lan) is kept as it is.
    if [ "${STATION_HTTPS:-}" != "lan" ]; then
        say "  https:// as well as http:// — a free certificate from Let's Encrypt,"
        say "  renewed by itself. Needs a DNS name above, and ports 443 and 80 open"
        say "  on the router. The http:// address keeps working."
        ask_yn STATION_HTTPS "Also serve the receiver over https://?" n
        if [ "$STATION_HTTPS" = y ] && { [ -z "$STATION_PUBLIC_HOST" ] \
             || [[ $STATION_PUBLIC_HOST =~ ^[0-9.]+$ ]] || [[ $STATION_PUBLIC_HOST == *:* ]]; }; then
            warn "https needs a DNS name (e.g. myname.ddns.net), not an IP address — left off."
            say "    Get a free name from a dynamic-DNS service, then: bash setup-https.sh"
            STATION_HTTPS=n
        fi
    fi

    # ── 5. ports and extras ──────────────────────────────────────────────────
    title "5/5  Ports and extras"
    ask_yn STATION_ADMIN "Admin panel (dashboard, logs, settings, users)?" y
    if [ -f "${RADAE_DIR:-$HOME/radae}/radae_rxe.py" ]; then
        say "  RADE is already installed here and keeps decoding whatever you answer;"
        say "  'n' only means it is not downloaded and installed again."
    fi
    ask_yn STATION_RADE "Install the FreeDV RADE decoder? (large: ~1 GB download, +20 min install)" y
    ask_yn STATION_DRM "Install the DRM decoder? (digital shortwave radio, a few minutes to build)" y
    ask_yn STATION_STATS "CPU / memory / temperature box on the page?" y
    # An https page may not open ws:// sockets, and most diversity partners
    # (PhantomSDR+, KiwiSDR) are plain http — so over https the relay is what
    # reaches them. Hence on by default whenever https is.
    local relay_def=n
    say "  The diversity relay lets listeners combine this receiver with another:"
    say "  it reaches WebSDRs always, and plain-http PhantomSDR+ / KiwiSDR stations"
    say "  when your page is served over https://."
    if [ "${STATION_HTTPS:-n}" != n ]; then
        relay_def=y
        say "  You serve https://, so without it most diversity partners cannot connect."
    fi
    ask_yn STATION_RELAY "Diversity relay (WebSDR partners; any partner from an https:// page)?" "$relay_def"
    ask_yn STATION_AUTOSTART "Start the receiver automatically when the computer boots?" y

    say ""
    say "  Only ONE port has to be opened (forwarded) on your router."
    local pub_def=9000
    TAKEN=()
    # A station installed before the wizard already has its ports in
    # admin_config.json (proxy, spectrumserver, panel). Offer those, so running
    # the wizard there does not move anything listeners or the router know.
    if [ ! -f "$STATION_CONF" ] && [ -f "$PHANTOMDIR/admin_config.json" ] && command -v python3 >/dev/null 2>&1; then
        local old
        old="$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(d.get("proxy_port",""), d.get("public_port",""), d.get("port",""))' \
               "$PHANTOMDIR/admin_config.json" 2>/dev/null)" || old=""
        read -r OLD_PROXY OLD_SDR OLD_ADMIN <<<"$old"
        if [[ ${OLD_PROXY:-} =~ ^[0-9]+$ ]] && [[ ${OLD_SDR:-} =~ ^[0-9]+$ ]]; then
            say "  This station already has ports set up — they are offered as they are."
            : "${PORT_PUBLIC:=$OLD_PROXY}" "${PORT_SDR:=$OLD_SDR}" "${PORT_ADMIN:=${OLD_ADMIN:-}}"
            # The services it already runs stay where they are; the proxy
            # simply reaches them there: RADE's old fixed port, the relay's
            # from its config, statistics from the address the page used.
            local old_stats old_relay
            old_stats="$(python3 -c 'import json,re,sys; v=json.load(open(sys.argv[1])).get("siteStats",""); m=re.search(r":(\d+)/*$", v); print(m.group(1) if m else "")' \
                         "$PHANTOMDIR/frontend/site_information.json" 2>/dev/null)" || old_stats=""
            old_relay="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("port",""))' \
                         "$PHANTOMDIR/websdr_relay.json" 2>/dev/null)" || old_relay=""
            : "${PORT_RADE:=8074}" "${PORT_STATS:=${old_stats:-3001}}" "${PORT_RELAY:=${old_relay:-8898}}"
            : "${PORT_DRM:=8075}"
        fi
    fi
    if [ -n "${PORT_PUBLIC:-}" ]; then pub_def="$PORT_PUBLIC"; TAKEN[$PORT_PUBLIC]=1
    else pub_def="$(next_free_port 9000)"; fi
    while true; do
        ask PORT_PUBLIC "Public port" "$pub_def"
        if ! [[ $PORT_PUBLIC =~ ^[0-9]+$ ]] || [ "$PORT_PUBLIC" -lt 1 ] || [ "$PORT_PUBLIC" -gt 65535 ]; then
            warn "A port is a number from 1 to 65535."; PORT_PUBLIC=""
            [ "$PHANTOM_NONINTERACTIVE" = "1" ] && die "PORT_PUBLIC is not a port"
            continue
        fi
        # Below 1024 only root may listen, and proxy.py runs as you. The router
        # can do it instead: forward its outside port 80 (say) to 9000 here.
        if [ "$PORT_PUBLIC" -lt 1024 ]; then
            warn "Ports below 1024 need root, and the proxy runs as your user."
            say "    Keep a port of 1024 or more here (9000), and on your router forward"
            say "    the outside port $PORT_PUBLIC to it: listeners then use :$PORT_PUBLIC."
            PORT_PUBLIC=""
            [ "$PHANTOM_NONINTERACTIVE" = "1" ] && die "PORT_PUBLIC below 1024 — forward it on the router instead"
            continue
        fi
        break
    done
    TAKEN=([$PORT_PUBLIC]=1)
    suggest_port PORT_SDR   $((PORT_PUBLIC + 1))
    suggest_port PORT_ADMIN $((PORT_PUBLIC + 10))
    suggest_port PORT_STATS $((PORT_PUBLIC + 11))
    suggest_port PORT_RADE  $((PORT_PUBLIC + 12))
    suggest_port PORT_RELAY $((PORT_PUBLIC + 13))
    suggest_port PORT_TLS   $((PORT_PUBLIC + 14))
    suggest_port PORT_DRM   $((PORT_PUBLIC + 15))
    show_ports
    CHANGE_PORTS=n
    ask_yn CHANGE_PORTS "Change any of the internal ports (e.g. keep the old numbers)?" n
    if [ "$CHANGE_PORTS" = y ]; then
        local pv pvs=(PORT_SDR PORT_ADMIN PORT_STATS PORT_RADE PORT_DRM PORT_RELAY)
        [ "${STATION_HTTPS:-n}" != n ] && pvs+=(PORT_TLS)
        # Each port is checked against the public one and the ones already
        # answered, so two services can never be handed the same port.
        TAKEN=([$PORT_PUBLIC]=1)
        for pv in "${pvs[@]}"; do
            while true; do
                ask "$pv" "  $pv" "${!pv}"
                if ! [[ ${!pv} =~ ^[0-9]+$ ]] || [ "${!pv}" -lt 1024 ] || [ "${!pv}" -gt 65535 ]; then
                    warn "Use a port from 1024 to 65535."
                elif [ -n "${TAKEN[${!pv}]:-}" ]; then
                    warn "Port ${!pv} is already given to another service here."
                else
                    break
                fi
                [ "$PHANTOM_NONINTERACTIVE" = "1" ] && die "$pv=${!pv} cannot be used"
                printf -v "$pv" '%s' ""
            done
            TAKEN[${!pv}]=1
        done
        show_ports
    fi
}

show_ports() {
    printf '\n    %-6s %s\n' "$PORT_PUBLIC" "public — the receiver page; forward this one"
    printf '    %-6s %s\n' "$PORT_SDR"   "spectrumserver (inside this computer)"
    printf '    %-6s %s\n' "$PORT_ADMIN" "admin panel    (reached as /admin)"
    printf '    %-6s %s\n' "$PORT_STATS" "statistics     (reached as /stats)"
    printf '    %-6s %s\n' "$PORT_RADE"  "RADE decoder   (reached as /rade)"
    printf '    %-6s %s\n' "$PORT_DRM"   "DRM decoder    (reached as /drm)"
    printf '    %-6s %s\n' "$PORT_RELAY" "WebSDR relay   (reached as /relay)"
    if [ "${STATION_HTTPS:-n}" != n ]; then
        printf '    %-6s %s\n' "$PORT_TLS" "https front    (Caddy on 443 hands visitors to it)"
        printf '    %-6s %s\n' "443, 80" "https, and the certificate check — forward these too"
    fi
    say ""
}

mhz() {           # Hz → "145.024" (three decimals), integer arithmetic only
    local hz="$1" khz
    [ "$hz" -lt 0 ] && hz=0
    khz=$(( (hz + 500) / 1000 ))
    printf '%d.%03d' $((khz / 1000)) $((khz % 1000))
}

summary() {
    local bw
    if [ "${RX_SIGNAL[$STATION_RECEIVER]}" = real ]; then
        bw="0 – $(mhz $((STATION_SPS / 2))) MHz"
    else
        bw="$(mhz $((STATION_FREQ - STATION_SPS / 2))) – $(mhz $((STATION_FREQ + STATION_SPS / 2))) MHz"
    fi
    say ""
    say "${B}Summary${N}"
    printf '  %-14s %s\n' "Receiver" "${RX_LABEL[$STATION_RECEIVER]}" \
        "Covers" "$bw  (sample rate $STATION_SPS)" \
        "Starts on" "$STATION_DEFAULT_FREQ Hz $STATION_MODULATION" \
        "Station" "${STATION_CALLSIGN:-—}  ${STATION_LOCATOR}  ${STATION_CITY}" \
        "Address" "${STATION_PUBLIC_HOST:-(not set)}:$PORT_PUBLIC" \
        "Listings" "sdr-list.xyz: $STATION_SDR_LIST   websdr.org: $STATION_WEBSDR_ORG" \
        "https" "$( [ "${STATION_HTTPS:-n}" = y ] && echo "yes — https://$STATION_PUBLIC_HOST/" || { [ "${STATION_HTTPS:-n}" = lan ] && echo "local network only" || echo no; } )" \
        "Extras" "admin: $STATION_ADMIN  RADE: $STATION_RADE  DRM: $STATION_DRM  stats: $STATION_STATS  relay: $STATION_RELAY  autostart: $STATION_AUTOSTART"
}

# ═════════════════════════════════════════════════════════════════════════════
#  WRITING THE FILES
# ═════════════════════════════════════════════════════════════════════════════
apply_files() {
    [ -f "$STATION_CONF" ] || die "no station.conf — run: bash configure-station.sh"
    command -v python3 >/dev/null 2>&1 || die "python3 is needed to write the config files"
    local stamp; stamp="$(date +%Y%m%d-%H%M%S)"
    set -a
    # shellcheck disable=SC1090
    . "$STATION_CONF"
    set +a
    STATION_SIGNAL="${RX_SIGNAL[$STATION_RECEIVER]:-iq}" PHANTOMDIR="$PHANTOMDIR" STAMP="$stamp" \
    OLD_HOST="${SAVED_HOST:-}" \
    python3 - <<'PY' || die "writing the config files failed (nothing was half-written)"
import json, os, re, shutil, sys
from pathlib import Path

E = os.environ
root = Path(E["PHANTOMDIR"])
stamp = E["STAMP"]
changed = []

def backup(p: Path):
    if p.exists():
        shutil.copy2(p, p.with_name(p.name + ".bak-" + stamp))

def write(p: Path, text: str):
    if p.exists() and p.read_text() == text:
        print(f"  ✔ {p.relative_to(root)} (already up to date)")
        return
    backup(p)
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(text)
    tmp.replace(p)
    changed.append(str(p.relative_to(root)))
    print(f"  ✔ {p.relative_to(root)}")

def tq(s):   # a TOML basic string
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'

yes = lambda k: E.get(k, "n").lower().startswith("y")

def clean_host(h):
    """Just the host: "http://my.host:8900/" → "my.host" (same as the shell's)."""
    h = re.sub(r"\s", "", str(h or ""))
    h = re.sub(r"^[a-z]+://", "", h, flags=re.I).split("/", 1)[0]
    if h.startswith("["):
        return h.split("]", 1)[0] + "]"
    return h.split(":", 1)[0] if h.count(":") == 1 else h

host = clean_host(E.get("STATION_PUBLIC_HOST", ""))
# A bare number is a port typed where the address belongs (it happened: "8900"
# went into sdr-list, websdr.org and every link of the page). Nothing is
# better than that.
if re.fullmatch(r"\d+", host):
    print(f"  ! STATION_PUBLIC_HOST=\"{host}\" is a port, not an address — left empty;"
          " set it with: bash configure-station.sh")
    host = ""
old_host = clean_host(E.get("OLD_HOST", ""))
call = E.get("STATION_CALLSIGN", "").strip()
port_public = int(E["PORT_PUBLIC"])
port_sdr = int(E["PORT_SDR"])

# ── config-<receiver>.toml ────────────────────────────────────────────────────
# Line-based on purpose: a TOML library would drop every comment, and the
# comments in these files are the documentation sysops actually read.
cfg = root / E["STATION_CONFIG"]
src = cfg if cfg.exists() else cfg.with_name(cfg.name + ".example")
if not src.exists():
    sys.exit(f"  ✖ neither {cfg.name} nor {cfg.name}.example exists")
lines = src.read_text().splitlines()

SEC = re.compile(r"^\s*\[([^\]]+)\]\s*(#.*)?$")

def section_range(name):
    start = None
    for i, l in enumerate(lines):
        m = SEC.match(l)
        if m and start is None and m.group(1).strip() == name:
            start = i
        elif m and start is not None:
            return start, i
    return (start, len(lines)) if start is not None else (None, None)

def set_key(section, key, value):
    s, e = section_range(section)
    if s is None:
        lines.extend(["", f"[{section}]"])
        s, e = len(lines) - 1, len(lines)
    pat = re.compile(r"^(\s*)" + re.escape(key) + r"(\s*)=(\s*)(\"(?:[^\"\\]|\\.)*\"|[^#\s]*)(.*)$")
    for i in range(s + 1, e):
        m = pat.match(lines[i])
        if m:
            lines[i] = f"{m.group(1)}{key}{m.group(2)}={m.group(3)}{value}{m.group(5)}"
            return
    # Not there yet: after the section's last setting, ahead of any comment
    # block that introduces the next section.
    j = s + 1
    for i in range(s + 1, e):
        t = lines[i].strip()
        if t and not t.startswith("#"):
            j = i + 1
    lines.insert(j, f"{key}={value}")

set_key("server", "port", str(port_sdr))
set_key("input", "sps", E["STATION_SPS"])
set_key("input", "frequency", E["STATION_FREQ"])
set_key("input", "signal", tq(E["STATION_SIGNAL"]))
set_key("input.defaults", "frequency", E["STATION_DEFAULT_FREQ"])
set_key("input.defaults", "modulation", tq(E["STATION_MODULATION"]))

set_key("websdr", "register_online", "true" if (yes("STATION_SDR_LIST") and host) else "false")
set_key("websdr", "name", tq(" ".join(x for x in (call, E.get("STATION_CITY", "")) if x) or "PhantomSDR+"))
set_key("websdr", "antenna", tq(E.get("STATION_ANTENNA", "") or "Antenna"))
set_key("websdr", "grid_locator", tq(E.get("STATION_LOCATOR", "")))
set_key("websdr", "hostname", tq(host))
# The port the directories send visitors to: the proxy's, not spectrumserver's.
set_key("websdr", "public_port", str(port_public))
if E.get("STATION_ACCELERATOR") in ("opencl", "none"):
    set_key("input", "accelerator", tq(E["STATION_ACCELERATOR"]))

# [websdr.org] ships commented out. Turning it on replaces that commented
# block with a real section; turning it off sets enabled = false.
org_on = yes("STATION_WEBSDR_ORG") and bool(host)
s, _ = section_range("websdr.org")
if s is None and org_on:
    hdr = next((i for i, l in enumerate(lines) if re.match(r"^\s*#\s*\[websdr\.org\]", l)), None)
    block = ["[websdr.org]",
             "enabled     = true",
             f"public_host = {tq(host)}",
             f"public_port = {port_public}",
             f"qth         = {tq(E.get('STATION_LOCATOR', ''))}",
             f"description = {tq((call + ' PhantomSDR+').strip())}",
             f"email       = {tq(E.get('STATION_EMAIL', ''))}",
             'logo        = "logo.jpg" # in frontend/public; replace the file to use your own']
    if hdr is not None:
        j = hdr + 1
        while j < len(lines) and re.match(r"^\s*#\s*[a-z_]+\s*=", lines[j]):
            j += 1
        lines[hdr:j] = block
    else:
        lines.extend([""] + block)
elif s is not None:
    set_key("websdr.org", "enabled", "true" if org_on else "false")
    if org_on:
        set_key("websdr.org", "public_host", tq(host))
        set_key("websdr.org", "public_port", str(port_public))
        set_key("websdr.org", "qth", tq(E.get("STATION_LOCATOR", "")))
        set_key("websdr.org", "description", tq((call + " PhantomSDR+").strip()))
        set_key("websdr.org", "email", tq(E.get("STATION_EMAIL", "")))

write(cfg, "\n".join(lines) + "\n")

# The page embeds {siteIP}/users.html; an http frame inside an https page is
# blocked, so with https on, siteIP is the https address.
site_ip = ((f"https://{host}" if E.get("STATION_HTTPS") == "y" else f"http://{host}:{port_public}")
           if host else "")

# Names this station is known by: now, before, and in the links of the
# receivers that run on this computer (those are ours by definition).
LOCAL = ("", "127.0.0.1", "localhost", "::1")
our_hosts = {host.lower(), old_host.lower(), "localhost", "127.0.0.1", ""}
try:
    try:
        import tomllib
    except ImportError:          # Python < 3.11
        import tomli as tomllib
    for r in tomllib.loads((root / "receivers.toml").read_text()).get("receiver", []):
        if str(r.get("host", "")) in LOCAL and re.match(r"^https?://", str(r.get("url", "")), re.I):
            our_hosts.add(clean_host(r["url"]).lower())
except Exception:
    pass

def names_us(url):
    """True when url points at this station: relative, or a host that is ours
    now, was ours before, is local, or is a port typed as a host ("8900")."""
    url = str(url or "").strip()
    if not re.match(r"^https?://", url, re.I):
        return True
    h = clean_host(url).lower()
    return h in our_hosts or re.fullmatch(r"\d+", h) is not None

def fix_list(d):
    """Every page here is served through proxy.py, which answers
    /receivers.json on whatever address the page was opened with (public
    name, LAN IP, localhost). A full address of our own only breaks that: it
    goes stale when a port or the name changes, and a page opened under
    another name hides the picker. A list on another machine is kept."""
    v = d.get("siteReceiversList")
    if isinstance(v, str) and re.match(r"^https?://", v, re.I) and names_us(v):
        d["siteReceiversList"] = ""

# ── frontend/site_information.json ───────────────────────────────────────────
si = root / "frontend" / "site_information.json"
base = si if si.exists() else root / "frontend" / "site_information.example.json"
info = json.loads(base.read_text()) if base.exists() else {}
sps, freq = int(E["STATION_SPS"]), int(E["STATION_FREQ"])
if E["STATION_SIGNAL"] == "real":
    sdr_base, sdr_bw = 0, sps // 2
else:
    sdr_base, sdr_bw = max(0, freq - sps // 2), sps
name = E.get("STATION_NAME", "").strip()
# The page may show a finer locator than the 4 or 6 characters the directories
# take (KM17VX69JA for KM17vx): kept while it is the same square, refined.
loc = E.get("STATION_LOCATOR", "")
page_loc = str(info.get("siteGridSquare", "")).strip()
if (loc and len(page_loc) > len(loc) and page_loc.upper().startswith(loc.upper())
        and re.fullmatch(r"[A-R]{2}[0-9]{2}([A-X]{2}([0-9]{2}([A-X]{2})?)?)?", page_loc.upper())):
    loc = page_loc
info.update({
    "siteSysop": f"{name}, {call}" if name and call else (call or name or "Sysop"),
    "siteSysopEmailAddress": E.get("STATION_EMAIL", ""),
    "siteGridSquare": loc,
    "siteCity": E.get("STATION_CITY", ""),
    "siteReceiver": {"rx888mk2": "RX888 MkII", "rtl": "RTL-SDR Blog V4" if yes("STATION_RTL_V4") else "RTL-SDR",
                     "rsp1a": "SDRplay RSP1A", "airspyhf": "Airspy HF+", "hackrf": "HackRF One",
                     "fobos": "RigExpert Fobos SDR", "fobos-hf": "RigExpert Fobos SDR"}.get(E["STATION_RECEIVER"], ""),
    "siteAntenna": E.get("STATION_ANTENNA", ""),
    "siteIP": site_ip,
    "siteStats": "/stats" if yes("STATION_STATS") else "",
    "siteRade": "/rade",
    "siteDrm": "/drm",
    "siteRelay": "/relay",
    "siteSDRBaseFrequency": sdr_base,
    "siteSDRBandwidth": sdr_bw,
    "siteRegion": int(E.get("STATION_REGION") or 1),
})
if E.get("STATION_HARDWARE", "").strip():
    info["siteHardware"] = E["STATION_HARDWARE"].strip()
# The template's descriptive placeholders would be shown to visitors as they
# are; a sysop's own text is never replaced.
for key, placeholder, value in (("siteHardware", "Hardware you are using, ", ""),
                                ("siteSoftware", "Software you are using", "PhantomSDR-Plus")):
    if info.get(key) == placeholder:
        info[key] = value
# The info panel's Receiver link: the maker's page for this receiver, unless
# the sysop put in an address of their own.
maker = {"rx888mk2": "https://www.rx-888.com/rx/", "rtl": "https://www.rtl-sdr.com/",
         "rsp1a": "https://www.sdrplay.com/rsp1a/", "airspyhf": "https://airspy.com/airspy-hf-plus/",
         "hackrf": "https://greatscottgadgets.com/hackrf/one/", "fobos": "https://rigexpert.com/",
         "fobos-hf": "https://rigexpert.com/"}
url = str(info.get("siteReceiverURL", "")).strip()
if not re.match(r"^https?://", url, re.I) or url in maker.values():
    info["siteReceiverURL"] = maker.get(E["STATION_RECEIVER"], "")
fix_list(info)
write(si, json.dumps(info, indent="\t", ensure_ascii=False) + "\n")

# ── websdr_relay.json (only when the relay is on) ───────────────────────────
if yes("STATION_RELAY"):
    rj = root / "websdr_relay.json"
    ex = root / "websdr_relay.json.example"
    relay = json.loads((rj if rj.exists() else ex).read_text()) if (rj.exists() or ex.exists()) else {}
    relay.update({"port": int(E["PORT_RELAY"]), "bind": "127.0.0.1",
                  # Without an address the old one stays — unless it is a port
                  # typed as a host ("http://8900:8900"), which is worse than none.
                  "site": f"http://{host}:{port_public}" if host else
                          ("" if re.fullmatch(r"\d+", clean_host(relay.get("site", ""))) else relay.get("site", "")),
                  "operator": " ".join(x for x in (call, f"<{E['STATION_EMAIL']}>" if E.get("STATION_EMAIL") else "") if x)
                              or relay.get("operator", "")})
    write(rj, json.dumps(relay, indent=2) + "\n")

# ── receivers.toml (several receivers behind the proxy) ─────────────────────
# proxy.py forwards to the port each [[receiver]] names, so a main receiver
# whose port moved has to move here too: left on the public port, the proxy
# forwarded to itself and the station went down (2026-10-11). Every link a
# picker shows carries ?rx=<id>: the proxy remembers the last receiver in a
# cookie, and a link without ?rx= would keep a 2 m visitor on 2 m.
# Line-based, like the .toml above, so the sysop's comments stay.
rt = root / "receivers.toml"
if rt.exists():
    rl = rt.read_text().splitlines()
    HDR = re.compile(r"^\s*\[")
    def kv(key):
        return re.compile(r"^(\s*)" + key + r"(\s*)=(\s*)(\"(?:[^\"\\]|\\.)*\"|[^#\s]*)(.*)$")
    def find(s, e, key):
        for i in range(s + 1, e):
            m = kv(key).match(rl[i])
            if m:
                return i, m
        return None, None
    def unq(v):
        v = v.strip()
        return json.loads(v) if v.startswith('"') else v
    def put(s, e, key, value):
        i, m = find(s, e, key)
        if m:
            rl[i] = f"{m.group(1)}{key}{m.group(2)}={m.group(3)}{value}{m.group(5)}"
        else:
            j = s + 1
            for k in range(s + 1, e):
                if rl[k].strip() and not rl[k].strip().startswith("#"):
                    j = k + 1
            rl.insert(j, f"{key} = {value}")
    starts = [i for i, l in enumerate(rl) if re.match(r"^\s*\[\[receiver\]\]\s*(#.*)?$", l)]
    for s in reversed(starts):          # bottom up: an insert never shifts a block still to do
        e = next((j for j in range(s + 1, len(rl)) if HDR.match(rl[j])), len(rl))
        _, m = find(s, e, "id")
        rid = unq(m.group(4)) if m else ""
        _, m = find(s, e, "host")
        local = (unq(m.group(4)) if m else "") in LOCAL
        main = find(s, e, "instance")[1] is None
        if main and local:
            put(s, e, "port", str(port_sdr))
        # A receiver on this computer is reached through this proxy, so its
        # link is always ours to write; one on another machine keeps its own.
        _, m = find(s, e, "url")
        if rid and (local or names_us(unq(m.group(4)) if m else "")):
            put(s, e, "url", tq(f"{site_ip}/?rx={rid}"))
    text = "\n".join(rl) + "\n"
    try:
        try:
            import tomllib
        except ImportError:          # Python < 3.11
            import tomli as tomllib
        parsed = tomllib.loads(text)
    except Exception as ex:
        parsed = None
        print(f"  ! receivers.toml would not parse after the update ({ex}) — left as it was;"
              f" its main receiver must be on port {port_sdr}")
    if parsed is not None:
        for r in parsed.get("receiver", []):
            if str(r.get("host", "127.0.0.1")) in ("127.0.0.1", "localhost", "::1") \
                    and int(r.get("port", 0)) == port_public:
                print(f"  ! receivers.toml: \"{r.get('id')}\" is on the public port {port_public} — "
                      "the proxy would forward to itself; give it its own port")
        write(rt, text)

# ── instances/<id>/www/site_information.json (the other receivers' pages) ────
# A second receiver's page reads its own copy, so the address, the side
# services and the receiver list follow the main page's here.
for p in sorted(root.glob("instances/*/www/site_information.json")):
    try:
        raw = p.read_text()
        d = json.loads(raw)
    except Exception as ex:
        print(f"  ! {p.relative_to(root)}: {ex} — left as it was")
        continue
    d.update({k: info[k] for k in ("siteIP", "siteStats", "siteRade", "siteDrm", "siteRelay")})
    fix_list(d)
    write(p, json.dumps(d, indent="\t" if "\n\t" in raw else 2, ensure_ascii=False) + "\n")

Path(root / ".station-changed").write_text("\n".join(changed) + ("\n" if changed else ""))
PY
}

# ═════════════════════════════════════════════════════════════════════════════
#  PUTTING A CHANGE INTO SERVICE (an installed station, run on its own)
# ═════════════════════════════════════════════════════════════════════════════
# The .toml, site_information.json and the relay settings are written above.
# What else holds a port or the start script is brought along here, so that
# changing a port is one command: admin_config.json (the proxy and the panel
# prefer it to station.conf), the statistics service, and the start-at-boot
# unit. Then, after one question, the page is rebuilt and whatever runs is
# restarted.
SUDO=""
if [ "$(id -u)" -ne 0 ] && command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi
unit_exists() { [ -f "/etc/systemd/system/$1.service" ] && [ -d /run/systemd/system ]; }
# A unit is this station's only when it runs from this folder: a second copy of
# PhantomSDR-Plus on the computer (a test tree, another station) must never
# restart or move the one on the air.
unit_ours() {
    unit_exists "$1" \
        && [ "$(systemctl show -p WorkingDirectory --value "$1" 2>/dev/null)" = "$PHANTOMDIR" ]
}
# The statistics server runs from its own folder, so it is recognised by the
# port it serves: the one this station's page used until now.
stats_ours() {
    unit_exists sdr-stats || return 1
    local old_stats; old_stats="$(set -- $SAVED_PORTS; printf '%s' "${4:-}")"
    [ -n "$old_stats" ] || return 1
    grep -q -E "Environment=PORT=$old_stats\b" /etc/systemd/system/sdr-stats.service.d/*.conf 2>/dev/null \
        || grep -q -E "process\.env\.PORT \|\| $old_stats\b" "$(systemctl show -p WorkingDirectory --value sdr-stats 2>/dev/null)/system-stats-server.js" 2>/dev/null
}

carry_ports() {
    local now="$PORT_PUBLIC $PORT_SDR $PORT_ADMIN $PORT_STATS $PORT_RADE $PORT_RELAY $PORT_DRM"
    PORTS_MOVED=n
    [ -n "$SAVED_PORTS" ] && [ "$SAVED_PORTS" != "$now" ] && PORTS_MOVED=y
    # https on/off or its loopback port: the proxy has to open or close that
    # listener, so it needs the restart even when no page file changed.
    if [ "${STATION_HTTPS:-n}" != "$SAVED_HTTPS" ] \
       || { [ "${STATION_HTTPS:-n}" != n ] && [ "${PORT_TLS:-}" != "$SAVED_TLS" ]; }; then
        PORTS_MOVED=y
    fi
    if [ "$PORTS_MOVED" = y ] && [ -f "$PHANTOMDIR/admin_config.json" ]; then
        python3 - "$PHANTOMDIR/admin_config.json" "$PORT_ADMIN" "$PORT_SDR" "$PORT_PUBLIC" <<'PY' \
            && ok "admin_config.json — panel $PORT_ADMIN, spectrumserver $PORT_SDR, public $PORT_PUBLIC"
import json, sys
p, admin, sdr, pub = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
cfg = json.load(open(p))
cfg.update({"port": admin, "public_port": sdr, "proxy_port": pub})
json.dump(cfg, open(p, "w"), indent=2)
PY
    fi
    # The statistics server takes PORT from its environment before its own
    # default, so a drop-in moves it without touching the installed server.
    local old_stats; old_stats="$(set -- $SAVED_PORTS; printf '%s' "${4:-}")"
    STATS_MOVED=n
    if [ -n "$old_stats" ] && [ "$old_stats" != "$PORT_STATS" ] && stats_ours; then
        STATS_MOVED=y
        if $SUDO mkdir -p /etc/systemd/system/sdr-stats.service.d 2>/dev/null \
           && printf '[Service]\nEnvironment=PORT=%s\n' "$PORT_STATS" \
              | $SUDO tee /etc/systemd/system/sdr-stats.service.d/port.conf >/dev/null 2>&1; then
            $SUDO systemctl daemon-reload 2>/dev/null
            ok "statistics server — port $PORT_STATS"
        else
            warn "could not move the statistics server — sudo is needed"
        fi
    fi
    # Start at boot follows a change of receiver.
    if [ -n "$SAVED_LAUNCHER" ] && [ "$SAVED_LAUNCHER" != "$STATION_LAUNCHER" ] \
       && unit_ours phantomsdr-receiver; then
        bash "$PHANTOMDIR/setup-autostart.sh" "$STATION_LAUNCHER" >/dev/null 2>&1 \
            && ok "start at boot — now $STATION_LAUNCHER"
    fi
}

put_into_service() {
    local changed="$1" page=n
    [[ $changed == *site_information.json* ]] && page=y
    [ -n "$changed" ] || [ "$PORTS_MOVED" = y ] || return 0
    say ""
    say "  To take effect:"
    [ "$page" = y ] && say "    • the page is rebuilt (a few minutes)"
    say "    • the receiver, and the proxy, panel, statistics and relay that run, are restarted"
    [ "$PORTS_MOVED" = y ] && [ -n "$SAVED_PORTS" ] && [ "${SAVED_PORTS%% *}" != "$PORT_PUBLIC" ] \
        && say "    • ${Y}the public port is now $PORT_PUBLIC — change the forwarding on your router too${N}"
    # PHANTOM_PUT_NOW=y|n answers this unattended (default there: no).
    PUT_NOW="${PHANTOM_PUT_NOW:-}"
    if [ -z "$PUT_NOW" ] && [ "$PHANTOM_NONINTERACTIVE" != "1" ]; then
        ask_yn PUT_NOW "Do this now? (listeners are cut off for a moment)" y
    fi
    [[ ${PUT_NOW:-n} =~ ^[Yy] ]] && PUT_NOW=y || PUT_NOW=n
    if [ "$PUT_NOW" != y ]; then
        say "  Later, by hand:"
        [ "$page" = y ] && say "      ./recompile.sh --frontend"
        say "      ./$STATION_LAUNCHER       (and: sudo systemctl restart phantomsdr-proxy phantomsdr-admin)"
        return 0
    fi
    if [ "$page" = y ]; then
        ( cd "$PHANTOMDIR" && bash ./recompile.sh --frontend >/dev/null 2>&1 ) \
            && ok "page rebuilt" || warn "the page did not rebuild — run: ./recompile.sh --frontend"
    fi
    local u
    for u in phantomsdr-proxy phantomsdr-admin phantomsdr-websdr-relay; do
        unit_ours "$u" || continue
        systemctl is-active --quiet "$u" 2>/dev/null || continue
        $SUDO systemctl restart "$u" 2>/dev/null && ok "restarted $u" || warn "could not restart $u"
    done
    if [ "${STATS_MOVED:-n}" = y ]; then
        $SUDO systemctl restart sdr-stats 2>/dev/null && ok "restarted sdr-stats" || warn "could not restart sdr-stats"
    fi
    # A proxy started by hand (no systemd) is not ours to restart.
    if ! unit_ours phantomsdr-proxy && pgrep -f "$PHANTOMDIR/proxy\.py" >/dev/null 2>&1; then
        warn "proxy.py runs without systemd — restart it by hand (bash manage_admin.sh stop; bash manage_admin.sh start)"
    fi
    # Only this folder's receiver: its watchdog runs "bash <this folder>/start-X.sh".
    local here; here="$(printf '%s' "$PHANTOMDIR" | sed 's/[][\.*^$+?(){}|/]/\\&/g')"
    if unit_ours phantomsdr-receiver && systemctl is-active --quiet phantomsdr-receiver; then
        $SUDO systemctl restart phantomsdr-receiver && ok "restarted the receiver"
    elif pgrep -f "$here/start-[a-z0-9-]+\.sh --watchdog" >/dev/null 2>&1; then
        ( cd "$PHANTOMDIR" && bash "./$STATION_LAUNCHER" -q >/dev/null 2>&1 ) && ok "restarted the receiver"
    else
        say "  The receiver is not running — start it with: ./$STATION_LAUNCHER"
    fi
}

# ═════════════════════════════════════════════════════════════════════════════
case "$MODE" in
    ask|all)
        ask_everything
        summary
        SAVE_IT=y
        [ "$PHANTOM_NONINTERACTIVE" = "1" ] || ask_yn SAVE_IT "Save these settings?" y
        [ "$SAVE_IT" = y ] || die "nothing was saved"
        save_conf
        ok "saved station.conf"
        ;;
esac

case "$MODE" in
    apply|all)
        title "Writing the configuration"
        apply_files
        changed="$(cat "$PHANTOMDIR/.station-changed" 2>/dev/null)"
        rm -f "$PHANTOMDIR/.station-changed"
        # Only on an installed station run on its own: the installer calls
        # --ask and --apply and starts everything itself at the end.
        if [ "$MODE" = all ] && [ -x "$PHANTOMDIR/build/spectrumserver" ]; then
            carry_ports
            put_into_service "$changed"
            # Relay switched on here: the answer alone only wrote its config,
            # and on an https station most diversity partners need it running.
            # --service keeps that config and installs the systemd unit.
            if [ "${STATION_RELAY:-n}" = y ] && command -v systemctl >/dev/null 2>&1 \
               && ! systemctl is-active --quiet phantomsdr-websdr-relay 2>/dev/null; then
                title "Diversity relay"
                bash "$PHANTOMDIR/setup_websdr_relay.sh" --service \
                    || warn "The relay did not start — run: bash setup_websdr_relay.sh"
            fi
            # https switched on, off, or moved to another loopback port: Caddy
            # follows (setup-https.sh calls back here with PHANTOM_FROM_HTTPS).
            if [ -z "${PHANTOM_FROM_HTTPS:-}" ]; then
                if [ "${STATION_HTTPS:-n}" != "$SAVED_HTTPS" ] \
                   || { [ "${STATION_HTTPS:-n}" != n ] && [ "${PORT_TLS:-}" != "$SAVED_TLS" ]; } \
                   || { [ "${STATION_HTTPS:-n}" = y ] && [ "${STATION_PUBLIC_HOST:-}" != "$SAVED_HOST" ]; }; then
                    case "${STATION_HTTPS:-n}" in
                        y)   bash "$PHANTOMDIR/setup-https.sh" ;;
                        lan) bash "$PHANTOMDIR/setup-https.sh" --lan ;;
                        *)   bash "$PHANTOMDIR/setup-https.sh" --remove ;;
                    esac
                fi
            fi
        fi
        ;;
esac
