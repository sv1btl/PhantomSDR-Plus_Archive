#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  PhantomSDR-Plus  –  start-fobos.sh
#  Universal launcher + watchdog for a RigExpert Fobos SDR, RF path 25-6000 MHz (via SoapySDR rx_sdr).
#
#  Same self-contained design as start-rx888mk2.sh: one script that STARTS,
#  RESTARTS, WATCHDOGS (auto-restarts on failure) and LOGS the server. Derives
#  its own directory — no hard-coded or user-specific paths. Shares stop-websdr.sh.
#
#  Usage:
#    ./start-fobos.sh              start (or restart) the server in the background
#    ./stop-websdr.sh              stop the server + watchdog (separate script)
#  Add -q to the start command for two-line output instead of the live log.
#
#  Env overrides (optional):
#    SPECTRUM_CORES=0-3            pin spectrumserver to these CPUs (taskset list)
#    SPECTRUM_CORES=none          do not pin at all
#    RADE_ENABLED=0               do not run the RADE sidecar at all
#    DRM_ENABLED=0                do not run the DRM helper at all
#    INSTANCE=vhf                 run as a separate receiver set up in
#                                 instances/vhf/; stop it with ./stop-websdr.sh vhf
#    RX_ARGS="…"                  override the rx_sdr argument string
#
#  Drivers: ./setup-fobos.sh (or install.sh option 5) builds SoapyFobosSDR,
#  rx_sdr and cf32_to_real. The Fobos streams ONE path at a time, RF or HF —
#  start-fobos.sh and start-fobos-hf.sh share the watchdog lock like every
#  start-*.sh, so starting one stops the other.
#
#  Choose the RF window before first use: -f (centre) and -s (sample rate) in
#  RX_ARGS below must match frequency= and sps= in config-fobos.toml.
#
#  NOTE: not tested on Fobos hardware in this RF mode — it reuses the exact
#  control/watchdog logic validated on RX-888; only the receiver command/config
#  differ.
# ─────────────────────────────────────────────────────────────────────────────

PHANTOMDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SELF="$PHANTOMDIR/$(basename "${BASH_SOURCE[0]}")"

# ── node from nvm ───────────────────────────────────────────────────────────
# The DRM helper runs on node. install.sh installs Node through nvm when the
# system copy is too old, and nvm puts node on PATH only in a login shell —
# started by systemd (phantomsdr-receiver.service, at boot) the launcher would
# find no node and skip the DRM helper, so every listener gets "The DRM
# decoder on the server cannot be reached". Use nvm's default node then.
if ! command -v node >/dev/null 2>&1; then
    _nvm="${NVM_DIR:-$HOME/.nvm}"
    _want="$(cat "$_nvm/alias/default" 2>/dev/null)"; _want="${_want#v}"
    _nb="$(ls -d "$_nvm/versions/node/v${_want}"*/bin 2>/dev/null | sort -V | tail -1)"
    [ -x "$_nb/node" ] || _nb="$(ls -d "$_nvm"/versions/node/v*/bin 2>/dev/null | sort -V | tail -1)"
    [ -n "$_nb" ] && [ -x "$_nb/node" ] && export PATH="$_nb:$PATH"
    unset _nvm _want _nb
fi

# ── station.conf (written by configure-station.sh) ───────────────────────────
# A station set up with the wizard keeps its choices there. For the main
# receiver, and only for the launcher the wizard was run for, STATION_FREQ and
# STATION_SPS replace the default tuning and sample rate the receiver is
# started with; RX_ARGS / RX888_ARGS given on the command line still win, and
# a named instance keeps using its own instance.env. The RADE sidecar then
# listens on loopback at PORT_RADE, because proxy.py carries it to the public
# port as /rade. Without station.conf nothing here changes anything.
if [ -f "$PHANTOMDIR/station.conf" ] && { [ -z "${INSTANCE:-}" ] || [ "${INSTANCE:-}" = "main" ]; }; then
    # shellcheck disable=SC1091
    . "$PHANTOMDIR/station.conf"
    if [ "${STATION_LAUNCHER:-}" != "$(basename "$SELF")" ]; then
        unset STATION_FREQ STATION_SPS             # chosen for another receiver
    fi
    if [ -n "${PORT_RADE:-}" ]; then
        export RADE_HELPER_PORT="${RADE_HELPER_PORT:-$PORT_RADE}"
        export RADE_HELPER_HOST="${RADE_HELPER_HOST:-127.0.0.1}"
    fi
    if [ -n "${PORT_DRM:-}" ]; then             # proxy.py carries it as /drm
        export DRM_HELPER_PORT="${DRM_HELPER_PORT:-$PORT_DRM}"
        export DRM_HELPER_HOST="${DRM_HELPER_HOST:-127.0.0.1}"
    fi
    # "No" in the wizard means "do not install RADE". A station that already
    # has ~/radae keeps decoding, as it always did; RADE_ENABLED=0 still
    # switches it off on purpose.
    if [ "${STATION_RADE:-}" = "n" ] && [ ! -f "${RADAE_DIR:-$HOME/radae}/radae_rxe.py" ]; then
        RADE_ENABLED="${RADE_ENABLED:-0}"
    fi
fi

# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═════════════════
RX_LABEL="Fobos SDR RF"
RX_COMM="rx_sdr"                                   # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-fobos.toml"
FIFO="$PHANTOMDIR/fobos.fifo"
# Keep -f / -s in step with frequency= / sps= in config-fobos.toml.
RX_ARGS="${RX_ARGS:--d driver=fobos -f ${STATION_FREQ:-97000000} -s ${STATION_SPS:-20000000} -I CF32 -F CF32 -}"
RX_CMD=(rx_sdr)                                    # binary; args come from RX_ARGS
prestart() { :; }
# ═════════════════════════════════════════════════════════════════════════════

# ── instance: several receivers on one box ───────────────────────────────────
# Empty (the default) is the main receiver and keeps the historical file names
# (logwebsdr.txt, spectrumserver.log, .watchdog.lock, the FIFO above), so a
# single-receiver station sees no change at all. A name — INSTANCE=vhf
# ./start-rtl.sh — gives this receiver its own log, server log, lock and FIFO,
# and ./stop-websdr.sh vhf stops only it. Two launchers run with the same
# instance replace each other, exactly as any two launchers did before.
#
# Every process started from here inherits PHANTOMSDR_INSTANCE. That tag, not
# the process name, is how this script and stop-websdr.sh tell receivers apart:
# two of them may run the very same binary (two rtl_sdr, or rx_sdr for both an
# RSP1A and an Airspy).
INSTANCE="${INSTANCE:-}"
[ "$INSTANCE" = "main" ] && INSTANCE=""
case "$INSTANCE" in
    *[!A-Za-z0-9_-]*)
        echo "$(basename "$SELF"): INSTANCE may only contain letters, digits, - and _" >&2
        exit 1 ;;
esac
export INSTANCE
export PHANTOMSDR_INSTANCE="${INSTANCE:-main}"
# The installation, too: a second copy of PhantomSDR-Plus on this computer (a
# test tree, another station) may use the same instance names.
export PHANTOMSDR_TREE="$PHANTOMDIR"
SFX="${INSTANCE:+-$INSTANCE}"
FIFO="${FIFO%.fifo}$SFX.fifo"

# A named instance lives in instances/<name>/: its own config.toml, and the
# working directory its spectrumserver runs in, so chat_history.txt,
# markers.json, the FFTW wisdom and logs/ are its own as well. An optional
# instance.env there is read last and may set RX_ARGS, SPECTRUM_CORES and the
# like for this receiver only.
INSTDIR=""
if [ -n "$INSTANCE" ]; then
    INSTDIR="$PHANTOMDIR/instances/$INSTANCE"
    CONFIG="$INSTDIR/config.toml"
    if [ ! -f "$CONFIG" ]; then
        echo "$(basename "$SELF"): instance $INSTANCE needs $CONFIG — create it first" >&2
        exit 1
    fi
    # shellcheck disable=SC1091
    [ -f "$INSTDIR/instance.env" ] && . "$INSTDIR/instance.env"
else
    # main.env is the main receiver's instance.env: the admin panel's Receivers
    # page keeps its gain there (RX_ARGS / RX888_ARGS), since configure-station.sh
    # rewrites station.conf. Read last, like instance.env.
    # shellcheck disable=SC1091
    [ -f "$PHANTOMDIR/main.env" ] && . "$PHANTOMDIR/main.env"
fi

LOG="$PHANTOMDIR/logwebsdr$SFX.txt"
SPECTRUM="$PHANTOMDIR/build/spectrumserver"
STOP="$PHANTOMDIR/stop-websdr.sh"
LOCK="$PHANTOMDIR/.watchdog$SFX.lock"

# RADE v1 sidecar (optional — skipped silently if rade_helper.py isn't present).
RADE="$PHANTOMDIR/rade_helper.py"
RADE_LOG="$PHANTOMDIR/rade.log"

# DRM helper (optional — skipped when setup-drm.sh has not built the decoder).
DRM_HELPER="$PHANTOMDIR/autorun/drm-helper.js"
DRM_BIN="$PHANTOMDIR/drm/bin/ubersdr-drm"
DRM_LOG="$PHANTOMDIR/drm.log"

# spectrumserver's own stdout/stderr (client connects, [WebSDROrg] registration,
# curl errors). Kept out of $LOG so the bring-up log stays readable; the
# [WebSDROrg] lines are mirrored into $LOG because those are worth watching.
SRV_LOG="$PHANTOMDIR/spectrumserver$SFX.log"
SRV_LOG_MAX=10485760            # rotate at 10 MB (one .1 generation kept)
LOG_MAX=2097152                 # rotate logwebsdr.txt at 2 MB (one .1 kept)

SS_PID=""
RX_PID=""
SS_TASKSET=()

# ── logging helpers ─────────────────────────────────────────────────────────
log()   { echo "$*"          >> "$LOG"; }
stamp() { date --rfc-email   >> "$LOG"; }

# ── keep $LOG bounded (it is append-only and long-lived) ─────────────────────
# One generation is kept: logwebsdr.txt.1. Note that everything writing to $LOG
# must reopen it per line (log() does, and so does the mirror in
# start_spectrumserver) — a writer holding the fd open would keep appending to
# the renamed inode and its output would vanish from the live log.
rotate_log() {
    local sz
    sz=$(wc -c < "$LOG" 2>/dev/null || echo 0)
    [ "$sz" -gt "$LOG_MAX" ] 2>/dev/null || return 0
    mv -f "$LOG" "$LOG.1" 2>/dev/null
    stamp
    log "(log passed $LOG_MAX bytes — previous log is now $(basename "$LOG").1)"
}

# ── keep $SRV_LOG bounded while the server is RUNNING ────────────────────────
# start_spectrumserver() trims this file too, but only at startup: a receiver
# left running for months therefore had no bound at all. This is the periodic
# half of it.
#
# It cannot rename the file the way rotate_log() does. spectrumserver.log is
# written by `tee -a`, which holds the fd open for the life of the server, so a
# rename would leave tee appending to the renamed inode and the live log would
# stay empty until the next restart — exactly the trap described above. Copy
# and truncate instead: tee opened with O_APPEND, so its next write lands at
# offset 0 of the emptied file. Lines written between the copy and the truncate
# are lost, which is the accepted cost of this approach (logrotate calls it
# copytruncate and makes the same trade).
rotate_srv_log() {
    local sz
    sz=$(wc -c < "$SRV_LOG" 2>/dev/null || echo 0)
    [ "$sz" -gt "$SRV_LOG_MAX" ] 2>/dev/null || return 0
    cp -f "$SRV_LOG" "$SRV_LOG.1" 2>/dev/null || return 0
    : > "$SRV_LOG"
    log "($(basename "$SRV_LOG") passed $SRV_LOG_MAX bytes — previous log is now $(basename "$SRV_LOG").1)"
}

# ── read one key out of one [section] of the TOML config ─────────────────────
# Deliberately tiny: enough for scalar keys (enabled/public_host/public_port),
# not a TOML parser. Arrays and multi-line values are not handled — spectrumserver
# is the authority on the config, this is only for what we print. $1 = section
# name without brackets (e.g. "websdr.org"), $2 = key. Empty output = not found.
toml_get() {
    [ -f "$CONFIG" ] || return 1
    awk -v sect="$1" -v key="$2" '
        /^[[:space:]]*\[/ {                       # section header line
            s = $0
            sub(/^[[:space:]]*\[/, "", s)
            sub(/\][[:space:]]*$/, "", s)
            in_s = (s == sect)
            next
        }
        !in_s { next }
        {
            line = $0
            sub(/^[[:space:]]+/, "", line)
            if (index(line, key) != 1) next       # key must start the line
            rest = substr(line, length(key) + 1)
            if (rest !~ /^[[:space:]]*=/) next    # ...and be followed by =
            sub(/^[^=]*=[[:space:]]*/, "", line)
            sub(/[[:space:]]+#.*$/, "", line)     # strip trailing comment
            gsub(/^["'"'"']|["'"'"']$/, "", line) # strip surrounding quotes
            sub(/[[:space:]]+$/, "", line)
            print line
            exit
        }
    ' "$CONFIG" 2>/dev/null
}

# ── announce what the config asks for regarding the public directories ───────
# Two independent mechanisms, both driven by the .toml:
#   [websdr] register_online  → periodic HTTPS POSTs to register_urls
#                               (sdr-list.xyz etc.); silent unless curl fails.
#   [websdr.org] enabled      → a persistent TCP registration thread that logs
#                               [WebSDROrg] Connected / ping / OK lines, which
#                               start_spectrumserver mirrors into $LOG.
report_registration() {
    local en host port
    en=$(toml_get "websdr.org" enabled)
    if [ "$en" = "true" ]; then
        host=$(toml_get "websdr.org" public_host)
        port=$(toml_get "websdr.org" public_port)
        log "websdr.org: ENABLED — announcing ${host:-?}:${port:-?} (watch for [WebSDROrg] lines)"
    else
        log "websdr.org: disabled ([websdr.org] enabled=true in $(basename "$CONFIG") to enable)"
    fi
    if [ "$(toml_get websdr register_online)" = "true" ]; then
        log "SDR directory: ENABLED — posting to [websdr] register_urls (quiet unless it errors)"
    else
        log "SDR directory: disabled ([websdr] register_online=true to enable)"
    fi
}

# ── which instance a process belongs to ──────────────────────────────────────
# Read from its environment. No tag means it was started before instances
# existed, which can only have been the main receiver.
instance_of() {
    local v
    v=$(tr '\0' '\n' < "/proc/$1/environ" 2>/dev/null | sed -n 's/^PHANTOMSDR_INSTANCE=//p')
    echo "${v:-main}"
}

# ── which installation a process belongs to (empty = started before the tag) ─
tree_of() {
    tr '\0' '\n' < "/proc/$1/environ" 2>/dev/null | sed -n 's/^PHANTOMSDR_TREE=//p'
}

# ── PIDs of THIS instance's processes with an exact command name ─────────────
# Same instance AND same installation — or no installation tag at all, which
# only a process started before the tag existed can lack.
own_pids() {
    local pid tree
    for pid in $(pgrep -x "$1" 2>/dev/null); do
        [ "$(instance_of "$pid")" = "$PHANTOMSDR_INSTANCE" ] || continue
        tree="$(tree_of "$pid")"
        [ -z "$tree" ] || [ "$tree" = "$PHANTOMDIR" ] || continue
        echo "$pid"
    done
}

# ── is a process of this instance alive (by exact command name)? ─────────────
# Zombies don't count.
is_running() {
    local pid stat
    for pid in $(own_pids "$1"); do
        stat=$(awk '{print $3}' "/proc/$pid/stat" 2>/dev/null)
        case "$stat" in Z) ;; "") ;; *) return 0 ;; esac
    done
    return 1
}

# ── SIGKILL this instance's processes with an exact command name ─────────────
kill_own() {
    local pids
    pids=$(own_pids "$1")
    # shellcheck disable=SC2086
    [ -n "$pids" ] && kill -KILL $pids 2>/dev/null
    return 0
}

# ── kill only the receiver/server processes (never the watchdog) ─────────────
# Writer first, then reader (spectrumserver): killing the reader first would
# hand the writer a Broken-Pipe panic on the FIFO.
kill_receivers() {
    kill_own "$RX_COMM"
    sleep 1
    kill_own spectrumserver
    sleep 2
    [ -n "$RX_PID" ] && wait "$RX_PID" 2>/dev/null; RX_PID=""
    [ -n "$SS_PID" ] && wait "$SS_PID" 2>/dev/null; SS_PID=""
}

# ── derive an optional CPU pin for spectrumserver + the capture process ──────
# On boxes with >4 cores, pin the FFT/audio threads and the sample reader to the
# lower cores and keep the top few free (reduces waterfall/audio jitter). The
# reserved top cores are where the autorun daemon pins its decode workers, and a
# decode burst can saturate them all — which is exactly what the sample reader
# must not be sharing. Not heat-neutral for the reader: it moves work onto
# higher-clocked cores. Generic via nproc; SPECTRUM_CORES overrides (a list to
# pin, or none/off to disable both pins).
compute_taskset() {
    SS_TASKSET=()
    command -v taskset >/dev/null 2>&1 || return
    local override nproc reserve hi
    case "$(printf '%s' "${SPECTRUM_CORES:-}" | tr '[:upper:]' '[:lower:]')" in
        "")                override="" ;;
        none|off|unpinned) return ;;
        *[!0-9,-]*)        override="" ;;
        *)                 override="$SPECTRUM_CORES" ;;
    esac
    if [ -n "$override" ]; then
        SS_TASKSET=(taskset -c "$override")
        return
    fi
    nproc=$(nproc 2>/dev/null || echo 0)
    if [ "$nproc" -gt 4 ]; then
        if [ "$nproc" -ge 12 ]; then reserve=4; else reserve=$(( nproc / 4 )); [ "$reserve" -lt 1 ] && reserve=1; fi
        hi=$(( nproc - reserve - 1 ))
        SS_TASKSET=(taskset -c "0-$hi")
    fi
}

# ── start the receiver (FIFO pre-open + retry) ───────────────────────────────
# Pre-opening the FIFO O_RDWR on fd 8 provides a reader so the receiver's
# write-open doesn't block; kill -0 then tests the real process. fd 8 is closed
# once spectrumserver holds the read end. Returns 0 if the receiver stays up.
start_receiver() {
    if ! command -v "${RX_CMD[0]}" >/dev/null 2>&1; then
        log "ERROR: receiver binary '${RX_CMD[0]}' not found in PATH"
        return 1
    fi
    local attempt
    for attempt in 1 2 3; do
        log "Starting $RX_LABEL ($RX_COMM, attempt $attempt/3)..."
        rm -f "$FIFO"
        mkfifo "$FIFO"
        exec 8<>"$FIFO"
        # taskset execs into the target, so $! stays the real receiver PID — the
        # kill -0 check below and kill_own are unaffected.
        # shellcheck disable=SC2086
        "${SS_TASKSET[@]}" "${RX_CMD[@]}" $RX_ARGS > "$FIFO" &
        RX_PID=$!
        sleep 5
        if kill -0 "$RX_PID" 2>/dev/null; then
            log "$RX_COMM running (PID $RX_PID)"
            return 0
        fi
        exec 8>&-
        RX_PID=""
        sleep 5
    done
    return 1
}

# ── start spectrumserver, then release the pre-opened FIFO fd ─────────────────
start_spectrumserver() {
    log "Starting spectrumserver (config: $(basename "$CONFIG"))..."

    # Keep spectrumserver.log from growing without bound across restarts.
    if [ -f "$SRV_LOG" ] && [ "$(wc -c < "$SRV_LOG" 2>/dev/null || echo 0)" -gt "$SRV_LOG_MAX" ]; then
        mv -f "$SRV_LOG" "$SRV_LOG.1" 2>/dev/null
    fi

    # Full output → $SRV_LOG; [WebSDROrg] registration lines also → $LOG so the
    # terminal mirror shows them. Two kinds of routine chatter are kept to
    # $SRV_LOG only, or $LOG would be nothing else: the /~~orgstatus callback
    # (every ~5s) and the keep-alive registration ping (every 60s, three lines
    # a time). What is left in $LOG is the registration story — start, connect,
    # the first ping and its acceptance, plus one "#N OK" confirmation after
    # every later reconnect (the counter never restarts, so #1 alone would go
    # quiet for the rest of the run). Nothing is filtered on the failure side:
    # send/receive failures, drops and connect errors don't match and pass
    # through. Process substitution (not a pipe) is used on purpose: with a
    # pipe, $! would be grep's PID and SS_PID would be wrong.
    "${SS_TASKSET[@]}" "$SPECTRUM" --config "$CONFIG" < "$FIFO" \
        > >(tee -a "$SRV_LOG" \
            | grep --line-buffered -E '^\[WebSDROrg\]' \
            | grep --line-buffered -v -E '^\[WebSDROrg\] /~~orgstatus' \
            | { after_connect=0
                while IFS= read -r l; do
                    # Ping filter. This lives in the read loop rather than in an
                    # awk stage on purpose: mawk buffers its INPUT and emits
                    # nothing until EOF, which for a process that runs for weeks
                    # means the mirror never appears at all. `read` is unbuffered.
                    msg=${l#"[WebSDROrg] "}
                    case "$msg" in
                        "Connected to "*) after_connect=1 ;;
                        "Sending registration ping #"*|"Waiting response for ping #"*)
                            [ "${msg##*#}" = "1" ] || continue ;;
                        "#"*" OK"*|"ping #"*" OK"*)
                            n=${msg#*#}; n=${n%% *}
                            [ "$n" = "1" ] || [ "$after_connect" = "1" ] || continue
                            after_connect=0 ;;
                    esac
                    echo "$l" >> "$LOG"
                done; }) 2>&1 &
    SS_PID=$!
    log "spectrumserver running (PID $SS_PID) — full output: $(basename "$SRV_LOG")"
    sleep 2
    exec 8>&-
    sleep 3
}

# ── RADE v1 sidecar ──────────────────────────────────────────────────────────
# rade_helper.py talks to the running spectrumserver, so its lifetime is tied to
# the server's: stopped before every bring-up, started after one succeeds, and
# revived by the same watchdog loop that watches the receiver. No separate
# self-restarting loop is needed — the loop below already polls every 5s.
# Availability is decided in ONE place so the log, the watchdog and the closing
# summary can never disagree. Echoes: ok | off | missing | nopython.
# A missing sidecar is not an error — the server runs fine without it, we just
# say so instead of leaving the user wondering.
rade_state() {
    [ -n "$INSTANCE" ]             && { echo instance; return; }
    [ "${RADE_ENABLED:-1}" = "0" ] && { echo off;      return; }
    [ -f "$RADE" ]                 || { echo missing;  return; }
    command -v python3 >/dev/null 2>&1 || { echo nopython; return; }
    echo ok
}

# Human-readable reason for every non-ok state (empty when ok).
rade_reason() {
    case "$(rade_state)" in
        instance) echo "RADE runs with the main receiver only — sidecar not activated for instance $INSTANCE" ;;
        off)      echo "RADE disabled (RADE_ENABLED=0) — sidecar not activated" ;;
        missing)  echo "RADE not installed ($(basename "$RADE") not found) — sidecar not activated" ;;
        nopython) echo "RADE not activated — python3 not found in PATH" ;;
    esac
}

rade_wanted() { [ "$(rade_state)" = "ok" ]; }
rade_running() { pgrep -f "rade_helper\.py" >/dev/null 2>&1; }

# The sidecar is a singleton on a fixed port that belongs to the main receiver,
# so another instance's restart must not take it down.
stop_rade() {
    [ -n "$INSTANCE" ] && return 0
    pkill -9 -f "rade_helper\.py" 2>/dev/null
    killall -KILL lpcnet_demo 2>/dev/null
    sleep 1
}

start_rade() {
    rade_wanted || return 0
    rade_running && return 0
    log "[RADE] sidecar starting at $(date --rfc-email)"
    python3 "$RADE" >> "$RADE_LOG" 2>&1 &
    disown 2>/dev/null
}

# ── DRM helper ───────────────────────────────────────────────────────────────
# autorun/drm-helper.js taps the running spectrumserver for each DRM listener,
# so it lives and dies with the server exactly like the RADE sidecar above.
# Echoes: ok | instance | off | missing | nonode.
drm_state() {
    [ -n "$INSTANCE" ]            && { echo instance; return; }
    [ "${DRM_ENABLED:-1}" = "0" ] && { echo off;      return; }
    [ -f "$DRM_HELPER" ] && [ -x "$DRM_BIN" ] || { echo missing; return; }
    command -v node >/dev/null 2>&1 || { echo nonode; return; }
    echo ok
}

drm_reason() {
    case "$(drm_state)" in
        instance) echo "DRM runs with the main receiver only — helper not activated for instance $INSTANCE" ;;
        off)      echo "DRM disabled (DRM_ENABLED=0) — helper not activated" ;;
        missing)  echo "DRM not installed (run ./setup-drm.sh) — helper not activated" ;;
        nonode)   echo "DRM not activated — node not found in PATH" ;;
    esac
}

drm_wanted() { [ "$(drm_state)" = "ok" ]; }
drm_running() { pgrep -f "autorun/drm-helper\.js" >/dev/null 2>&1; }

# A singleton on a fixed port that belongs to the main receiver; its decoders
# (one ubersdr-drm per listener) go with it.
stop_drm() {
    [ -n "$INSTANCE" ] && return 0
    pkill -f "autorun/drm-helper\.js" 2>/dev/null
    pkill -9 -f "drm/bin/ubersdr-drm" 2>/dev/null
}

start_drm() {
    drm_wanted || return 0
    drm_running && return 0
    log "[DRM] helper starting at $(date --rfc-email)"
    node "$DRM_HELPER" >> "$DRM_LOG" 2>&1 &
    disown 2>/dev/null
}

# ── bring the whole chain up and confirm it (polls, no fixed sleep) ──────────
bring_up() {
    local kind="$1" i failed=""
    kill_receivers
    stop_rade
    stop_drm
    if ! start_receiver; then
        stamp; log "Server ${kind} FAILED — $RX_COMM did not start"; log " "
        return 1
    fi
    start_spectrumserver

    for i in $(seq 1 24); do
        if is_running spectrumserver && is_running "$RX_COMM"; then
            stamp
            start_rade
            start_drm
            [ "$kind" = "initial" ] && log "Server started normally" || log "Server restarted normally"
            log " "
            return 0
        fi
        sleep 5
    done

    is_running spectrumserver || failed="spectrumserver"
    is_running "$RX_COMM"     || failed="${failed:+$failed + }$RX_COMM"
    stamp; log "Server ${kind} FAILED — ${failed:-processes} did not come up"; log " "
    return 1
}

# ── watchdog loop: restart in place whenever a process dies ──────────────────
watchdog_loop() {
    local reason ticks=0
    while true; do
        sleep 5
        # Size-check the log every ~5 min (60 ticks) rather than every tick.
        ticks=$(( ticks + 1 ))
        if [ $(( ticks % 60 )) -eq 0 ]; then rotate_log; rotate_srv_log; fi
        reason=""
        is_running spectrumserver || reason="spectrumserver"
        is_running "$RX_COMM"     || reason="${reason:+$reason + }$RX_COMM"
        if [ -n "$reason" ]; then
            stamp
            log "PhantomSDR Server Broken: $reason — performing restart"
            log " "
            bring_up "restart"
            continue
        fi
        # Server is healthy: revive only the sidecar if it died on its own.
        if rade_wanted && ! rade_running; then
            log "[RADE] sidecar exited — restarting"
            start_rade
        fi
        if drm_wanted && ! drm_running; then
            log "[DRM] helper exited — restarting"
            start_drm
        fi
    done
}

# ── watchdog entry point (the detached process) ──────────────────────────────
watchdog_main() {
    exec 9>"$LOCK"
    if command -v flock >/dev/null 2>&1 && ! flock -n 9; then
        echo "$(basename "$SELF"): another watchdog is already running — exiting" >&2
        exit 0
    fi

    # Everything below starts from here, so spectrumserver's relative paths
    # (html_root, chat, markers, wisdom, logs/) land in the instance folder.
    if [ -n "$INSTDIR" ] && ! cd "$INSTDIR"; then
        log "ERROR: cannot enter $INSTDIR"
        exit 1
    fi
    rotate_log
    stamp
    log "Starting the initialization script of the PhantomSDR Server ($RX_LABEL${INSTANCE:+, instance $INSTANCE})"
    log " "
    compute_taskset
    if [ ${#SS_TASKSET[@]} -gt 0 ]; then
        log "CPU pin: ${SS_TASKSET[*]} (SPECTRUM_CORES=none to disable)"
    else
        log "CPU pin: none (unpinned)"
    fi
    report_registration
    if rade_wanted; then
        log "RADE: enabled — sidecar will start once the server is up"
    else
        log "$(rade_reason)"
    fi
    if drm_wanted; then
        log "DRM: enabled — helper will start once the server is up"
    else
        log "$(drm_reason)"
    fi
    prestart
    bring_up "initial"
    watchdog_loop
}

# ── launcher entry point (what the user runs) ────────────────────────────────
# The watchdog is detached from the terminal (that is the whole point — it must
# outlive the shell), so it can only write to $LOG. To still show what is going
# on, the launcher mirrors the log to the terminal while the bring-up runs, then
# reports the outcome and exits. Killing the launcher (Ctrl-C) only stops the
# mirroring; the watchdog keeps going. -q restores the old two-line output.
launch() {
    local quiet="$1" tail_pid="" up=0 i

    echo "PhantomSDR-Plus ($RX_LABEL${INSTANCE:+, instance $INSTANCE})"
    echo "  stopping instance $PHANTOMSDR_INSTANCE if it is running..."
    [ -f "$STOP" ] && bash "$STOP" "$PHANTOMSDR_INSTANCE" >/dev/null 2>&1
    sleep 5                        # let the device fully release after a kill

    # Mirror only what this run appends (-n 0), started before the watchdog so
    # no line is missed. -F survives the log being rotated out from under us.
    if [ "$quiet" != "quiet" ] && command -v tail >/dev/null 2>&1; then
        echo "  starting watchdog — live log below (Ctrl-C is safe, it keeps running)"
        echo "  ────────────────────────────────────────────────────────────"
        tail -n 0 -F "$LOG" 2>/dev/null &
        tail_pid=$!
    else
        echo "PhantomSDR-Plus ($RX_LABEL${INSTANCE:+, instance $INSTANCE}) starting in the background."
        echo "Progress is logged to: $LOG"
    fi

    if command -v setsid >/dev/null 2>&1; then
        setsid bash "$SELF" --watchdog >/dev/null 2>&1 &
    else
        nohup bash "$SELF" --watchdog >/dev/null 2>&1 &
    fi
    disown 2>/dev/null

    [ -n "$tail_pid" ] || exit 0

    # Worst case is ~30s of receiver retries plus the ~120s confirm poll inside
    # bring_up, so give it a little over 3 minutes before handing back the
    # prompt — the watchdog carries on either way.
    for i in $(seq 1 65); do
        sleep 3
        if is_running spectrumserver && is_running "$RX_COMM"; then up=1; break; fi
    done

    # If websdr.org registration is on, keep the mirror running a bit longer so
    # the [WebSDROrg] connect/ping/OK handshake is actually seen. It runs in a
    # thread of its own, so it lands a few seconds after the server is up.
    local org_state="off"
    if [ "$up" = 1 ] && [ "$(toml_get "websdr.org" enabled)" = "true" ]; then
        org_state="pending"
        for i in $(seq 1 15); do
            sleep 2
            if tail -n 60 "$LOG" 2>/dev/null | grep -qE '^\[WebSDROrg\] (ping )?#[0-9]+ OK'; then
                org_state="ok"; break
            fi
        done
    fi

    sleep 2                        # let the last log lines flush through tail
    kill "$tail_pid" 2>/dev/null
    wait "$tail_pid" 2>/dev/null
    echo "  ────────────────────────────────────────────────────────────"

    if [ "$up" = 1 ]; then
        echo "  ✔ server is up   (spectrumserver + $RX_COMM running)"
        if ! rade_wanted; then
            echo "  · $(rade_reason)"
        elif rade_running; then
            echo "  ✔ RADE sidecar running"
        else
            echo "  ! RADE sidecar not up — see $RADE_LOG"
        fi
        if ! drm_wanted; then
            echo "  · $(drm_reason)"
        elif drm_running; then
            echo "  ✔ DRM helper running"
        else
            echo "  ! DRM helper not up — see $DRM_LOG"
        fi
        case "$org_state" in
            ok)      echo "  ✔ websdr.org registered ($(toml_get "websdr.org" public_host):$(toml_get "websdr.org" public_port))" ;;
            pending) echo "  ! websdr.org enabled but no OK yet — it retries every 30s"
                     echo "    Check: grep WebSDROrg $LOG" ;;
            *)       echo "  · websdr.org registration disabled in $(basename "$CONFIG")" ;;
        esac
        [ "$(toml_get websdr register_online)" = "true" ] \
            && echo "  · SDR directory posting enabled (errors only, in $(basename "$SRV_LOG"))"
    else
        echo "  ✖ server did not come up in time — the watchdog is still retrying."
        echo "    Check: tail -f $LOG"
    fi
    echo "  Full log: $LOG"
    exit 0
}

case "${1:-}" in
    --watchdog)          watchdog_main ;;
    ""|start|restart)    launch ;;
    -q|--quiet)          launch quiet ;;
    *) echo "usage: $(basename "$0") [start|restart|-q]" >&2; exit 1 ;;
esac
