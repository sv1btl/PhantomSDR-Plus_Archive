#!/usr/bin/env python3
"""
PhantomSDR-Plus Admin Panel — Internal service (localhost only).
Do NOT run this directly for public access.
Use proxy.py to expose it on the main port alongside spectrumserver.

Direct access (internal/dev only): http://127.0.0.1:8901/admin
Via proxy (production):            http://server_address:8900/admin
Default password: admin (change on first login!)
"""

import os
import sys
import json
import hashlib
import subprocess
import threading
import time
import signal
import re
import shlex
import glob
import shutil
import logging
from collections import deque
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None

try:
    import tomli_w
except ImportError:
    tomli_w = None

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

# CPU over-temperature guard. Optional: a missing or broken thermal_guard.py
# must never stop the panel itself from starting.
try:
    import thermal_guard
    HAS_THERMAL = True
except Exception:
    thermal_guard = None
    HAS_THERMAL = False

from flask import (Flask, render_template_string, request, session,
                   redirect, url_for, jsonify, Response, flash)

# ─── Config ────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.resolve()
ADMIN_CONFIG_FILE = BASE_DIR / "admin_config.json"
ADMIN_PORT = int(os.environ.get("ADMIN_PORT", 3000))    # internal only — proxy.py exposes it publicly
ADMIN_BIND = os.environ.get("ADMIN_BIND", "127.0.0.1")  # localhost by default; set "0.0.0.0" for standalone
PUBLIC_PORT = int(os.environ.get("PUBLIC_PORT", 8900))  # display default only — port users actually connect to

def _get_or_create_secret_key():
    """Load secret key from config (persistent across restarts) or create and save one."""
    env_key = os.environ.get("ADMIN_SECRET")
    if env_key:
        return env_key
    try:
        if ADMIN_CONFIG_FILE.exists():
            with open(ADMIN_CONFIG_FILE) as f:
                cfg = json.load(f)
            key = cfg.get("secret_key")
            if key:
                return key
            # First run: generate, persist, return
            key = os.urandom(24).hex()
            cfg["secret_key"] = key
            with open(ADMIN_CONFIG_FILE, "w") as f:
                json.dump(cfg, f, indent=2)
            return key
    except Exception:
        pass
    return os.urandom(24).hex()  # fallback: ephemeral key (config unreadable)

SECRET_KEY = _get_or_create_secret_key()

DEFAULT_CONFIG = {
    "password_hash": hashlib.sha256(b"admin").hexdigest(),
    "port": ADMIN_PORT,
    "sdr_base_dir": str(BASE_DIR),
    "log_lines": 200,
    "start_script": "",
    "stop_script":  "",
    "public_port":  PUBLIC_PORT   # spectrumserver port (main receiver); listeners use proxy_port when proxy.py runs
}

# ─── App setup ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = SECRET_KEY

# Trust X-Forwarded-* headers from proxy.py so Flask generates correct
# external URLs for redirects and url_for() calls.
try:
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_host=1, x_proto=1, x_port=1)
except ImportError:
    pass  # Werkzeug < 1.0 — skip, redirects may use internal URL

log_buffer = []
log_lock = threading.Lock()

# ── Waterfall message (fixed banner shown to all connected users) ──────────────
_wf_message      = {"text": "", "color": "#ffffff"}
_wf_message_lock = threading.Lock()

LOG_FILES = {
    "logwebsdr.txt": "logwebsdr.txt",
    "spectrumserver.log": "spectrumserver.log",
    "admin.log": "admin.log",
    "rade.log": "rade.log",
    "drm.log": "drm.log",
    "crash.log": "crash.log",
    "autorun.log": "autorun.log",
    "proxy.log": "proxy.log",
}

# Logs that "Clear Logs" must leave alone. Empty by sysop decision: the button
# clears every log in LOG_FILES, autorun.log included.
#
# Both exclusions that used to live here are gone for the same reason — a button
# labelled "Clear Logs" that silently keeps a file looks broken, and neither file
# needed protecting. proxy.log is an access log the sysop owns; autorun.log is
# the decoder log, and while its spot history cannot be reconstructed, logrotate
# (logrotate/phantomsdr) keeps the rotated archives in logproxy/, so a clear
# costs only what has accumulated since the last rotation.
#
# Clearing autorun.log under a running decoder is safe: the daemon holds it open
# O_APPEND, so an in-place truncate takes effect immediately and the daemon goes
# on appending to the same inode. Whatever cannot be written is named in the
# toast rather than reported as success.
CLEAR_EXCLUDE = set()

# ─── Helpers ───────────────────────────────────────────────────────────────────
def load_admin_config():
    if ADMIN_CONFIG_FILE.exists():
        with open(ADMIN_CONFIG_FILE) as f:
            return json.load(f)
    return DEFAULT_CONFIG.copy()

def save_admin_config(cfg):
    with open(ADMIN_CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

def hash_password(pwd):
    return hashlib.sha256(pwd.encode()).hexdigest()

def check_password(pwd):
    cfg = load_admin_config()
    return hash_password(pwd) == cfg.get("password_hash", "")

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("authenticated"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def get_sdr_dir():
    cfg = load_admin_config()
    return Path(cfg.get("sdr_base_dir", str(BASE_DIR)))

def find_config_files():
    base = get_sdr_dir()
    files = {}
    for pattern in ["config.toml", "config-*.toml", "config.example.*.toml"]:
        for f in sorted(base.glob(pattern)):
            files[f.name] = str(f)
    return files

def find_editable_files():
    """Find all editable files (.sh .toml .cpp .h .txt .json .html) in PhantomSDR-Plus dir."""
    import os
    base  = get_sdr_dir()
    exts  = {'.sh', '.toml', '.cpp', '.h', '.txt', '.json', '.html'}
    files = {}
    skip  = {'node_modules', 'build', 'dist', '__pycache__', '.git'}
    for root, dirs, filenames in os.walk(str(base)):
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in skip]
        for fn in sorted(filenames):
            if Path(fn).suffix.lower() in exts:
                if fn == "admin_config.json":
                    continue
                full = os.path.join(root, fn)
                rel  = os.path.relpath(full, str(base))
                files[rel] = full
    return dict(sorted(files.items()))

def find_json_files():
    base = get_sdr_dir()
    files = {}
    for pattern in ["*.json", "frontend/src/*.json", "frontend/*.json"]:
        for f in sorted(base.glob(pattern)):
            if f.name != "admin_config.json":
                files[str(f.relative_to(base))] = str(f)
    return files

def find_sh_files():
    """Discover all .sh files inside PhantomSDR-Plus directory. Returns {rel_path: abs_path}."""
    import os
    base  = get_sdr_dir()
    files = {}
    for root, dirs, filenames in os.walk(str(base)):
        dirs[:] = [d for d in dirs if not d.startswith('.')
                   and d not in ('node_modules', 'build', 'dist', '__pycache__')]
        for fn in sorted(filenames):
            if fn.endswith('.sh'):
                full = os.path.join(root, fn)
                rel  = os.path.relpath(full, str(base))
                files[rel] = full
    return dict(sorted(files.items()))

def find_config_files_all():
    """Find all .toml config files inside PhantomSDR-Plus directory. Returns {name: abs_path}."""
    base  = get_sdr_dir()
    files = {}
    for pattern in ["config.toml", "config-*.toml", "config.example.*.toml", "*.toml"]:
        for f in sorted(base.glob(pattern)):
            files[f.name] = str(f)
    return dict(sorted(files.items()))

def get_allowed_configs():
    return find_config_files_all()

def get_allowed_scripts():
    return find_sh_files()
# ─── First-run / Setup helpers ─────────────────────────────────────────────────

# ─── Where this copy came from ─────────────────────────────────────────────────
# PhantomSDR-Plus is developed at ORIGIN_REPO. A sysop who cloned a fork may not
# know that, so the panel shows a notice while the tree's origin remote points
# elsewhere — the same check the installers and update.sh make. A notice only:
# the GPL allows forks. The remote is read from .git/config directly when git
# is missing or refuses the tree (another user's checkout).
ORIGIN_REPO = "https://github.com/sv1btl/PhantomSDR-Plus"

def _origin_norm(url):
    u = url.strip().lower()
    u = re.sub(r"^[a-z+]+://", "", u)
    u = re.sub(r"^[^@/]*@", "", u)
    u = re.sub(r"^github\.com:", "github.com/", u)
    u = u.rstrip("/")
    if u.endswith(".git"):
        u = u[:-4]
    return u

def tree_origin():
    """The tree's origin remote, credentials stripped, or "" when there is none."""
    url = ""
    try:
        url = subprocess.run(["git", "-C", str(BASE_DIR), "config", "--get",
                              "remote.origin.url"], capture_output=True,
                             text=True, timeout=5).stdout.strip()
    except Exception:
        url = ""
    if not url:
        try:
            section = None
            for line in (BASE_DIR / ".git" / "config").read_text(errors="replace").splitlines():
                line = line.strip()
                if line.startswith("["):
                    section = line
                elif section == '[remote "origin"]' and re.match(r"url\s*=", line):
                    url = line.split("=", 1)[1].strip()
                    break
        except Exception:
            url = ""
    # Never show a token: https://user:token@github.com/... -> https://github.com/...
    return re.sub(r"^([a-z+]+://)[^@/]*@", r"\1", url)

def fork_origin():
    """The fork this tree was cloned from, or None for the original / no git."""
    url = tree_origin()
    if url and _origin_norm(url) != "github.com/sv1btl/phantomsdr-plus":
        return url
    return None

def is_first_run():
    if not ADMIN_CONFIG_FILE.exists():
        return True
    try:
        return not load_admin_config().get("setup_complete", False)
    except Exception:
        return True

def auto_detect_sdr_candidates():
    import glob as _glob
    seen, found = set(), []
    def add(p):
        s = str(Path(p).resolve())
        if s not in seen:
            seen.add(s); found.append(s)
    add(BASE_DIR)
    for tmpl in ["~/PhantomSDR-Plus", "~/phantomsdr", "/opt/PhantomSDR-Plus",
                 "/usr/local/PhantomSDR-Plus", "/home/*/PhantomSDR-Plus"]:
        for hit in _glob.glob(str(Path(tmpl).expanduser())):
            if Path(hit).is_dir(): add(hit)
    try:
        r = subprocess.run(["pgrep", "-a", "-f", "spectrumserver"],
                           capture_output=True, text=True, timeout=3)
        for line in r.stdout.splitlines():
            for part in line.split():
                if "spectrumserver" in part and os.sep in part:
                    for anc in [Path(part).parent, Path(part).parent.parent]:
                        if anc.is_dir(): add(anc)
    except Exception:
        pass
    def score(s):
        p = Path(s)
        return (4*int((p/"build"/"spectrumserver").exists()) +
                3*int(bool(list(p.glob("config*.toml")))) +
                2*int((p/"frontend").is_dir()) +
                  int((p/"admin_server.py").exists()))
    found.sort(key=score, reverse=True)
    return found or [str(BASE_DIR)]


def get_process_status():
    status = {"running": False, "pid": None, "name": None, "cpu": 0, "mem": 0, "uptime": None}
    proc_name = "spectrumserver"
    try:
        proc_name = load_admin_config().get("sdr_process_name", "spectrumserver").strip() or "spectrumserver"
    except Exception:
        pass
    # pgrep first — works across users, no psutil needed
    try:
        r = subprocess.run(["pgrep", "-f", proc_name], capture_output=True, text=True, timeout=3)
        pids = [p for p in r.stdout.split() if p.isdigit()]
        if pids:
            status.update({"running": True, "pid": int(pids[0]), "name": proc_name})
    except Exception:
        pass
    # psutil enriches with CPU/mem/uptime
    if HAS_PSUTIL:
        try:
            for proc in psutil.process_iter(["pid", "name", "cmdline", "cpu_percent", "memory_info", "create_time"]):
                try:
                    pname = (proc.info["name"] or "").lower()
                    cmd   = " ".join(proc.info["cmdline"] or []).lower()
                    if proc_name.lower() in pname or proc_name.lower() in cmd:
                        ut = time.time() - proc.info["create_time"]
                        status.update({"running": True, "pid": proc.info["pid"],
                                       "name": proc.info["name"],
                                       "cpu": proc.cpu_percent(interval=0.1),
                                       "mem": round(proc.info["memory_info"].rss / 1024 / 1024, 1),
                                       "uptime": str(timedelta(seconds=int(ut)))})
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                except Exception:
                    pass
        except Exception:
            pass
    return status


def get_temperature():
    """Try multiple methods to get CPU temperature."""
    # psutil sensors
    if HAS_PSUTIL and hasattr(psutil, "sensors_temperatures"):
        try:
            temps = psutil.sensors_temperatures()
            for key in ("coretemp", "cpu_thermal", "acpitz", "k10temp", "zenpower"):
                if key in temps and temps[key]:
                    return round(temps[key][0].current, 1)
            # any first available
            for key, entries in temps.items():
                if entries:
                    return round(entries[0].current, 1)
        except Exception:
            pass
    # /sys/class/thermal fallback
    try:
        import glob
        for p in sorted(glob.glob("/sys/class/thermal/thermal_zone*/temp")):
            with open(p) as f:
                val = int(f.read().strip())
            if val > 0:
                return round(val / 1000.0, 1)
    except Exception:
        pass
    # sensors command fallback
    try:
        r = subprocess.run(["sensors"], capture_output=True, text=True, timeout=2)
        import re
        m = re.search(r'[Tt]emp\d*:\s+\+?([\d.]+)', r.stdout)
        if m:
            return round(float(m.group(1)), 1)
    except Exception:
        pass
    return None

def get_system_stats():
    if not HAS_PSUTIL:
        return {"cpu": "N/A", "mem_used": "N/A", "mem_total": "N/A", "disk_used": "N/A", "disk_total": "N/A", "temp": None}
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    return {
        "cpu": psutil.cpu_percent(interval=0.5),
        "mem_used": round(mem.used / 1024**3, 1),
        "mem_total": round(mem.total / 1024**3, 1),
        "mem_pct": mem.percent,
        "disk_used": round(disk.used / 1024**3, 1),
        "disk_total": round(disk.total / 1024**3, 1),
        "disk_pct": disk.percent,
        "temp": get_temperature(),
    }

def get_top_processes(n=12):
    """Return top N processes sorted by CPU usage."""
    if not HAS_PSUTIL:
        # Fallback: use 'ps' command
        try:
            result = subprocess.run(
                ["ps", "aux", "--sort=-%cpu"],
                capture_output=True, text=True
            )
            lines = result.stdout.strip().split("\n")[1:n+1]
            procs = []
            for line in lines:
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    procs.append({
                        "pid": parts[1],
                        "cpu": parts[2],
                        "mem": parts[3],
                        "name": parts[10][:40],
                    })
            return procs
        except Exception:
            return []
    procs = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status", "username"]):
        try:
            procs.append({
                "pid": proc.info["pid"],
                "name": (proc.info["name"] or "")[:35],
                "cpu": round(proc.info["cpu_percent"] or 0, 1),
                "mem": round(proc.info["memory_percent"] or 0, 1),
                "status": proc.info["status"],
                "user": (proc.info["username"] or "")[:12],
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    procs.sort(key=lambda x: x["cpu"], reverse=True)
    return procs[:n]

# ── Stats history sampler (Graphs page) ───────────────────────────────────────
# A background thread samples a few cheap counters on a fixed interval and keeps
# them in a ring buffer, so the Graphs page has history the moment it is opened
# instead of having to build it up from scratch each visit. Nothing here touches
# the disk: the buffer is memory-only and is lost on restart by design.
# Two tiers. The fine tier gives a live 2s view; the coarse tier carries the
# long ranges. Storing a day at 2s would be ~43000 points — tens of MB to hold,
# a multi-MB first payload, and 40 points per pixel of canvas, which no screen
# can show. Aggregating to 30s keeps a day in 2880 points instead.
GRAPH_INTERVAL_S   = 2          # seconds between fine samples
GRAPH_FINE_S       = 3600       # how far back the fine tier reaches (1h)
GRAPH_COARSE_EVERY = 15         # fine samples per coarse point (15 x 2s = 30s)
GRAPH_COARSE_S     = 24 * 3600  # how far back the coarse tier reaches (24h)

GRAPH_COARSE_INTERVAL_S = GRAPH_INTERVAL_S * GRAPH_COARSE_EVERY
GRAPH_MAXLEN        = GRAPH_FINE_S // GRAPH_INTERVAL_S
GRAPH_COARSE_MAXLEN = GRAPH_COARSE_S // GRAPH_COARSE_INTERVAL_S
# Ranges longer than this are served from the coarse tier.
GRAPH_HISTORY_S     = GRAPH_COARSE_S   # deepest range the page can ask for

_graph_history = deque(maxlen=GRAPH_MAXLEN)
_graph_coarse  = deque(maxlen=GRAPH_COARSE_MAXLEN)
_graph_pending = []            # fine samples not yet folded into a coarse point
_graph_lock    = threading.Lock()
_graph_started = False


def _graph_fold(batch):
    """Average a run of fine samples into one coarse point.

    Averages over the readings that exist; a field is None only when every
    sample in the run lacked it, so an occasional failed read thins the average
    instead of punching a hole in the long-range view.
    """
    def avg(key, nd):
        vals = [p[key] for p in batch if p.get(key) is not None]
        return round(sum(vals) / len(vals), nd) if vals else None
    users = [p["u"] for p in batch if p.get("u") is not None]
    return {
        "t":  batch[-1]["t"],
        "l":  avg("l", 1),
        "f":  avg("f", 2),
        "fm": avg("fm", 2),
        "c":  avg("c", 1),
        "u":  round(sum(users) / len(users)) if users else None,
    }


def get_cpu_frequency():
    """Current CPU clock in GHz: (average across cores, fastest core, hw limit).

    psutil first, then the cpufreq sysfs tree.  Both read the same kernel data
    that cpufreq-info formats, so cpufrequtils is not required.  Any element may
    be None when the platform does not expose it.
    """
    if HAS_PSUTIL:
        try:
            per = psutil.cpu_freq(percpu=True)
            cur = [f.current for f in per if f and f.current]
            if cur:
                limit = max((f.max for f in per if f and f.max), default=0)
                return (round(sum(cur) / len(cur) / 1000, 2),
                        round(max(cur) / 1000, 2),
                        round(limit / 1000, 2) if limit else None)
        except Exception:
            pass
    try:
        cur, limit = [], 0
        for d in sorted(glob.glob("/sys/devices/system/cpu/cpu[0-9]*/cpufreq")):
            try:
                with open(os.path.join(d, "scaling_cur_freq")) as f:
                    cur.append(int(f.read().strip()))
            except Exception:
                pass
            try:
                with open(os.path.join(d, "cpuinfo_max_freq")) as f:
                    limit = max(limit, int(f.read().strip()))
            except Exception:
                pass
        cur = [c for c in cur if c > 0]
        if cur:
            return (round(sum(cur) / len(cur) / 1e6, 2),
                    round(max(cur) / 1e6, 2),
                    round(limit / 1e6, 2) if limit else None)
    except Exception:
        pass
    return (None, None, None)


def _receivers_toml():
    """receivers.toml next to proxy.py (several receivers on one port), or {}."""
    try:
        with open(BASE_DIR / "receivers.toml", "rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}


def _main_receiver_port():
    """(port, source) of the MAIN receiver's spectrumserver — the one public_port
    must name — or (None, None). Taken from the running spectrumserver's own
    --config (the copies of the receiver templates in the base dir all say 9001,
    so a file on disk cannot tell which one is live), else from the receivers.toml
    entry without an instance."""
    if HAS_PSUTIL and tomllib is not None:
        try:
            for proc in psutil.process_iter(["name", "cmdline"]):
                cmd = proc.info.get("cmdline") or []
                if "spectrumserver" not in (proc.info.get("name") or "") or "--config" not in cmd:
                    continue
                i = cmd.index("--config")
                if i + 1 >= len(cmd):
                    continue
                conf = Path(cmd[i + 1])
                if not conf.is_absolute():
                    conf = get_sdr_dir() / conf
                if "instances" in conf.parts:
                    continue
                with open(conf, "rb") as f:
                    port = tomllib.load(f).get("server", {}).get("port")
                if port:
                    return int(port), conf.name + " [server] port (running receiver)"
        except Exception:
            pass
    for r in _receivers_toml().get("receiver", []):
        if not str(r.get("instance") or "").strip() and r.get("port"):
            try:
                return int(r["port"]), "receivers.toml (main receiver)"
            except (TypeError, ValueError):
                pass
    return None, None


def _sdr_ports():
    """Every spectrumserver port on this box: public_port first, then any other
    receiver receivers.toml lists. One entry on a single-receiver station."""
    cfg = load_admin_config()
    ports = [int(cfg.get("public_port", PUBLIC_PORT))]
    for r in _receivers_toml().get("receiver", []):
        try:
            p = int(r.get("port"))
        except (TypeError, ValueError):
            continue
        if p not in ports:
            ports.append(p)
    return ports


def count_connected_users():
    """Number of clients currently on the WebSDR, or None if it cannot be read.

    Uses spectrumserver's own /users endpoint — the authoritative session list —
    rather than counting sockets with 'ss', which cannot see past the proxy.
    """
    import urllib.request
    total, seen = 0, False
    # Summed over every receiver; one that is down just adds nothing.
    for port in _sdr_ports():
        try:
            with urllib.request.urlopen("http://127.0.0.1:%d/users" % port, timeout=2) as r:
                d = json.loads(r.read().decode())
        except Exception:
            continue
        seen = True
        total += d["total"] if isinstance(d.get("total"), int) else len(d.get("users", []))
    return total if seen else None


def _graph_sampler():
    """Append one sample per interval.  Never raises — a bad sample is skipped."""
    if HAS_PSUTIL:
        try:
            psutil.cpu_percent(interval=None)   # prime the delta counter
        except Exception:
            pass
    while True:
        time.sleep(GRAPH_INTERVAL_S)
        # Thermal guard rides along on this loop — it needs a temperature every
        # couple of seconds and the sampler already wakes up to take one. Its
        # own try/except so a guard problem can never stop graph sampling.
        if HAS_THERMAL:
            try:
                thermal_guard.tick()
            except Exception:
                pass
        try:
            load = None
            if HAS_PSUTIL:
                # interval=None measures since the previous call, i.e. across the
                # whole sleep — no extra blocking sample needed.
                load = round(psutil.cpu_percent(interval=None), 1)
            freq, freq_max, _ = get_cpu_frequency()
            point = {
                "t": int(time.time()),
                "l": load,
                "f": freq,
                "fm": freq_max,
                "c": get_temperature(),
                "u": count_connected_users(),
            }
            with _graph_lock:
                _graph_history.append(point)
                _graph_pending.append(point)
                if len(_graph_pending) >= GRAPH_COARSE_EVERY:
                    _graph_coarse.append(_graph_fold(_graph_pending))
                    _graph_pending.clear()
        except Exception:
            pass


def start_graph_sampler():
    global _graph_started
    if _graph_started:
        return
    _graph_started = True
    threading.Thread(target=_graph_sampler, name="graph-sampler", daemon=True).start()


def start_thermal_guard():
    """Wire the CPU over-temperature guard to this panel's start/stop paths.

    The guard itself knows nothing about PhantomSDR: it is handed callbacks, so
    it acts through whatever start/stop method THIS sysop configured, and works
    the same whether the server is supervised by a watchdog, systemd or nothing.
    """
    if not HAS_THERMAL:
        return False

    def _start():
        name = (load_admin_config().get("start_script") or "").strip()
        if not name:
            return (False, "no start_script configured — not restarting")
        return run_script(name)

    def _running():
        try:
            return bool(get_process_status().get("running"))
        except Exception:
            return False

    try:
        thermal_guard.init(load_admin_config, stop_server, _start, _running, get_sdr_dir())
        return True
    except Exception as e:
        print("[WARN] thermal guard failed to start: %s" % e)
        return False


def run_script(script_name, args=None, env=None):
    base = get_sdr_dir()
    sh   = get_allowed_scripts()
    # Resolve absolute path from whitelist map
    if script_name in sh:
        script_path = Path(sh[script_name])
    elif Path(script_name).is_absolute() and Path(script_name).exists():
        script_path = Path(script_name)
    else:
        script_path = base / script_name
    if not script_path.exists():
        return False, "Script not found: " + str(script_path)
    try:
        script_path.chmod(script_path.stat().st_mode | 0o111)
        # Output goes to a file, not a pipe: a start script tails its log for
        # minutes, and a pipe nobody reads after 3 s fills up and blocks it.
        log_path = get_sdr_dir() / "logs" / "admin-scripts.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as logf:
            logf.write("\n=== " + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "  " + script_path.name + " ===\n")
            logf.flush()
            offset = logf.tell()
            proc = subprocess.Popen(
                ["bash", str(script_path)] + list(args or []),
                cwd=str(script_path.parent),
                env=dict(os.environ, **env) if env else None,
                stdout=logf,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
        try:
            proc.wait(timeout=3)
            tail = ""
        except subprocess.TimeoutExpired:
            tail = chr(10) + "(still running — full output in logs/admin-scripts.log)"
        with open(log_path, encoding="utf-8", errors="replace") as f:
            f.seek(offset)
            out = f.read(4000) + tail
        with log_lock:
            log_buffer.append("[" + datetime.now().strftime("%H:%M:%S") + "] RAN " + script_name + ": " + out[:200])
        return True, "Started " + script_path.name + " (PID " + str(proc.pid) + ")" + chr(10) + out
    except Exception as e:
        return False, str(e)

def stop_server():
    cfg = load_admin_config()
    configured = cfg.get("stop_script", "").strip()
    if configured:
        return run_script(configured)
    base = get_sdr_dir()
    fallback = base / "stop-websdr.sh"
    if fallback.exists():
        return run_script("stop-websdr.sh")
    # Last resort: kill by process name
    try:
        subprocess.run(["killall", "spectrumserver"], capture_output=True)
        return True, "Sent SIGTERM to spectrumserver"
    except Exception as e:
        return False, str(e)

def read_file_safe(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception as e:
        return f"# Error reading file: {e}"

def write_file_safe(path, content):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True, "Saved successfully"
    except Exception as e:
        return False, str(e)

def tail_file_lines(path, n):
    """The last n lines of a file, without reading all of it.

    This used to be f.readlines()[-n:], which pulls the entire file into memory
    to show a hundred lines. spectrumserver.log reaches ~10 MB before it
    rotates and the viewer refreshes every 3 seconds; measured, the old path
    costs about 30 ms per refresh at that size against 0.2 ms here. Not fatal,
    but it is pure waste on a panel that is polling anyway, and it grows with
    the log. Walk backwards from the end in blocks until there are enough
    newlines. Verified line-for-line against tail(1), including on an empty
    file, one with no trailing newline, and one spanning several blocks.
    """
    block = 64 * 1024
    data = b""
    with open(path, "rb") as f:
        f.seek(0, os.SEEK_END)
        pos = f.tell()
        while pos > 0 and data.count(b"\n") <= n:
            step = min(block, pos)
            pos -= step
            f.seek(pos)
            data = f.read(step) + data
    text = data.decode("utf-8", errors="replace")
    return [l.rstrip() for l in text.splitlines()[-n:]]

def read_log_lines(log_name, n=100):
    base = get_sdr_dir()
    if log_name not in LOG_FILES:
        return []
    lf = base / LOG_FILES[log_name]
    lines = []
    if lf.exists():
        try:
            lines = tail_file_lines(lf, n)
        except Exception as e:
            lines = [f"Error reading {lf.name}: {e}"]
    if log_name == "admin.log":
        with log_lock:
            mem_lines = list(log_buffer[-50:])
        return lines + mem_lines   # file (older) first, in-memory (newer) last
    return lines

def tail_log(n=100, log_name=None):
    if log_name:
        return read_log_lines(log_name, n)

    base = get_sdr_dir()
    lines = []
    for name in LOG_FILES:
        lf = base / LOG_FILES[name]
        if lf.exists():
            try:
                file_lines = tail_file_lines(lf, n)
                lines.append(f"===== {lf.name} =====")
                lines.extend(file_lines)
            except Exception as e:
                lines.append(f"===== {lf.name} =====")
                lines.append(f"Error reading {lf.name}: {e}")

    # Fallback: journalctl only if no log files were found/read
    if not lines:
        try:
            result = subprocess.run(
                ["journalctl", "-u", "phantomsdr-admin", "-n", str(n), "--no-pager", "--output=short"],
                capture_output=True, text=True, timeout=3
            )
            if result.stdout.strip():
                lines = result.stdout.strip().splitlines()
        except Exception:
            pass

    # Also try journalctl for spectrumserver process
    if not lines:
        try:
            result = subprocess.run(
                ["journalctl", "_COMM=spectrumserver", "-n", str(n), "--no-pager", "--output=short"],
                capture_output=True, text=True, timeout=3
            )
            if result.stdout.strip():
                lines = result.stdout.strip().splitlines()
        except Exception:
            pass

    with log_lock:
        mem_lines = list(log_buffer[-50:])
    return lines + mem_lines   # file (older) first, in-memory (newer) last

# ─── HTML Template ─────────────────────────────────────────────────────────────
LOGIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PhantomSDR Admin · Login</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --green:#00ff41;--green2:#00cc33;--amber:#ffb000;--red:#ff3333;
  --bg:#050a05;--panel:#0d1a0d;--border:#1a3a1a;--dim:#1f3a1f;
  --text:#c8ffc8;--text2:#7ab87a;--glow:0 0 10px #00ff4155,0 0 20px #00ff4122;
}
body{background:var(--bg);font-family:'Share Tech Mono',monospace;color:var(--text);
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  background-image:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,255,65,0.015) 2px,rgba(0,255,65,0.015) 4px);}
body::before{content:'';position:fixed;inset:0;background:radial-gradient(ellipse 80% 60% at 50% 40%,rgba(0,255,65,0.04) 0%,transparent 70%);pointer-events:none;}

.login-wrap{width:380px;animation:fadeIn .6s ease;}
@keyframes fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}

.logo{text-align:center;margin-bottom:2rem;}
.logo-title{font-family:'Orbitron',sans-serif;font-weight:900;font-size:1.4rem;
  color:var(--green);text-shadow:var(--glow);letter-spacing:0.1em;}
.logo-sub{font-size:.7rem;color:var(--text2);letter-spacing:.3em;margin-top:.4rem;}
.logo-icon{font-size:3rem;margin-bottom:.5rem;filter:drop-shadow(0 0 12px #00ff41);}

.card{background:var(--panel);border:1px solid var(--border);border-radius:4px;
  padding:2rem;box-shadow:0 0 40px rgba(0,255,65,0.08),inset 0 1px 0 rgba(0,255,65,0.1);}

label{display:block;font-size:.7rem;color:var(--text2);letter-spacing:.2em;margin-bottom:.4rem;margin-top:1.2rem;}
label:first-of-type{margin-top:0;}

input[type=password]{width:100%;background:#071007;border:1px solid var(--border);
  color:var(--green);font-family:'Share Tech Mono',monospace;font-size:.9rem;
  padding:.7rem 1rem;border-radius:3px;outline:none;transition:.2s;caret-color:var(--green);}
input[type=password]:focus{border-color:var(--green);box-shadow:var(--glow);}

.btn{width:100%;margin-top:1.5rem;padding:.8rem;background:transparent;
  border:1px solid var(--green);color:var(--green);font-family:'Orbitron',sans-serif;
  font-size:.75rem;letter-spacing:.2em;cursor:pointer;border-radius:3px;
  transition:.2s;text-transform:uppercase;}
.btn:hover{background:rgba(0,255,65,0.1);box-shadow:var(--glow);}

.error{background:rgba(255,51,51,0.1);border:1px solid #ff333355;color:#ff6666;
  padding:.7rem 1rem;border-radius:3px;font-size:.8rem;margin-bottom:1rem;text-align:center;}

.blink{animation:blink 1.2s step-end infinite;}
@keyframes blink{50%{opacity:0}}

.scanlines{pointer-events:none;position:fixed;inset:0;
  background:repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,0.08) 3px,rgba(0,0,0,0.08) 4px);
  z-index:9999;}
</style>
</head>
<body>
<div class="scanlines"></div>
<div class="login-wrap">
  <div class="logo">
    <div class="logo-icon">📡</div>
    <div class="logo-title">PHANTOM<span style="color:var(--amber)">SDR</span></div>
    <div class="logo-sub">ADMIN CONTROL PANEL</div>
  </div>
  <div class="card">
    {% if error %}<div class="error">⚠ {{ error }}</div>{% endif %}
    <form method="post">
      <label>ACCESS CODE</label>
      <input type="password" name="password" autofocus placeholder="••••••••">
      <button type="submit" class="btn">▶ AUTHENTICATE<span class="blink">_</span></button>
    </form>
  </div>
</div>
</body>
</html>"""

SETUP_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PhantomSDR Admin &#183; Setup</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{--green:#00ff41;--amber:#ffb000;--red:#ff3333;--blue:#00ccff;
  --bg:#050a05;--panel:#0d1a0d;--border:#1a3a1a;--text:#c8ffc8;--text2:#7ab87a;--text3:#4a8a4a;
  --glow:0 0 10px #00ff4155,0 0 20px #00ff4122;}
body{background:var(--bg);font-family:"Share Tech Mono",monospace;color:var(--text);
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  background-image:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,255,65,0.015) 2px,rgba(0,255,65,0.015) 4px);}
body::before{content:"";position:fixed;inset:0;background:radial-gradient(ellipse 80% 60% at 50% 40%,rgba(0,255,65,0.04) 0%,transparent 70%);pointer-events:none;}
.scanlines{pointer-events:none;position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,0.08) 3px,rgba(0,0,0,0.08) 4px);z-index:9999;}
.wrap{width:500px;max-width:96vw;animation:fadeIn .5s ease;}
@keyframes fadeIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
.logo{text-align:center;margin-bottom:1.5rem;}
.logo-icon{font-size:2.5rem;filter:drop-shadow(0 0 10px #00ff41);}
.logo-title{font-family:"Orbitron",sans-serif;font-weight:900;font-size:1.3rem;color:var(--green);text-shadow:var(--glow);letter-spacing:.1em;margin-top:.4rem;}
.logo-sub{font-size:.65rem;color:var(--text3);letter-spacing:.3em;margin-top:.3rem;}
.card{background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:1.6rem;box-shadow:0 0 40px rgba(0,255,65,0.06);}
.step-label{font-family:"Orbitron",sans-serif;font-size:.6rem;color:var(--text3);letter-spacing:.25em;margin-bottom:1.2rem;padding-bottom:.5rem;border-bottom:1px solid var(--border);}
.field{margin-bottom:1rem;}
.field label{display:block;font-size:.65rem;color:var(--text2);letter-spacing:.15em;margin-bottom:.35rem;}
.field input,.field select{width:100%;background:#071007;border:1px solid var(--border);color:var(--green);
  font-family:"Share Tech Mono",monospace;font-size:.85rem;padding:.6rem .8rem;border-radius:3px;outline:none;transition:.15s;}
.field input:focus,.field select:focus{border-color:var(--green);box-shadow:var(--glow);}
.field-row{display:grid;grid-template-columns:1fr 1fr;gap:.7rem;}
.hint{font-size:.62rem;color:var(--text3);margin-top:.3rem;line-height:1.5;}
.detect-btn{display:inline-flex;align-items:center;gap:.4rem;padding:.35rem .7rem;font-size:.65rem;cursor:pointer;border-radius:2px;border:1px solid #00ccff55;color:var(--blue);background:transparent;font-family:"Share Tech Mono",monospace;transition:.15s;margin-bottom:.5rem;}
.detect-btn:hover{background:rgba(0,204,255,0.08);}
.btn{width:100%;margin-top:1.2rem;padding:.85rem;background:transparent;border:1px solid var(--green);color:var(--green);font-family:"Orbitron",sans-serif;font-size:.75rem;letter-spacing:.2em;cursor:pointer;border-radius:3px;transition:.2s;text-transform:uppercase;}
.btn:hover{background:rgba(0,255,65,0.1);box-shadow:var(--glow);}
.btn:disabled{opacity:.4;cursor:not-allowed;}
.err{background:rgba(255,51,51,0.1);border:1px solid #ff333355;color:#ff6666;padding:.6rem .9rem;border-radius:3px;font-size:.75rem;margin-top:.8rem;display:none;}
.ok-msg{background:rgba(0,255,65,0.08);border:1px solid #00ff4155;color:var(--green);padding:.6rem .9rem;border-radius:3px;font-size:.75rem;margin-top:.8rem;display:none;}
.blink{animation:blink 1.2s step-end infinite;}
@keyframes blink{50%{opacity:0}}
</style>
</head>
<body>
<div class="scanlines"></div>
<div class="wrap">
  <div class="logo">
    <div class="logo-icon">&#128225;</div>
    <div class="logo-title">PHANTOM<span style="color:var(--amber)">SDR</span></div>
    <div class="logo-sub">FIRST-RUN SETUP</div>
  </div>
  <div class="card">
    <div class="step-label">&#9654; CHOOSE YOUR ADMIN PASSWORD</div>
    <div class="hint" style="margin-bottom:1rem;line-height:1.6;">
      The installer already set up this station:<br>
      Folder: <b>{{ sdr_dir }}</b><br>
      Listener port: <b>{{ listen_port }}</b>{% if sdr_port != listen_port %} &#183; spectrumserver: <b>{{ sdr_port }}</b>{% endif %}<br>
      You can change these later in Settings.
    </div>
    <div class="field">
      <label>NEW ADMIN PASSWORD <span style="color:var(--red)">*</span></label>
      <input type="password" id="new-pwd" placeholder="Choose a strong password" autocomplete="new-password">
    </div>
    <div class="field">
      <label>CONFIRM PASSWORD</label>
      <input type="password" id="new-pwd2" placeholder="Repeat password" autocomplete="new-password">
    </div>
    <div class="err" id="err-box"></div>
    <div class="ok-msg" id="ok-box">Setup complete! Redirecting...<span class="blink">_</span></div>
    <button class="btn" onclick="completeSetup()" id="setup-btn">&#9654; COMPLETE SETUP<span class="blink">_</span></button>
  </div>
</div>
<script>
function showErr(msg) {
  var el = document.getElementById("err-box");
  el.textContent = msg; el.style.display = "block";
  document.getElementById("ok-box").style.display = "none";
}
async function completeSetup() {
  document.getElementById("err-box").style.display = "none";
  var pw  = document.getElementById("new-pwd").value;
  var pw2 = document.getElementById("new-pwd2").value;
  if (!pw)           { showErr("Password is required"); return; }
  if (pw.length < 4) { showErr("Password must be at least 4 characters"); return; }
  if (pw !== pw2)    { showErr("Passwords do not match"); return; }
  var btn = document.getElementById("setup-btn");
  btn.disabled = true; btn.textContent = "Saving...";
  try {
    var r = await fetch("/admin/api/setup", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({new_password: pw})
    });
    var d = await r.json();
    if (d.ok) {
      document.getElementById("ok-box").style.display = "block";
      btn.style.display = "none";
      setTimeout(function() { window.location.href = "/admin/dashboard"; }, 1200);
    } else {
      showErr(d.msg || "Setup failed");
      btn.disabled = false; btn.textContent = "&#9654; COMPLETE SETUP_";
    }
  } catch(e) {
    showErr("Network error: " + e.message);
    btn.disabled = false; btn.textContent = "&#9654; COMPLETE SETUP_";
  }
}
</script>
</body>
</html>"""

MAIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PhantomSDR Admin Panel</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<script>
// Sun above the horizon (sunrise to sunset) at lat/lon, now. Low-precision
// solar position (about a minute of accuracy), enough to pick a theme.
function _adminSunUp(lat, lon, d) {
  var r = Math.PI / 180, n = d.getTime() / 86400000 - 10957.5;
  var g = (357.529 + 0.98560028 * n) * r, q = 280.459 + 0.98564736 * n;
  var L = (q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * r;
  var e = (23.439 - 0.00000036 * n) * r;
  var dec = Math.asin(Math.sin(e) * Math.sin(L));
  var ra = Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L));
  var gmst = (18.697374558 + 24.06570982441908 * n) % 24;
  var H = (gmst * 15 + lon) * r - ra;
  var alt = Math.asin(Math.sin(lat * r) * Math.sin(dec) + Math.cos(lat * r) * Math.cos(dec) * Math.cos(H));
  return alt / r > -0.833;
}
// "auto": light by day, dark at night, at the station's locator (Site Info);
// without one, 07:00-19:00 local time counts as day.
function _adminAutoTheme() {
  var now = new Date(), loc = null;
  try { loc = JSON.parse(localStorage.getItem('adminThemeLoc') || 'null'); } catch (e) {}
  var day = loc ? _adminSunUp(loc[0], loc[1], now) : (now.getHours() >= 7 && now.getHours() < 19);
  return day ? 'light' : 'dark';
}
(function () {
  var t = 'green';
  try { t = localStorage.getItem('adminTheme') || 'green'; } catch (e) {}
  if (t === 'auto') t = _adminAutoTheme();
  document.documentElement.setAttribute('data-theme', t);
})();
</script>
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --green:#00ff41;--green2:#00cc33;--amber:#ffb000;--red:#ff4040;--blue:#00ccff;
  --bg:#050a05;--panel:#0a150a;--panel2:#0d1a0d;--border:#1a3a1a;--dim:#1f3a1f;
  --text:#c8ffc8;--text2:#7ab87a;--text3:#4a8a4a;
  --glow:0 0 8px rgba(var(--accent-rgb),.33),0 0 20px rgba(var(--accent-rgb),.13);
  --glow-amber:0 0 8px rgba(var(--amber-rgb),.33),0 0 20px rgba(var(--amber-rgb),.13);
  --glow-red:0 0 8px rgba(var(--red-rgb),.33);
  /* Theme variables (Settings → Appearance). These defaults are the classic
     green phosphor theme; html[data-theme=…] below overrides them. */
  --accent-rgb:0,255,65;--red-rgb:255,64,64;--amber-rgb:255,176,0;--blue-rgb:0,204,255;
  --ok:var(--green);--ok-rgb:var(--accent-rgb);
  --field:#071207;--deep:#030803;--row:#0a1a0a;--tile:#071007;--code-text:#c8ffc8;
  --font:'Share Tech Mono',monospace;--font-mono:'Share Tech Mono',monospace;
  --font-head:'Orbitron',sans-serif;--fs:20px;--radius:3px;
  --card-bg:var(--panel);--card-shadow:none;--recess:none;
  --body-bg:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,255,65,0.01) 2px,rgba(0,255,65,0.01) 4px);
}
html,body{height:100%;background:var(--bg);font-family:var(--font);
  color:var(--text);font-size:var(--fs);}
body{background-image:var(--body-bg);}

/* Layout */
.layout{display:flex;height:100vh;overflow:hidden;}
.sidebar{width:220px;min-width:220px;background:var(--panel);border-right:1px solid var(--border);
  display:flex;flex-direction:column;overflow-y:auto;}
.main{flex:1;overflow:hidden;display:flex;flex-direction:column;}
.topbar{background:var(--panel);border-bottom:1px solid var(--border);
  padding:.7rem 1.2rem;display:flex;align-items:center;justify-content:space-between;}
.content{flex:1;overflow-y:auto;padding:1.4rem;}

/* Sidebar */
.sidebar-logo{padding:1.2rem 1rem;border-bottom:1px solid var(--border);text-align:center;}
.sidebar-logo .title{font-family:var(--font-head);font-weight:900;font-size:1rem;
  color:var(--green);text-shadow:var(--glow);}
.sidebar-logo .sub{font-size:.6rem;color:var(--text3);letter-spacing:.3em;margin-top:.2rem;}
.sidebar-logo .icon{font-size:1.8rem;margin-bottom:.3rem;filter:drop-shadow(0 0 8px var(--green));}

.nav-section{padding:.5rem 0;}
.nav-label{font-size:.55rem;color:var(--text3);letter-spacing:.3em;padding:.4rem 1rem .2rem;}
.nav-item{display:flex;align-items:center;gap:.6rem;padding:.55rem 1rem;
  cursor:pointer;color:var(--text2);transition:.15s;border-left:2px solid transparent;
  text-decoration:none;font-size:.8rem;}
.nav-item:hover{color:var(--green);background:rgba(var(--accent-rgb),0.05);border-left-color:var(--green2);}
.nav-item.active{color:var(--green);background:rgba(var(--accent-rgb),0.08);
  border-left-color:var(--green);text-shadow:var(--glow);}
.nav-item .icon{font-size:1rem;width:1.2rem;text-align:center;}

.sidebar-footer{margin-top:auto;padding:.8rem 1rem;border-top:1px solid var(--border);
  font-size:.65rem;color:var(--text3);}

/* Topbar */
.topbar-title{font-family:var(--font-head);font-size:.85rem;color:var(--green);}
.status-pill{display:inline-flex;align-items:center;gap:.4rem;
  padding:.3rem .7rem;border-radius:2px;font-size:.7rem;}
.status-pill.online{background:rgba(var(--ok-rgb),0.1);border:1px solid rgba(var(--ok-rgb),.33);color:var(--ok);}
.status-pill.offline{background:rgba(var(--red-rgb),0.1);border:1px solid rgba(var(--red-rgb),.33);color:var(--red);}
.status-dot{width:6px;height:6px;border-radius:50%;animation:pulse 2s infinite;}
.status-dot.online{background:var(--ok);box-shadow:0 0 6px var(--ok);}
.status-dot.offline{background:var(--red);}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}

.topbar-right{display:flex;align-items:center;gap:1rem;}
.topbar-time{font-size:.7rem;color:var(--text3);}
.topbar-theme{display:inline-flex;align-items:center;gap:.4rem;font-size:.65rem;color:var(--text3);letter-spacing:.1em;}
.topbar-theme select{font-family:var(--font);font-size:.68rem;padding:.2rem .4rem;letter-spacing:0;}
.logout-btn{font-size:.65rem;color:var(--text3);text-decoration:none;
  padding:.2rem .5rem;border:1px solid var(--border);border-radius:2px;transition:.15s;}
.logout-btn:hover{color:var(--red);border-color:rgba(var(--red-rgb),.33);}

/* Cards */
.grid{display:grid;gap:1rem;}
.grid-2{grid-template-columns:1fr 1fr;}
.grid-3{grid-template-columns:1fr 1fr 1fr;}
.grid-4{grid-template-columns:repeat(4,1fr);}
.grid-5{grid-template-columns:repeat(5,1fr);}

.card{background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:1rem;
  box-shadow:var(--card-shadow);}
.card-header{font-family:var(--font-head);font-size:.7rem;color:var(--text2);
  letter-spacing:.15em;margin-bottom:.8rem;display:flex;align-items:center;gap:.5rem;}
.card-header .dot{width:6px;height:6px;border-radius:50%;background:var(--green);
  box-shadow:0 0 6px var(--green);}

/* Stat cards */
.stat-val{font-family:var(--font-head);font-size:1.6rem;font-weight:700;
  color:var(--green);text-shadow:var(--glow);}
.stat-label{font-size:.65rem;color:var(--text3);margin-top:.2rem;letter-spacing:.1em;}
.stat-sub{font-size:.7rem;color:var(--text2);margin-top:.3rem;}

/* Load/temperature thresholds. These are NOT the terminal palette above: they
   are the web UI's colours (App.svelte), so the same reading looks the same in
   both places.  The chrome stays green; only the numbers that mean "hot" move. */
:root{--stat-ok:#4ade80;--stat-warn:#fbbf24;--stat-bad:#ef4444;}

/* Progress bars */
.bar-wrap{background:var(--field);border-radius:2px;height:6px;margin-top:.5rem;overflow:hidden;}
.bar-fill{height:100%;border-radius:2px;transition:.5s;background:var(--stat-ok);}
.bar-fill.warn{background:var(--stat-warn);}
.bar-fill.danger{background:var(--stat-bad);}

/* Buttons */
.btn{display:inline-flex;align-items:center;gap:.4rem;padding:.5rem .9rem;
  font-family:var(--font-mono);font-size:.75rem;cursor:pointer;
  border-radius:2px;transition:.15s;border:1px solid;background:transparent;letter-spacing:.05em;}
.btn-green{color:var(--green);border-color:rgba(var(--accent-rgb),.33);}
.btn-green:hover{background:rgba(var(--accent-rgb),0.1);box-shadow:var(--glow);}
.btn-red{color:var(--red);border-color:rgba(var(--red-rgb),.33);}
.btn-red:hover{background:rgba(var(--red-rgb),0.1);box-shadow:var(--glow-red);}
.btn-amber{color:var(--amber);border-color:rgba(var(--amber-rgb),.33);}
.fork-notice{margin-bottom:1rem;padding:.7rem 1rem;border:1px solid rgba(var(--amber-rgb),.47);border-radius:4px;
  background:rgba(var(--amber-rgb),.06);color:var(--amber);font-size:.8rem;line-height:1.5;overflow-wrap:anywhere;}
.fork-notice a{color:var(--amber);text-decoration:underline;}
.btn-amber:hover{background:rgba(var(--amber-rgb),0.1);box-shadow:var(--glow-amber);}
.btn-blue{color:var(--blue);border-color:rgba(var(--blue-rgb),.33);}
.btn-blue:hover{background:rgba(var(--blue-rgb),0.1);}
.btn-lg{padding:.7rem 1.4rem;font-size:.85rem;}
.btn:disabled{opacity:.4;cursor:not-allowed;}
/* Range picker on the Graphs page: the selected range must read as chosen, not
   merely hovered, so it gets the filled state the other buttons only borrow. */
.btn.graph-range{color:var(--text2);border-color:var(--border);}
.btn.graph-range:hover{color:var(--green);border-color:rgba(var(--accent-rgb),.33);}
.btn.graph-range.active{color:var(--green);border-color:rgba(var(--accent-rgb),.53);
  background:rgba(var(--accent-rgb),0.08);box-shadow:var(--glow);}
/* Larger type on the Graphs page only — these are readings meant to be read
   from across the room, not the dense label text the other pages use.  Scoped
   to #page-graphs so the shared card classes keep their sizing elsewhere. */
#page-graphs .card-header{font-size:.78rem;}
#page-graphs .stat-val{font-size:2rem;}
#page-graphs .stat-label{font-size:.78rem;}
#page-graphs .btn.graph-range{font-size:.82rem;padding:.55rem 1rem;}

/* Per-decoder spot tiles (Spot Reporting page) */
.ar-spot-tile{background:var(--tile);border:1px solid var(--border);border-radius:3px;
  padding:.6rem .7rem;text-align:center;}
.ar-spot-mode{font-family:var(--font-head);font-size:.72rem;color:var(--text2);
  letter-spacing:.18em;}
.ar-spot-count{font-family:var(--font-head);font-size:1.7rem;font-weight:700;
  color:var(--green);text-shadow:var(--glow);margin:.15rem 0 .1rem;}
.ar-spot-count.idle{color:var(--text3);text-shadow:none;}
.ar-spot-sub{font-size:.63rem;color:var(--text3);letter-spacing:.05em;line-height:1.5;}
/* Uploaded-count badge next to each mode in the bands/modes header */
.ar-hdr-badge{display:inline-block;margin-left:.35rem;padding:0 .35rem;border-radius:2px;
  font-family:var(--font-mono);font-size:.62rem;letter-spacing:0;
  background:rgba(var(--accent-rgb),0.12);color:var(--green);border:1px solid rgba(var(--accent-rgb),.27);}
.ar-hdr-badge:empty{display:none;}
/* All-time spot count printed beside each band/mode checkbox */
/* Sits tight against its own checkbox: the count belongs to that one slot, and
   a wide gap lets the eye pair it with the neighbouring column instead. The
   checkbox loses its default margin for the same reason. */
/* table.markers input sets width:100% for the text inputs on the Markers page.
   Inherited by these checkboxes it stretched each one across its whole cell,
   which shoved the count to the far right of the column — and off the edge
   entirely in the last one, so WSPR's numbers sat in the horizontal overflow. */
#ar-matrix input[type=checkbox]{width:auto;margin:0;vertical-align:middle;}
.ar-slot-tot{margin-left:.5rem;vertical-align:middle;
  font-family:var(--font-mono);font-size:.74rem;
  color:var(--green);text-shadow:0 0 6px rgba(var(--accent-rgb),.53);}
/* Decodes with nothing uploaded yet — amber rather than a dim grey: it is a
   normal waiting state (PSK Reporter only flushes every 5 min), so it should be
   as readable as the uploaded count, just distinguishable from it. */
.ar-slot-tot.none{color:var(--amber);text-shadow:0 0 6px rgba(var(--amber-rgb),.47);}
.ar-slot-tot:empty{display:none;}

/* Server control card */
.sdr-control{display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-start;}
.sdr-info{flex:1;min-width:200px;}
.sdr-info p{margin:.3rem 0;font-size:.75rem;color:var(--text2);}
.sdr-info .val{color:var(--green);}
.sdr-btns{display:flex;flex-direction:column;gap:.5rem;}
.script-select{background:var(--field);border:1px solid var(--border);color:var(--text);
  font-family:var(--font-mono);font-size:.75rem;padding:.4rem .6rem;
  border-radius:2px;width:100%;margin-bottom:.5rem;}
.script-select:focus{border-color:var(--green);outline:none;}

/* Editor */
.editor-toolbar{display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;margin-bottom:.7rem;}
.file-select{background:var(--field);border:1px solid var(--border);color:var(--text);
  font-family:var(--font-mono);font-size:.75rem;padding:.4rem .7rem;
  border-radius:2px;flex:1;}
.file-select:focus{outline:none;border-color:var(--green);}
textarea.code{width:100%;background:var(--deep);border:1px solid var(--border);color:var(--code-text);
  font-family:var(--font-mono);font-size:.75rem;line-height:1.6;
  padding:.8rem;border-radius:3px;resize:vertical;outline:none;
  min-height:400px;transition:.2s;}
textarea.code:focus{border-color:var(--green);box-shadow:var(--glow);}

/* Toast */
#toast{position:fixed;bottom:1.5rem;right:1.5rem;z-index:9999;display:flex;
  flex-direction:column;gap:.4rem;}
.toast{padding:.6rem 1rem;border-radius:3px;font-size:.75rem;
  animation:toastIn .3s ease;border:1px solid;}
.toast.ok{background:rgba(var(--accent-rgb),0.12);border-color:rgba(var(--accent-rgb),.33);color:var(--green);}
.toast.err{background:rgba(var(--red-rgb),0.12);border-color:rgba(var(--red-rgb),.33);color:var(--red);}
@keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}

/* Log viewer */
.log-box{background:var(--deep);border:1px solid var(--border);border-radius:3px;
  padding:.8rem;font-size:.7rem;line-height:1.8;height:400px;overflow-y:auto;
  color:var(--text2);word-break:break-all;}
.log-box::-webkit-scrollbar{width:4px;}
.log-box::-webkit-scrollbar-track{background:var(--bg);}
.log-box::-webkit-scrollbar-thumb{background:var(--dim);}
.log-line-err{color:var(--red);}
.log-line-warn{color:var(--amber);}
.log-line-ok{color:var(--ok);}

/* Tabs inside sections */
.tab-bar{display:flex;flex-wrap:wrap;border-bottom:1px solid var(--border);margin-bottom:1rem;}
.tab{padding:.5rem 1rem;font-size:.7rem;cursor:pointer;color:var(--text3);
  border-bottom:2px solid transparent;transition:.15s;letter-spacing:.1em;}
.tab.active{color:var(--green);border-bottom-color:var(--green);}
.tab-pane{display:none;}
.tab-pane.active{display:block;}

/* Section heading */
.section-head{font-family:var(--font-head);font-size:.8rem;color:var(--green);
  letter-spacing:.15em;margin-bottom:1rem;padding-bottom:.5rem;
  border-bottom:1px solid var(--border);}

/* JSON editor helpers */
.json-path{font-size:.65rem;color:var(--text3);margin-bottom:.5rem;}

input[type=text],input[type=password],input[type=number]{
  background:var(--field);border:1px solid var(--border);color:var(--text);
  font-family:var(--font-mono);font-size:.8rem;padding:.4rem .7rem;
  border-radius:2px;outline:none;transition:.15s;}
input:focus{border-color:var(--green);box-shadow:0 0 6px rgba(var(--accent-rgb),.13);}

/* Chat history */
.chat-log{background:var(--deep);border:1px solid var(--border);border-radius:3px;
  padding:.8rem;font-size:.75rem;line-height:2;height:500px;overflow-y:auto;}
.chat-msg{display:flex;align-items:baseline;gap:.5rem;border-bottom:1px solid var(--row);padding:.3rem 0;}
.chat-msg-text{flex:1;}
.chat-nick{color:var(--amber);}
.chat-time{color:var(--text3);font-size:.65rem;}
.chat-del-btn{flex-shrink:0;background:transparent;border:1px solid rgba(var(--red-rgb),.27);color:var(--red);
  font-family:var(--font-mono);font-size:.6rem;padding:.1rem .4rem;border-radius:2px;
  cursor:pointer;transition:.15s;line-height:1.4;}
.chat-del-btn:hover{background:rgba(var(--red-rgb),0.15);border-color:rgba(var(--red-rgb),.53);}

/* Top processes table */
table.top-procs{width:100%;border-collapse:collapse;font-size:.72rem;}
table.top-procs th{color:var(--text3);font-weight:normal;letter-spacing:.1em;
  padding:.35rem .5rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;}
table.top-procs td{padding:.3rem .5rem;border-bottom:1px solid var(--row);
  white-space:nowrap;overflow:hidden;max-width:200px;text-overflow:ellipsis;}
table.top-procs tr:hover td{background:rgba(var(--accent-rgb),0.04);}
#rx-table tbody tr + tr td{border-top:3px solid var(--amber);}
#rx-table tbody td{padding-top:.6rem;padding-bottom:.6rem;}
table.top-procs .cpu-hi{color:var(--stat-bad);}
table.top-procs .cpu-med{color:var(--stat-warn);}
table.top-procs .cpu-ok{color:var(--stat-ok);}
table.top-procs .mem-col{color:var(--blue);}

/* ── Mobile Bottom Nav Bar ──────────────────────────────────── */
.bottom-nav{display:none;}
.hamburger{display:none;}
.sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:199;}
.sidebar-backdrop.open{display:block;}

@media(max-width:768px){
  /* The sidebar becomes a drawer: the bottom bar's MENU opens it, so every
     page stays reachable on a phone (the bar itself has room for six). */
  .sidebar{position:fixed;top:0;bottom:0;left:0;z-index:200;width:min(270px,82vw);min-width:0;
    transform:translateX(-102%);transition:transform .2s ease;box-shadow:4px 0 24px rgba(0,0,0,.5);}
  .sidebar.open{transform:none;}
  .sidebar{scrollbar-width:thin;scrollbar-color:var(--dim) var(--panel);}
  .sidebar .nav-item{padding:.75rem 1rem;font-size:.9rem;}
  .hamburger{display:none !important;}

  /* Layout: vertical stack, leave room for bottom nav */
  .layout{flex-direction:column;}
  .main{height:100vh;height:100dvh;display:flex;flex-direction:column;}
  .content{flex:1;overflow-y:auto;padding:.6rem;padding-bottom:70px;}

  /* Topbar */
  .topbar{padding:.5rem .8rem;gap:.5rem;}
  .topbar-title{font-size:.8rem;flex:1;}
  .topbar-time{display:none;}
  .topbar-theme{font-size:.55rem;gap:.25rem;}
  .topbar-theme select{min-height:32px;font-size:.62rem;padding:.1rem .1rem;width:5.2rem;}
  .topbar{flex-wrap:wrap;row-gap:.4rem;}
  .topbar-right{gap:.45rem;margin-left:auto;}
  .logout-btn{white-space:nowrap;padding:.2rem .35rem;}
  .status-pill{padding:.2rem .5rem;font-size:.65rem;}

  /* Bottom navigation bar */
  .bottom-nav{
    display:flex;position:fixed;bottom:0;left:0;right:0;z-index:100;
    background:var(--panel);border-top:1px solid var(--border);
    height:58px;align-items:stretch;
    box-shadow:0 -4px 20px rgba(0,0,0,.5);
  }
  .bottom-nav a{
    flex:1;display:flex;flex-direction:column;align-items:center;
    justify-content:center;gap:2px;color:var(--text3);text-decoration:none;
    font-size:.5rem;letter-spacing:.05em;border-top:2px solid transparent;
    transition:.15s;padding:.3rem .1rem;min-width:0;
    -webkit-tap-highlight-color:transparent;
  }
  .bottom-nav a .bi{font-size:1.3rem;line-height:1;}
  .bottom-nav a span{font-size:.48rem;letter-spacing:.02em;white-space:nowrap;}
  .bottom-nav a.active{color:var(--green);border-top-color:var(--green);}
  .bottom-nav{padding-bottom:env(safe-area-inset-bottom);}
  .bottom-nav a:active{background:rgba(var(--accent-rgb),0.08);}

  /* Grids → single column */
  .grid-2,.grid-3,.grid-4,.grid-5{grid-template-columns:1fr !important;}

  /* Cards */
  .card{padding:.7rem;overflow-x:auto;}

  /* Stat values */
  .stat-val{font-size:1.3rem;}

  /* Buttons — full width on mobile for easy tapping */
  .btn{padding:.7rem 1rem;font-size:.85rem;min-height:44px;}
  .btn-lg{padding:.8rem 1.2rem;font-size:.9rem;}

  /* Form controls — larger for touch */
  .script-select,.file-select,
  input[type=text],input[type=password],input[type=number]{
    font-size:1rem;padding:.6rem .8rem;min-height:44px;}
  select{min-height:44px;}

  /* Log boxes */
  .log-box{height:220px !important;font-size:.7rem;}

  /* Tables: horizontal scroll */
  table.markers,table.top-procs{min-width:420px;}

  /* Textarea */
  textarea.code{min-height:200px;font-size:.8rem;}

  /* Toast position above bottom nav */
  #toast{bottom:70px;}

  /* Section heading */
  .section-head{font-size:.75rem;}
}

@media(max-width:340px){
  .bottom-nav a .bi{font-size:1.1rem;}
  .bottom-nav a span:not(.bi){display:none;}
  .bottom-nav{height:52px;}
  .content{padding-bottom:60px;}
}

/* ── Responsive helpers (all widths) ───────────────────────── */
.layout{height:100dvh;}
input,select,textarea{max-width:100%;}
.field-row{display:grid;grid-template-columns:1fr 1fr;gap:.7rem;}
/* A card title's grey side note moves under the title when both do not fit. */
.card-header{flex-wrap:wrap;row-gap:.3rem;}
.card-header>span[style*="margin-left:auto"]{flex:1 1 12rem;text-align:right;}
/* Receivers table: names and buttons wrap instead of being cut at 200 px. */
#rx-table td{white-space:normal;max-width:none;overflow:visible;}
#rx-table td:first-child{min-width:9rem;}
#rx-table td:last-child{min-width:12rem;}
@media(max-width:1100px) and (min-width:769px){
  .sidebar{width:190px;min-width:190px;}
  .content{padding:1rem;}
  .grid-4,.grid-5{grid-template-columns:repeat(2,1fr) !important;}
  .grid-3{grid-template-columns:repeat(2,1fr) !important;}
}
@media(max-width:600px){
  .field-row{grid-template-columns:1fr;}
  /* Two/three-column forms written inline → one column. */
  .page [style*="grid-template-columns:1fr 1fr"],
  .page [style*="grid-template-columns:repeat(4,1fr)"],
  .page [style*="grid-template-columns:repeat(5,1fr)"]{grid-template-columns:1fr !important;}
  .topbar-theme{font-size:0;gap:0;}
  .topbar-title{font-size:.75rem;}
}
/* Tablets: the receivers list is wide (buttons), so it turns into cards earlier. */
@media(max-width:1100px){
  #rx-table.stack,#rx-table.stack tbody,#rx-table.stack tr,#rx-table.stack td{display:block;width:100%;max-width:none;}
  #rx-table.stack{min-width:0 !important;}
  #rx-table.stack thead,#rx-table.stack tr.stack-head{display:none;}
  #rx-table.stack tr{border:1px solid var(--border);border-radius:3px;margin-bottom:.5rem;padding:.35rem .6rem;}
  #rx-table.stack td{white-space:normal;overflow:visible;border:none !important;padding:.25rem 0 !important;
    text-align:right;overflow-wrap:anywhere;}
  #rx-table.stack td::after{content:"";display:block;clear:both;}
  #rx-table.stack td::before{content:attr(data-label);float:left;margin-right:.8rem;color:var(--text3);text-align:left;
    font-size:.62rem;letter-spacing:.1em;text-transform:uppercase;line-height:1.9;}
  #rx-table.stack td[data-label=""]{text-align:left;}
  #rx-table.stack td[data-label=""]::before{display:none;}
  #rx-table.stack td:empty{display:none;}
  #rx-table.stack{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:.6rem;}
  #rx-table.stack tbody{display:contents;}
  #rx-table.stack tbody tr + tr td{border-top:none !important;}
  #rx-table.stack tr{margin:0;border-top:3px solid var(--amber);}
  #rx-table.stack td:last-child .btn{width:100%;justify-content:center;}
}
@media(max-width:900px){
  /* Data tables → one card per row; each cell carries its column name
     (data-label, set by stackTables()). */
  table.stack,table.stack tbody,table.stack tr,table.stack td{display:block;width:100%;max-width:none;}
  table.stack{min-width:0 !important;}
  table.stack thead,table.stack tr.stack-head{display:none;}
  table.stack tr{border:1px solid var(--border);border-radius:3px;margin-bottom:.5rem;padding:.35rem .6rem;}
  table.stack td{white-space:normal;overflow:visible;border:none !important;padding:.25rem 0 !important;
    text-align:right;overflow-wrap:anywhere;}
  table.stack td::after{content:"";display:block;clear:both;}
  table.stack td::before{content:attr(data-label);float:left;margin-right:.8rem;color:var(--text3);text-align:left;
    font-size:.62rem;letter-spacing:.1em;text-transform:uppercase;line-height:1.9;}
  table.stack td[data-label=""]{text-align:left;}
  table.stack td[data-label=""]::before{display:none;}
  table.stack td:empty{display:none;}
}

.scanlines{pointer-events:none;position:fixed;inset:0;
  background:repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,0.06) 3px,rgba(0,0,0,0.06) 4px);
  z-index:9999;}

/* Pages */
.page{display:none;}
.page.active{display:block;}

/* Markers table */
table.markers{width:100%;border-collapse:collapse;font-size:.75rem;}
table.markers th{color:var(--text3);font-weight:normal;letter-spacing:.1em;
  padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;}
table.markers td{padding:.4rem .6rem;border-bottom:1px solid var(--row);vertical-align:middle;}
table.markers tr:hover td{background:rgba(var(--accent-rgb),0.03);}
table.markers input{width:100%;background:transparent;border:none;
  color:var(--text);font-family:var(--font-mono);font-size:.75rem;}
table.markers input:focus{background:var(--field);outline:1px solid var(--border);}

/* Listener map (Leaflet) */
#umap.leaflet-container{font-family:var(--font-mono);font-size:.7rem;}
#umap .leaflet-popup-content-wrapper,#umap .leaflet-popup-tip,#umap .leaflet-tooltip{
  background:var(--panel);color:var(--text);border:1px solid var(--border);box-shadow:0 0 12px rgba(var(--accent-rgb),.15);}
#umap .leaflet-popup-content{margin:.6rem .8rem;line-height:1.5;font-size:.68rem;}
#umap .umap-pop-head{font-family:var(--font-head);color:var(--green);font-size:.66rem;letter-spacing:.05em;margin-bottom:.3rem;}
#umap .leaflet-control-layers,#umap .leaflet-bar a{background:var(--panel);color:var(--text);border-color:var(--border);}
#umap .leaflet-control-attribution{background:var(--panel);color:var(--text3);}
#umap .leaflet-control-attribution a{color:var(--text2);}

/* ── Themes ─────────────────────────────────────────────────────────────────
   Chosen in Settings → Appearance, kept per browser (localStorage
   "adminTheme"); "auto" picks dark or light from the computer's setting. */
html[data-theme=amber]{
  --green:#ffb000;--green2:#cc8c00;--amber:#ff7a1a;--red:#ff4a3a;--blue:#7fd4ff;
  --accent-rgb:255,176,0;--amber-rgb:255,122,26;--red-rgb:255,74,58;--blue-rgb:127,212,255;
  --ok:#ffc94a;--ok-rgb:255,201,74;
  --bg:#0a0702;--panel:#140e05;--panel2:#1a1206;--border:#3a2a10;--dim:#4a3614;
  --text:#ffe2b0;--text2:#c89a5a;--text3:#8f6e3e;
  --field:#100b04;--deep:#070402;--row:#1d150a;--tile:#110b04;--code-text:#ffe2b0;
  --glow:0 0 8px rgba(255,176,0,.33),0 0 20px rgba(255,176,0,.13);
  --body-bg:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(255,176,0,0.012) 2px,rgba(255,176,0,0.012) 4px);
}
html[data-theme=metal]{
  --green:#8fd3ff;--green2:#5fb4e8;--amber:#f5b942;--red:#ff6b6b;--blue:#a5b4fc;
  --accent-rgb:143,211,255;--amber-rgb:245,185,66;--red-rgb:255,107,107;--blue-rgb:165,180,252;
  --ok:#4ade80;--ok-rgb:74,222,128;
  --bg:#171b21;--panel:#242b35;--panel2:#2b333f;--border:#39424f;--dim:#4a5462;
  --text:#e4e7eb;--text2:#aeb6c1;--text3:#808a97;
  --field:#1a1f27;--deep:#161a21;--row:#2f3742;--tile:#1d232c;--code-text:#dfe6ee;
  --radius:6px;--glow:none;--glow-amber:none;--glow-red:none;--body-bg:none;
  /* bead-blasted anodised grain, as .screw-panel on the receiver page */
  --card-bg:#242b35 url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='160' height='160' filter='url(%23g)' opacity='0.38'/%3E%3C/svg%3E") 0 0/160px 160px;
  /* one light source, upper right: lit top/right edges, shadow falls down-left */
  --card-shadow:inset -1px 1px 0 rgba(255,255,255,.10),inset 1px -1px 0 rgba(0,0,0,.45),-4px 5px 12px rgba(0,0,0,.45);
  --recess:inset -2px 2px 3px rgba(0,0,0,.55),inset 1px -1px 0 rgba(255,255,255,.06);
}
html[data-theme=metal] .card{background-blend-mode:overlay;}
html[data-theme=metal] .sidebar,html[data-theme=metal] .topbar{
  background:linear-gradient(225deg,#2a313c,#1f252e);}
html[data-theme=dark]{
  --green:#60a5fa;--green2:#3b82f6;--amber:#fbbf24;--red:#f87171;--blue:#22d3ee;
  --accent-rgb:96,165,250;--amber-rgb:251,191,36;--red-rgb:248,113,113;--blue-rgb:34,211,238;
  --ok:#4ade80;--ok-rgb:74,222,128;
  --bg:#14161b;--panel:#1d2027;--panel2:#242832;--border:#323743;--dim:#3d4351;
  --text:#e6e8ec;--text2:#a9b0bc;--text3:#7a8291;
  --field:#171a20;--deep:#121419;--row:#2a2e38;--tile:#191c23;--code-text:#e6e8ec;
  --radius:8px;--glow:none;--glow-amber:none;--glow-red:none;--body-bg:none;
  --card-shadow:0 1px 3px rgba(0,0,0,.35);
}
html[data-theme=light]{
  --green:#1d4ed8;--green2:#2563eb;--amber:#b45309;--red:#c62828;--blue:#0e7490;
  --accent-rgb:29,78,216;--amber-rgb:180,83,9;--red-rgb:198,40,40;--blue-rgb:14,116,144;
  --ok:#15803d;--ok-rgb:21,128,61;
  --bg:#eef1f5;--panel:#ffffff;--panel2:#f6f8fa;--border:#d5dbe3;--dim:#c3cbd5;
  --text:#000000;--text2:#111111;--text3:#333333;
  --field:#ffffff;--deep:#f8fafc;--row:#e8ecf1;--tile:#f6f8fa;--code-text:#000000;
  --stat-ok:#16a34a;--stat-warn:#d97706;--stat-bad:#dc2626;
  --radius:8px;--glow:none;--glow-amber:none;--glow-red:none;--body-bg:none;
  --card-shadow:0 1px 3px rgba(16,24,40,.08),0 1px 2px rgba(16,24,40,.05);
}
html[data-theme=light] .sidebar-backdrop.open{background:rgba(0,0,0,.35);}
html[data-theme=light] .bottom-nav{box-shadow:0 -2px 10px rgba(0,0,0,.08);}
html[data-theme=light] .bar-wrap{background:var(--row);}
/* scan lines belong to the phosphor/amber displays only */
html[data-theme=metal] .scanlines,html[data-theme=dark] .scanlines,html[data-theme=light] .scanlines{display:none;}
input[type=text],input[type=password],input[type=number],select,textarea.code,.log-box,.chat-log{box-shadow:var(--recess);}
select{background:var(--field);color:var(--text);border:1px solid var(--border);border-radius:2px;}
/* the open drop-down list follows the theme instead of the system's white */
select option{background:var(--panel);color:var(--text);}
/* native drop-down frames: dark on the dark themes */
html{color-scheme:dark;}
html[data-theme=light]{color-scheme:light;}
/* BAN duration menu, drawn by the page so its frame takes the theme too */
.ban-menu{position:fixed;z-index:9999;background:var(--panel);border:1px solid rgba(var(--amber-rgb),.5);
  border-radius:3px;box-shadow:0 4px 14px rgba(0,0,0,.35);padding:.2rem 0;min-width:5rem;}
.ban-menu div{padding:.3rem .8rem;font-size:.7rem;color:var(--text);cursor:pointer;white-space:nowrap;}
.ban-menu div:hover{background:rgba(var(--amber-rgb),.15);color:var(--amber);}
</style>
</head>
<body>
<div class="scanlines"></div>
<div class="layout">
  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="sidebar-logo">
      <div class="icon">📡</div>
      <div class="title">PHANTOM<span style="color:var(--amber)">SDR</span></div>
      <div class="sub">ADMIN v5.4.0</div>
    </div>
    <div class="nav-section">
      <div class="nav-label">MAIN</div>
      <a class="nav-item active" onclick="showPage('dashboard',this)" href="#">
        <span class="icon">⬡</span><span>Dashboard</span>
      </a>
    </div>
    <div class="nav-section">
      <div class="nav-label">CONFIGURATION</div>
      <a class="nav-item" onclick="showPage('receivers',this)" href="#">
        <span class="icon">📡</span><span>Receivers</span>
      </a>
      <a class="nav-item" onclick="showPage('config',this)" href="#">
        <span class="icon">⚙</span><span>Config Editor</span>
      </a>
      <a class="nav-item" onclick="showPage('siteinfo',this)" href="#">
        <span class="icon">◎</span><span>Site Info</span>
      </a>
      <a class="nav-item" onclick="showPage('markers',this)" href="#">
        <span class="icon">◉</span><span>Markers</span>
      </a>
      <a class="nav-item" onclick="showPage('reporting',this)" href="#">
        <span class="icon">📶</span><span>Spot Reporting</span>
      </a>
    </div>
    <div class="nav-section">
      <div class="nav-label">MONITORING</div>
      <a class="nav-item" onclick="showPage('logs',this)" href="#">
        <span class="icon">▤</span><span>Log Viewer</span>
      </a>
      <a class="nav-item" onclick="showPage('chat',this)" href="#">
        <span class="icon">◫</span><span>Chat History</span>
      </a>
      <a class="nav-item" onclick="showPage('graphs',this)" href="#">
        <span class="icon">📈</span><span>Graphs</span>
      </a>
      <a class="nav-item" onclick="showPage('users',this)" href="#">
        <span class="icon">👥</span><span>Users</span>
      </a>
      <a class="nav-item" onclick="showPage('visitors',this)" href="#" id="nav-visitors">
        <span class="icon">📈</span><span>Visitors</span>
      </a>
      <a class="nav-item" onclick="showPage('wfmsg',this)" href="#">
        <span class="icon">📢</span><span>WF Message</span>
      </a>
    </div>
    <div class="nav-section">
      <div class="nav-label">SYSTEM</div>
      <a class="nav-item" onclick="showPage('settings',this)" href="#">
        <span class="icon">◧</span><span>Settings</span>
      </a>
    </div>
    <div class="sidebar-footer">
      PhantomSDR-Plus<br>Admin Panel
    </div>
  </div>

  <!-- Main -->
  <div class="main">
    <div class="topbar">
      <div class="topbar-title" id="page-title">DASHBOARD</div>
      <div class="topbar-right">
        <div id="sdr-status" class="status-pill offline">
          <div class="status-dot offline"></div>
          <span>OFFLINE</span>
        </div>
        <label class="topbar-theme" title="Theme of this panel (saved in this browser)">THEME
          <select id="theme-sel-top" onchange="setAdminTheme(this.value)">
            <option value="green">Phosphor green</option>
            <option value="amber">Amber display</option>
            <option value="metal">Metal panel</option>
            <option value="dark">Modern dark</option>
            <option value="light">Light</option>
            <option value="auto">Auto (day/night)</option>
          </select>
        </label>
        <div class="topbar-time" id="clock">--:--:--</div>
        <a class="logout-btn" href="/admin/logout">⏻ LOGOUT</a>
      </div>
    </div>

    <div class="content">

      {% if fork_origin %}
      <!-- Installed from a fork — see fork_origin() -->
      <div class="fork-notice">
        &#9432; This copy of PhantomSDR-Plus was installed from a fork:
        <b>{{ fork_origin }}</b><br>
        The original PhantomSDR-Plus is developed at
        <a href="{{ origin_repo }}" target="_blank" rel="noopener noreferrer">{{ origin_repo }}</a>.
        A fork may be older than the original or changed by its owner; updates,
        documentation and support come from the original.
      </div>
      {% endif %}

      <!-- ══════ DASHBOARD PAGE ══════ -->
      <div class="page active" id="page-dashboard">
        <div class="grid grid-5" style="margin-bottom:1rem;">
          <div class="card">
            <div class="card-header"><div class="dot"></div>SDR STATUS</div>
            <div class="stat-val" id="stat-status">--</div>
            <div class="stat-label">PROCESS STATE</div>
            <div class="stat-sub" id="stat-pid">PID: --</div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot" style="background:var(--amber);box-shadow:0 0 6px var(--amber)"></div>CPU USAGE</div>
            <div class="stat-val" id="stat-cpu">--%</div>
            <div class="stat-label">SYSTEM CPU</div>
            <div class="bar-wrap"><div class="bar-fill" id="bar-cpu" style="width:0%"></div></div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot" style="background:var(--blue);box-shadow:0 0 6px var(--blue)"></div>MEMORY</div>
            <div class="stat-val" id="stat-mem">-- GB</div>
            <div class="stat-label">USED / TOTAL</div>
            <div class="bar-wrap"><div class="bar-fill" id="bar-mem" style="width:0%"></div></div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot" style="background:#ff88ff;box-shadow:0 0 6px #ff88ff"></div>DISK</div>
            <div class="stat-val" id="stat-disk">-- GB</div>
            <div class="stat-label">USED / TOTAL</div>
            <div class="bar-wrap"><div class="bar-fill" id="bar-disk" style="width:0%"></div></div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot" style="background:#ff4444;box-shadow:0 0 6px #ff4444"></div>TEMPERATURE</div>
            <div class="stat-val" id="stat-temp">--&#176;C</div>
            <div class="stat-label">CPU TEMP</div>
            <div class="bar-wrap"><div class="bar-fill" id="bar-temp" style="width:0%;background:linear-gradient(90deg,#4ade80,#fbbf24,#ef4444)"></div></div>
            <div class="stat-sub" id="stat-temp-guard" style="margin-top:.3rem;">GUARD: --</div>
          </div>
        </div>

        <!-- ══════ SYSTEM HEALTH ══════ -->
        <div class="card" id="health-card" style="margin-bottom:1rem;">
          <div class="card-header">
            <div class="dot" id="hl-dot"></div>
            SYSTEM HEALTH
            <span style="margin-left:auto;font-size:.6rem;color:var(--text3);cursor:pointer;" onclick="loadHealth()">↻ refresh</span>
          </div>
          <div class="grid grid-2" style="gap:1rem;">
            <div>
              <div style="font-size:.65rem;color:var(--text3);margin-bottom:.3rem;">RECEIVERS</div>
              <div id="hl-rx" style="font-size:.75rem;line-height:1.7;">Loading...</div>
              <div style="font-size:.65rem;color:var(--text3);margin:.6rem 0 .3rem;">RADE</div>
              <div id="hl-rade" style="font-size:.75rem;line-height:1.7;"></div>
              <div style="font-size:.65rem;color:var(--text3);margin:.6rem 0 .3rem;">DISK &amp; LOG FOLDERS</div>
              <div id="hl-disk" style="font-size:.75rem;line-height:1.7;"></div>
            </div>
            <div>
              <div style="font-size:.65rem;color:var(--text3);margin-bottom:.3rem;">RECENT ALERTS</div>
              <div id="hl-events" style="font-size:.72rem;line-height:1.6;max-height:9rem;overflow:auto;"></div>
              <div style="font-size:.65rem;color:var(--text3);margin:.6rem 0 .3rem;">LAST CRASH.LOG ENTRY <span id="hl-crash-when"></span></div>
              <pre id="hl-crash" style="font-size:.62rem;color:var(--text2);white-space:pre-wrap;max-height:9rem;overflow:auto;margin:0;"></pre>
            </div>
          </div>
        </div>

        <!-- ══════ RECEIVE DIVERSITY (every listener, every source type) ══════ -->
        <div class="card" id="div-card" style="margin-bottom:1rem;">
          <div class="card-header">
            <div class="dot" id="dv-dot" style="background:var(--text3);box-shadow:none"></div>
            RECEIVE DIVERSITY
            <span style="margin-left:auto;font-size:.6rem;color:var(--text3);">listeners combining with another receiver &#183; WebSDR partners go through the relay below</span>
          </div>
          <div id="dv-list" style="font-size:.7rem;color:var(--text2);">--</div>
        </div>

        <!-- ══════ WEBSDR DIVERSITY RELAY ══════ -->
        <div class="card" id="relay-card" style="margin-bottom:1rem;display:none;">
          <div class="card-header">
            <div class="dot" id="rl-dot" style="background:var(--text3);box-shadow:none"></div>
            WEBSDR DIVERSITY RELAY
            <span style="margin-left:auto;font-size:.6rem;color:var(--text3);" id="rl-ua"></span>
          </div>
          <div class="grid grid-4" style="gap:.6rem;margin-bottom:.6rem;">
            <div><div style="font-size:.6rem;color:var(--text3);">STATE</div>
                 <div id="rl-state" style="font-size:.9rem;color:var(--green);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">PORT</div>
                 <div id="rl-port" style="font-size:.9rem;color:var(--text);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">SESSIONS</div>
                 <div id="rl-sessions" style="font-size:.9rem;color:var(--amber);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">CAP PER SITE</div>
                 <div id="rl-cap" style="font-size:.9rem;color:var(--text);">--</div></div>
          </div>
          <div id="rl-hosts" style="font-size:.7rem;color:var(--text2);"></div>
          <div id="rl-reason" style="font-size:.65rem;color:var(--text3);margin-top:.3rem;"></div>
        </div>

        <!-- ══════ DRM DECODER ══════ -->
        <div class="card" id="drm-card" style="margin-bottom:1rem;display:none;">
          <div class="card-header">
            <div class="dot" id="drm-dot" style="background:var(--text3);box-shadow:none"></div>
            DRM DECODER
            <span style="margin-left:auto;font-size:.6rem;color:var(--text3);">autorun/drm-helper.js &#183; one ubersdr-drm per listener</span>
          </div>
          <div class="grid grid-4" style="gap:.6rem;margin-bottom:.6rem;">
            <div><div style="font-size:.6rem;color:var(--text3);">STATE</div>
                 <div id="drm-state" style="font-size:.9rem;color:var(--green);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">DECODERS IN USE</div>
                 <div id="drm-used" style="font-size:.9rem;color:var(--amber);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">PER LISTENER</div>
                 <div id="drm-perip" style="font-size:.9rem;color:var(--text);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">PORT</div>
                 <div id="drm-port" style="font-size:.9rem;color:var(--text);">--</div></div>
          </div>
          <div id="drm-sessions" style="font-size:.7rem;color:var(--text2);font-family:'Share Tech Mono',monospace;"></div>
          <div style="display:flex;flex-wrap:wrap;align-items:center;gap:.8rem;margin-top:.7rem;font-size:.72rem;">
            <label style="display:flex;align-items:center;gap:.4rem;">
              <input type="checkbox" id="drm-enabled" onchange="this.dataset.dirty='1'"> DRM on</label>
            <label style="display:flex;align-items:center;gap:.4rem;">Maximum listeners
              <input id="drm-max" type="number" min="1" max="20" onchange="this.dataset.dirty='1'"
                     style="width:3.4rem;background:var(--tile);border:1px solid var(--border);color:var(--green);padding:.15rem;"></label>
            <button class="btn btn-green" style="padding:.2rem .6rem;font-size:.65rem;" onclick="saveDrm()">&#128190; SAVE</button>
            <span style="font-size:.6rem;color:var(--text3);">applied within 5 s, no restart &#183; each listener costs ~2 % of one core and ~192 kbit/s upload</span>
          </div>
          <div id="drm-reason" style="font-size:.65rem;color:var(--text3);margin-top:.3rem;"></div>
        </div>

        <!-- ══════ THERMAL GUARD ══════ -->
        <div class="card" id="thermal-card" style="margin-bottom:1rem;display:none;">
          <div class="card-header">
            <div class="dot" id="tg-dot" style="background:#ff4444;box-shadow:0 0 6px #ff4444"></div>
            THERMAL GUARD
            <span style="margin-left:auto;font-size:.6rem;color:var(--text3);" id="tg-sensor"></span>
          </div>
          <div class="grid grid-4" style="gap:.6rem;margin-bottom:.6rem;">
            <div><div style="font-size:.6rem;color:var(--text3);">STATE</div>
                 <div id="tg-state" style="font-size:.9rem;color:var(--green);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">MODE</div>
                 <div id="tg-mode" style="font-size:.9rem;color:var(--text);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">STOPS AT</div>
                 <div id="tg-stop" style="font-size:.9rem;color:var(--amber);">--</div></div>
            <div><div style="font-size:.6rem;color:var(--text3);">RESUMES AT</div>
                 <div id="tg-resume" style="font-size:.9rem;color:var(--blue);">--</div></div>
          </div>
          <div id="tg-reason" style="font-size:.7rem;color:var(--text2);margin-bottom:.4rem;"></div>
          <div id="tg-last" style="font-size:.68rem;color:var(--text3);font-family:'Share Tech Mono',monospace;word-break:break-word;"></div>
          <div style="margin-top:.6rem;">
            <button class="btn btn-amber" style="padding:.2rem .6rem;font-size:.65rem;"
                    onclick="thermalReset()">CLEAR LOCKOUT</button>
            <span style="font-size:.6rem;color:var(--text3);margin-left:.5rem;">
              thresholds and mode are in Settings</span>
          </div>
        </div>

        <div class="card" style="margin-bottom:1rem;">
          <div class="card-header">
            <div class="dot" style="background:var(--green);box-shadow:0 0 6px var(--green)"></div>
            TERMINAL
            <span style="margin-left:.4rem;font-size:.6rem;color:var(--text3);" id="term-cwd">~</span>
            <span style="margin-left:auto;font-size:.6rem;color:var(--text3);cursor:pointer;" onclick="termClear()">&#10005; CLEAR</span>
          </div>
          <div id="term-output"
            style="font-family:'Share Tech Mono',monospace;font-size:.75rem;line-height:1.5;
                   background:var(--deep);border:1px solid var(--border);border-radius:3px;
                   padding:.5rem .7rem;height:300px;overflow-y:auto;color:var(--text);
                   white-space:pre-wrap;word-break:break-all;"></div>
          <div style="display:flex;align-items:center;gap:.4rem;margin-top:.4rem;
                      background:var(--deep);border:1px solid var(--border);border-radius:3px;padding:.3rem .6rem;">
            <span style="color:var(--green);font-size:.75rem;flex-shrink:0;">$</span>
            <input id="term-input" type="text" autocomplete="off" spellcheck="false"
              style="flex:1;background:transparent;border:none;outline:none;
                     color:var(--green);font-family:'Share Tech Mono',monospace;font-size:.75rem;"
              placeholder="type command and press Enter"
              onkeydown="termKey(event)">
            <button class="btn btn-green" style="padding:.2rem .6rem;font-size:.65rem;" onclick="termRun()">&#9654;</button>
          </div>
        </div>
        
        <div class="grid grid-2" style="margin-bottom:1rem;">
          <div class="card">
            <div class="card-header">
              <div class="dot"></div>RECENT LOG OUTPUT
              <span style="margin-left:auto;font-size:.6rem;color:var(--text3);cursor:pointer;" onclick="loadLogs('dash-log')">↻ refresh</span>
            </div>
            <div class="log-box" id="dash-log" style="height:280px;">Loading...</div>
          </div>
          <div class="card">
            <div class="card-header">
              <div class="dot" style="background:var(--amber);box-shadow:0 0 6px var(--amber)"></div>
              TOP PROCESSES
              <span style="margin-left:auto;font-size:.6rem;color:var(--text3);cursor:pointer;" onclick="updateStatus()">↻ refresh</span>
            </div>
            <table class="top-procs" data-nostack>
              <thead>
                <tr>
                  <th>PID</th><th>NAME</th><th>USER</th><th>CPU%</th><th>MEM%</th>
                </tr>
              </thead>
              <tbody id="top-procs-tbody">
                <tr><td colspan="5" style="color:var(--text3);text-align:center;">Loading...</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- ══════ CONFIG EDITOR PAGE ══════ -->
      <div class="page" id="page-receivers">
        <div class="section-head">RECEIVERS</div>
        <div class="card" style="margin-bottom:1rem;">
          <div style="overflow-x:auto;"><table class="top-procs" id="rx-table" style="width:100%;"></table></div>
          <div style="margin-top:.8rem;display:flex;gap:.6rem;flex-wrap:wrap;align-items:center;">
            <button class="btn btn-green" onclick="rxShowAdd()">➕ ADD NEW RECEIVER</button>
            <span style="font-size:.7rem;color:var(--text3);">Guide: docs/MULTI_RECEIVER.md</span>
          </div>
        </div>

        <div class="card" id="rx-change-card" style="margin-bottom:1rem;display:none;">
          <div class="card-header"><div class="dot"></div><span id="rx-change-title">CHANGE SETTINGS</span></div>
          <div class="field-row" id="rx-c-band-row" style="margin-bottom:.6rem;">
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">CENTRE FREQUENCY (MHz)</label>
              <input type="number" id="rx-c-freq" step="0.001" style="width:100%;" oninput="rxChangePreview()"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">BANDWIDTH (sample rate)</label>
              <select id="rx-c-sps" style="width:100%;" onchange="rxChangePreview()"></select></div>
          </div>
          <div class="field-row" style="margin-bottom:.6rem;">
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">A NEW LISTENER STARTS ON (MHz)</label>
              <input type="number" id="rx-c-dflt" step="0.0001" style="width:100%;" oninput="rxChangePreview()"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">IN MODE</label>
              <select id="rx-c-mode" style="width:100%;"></select></div>
          </div>
          <div id="rx-c-gain-wrap" style="display:none;margin-bottom:.6rem;">
            <div id="rx-c-g-rx888" class="field-row" style="margin-bottom:.6rem;">
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">GAIN (VGA 0 – 127)</label>
                <input type="number" id="rx-c-g-gain" min="0" max="127" step="1" style="width:100%;"></div>
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">GAIN MODE</label>
                <select id="rx-c-g-mode" style="width:100%;"><option value="low">low</option><option value="high">high</option></select></div>
            </div>
            <div id="rx-c-g-rx888b" class="field-row" style="margin-bottom:.6rem;">
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">ATTENUATION (0 – 63)</label>
                <input type="number" id="rx-c-g-att" min="0" max="63" step="1" style="width:100%;"></div>
              <div style="display:flex;align-items:flex-end;"><label style="font-size:.75rem;color:var(--text2);">
                <input type="checkbox" id="rx-c-g-pga"> PGA on (pre-amplifier)</label></div>
            </div>
            <div id="rx-c-g-rtl" style="margin-bottom:.6rem;"><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">RF GAIN (dB)</label>
              <select id="rx-c-g-rtlgain" style="width:100%;"></select></div>
          </div>
          <div id="rx-c-name-wrap" style="margin-bottom:.6rem;"><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">NAME ON ITS BUTTON</label>
            <input type="text" id="rx-c-name" style="width:100%;"></div>
          <div id="rx-c-preview" style="font-size:.75rem;color:var(--text2);margin-bottom:.6rem;"></div>
          <div style="display:flex;gap:.6rem;flex-wrap:wrap;">
            <button class="btn btn-amber" id="rx-c-apply" onclick="rxApplyChange()">✔ APPLY AND RESTART THIS RECEIVER</button>
            <button class="btn" onclick="document.getElementById('rx-change-card').style.display='none'">CANCEL</button>
          </div>
          <div id="rx-c-out" style="margin-top:.6rem;font-size:.7rem;color:var(--text2);white-space:pre-wrap;max-height:14rem;overflow:auto;"></div>
        </div>

        <div class="card" id="rx-rename-card" style="margin-bottom:1rem;display:none;">
          <div class="card-header"><div class="dot"></div><span id="rx-rename-title">RENAME BUTTON</span></div>
          <p style="color:var(--text2);font-size:.75rem;margin-bottom:.6rem;">
            The name on the receiver picker button. Nothing restarts and nobody is cut off; the short name (?rx=) stays the same, so links keep working.
          </p>
          <div style="margin-bottom:.6rem;"><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">NAME ON ITS BUTTON</label>
            <input type="text" id="rx-r-name" maxlength="60" style="width:100%;" onkeydown="if (event.key === 'Enter') rxApplyRename()"></div>
          <div style="display:flex;gap:.6rem;flex-wrap:wrap;">
            <button class="btn btn-amber" onclick="rxApplyRename()">✔ SAVE NAME</button>
            <button class="btn" onclick="document.getElementById('rx-rename-card').style.display='none'">CANCEL</button>
          </div>
          <div id="rx-r-out" style="margin-top:.6rem;font-size:.7rem;color:var(--text2);white-space:pre-wrap;"></div>
        </div>

        <div class="card" id="rx-delete-card" style="margin-bottom:1rem;display:none;">
          <div class="card-header"><div class="dot"></div><span id="rx-delete-title">DELETE RECEIVER</span></div>
          <p id="rx-d-what" style="color:var(--text2);font-size:.75rem;margin-bottom:.6rem;"></p>
          <div style="font-size:.75rem;color:var(--text2);margin-bottom:.6rem;">
            <label><input type="checkbox" id="rx-d-keep" checked> keep a copy of its folder in admin-backups/ (untick to delete it for good)</label>
          </div>
          <div style="margin-bottom:.6rem;"><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">TYPE ITS SHORT NAME TO CONFIRM</label>
            <input type="text" id="rx-d-confirm" style="width:100%;" autocomplete="off"></div>
          <div style="display:flex;gap:.6rem;flex-wrap:wrap;">
            <button class="btn btn-red" id="rx-d-apply" onclick="rxApplyDelete()">🗑 DELETE THIS RECEIVER</button>
            <button class="btn" onclick="document.getElementById('rx-delete-card').style.display='none'">CANCEL</button>
          </div>
          <div id="rx-d-out" style="margin-top:.6rem;font-size:.7rem;color:var(--text2);white-space:pre-wrap;"></div>
        </div>

        <div class="card" id="rx-add-card" style="margin-bottom:1rem;display:none;">
          <div class="card-header"><div class="dot"></div>ADD NEW RECEIVER</div>
          <p style="color:var(--text2);font-size:.75rem;margin-bottom:.6rem;">
            Fill this in, press PREPARE, and run the two lines it gives in a terminal on this computer.
            Installing the driver and restarting the proxy need your sudo password, so that part never runs from this page.
          </p>
          <div id="rx-a-usb" style="font-size:.7rem;color:var(--text2);margin-bottom:.6rem;"></div>
          <div class="field-row" style="margin-bottom:.6rem;">
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">RECEIVER</label>
              <select id="rx-a-type" style="width:100%;" onchange="rxAddType()">
                <option value="2">RTL-SDR (Blog V3/V4, other RTL2832U)</option>
                <option value="6">Airspy HF+</option>
                <option value="3">SDRplay RSP1A</option>
                <option value="7">HackRF One</option>
                <option value="4">Fobos SDR — RF path</option>
                <option value="5">Fobos SDR — HF1/HF2 direct sampling</option>
                <option value="1">RX888 MkII / RX888 (direct sampling)</option>
              </select></div>
            <div id="rx-a-v4-wrap" style="display:flex;align-items:flex-end;"><label style="font-size:.75rem;color:var(--text2);">
              <input type="checkbox" id="rx-a-v4"> it is an RTL-SDR Blog V4</label></div>
          </div>
          <div class="field-row" style="margin-bottom:.6rem;">
            <div id="rx-a-freq-wrap"><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">CENTRE FREQUENCY (MHz)</label>
              <input type="number" id="rx-a-freq" step="0.001" style="width:100%;" oninput="rxAddName()"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">BANDWIDTH (sample rate)</label>
              <select id="rx-a-sps" style="width:100%;"></select>
              <input type="number" id="rx-a-sps-num" style="width:100%;display:none;"></div>
          </div>
          <div class="field-row" style="margin-bottom:.6rem;">
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">SHORT NAME (?rx=&lt;name&gt;)</label>
              <input type="text" id="rx-a-name" style="width:100%;"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">NAME ON ITS BUTTON</label>
              <input type="text" id="rx-a-label" style="width:100%;"></div>
          </div>
          <div class="field-row" style="margin-bottom:.6rem;">
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">ITS ANTENNA</label>
              <input type="text" id="rx-a-antenna" style="width:100%;" placeholder="Antenna"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">STATION'S PUBLIC ADDRESS</label>
              <input type="text" id="rx-a-host" style="width:100%;"></div>
          </div>
          <div style="font-size:.75rem;color:var(--text2);display:grid;gap:.25rem;margin-bottom:.6rem;">
            <label><input type="checkbox" id="rx-a-driver" checked> install or update its driver (sudo)</label>
            <label><input type="checkbox" id="rx-a-picker" checked> show the receiver picker on the main page too (rebuilds the page)</label>
            <label><input type="checkbox" id="rx-a-admin" checked> set this panel's start script to start-all.sh (so Restart and the thermal guard bring back every receiver)</label>
            <label><input type="checkbox" id="rx-a-start" checked> start the new receiver at the end</label>
            <label><input type="checkbox" id="rx-a-proxy" checked> restart the proxy at the end, so listeners reach it (sudo)</label>
          </div>
          <div style="display:flex;gap:.6rem;flex-wrap:wrap;">
            <button class="btn btn-green" onclick="rxAddPrepare()">▶ PREPARE</button>
            <button class="btn" onclick="document.getElementById('rx-add-card').style.display='none'">CANCEL</button>
          </div>
          <div id="rx-a-out" style="margin-top:.6rem;font-size:.7rem;color:var(--text2);"></div>
        </div>
      </div>

      <div class="page" id="page-config">
        <div class="section-head">FILE EDITOR</div>
        <div class="editor-toolbar">
          <select class="file-select" id="config-file-sel" onchange="loadConfigFile()" style="flex:1;min-width:0;"></select>
          <button class="btn btn-blue" onclick="loadConfigList(true)">🔄 RESCAN</button>
          <button class="btn btn-blue" onclick="loadConfigFile()">↻ RELOAD</button>
          <button class="btn btn-green" onclick="saveConfigFile()">💾 SAVE</button>
        </div>
        <div class="json-path" id="config-filepath">--</div>
        <textarea class="code" id="config-editor" rows="32" spellcheck="false" placeholder="Select a file to edit..."></textarea>
        <div style="margin-top:.5rem;display:flex;gap:.5rem;align-items:center;">
          <button class="btn btn-green" onclick="saveConfigFile()">💾 SAVE FILE</button>
          <span style="font-size:.65rem;color:var(--text3);margin-left:.5rem;" id="config-save-msg"></span>
        </div>
      </div>

      <!-- ══════ SITE INFO PAGE ══════ -->
      <div class="page" id="page-siteinfo">
        <div class="section-head">SITE INFORMATION EDITOR</div>
        <div class="editor-toolbar">
          <select class="file-select" id="json-file-sel" onchange="loadJsonFile()"></select>
          <button class="btn btn-blue" onclick="loadJsonFile()">↻ RELOAD</button>
        </div>
        <div class="tab-bar">
          <div class="tab active" onclick="switchJsonTab('form',this)">FORM VIEW</div>
          <div class="tab" onclick="switchJsonTab('raw',this)">RAW JSON</div>
        </div>
        <div class="tab-pane active" id="json-form-pane">
          <div id="json-form-fields" style="display:grid;grid-template-columns:1fr 1fr;gap:.6rem;"></div>
          <div style="margin-top:.8rem;display:flex;gap:.5rem;">
            <button class="btn btn-green" onclick="saveJsonForm()">💾 SAVE CHANGES</button>
            <span id="json-save-msg" style="font-size:.65rem;color:var(--text3);margin-left:.5rem;"></span>
          </div>
        </div>
        <div class="tab-pane" id="json-raw-pane">
          <textarea class="code" id="json-raw-editor" rows="25" spellcheck="false"></textarea>
          <div style="margin-top:.5rem;">
            <button class="btn btn-green" onclick="saveJsonRaw()">💾 SAVE RAW JSON</button>
          </div>
        </div>
      </div>

      <!-- ══════ MARKERS PAGE ══════ -->
      <div class="page" id="page-markers">
        <div class="section-head">FREQUENCY MARKERS EDITOR</div>
        <div style="margin-bottom:.8rem;display:flex;gap:.5rem;flex-wrap:wrap;">
          <button class="btn btn-green" onclick="addMarker()">+ ADD MARKER</button>
          <button class="btn btn-amber" onclick="saveMarkers()">💾 SAVE MARKERS</button>
          <button class="btn btn-blue" onclick="loadMarkers()">↻ RELOAD</button>
          <span id="markers-save-msg" style="font-size:.65rem;color:var(--text3);margin:auto 0;"></span>
        </div>
        <div class="card" style="overflow-x:auto;">
          <table class="markers">
            <thead>
              <tr>
                <th>FREQUENCY (Hz)</th><th>NAME</th><th>MODE</th><th>COLOR</th><th>ACTION</th>
              </tr>
            </thead>
            <tbody id="markers-tbody"></tbody>
          </table>
        </div>
        <div style="margin-top:.8rem;">
          <div class="card-header"><div class="dot"></div>RAW JSON PREVIEW</div>
          <textarea class="code" id="markers-raw" rows="10" readonly style="opacity:.7;"></textarea>
        </div>
      </div>

      <!-- ══════ SPOT REPORTING PAGE ══════ -->
      <div class="page" id="page-reporting">
        <div class="section-head">SPOT REPORTING &#183; AUTORUN</div>

        <div class="card" style="margin-bottom:.9rem;">
          <div class="card-header"><div class="dot" id="ar-dot"></div><span id="ar-state">&#8212;</span></div>
          <div id="ar-status" style="font-size:.7rem;color:var(--text2);line-height:1.7;">&#8212;</div>
          <div style="margin-top:.8rem;display:flex;gap:.5rem;flex-wrap:wrap;">
            <button class="btn btn-green" onclick="autorunStart()">&#9654; START</button>
            <button class="btn btn-red" onclick="autorunStop()">&#9632; STOP</button>
            <button class="btn btn-amber" onclick="autorunSave()">&#128190; SAVE CONFIG</button>
            <button class="btn btn-blue" onclick="autorunLoad()">&#8635; RELOAD</button>
            <button class="btn btn-red" onclick="autorunFreeAll()">&#10005; FREE ALL SLOTS</button>
            <span id="ar-msg" style="font-size:.65rem;color:var(--text3);margin:auto 0;"></span>
          </div>
        </div>

        <!-- Per-decoder spot tally.  The aggregate PSK Reporter figure above
             cannot separate FT8, FT4 and JS8 (they share one upload queue), so
             the daemon counts them separately and reports them here. -->
        <div class="card" style="margin-bottom:.9rem;">
          <div class="card-header"><div class="dot"></div>SPOTS UPLOADED PER DECODER</div>
          <div class="grid grid-4" id="ar-spots-grid">
            <div class="ar-spot-tile">
              <div class="ar-spot-mode">FT8</div>
              <div class="ar-spot-count" id="ar-up-ft8">&#8212;</div>
              <div class="ar-spot-sub" id="ar-sub-ft8">&#8212;</div>
            </div>
            <div class="ar-spot-tile">
              <div class="ar-spot-mode">FT4</div>
              <div class="ar-spot-count" id="ar-up-ft4">&#8212;</div>
              <div class="ar-spot-sub" id="ar-sub-ft4">&#8212;</div>
            </div>
            <div class="ar-spot-tile">
              <div class="ar-spot-mode">JS8</div>
              <div class="ar-spot-count" id="ar-up-js8">&#8212;</div>
              <div class="ar-spot-sub" id="ar-sub-js8">&#8212;</div>
            </div>
            <div class="ar-spot-tile">
              <div class="ar-spot-mode">WSPR</div>
              <div class="ar-spot-count" id="ar-up-wspr">&#8212;</div>
              <div class="ar-spot-sub" id="ar-sub-wspr">&#8212;</div>
            </div>
          </div>
          <p style="color:var(--text3);font-size:.65rem;margin-top:.6rem;" id="ar-spots-note">
            Counts run from the last daemon start &#8212; Stop/Start resets them to zero.</p>
        </div>

        <div class="card" style="margin-bottom:.9rem;">
          <div class="card-header"><div class="dot"></div>REPORTER IDENTITY</div>
          <p style="color:var(--text2);font-size:.68rem;margin:.2rem 0 .7rem;">
            Spots upload under this callsign/grid. Defaults come from Site Info (siteSysop /
            siteGridSquare, first 6 chars). Editable for other sysops &#8212; set your own call before enabling reporting.</p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem;">
            <div class="field"><label>CALLSIGN</label><input id="ar-call" type="text" placeholder="SV1BTL"></div>
            <div class="field"><label>GRID (6 CHAR)</label><input id="ar-grid" type="text" maxlength="6" placeholder="KM17VX"></div>
          </div>
        </div>

        <div class="card" style="margin-bottom:.9rem;">
          <div class="card-header"><div class="dot"></div>REPORTING DESTINATIONS</div>
          <label style="display:flex;align-items:center;gap:.5rem;font-size:.72rem;margin:.4rem 0;">
            <input type="checkbox" id="ar-psk"> PSK Reporter <span style="color:var(--text3)">&#8212; FT8 &amp; FT4 &#8594; report.pskreporter.info</span></label>
          <label style="display:flex;align-items:center;gap:.5rem;font-size:.72rem;margin:.4rem 0;">
            <input type="checkbox" id="ar-wspr"> wsprnet <span style="color:var(--text3)">&#8212; WSPR &#8594; wsprnet.org</span></label>
          <p style="color:var(--amber);font-size:.65rem;margin-top:.5rem;">Reporting is OFF by default. Nothing uploads until you enable a destination, Save, and Start.</p>
        </div>

        <div class="card">
          <div class="card-header"><div class="dot"></div>BANDS &amp; MODES
            <span style="margin-left:auto;font-size:.62rem;color:var(--text3);">MAX SLOTS
              <input id="ar-max" type="number" min="1" max="64" onchange="autorunCount()" style="width:3.4rem;margin-left:.3rem;background:var(--tile);border:1px solid var(--border);color:var(--green);padding:.15rem;"></span>
          </div>
          <div style="overflow-x:auto;"><table class="markers" id="ar-matrix"></table></div>
          <p style="color:var(--text3);font-size:.62rem;margin-top:.5rem;" id="ar-count">&#8212;</p>
          <p style="color:var(--text3);font-size:.62rem;margin-top:.3rem;display:none;" id="ar-slot-note">
            The number beside each box is that band+mode's <b>all-time</b> uploaded spots, kept across
            restarts. <span style="color:var(--amber)">Amber with a dot (&#183;123)</span> means decodes not
            uploaded yet &#8212; normal between flushes; a plain
            <span style="color:var(--amber)">0</span> means enabled but nothing decoded yet (WSPR can take
            minutes &#8212; it runs on a 2-minute cycle). Hover for the detail.</p>
        </div>
      </div>

      <!-- ══════ LOG VIEWER PAGE ══════ -->
      <div class="page" id="page-logs">
        <div class="section-head">LOG VIEWER</div>
        <div style="display:flex;gap:.5rem;margin-bottom:.7rem;flex-wrap:wrap;">
          <button class="btn btn-blue" onclick="loadCurrentLogTab()">↻ REFRESH LOGS</button>
          <button class="btn btn-green" id="auto-refresh-btn" onclick="toggleAutoRefresh()">⏵ AUTO REFRESH</button>
          <button class="btn btn-red" onclick="clearLogView()">✕ CLEAR LOGS</button>
        </div>
        <div class="tab-bar" style="margin-bottom:.6rem;">
          <div class="tab log-tab active" data-log-name="logwebsdr.txt" onclick="switchLogTab('logwebsdr.txt', this)">LOGWEBSDR</div>
          <div class="tab log-tab" data-log-name="spectrumserver.log" onclick="switchLogTab('spectrumserver.log', this)">SPECTRUMSERVER</div>
          <div class="tab log-tab" data-log-name="admin.log" onclick="switchLogTab('admin.log', this)">ADMIN</div>
          <div class="tab log-tab" data-log-name="rade.log" onclick="switchLogTab('rade.log', this)">RADE</div>
          <div class="tab log-tab" data-log-name="drm.log" onclick="switchLogTab('drm.log', this)">DRM</div>
          <div class="tab log-tab" data-log-name="crash.log" onclick="switchLogTab('crash.log', this)">CRASH</div>
          <div class="tab log-tab" data-log-name="autorun.log" onclick="switchLogTab('autorun.log', this)">AUTORUN</div>
          <div class="tab log-tab" data-log-name="proxy.log" onclick="switchLogTab('proxy.log', this)">PROXY</div>
        </div>
        <div class="tab-pane log-tab-pane active" id="log-pane-logwebsdr">
          <div class="log-box" id="main-log-logwebsdr" style="height:550px;"></div>
        </div>
        <div class="tab-pane log-tab-pane" id="log-pane-spectrumserver">
          <div class="log-box" id="main-log-spectrumserver" style="height:550px;"></div>
        </div>
        <div class="tab-pane log-tab-pane" id="log-pane-admin">
          <div class="log-box" id="main-log-admin" style="height:550px;"></div>
        </div>
        <div class="tab-pane log-tab-pane" id="log-pane-rade">
          <div class="log-box" id="main-log-rade" style="height:550px;"></div>
        </div>
        <div class="tab-pane log-tab-pane" id="log-pane-drm">
          <div class="log-box" id="main-log-drm" style="height:550px;"></div>
        </div>
        <div class="tab-pane log-tab-pane" id="log-pane-crash">
          <div class="log-box" id="main-log-crash" style="height:550px;"></div>
        </div>
        <div class="tab-pane log-tab-pane" id="log-pane-autorun">
          <div class="log-box" id="main-log-autorun" style="height:550px;"></div>
        </div>
        <div class="tab-pane log-tab-pane" id="log-pane-proxy">
          <div class="log-box" id="main-log-proxy" style="height:550px;"></div>
        </div>
      </div>

      <!-- ══════ CHAT HISTORY PAGE ══════ -->
      <div class="page" id="page-chat">
        <div class="section-head">CHAT HISTORY</div>
        <div style="display:flex;gap:.5rem;margin-bottom:.7rem;">
          <button class="btn btn-blue" onclick="loadChat()">↻ REFRESH</button>
        </div>
        <div class="chat-log" id="chat-log">Loading...</div>
      </div>

      <!-- ══════ SETTINGS PAGE ══════ -->
      <div class="page" id="page-settings">
        <div class="section-head">ADMIN SETTINGS</div>
        <div class="card" style="margin-bottom:1rem;">
          <div class="card-header"><div class="dot"></div>APPEARANCE</div>
          <div style="display:flex;gap:.8rem;align-items:center;flex-wrap:wrap;">
            <label style="font-size:.7rem;color:var(--text2);" for="theme-sel">THEME</label>
            <select id="theme-sel" onchange="setAdminTheme(this.value)" style="padding:.4rem .6rem;font-size:.8rem;">
              <option value="green">Phosphor green (classic)</option>
              <option value="amber">Amber display</option>
              <option value="metal">Metal panel (as the receiver page)</option>
              <option value="dark">Modern dark</option>
              <option value="light">Light</option>
              <option value="auto">Auto: light by day, dark at night (station locator)</option>
            </select>
            <span style="font-size:.65rem;color:var(--text3);">Saved in this browser only.</span>
          </div>
        </div>
        <div class="grid grid-2" style="margin-bottom:1rem;">
          <div class="card">
            <div class="card-header"><div class="dot"></div>CHANGE PASSWORD</div>
            <form onsubmit="changePassword(event)">
              <div style="margin-bottom:.6rem;">
                <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">CURRENT PASSWORD</label>
                <input type="password" id="old-pwd" style="width:100%;">
              </div>
              <div style="margin-bottom:.6rem;">
                <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">NEW PASSWORD</label>
                <input type="password" id="new-pwd" style="width:100%;">
              </div>
              <div style="margin-bottom:.8rem;">
                <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">CONFIRM NEW PASSWORD</label>
                <input type="password" id="new-pwd2" style="width:100%;">
              </div>
              <button type="submit" class="btn btn-green">🔑 UPDATE PASSWORD</button>
            </form>
            <div class="card-header" style="margin:1.2rem 0 .5rem;"><div class="dot" style="background:var(--blue);box-shadow:0 0 6px var(--blue);"></div>PORTS</div>
            <div id="ports-list" style="font-size:.7rem;color:var(--text2);">Loading…</div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot"></div>SDR BASE DIRECTORY</div>
            <p style="color:var(--text2);font-size:.75rem;margin-bottom:.6rem;">Path to PhantomSDR-Plus installation:</p>
            <input type="text" id="sdr-dir" style="width:100%;margin-bottom:1rem;" placeholder="/path/to/PhantomSDR-Plus">
            <div class="card-header" style="margin:.4rem 0;">
              <div class="dot" style="background:var(--blue);box-shadow:0 0 6px var(--blue);"></div>
              SPECTRUMSERVER PORT (MAIN RECEIVER)
            </div>
            <p id="public-port-help" style="color:var(--text2);font-size:.7rem;margin-bottom:.4rem;">Port spectrumserver listens on.<br>With no proxy, this is also the port listeners connect to.<br>Used for Kick and connection counts.</p>
            <input type="number" id="public-port" style="width:100%;margin-bottom:.4rem;" min="1" max="65535" oninput="renderPortHelp()">
            <p style="color:var(--text2);font-size:.7rem;margin-bottom:1rem;">Listener port (proxy): <b id="proxy-port-ro">—</b> <span style="opacity:.7;">(read-only, proxy_port in admin_config.json)</span></p>
            <div class="card-header" style="margin:.4rem 0;">
              <div class="dot" style="background:var(--green);box-shadow:0 0 6px var(--green);"></div>
              DEFAULT START SCRIPT
            </div>
            <div style="display:flex;gap:.5rem;margin-bottom:.8rem;">
              <select class="script-select" id="default-start-sel" style="flex:1;min-width:0;"></select>
              <button class="btn btn-green" id="run-start-btn" onclick="runDefaultScript('start')" title="Run the saved start script now">▶ START</button>
            </div>
            <div class="card-header" style="margin:.4rem 0;">
              <div class="dot" style="background:var(--red);box-shadow:0 0 6px var(--red);"></div>
              DEFAULT STOP SCRIPT
            </div>
            <div style="display:flex;gap:.5rem;margin-bottom:.8rem;">
              <select class="script-select" id="default-stop-sel" style="flex:1;min-width:0;"></select>
              <button class="btn btn-red" id="run-stop-btn" onclick="runDefaultScript('stop')" title="Run the saved stop script now">■ STOP</button>
            </div>
            <button class="btn btn-amber" onclick="saveSettings()">💾 SAVE SETTINGS</button>
            <div id="settings-msg" style="margin-top:.5rem;font-size:.7rem;color:var(--text3);white-space:pre-wrap;max-height:16rem;overflow:auto;"></div>
          </div>
        </div>

        <!-- ══════ HTTPS ══════ -->
        <div class="section-head">HTTPS</div>
        <div class="card" style="margin-bottom:1rem;">
          <p style="color:var(--text2);font-size:.75rem;margin-bottom:.6rem;">
            Serve the receiver over https:// as well as http:// (Caddy in front, free Let's Encrypt certificate).
            The http address keeps working. Turning it on needs your sudo password, so it runs in a terminal — never from this page.
          </p>
          <div style="display:flex;gap:.8rem;align-items:center;flex-wrap:wrap;margin-bottom:.6rem;">
            <span id="https-state" style="font-size:.75rem;color:var(--text2);">—</span>
            <button class="btn btn-green" id="https-btn" onclick="httpsAction()" disabled>…</button>
          </div>
          <div id="https-out" style="font-size:.7rem;color:var(--text2);white-space:pre-wrap;"></div>
        </div>

        <!-- ══════ THERMAL GUARD SETTINGS ══════ -->
        <div class="section-head">THERMAL GUARD</div>
        <div class="card" style="margin-bottom:1rem;">
          <p style="color:var(--text2);font-size:.75rem;margin-bottom:.6rem;">
            Protects the machine when the CPU overheats. Blank temperature fields mean
            <b>auto</b> — derived from this machine's own critical trip point
            (<span id="tg-cfg-crit">--</span>), so the numbers are right for Intel, AMD and Pi alike.
            Every stage must be held for its sustain time, so a brief spike never acts.
            <b>Start with mode = log</b> for a while and read the results in the CRASH log.
          </p>
          <div class="field-row" style="margin-bottom:.7rem;">
            <div>
              <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">MODE</label>
              <select id="tg-cfg-mode" style="width:100%;">
                <option value="log">log — record only, never act (safe default)</option>
                <option value="throttle">throttle — lower CPU clock, never stop</option>
                <option value="stop">stop — throttle, then stop the server</option>
                <option value="stop+restart">stop+restart — and restart once cool</option>
              </select>
            </div>
            <div>
              <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">ENABLED</label>
              <select id="tg-cfg-enabled" style="width:100%;">
                <option value="1">yes</option><option value="0">no</option>
              </select>
            </div>
          </div>
          <div class="grid grid-4" style="gap:.6rem;margin-bottom:.7rem;">
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">WARN °C</label>
                 <input type="number" step="0.5" id="tg-cfg-warn" style="width:100%;" placeholder="auto"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">THROTTLE °C</label>
                 <input type="number" step="0.5" id="tg-cfg-throttle" style="width:100%;" placeholder="auto"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">STOP °C</label>
                 <input type="number" step="0.5" id="tg-cfg-stop" style="width:100%;" placeholder="auto"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">RESUME °C</label>
                 <input type="number" step="0.5" id="tg-cfg-resume" style="width:100%;" placeholder="auto"></div>
          </div>
          <div class="grid grid-4" style="gap:.6rem;margin-bottom:.7rem;">
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">STOP SUSTAIN (s)</label>
                 <input type="number" id="tg-cfg-sustain" style="width:100%;" placeholder="60"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">WARN SUSTAIN (s)</label>
                 <input type="number" id="tg-cfg-warnsustain" style="width:100%;" placeholder="30"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">RESUME HOLD (s)</label>
                 <input type="number" id="tg-cfg-resumes" style="width:100%;" placeholder="300"></div>
            <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">MAX STOPS / HOUR</label>
                 <input type="number" id="tg-cfg-maxstops" style="width:100%;" placeholder="2"></div>
          </div>
          <div style="margin-bottom:.7rem;">
            <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">
              TEST TEMPERATURE °C — inject a fake reading to prove the whole path works, blank = off</label>
            <input type="number" step="0.5" id="tg-cfg-test" style="width:100%;" placeholder="blank = use the real sensor">
          </div>
          <button class="btn btn-amber" onclick="saveThermal()">💾 SAVE THERMAL SETTINGS</button>
          <div id="tg-cfg-msg" style="margin-top:.5rem;font-size:.7rem;color:var(--text3);"></div>
        </div>
        <div class="grid grid-2" style="margin-top:1rem;">
          <div class="card">
            <div class="card-header"><div class="dot" style="background:var(--amber);box-shadow:0 0 6px var(--amber)"></div>ALERTS — EMAIL / TELEGRAM</div>
            <p style="color:var(--text2);font-size:.7rem;margin-bottom:.6rem;">A message when a receiver goes off the air or comes back, is restarted, the thermal guard changes stage, or crash.log gets a new entry. Checked every 30 s; the same alert at most once per 5 minutes.</p>
            <div style="display:flex;flex-wrap:wrap;gap:.8rem;font-size:.72rem;margin-bottom:.8rem;">
              <label><input type="checkbox" id="al-ev-down"> off the air</label>
              <label><input type="checkbox" id="al-ev-up"> back on air</label>
              <label><input type="checkbox" id="al-ev-restart"> restarted</label>
              <label><input type="checkbox" id="al-ev-thermal"> thermal guard</label>
              <label><input type="checkbox" id="al-ev-crash"> crash.log</label>
            </div>
            <div class="card-header" style="margin:.4rem 0;"><label><input type="checkbox" id="al-tg-on"> TELEGRAM</label></div>
            <div class="grid grid-2" style="gap:.5rem;margin-bottom:.4rem;">
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">BOT TOKEN (from @BotFather)</label><input type="password" id="al-tg-token" style="width:100%;" autocomplete="off"></div>
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">CHAT ID (your own, e.g. from @userinfobot)</label><input type="text" id="al-tg-chat" style="width:100%;"></div>
            </div>
            <div class="card-header" style="margin:.8rem 0 .4rem;"><label><input type="checkbox" id="al-em-on"> EMAIL</label></div>
            <div class="grid grid-2" style="gap:.5rem;margin-bottom:.4rem;">
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">SMTP SERVER</label><input type="text" id="al-em-host" style="width:100%;" placeholder="smtp.example.com"></div>
              <div style="display:flex;gap:.5rem;">
                <div style="flex:1;"><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">PORT</label><input type="number" id="al-em-port" style="width:100%;" placeholder="465"></div>
                <div style="flex:1;"><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">SECURITY</label><select id="al-em-sec" style="width:100%;"><option value="ssl">SSL</option><option value="starttls">STARTTLS</option><option value="none">none</option></select></div>
              </div>
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">USER</label><input type="text" id="al-em-user" style="width:100%;" autocomplete="off"></div>
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">PASSWORD</label><input type="password" id="al-em-pass" style="width:100%;" autocomplete="new-password"></div>
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">FROM (address, or just a name; blank = user)</label><input type="text" id="al-em-from" style="width:100%;"></div>
              <div><label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">TO</label><input type="text" id="al-em-to" style="width:100%;"></div>
            </div>
            <div style="display:flex;gap:.5rem;margin-top:.8rem;">
              <button class="btn btn-amber" onclick="saveAlerts()">💾 SAVE ALERTS</button>
              <button class="btn btn-blue" onclick="testAlerts()">✉ SEND TEST</button>
            </div>
            <div id="al-msg" style="margin-top:.5rem;font-size:.7rem;color:var(--text3);"></div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot" style="background:var(--blue);box-shadow:0 0 6px var(--blue)"></div>BACKUP &amp; RESTORE OF THE STATION SETTINGS</div>
            <p style="color:var(--text2);font-size:.7rem;margin-bottom:.6rem;">One zip with this station's own settings: the receiver .toml configs, receivers.toml, station.conf, site information, markers, band settings, the relay, DRM and spot-reporting settings, the ban list, and the same for every extra receiver in instances/. Not included: the admin password, the alert secrets, the logs and the program itself.</p>
            <button class="btn btn-green" onclick="window.location='/admin/api/backup'">⬇ DOWNLOAD BACKUP</button>
            <div style="margin-top:1.2rem;font-size:.65rem;color:var(--text3);margin-bottom:.3rem;">RESTORE FROM A BACKUP ZIP</div>
            <input type="file" id="rs-file" accept=".zip,application/zip" style="width:100%;margin-bottom:.5rem;">
            <button class="btn btn-red" onclick="restoreBackup()">⬆ RESTORE</button>
            <p style="color:var(--text3);font-size:.65rem;margin-top:.5rem;">Only the files listed above are taken from the zip. Every file it replaces is copied first to admin-backups/restore-&lt;date&gt;/. Afterwards restart the receivers (and rebuild the page if site information or band settings were in it).</p>
            <div id="rs-msg" style="margin-top:.5rem;font-size:.7rem;color:var(--text3);"></div>
          </div>
        </div>
      </div>

      <div class="page" id="page-visitors">
        <div class="section-head">VISITOR STATISTICS
          <span style="margin-left:auto;font-size:.65rem;">
            <select id="vs-days" onchange="loadVisitors()">
              <option value="1">Today</option><option value="7" selected>7 days</option>
              <option value="14">14 days</option><option value="31">31 days</option>
            </select>
            <button class="btn" onclick="loadVisitors()">↻ RELOAD</button>
          </span>
        </div>
        <p style="color:var(--text3);font-size:.68rem;margin:0 0 .8rem;">From the private listener logs of every receiver (with the addresses, which the public pages no longer show). Days and hours are UTC; the station's own decoders (local connections) are left out.</p>
        <div class="grid grid-4" style="margin-bottom:1rem;" id="vs-totals"></div>
        <div class="grid grid-2" style="margin-bottom:1rem;">
          <div class="card">
            <div class="card-header"><div class="dot"></div>PER DAY</div>
            <div id="vs-days-tbl" style="overflow:auto;"></div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot" style="background:var(--amber);box-shadow:0 0 6px var(--amber)"></div>BUSIEST HOURS (UTC, sessions started)</div>
            <div id="vs-hours" style="display:flex;align-items:flex-end;gap:2px;height:8rem;padding-top:.5rem;"></div>
            <div style="display:flex;justify-content:space-between;font-size:.55rem;color:var(--text3);"><span>00</span><span>06</span><span>12</span><span>18</span><span>23</span></div>
            <div class="card-header" style="margin-top:1rem;"><div class="dot" style="background:var(--blue);box-shadow:0 0 6px var(--blue)"></div>COUNTRIES (visitors)</div>
            <div id="vs-cc" style="font-size:.75rem;line-height:1.7;"></div>
            <div class="card-header" style="margin-top:1rem;"><div class="dot" style="background:var(--green);box-shadow:0 0 6px var(--green)"></div>DECODERS (sessions that ran each)</div>
            <div id="vs-dec" style="font-size:.75rem;line-height:1.7;"></div>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><div class="dot" style="background:#ff4444;box-shadow:0 0 6px #ff4444"></div>ADDRESSES — most sessions at the same time first (a flood shows up here)</div>
          <div id="vs-addr" style="overflow:auto;"></div>
        </div>
      </div>

      <!-- ══════ USERS PAGE ══════ -->
      <!-- ══════ GRAPHS PAGE ══════ -->
      <div class="page" id="page-graphs">
        <div class="section-head">SYSTEM GRAPHS</div>
        <div style="display:flex;gap:.5rem;margin-bottom:.8rem;flex-wrap:wrap;align-items:center;">
          <button class="btn btn-green graph-range active" data-range="900"  onclick="graphSetRange(900,this)">15 MIN</button>
          <button class="btn graph-range" data-range="3600" onclick="graphSetRange(3600,this)">1 HOUR</button>
          <button class="btn graph-range" data-range="14400" onclick="graphSetRange(14400,this)">4 HOURS</button>
          <button class="btn graph-range" data-range="43200" onclick="graphSetRange(43200,this)">12 HOURS</button>
          <button class="btn graph-range" data-range="86400" onclick="graphSetRange(86400,this)">24 HOURS</button>
          <span style="font-size:.78rem;color:var(--text3);margin-left:.4rem;" id="graph-info-label"></span>
        </div>

        <!-- Current values.  Each graph panel below is titled and scaled on its
             own, so these tiles carry the exact reading the curves only imply. -->
        <div class="grid grid-4" style="margin-bottom:1rem;">
          <div class="card">
            <div class="card-header"><div class="dot"></div>CPU FREQUENCY</div>
            <div class="stat-val" id="g-cur-freq">--</div>
            <div class="stat-label" id="g-sub-freq">GHz average</div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot"></div>CPU LOAD</div>
            <div class="stat-val" id="g-cur-load">--</div>
            <div class="stat-label">percent</div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot"></div>CPU TEMPERATURE</div>
            <div class="stat-val" id="g-cur-temp">--</div>
            <div class="stat-label" id="g-sub-temp">degrees C</div>
          </div>
          <div class="card">
            <div class="card-header"><div class="dot"></div>USERS ONLINE</div>
            <div class="stat-val" id="g-cur-users">--</div>
            <div class="stat-label">connected now</div>
          </div>
        </div>

        <div class="card" style="padding:.6rem .4rem .2rem .4rem;">
          <!-- Four stacked panels sharing one time axis.  Deliberately NOT one
               chart with several y-scales: GHz, %, °C and a head-count have no
               common scale, and overlaying them would invent relationships that
               are not in the data. -->
          <div id="graph-empty" style="display:none;color:var(--text3);font-size:.72rem;text-align:center;padding:2rem .6rem;"></div>
          <canvas id="graph-canvas" style="width:100%;display:block;cursor:crosshair;"></canvas>
          <div id="graph-tooltip" style="display:none;position:absolute;z-index:50;pointer-events:none;
               background:var(--tile);border:1px solid var(--border);border-radius:3px;padding:.45rem .6rem;
               font-size:.8rem;line-height:1.5;color:var(--text);white-space:nowrap;box-shadow:0 4px 14px #000a;"></div>
        </div>
      </div>

      <div class="page" id="page-users">
        <div class="section-head">CONNECTED USERS</div>
        <div style="display:flex;gap:.5rem;margin-bottom:.8rem;flex-wrap:wrap;align-items:center;">
          <button class="btn btn-blue" onclick="loadUsers()">&#8635; REFRESH</button>
          <button class="btn btn-green" id="users-auto-btn" onclick="toggleUsersAutoRefresh()">&#9654; AUTO</button>
          <button class="btn btn-amber" onclick="showPage('visitors', document.getElementById('nav-visitors'))">📈 VISITOR STATISTICS</button>
          <span style="font-size:.65rem;color:var(--text3);margin-left:.4rem;" id="users-info-label"></span>
        </div>
        <div id="users-error" style="display:none;background:rgba(255,64,64,.08);border:1px solid rgba(255,64,64,.3);border-radius:3px;color:var(--red);padding:.5rem .9rem;font-size:.72rem;margin-bottom:.6rem;"></div>
        <div class="card" style="overflow-x:auto;padding:0;">
          <table style="width:100%;border-collapse:collapse;font-size:.75rem;">
            <thead>
              <tr>
                <th style="color:var(--text3);font-weight:normal;letter-spacing:.1em;padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;">NAME / CALL</th>
                <th style="color:var(--text3);font-weight:normal;letter-spacing:.1em;padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;">IP / LOCATION</th>
                <th id="users-rx-th" style="display:none;color:var(--text3);font-weight:normal;letter-spacing:.1em;padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;">RECEIVER</th>
                <th style="color:var(--text3);font-weight:normal;letter-spacing:.1em;padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;">FREQUENCY</th>
                <th style="color:var(--text3);font-weight:normal;letter-spacing:.1em;padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;">MODE</th>
                <th style="color:var(--text3);font-weight:normal;letter-spacing:.1em;padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;">DURATION</th>
                <th style="color:var(--text3);font-weight:normal;letter-spacing:.1em;padding:.4rem .6rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap;">ACTION</th>
              </tr>
            </thead>
            <tbody id="users-tbody">
              <tr><td colspan="8" style="color:var(--text3);text-align:center;padding:.8rem;">Click REFRESH to load</td></tr>
            </tbody>
          </table>
        </div>
        <div class="card" id="bans-card" style="display:none;margin-top:.8rem;overflow-x:auto;padding:0;">
          <div class="card-header" style="padding:.6rem .9rem;margin:0;display:flex;align-items:center;gap:.6rem;">
            <div class="dot"></div>BANNED
            <span style="font-size:.6rem;color:var(--text3);margin-left:auto;">kept across receiver restarts</span>
          </div>
          <table style="width:100%;border-collapse:collapse;font-size:.75rem;">
            <tbody id="bans-tbody"></tbody>
          </table>
        </div>
        <div class="card" style="margin-top:.8rem;padding:0;overflow:hidden;">
          <div class="card-header" style="padding:.6rem .9rem;margin:0;display:flex;align-items:center;gap:.6rem;">
            <div class="dot"></div>LISTENER MAP
            <span style="font-size:.6rem;color:var(--text3);margin-left:auto;" id="umap-info"></span>
          </div>
          <div id="umap" style="height:420px;background:var(--bg);"></div>
        </div>
      </div>

      <!-- ══════ WATERFALL MESSAGE PAGE ══════ -->
      <div class="page" id="page-wfmsg">
        <div class="section-head">📢 WATERFALL MESSAGE</div>
        <div class="grid grid-2">

          <div class="card">
            <div class="card-header">
              <div class="dot" style="background:var(--amber);box-shadow:0 0 6px var(--amber)"></div>
              COMPOSE &amp; BROADCAST
            </div>

            <div style="margin-bottom:.6rem;">
              <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">MESSAGE (max 200 chars)</label>
              <textarea id="wfmsg-text"
                style="width:100%;background:var(--deep);border:1px solid var(--border);
                       color:var(--text);font-family:'Share Tech Mono',monospace;
                       font-size:.85rem;padding:.5rem .7rem;border-radius:3px;
                       resize:vertical;height:80px;outline:none;transition:.15s;"
                placeholder="QRT in 10 min — 73 de SV1BTL!" maxlength="200"
                onfocus="this.style.borderColor='var(--amber)'"
                onblur="this.style.borderColor='var(--border)'"></textarea>
              <div id="wfmsg-charcount" style="font-size:.6rem;color:var(--text3);text-align:right;margin-top:.2rem;">0 / 200</div>
            </div>

            <div style="margin-bottom:.8rem;">
              <label style="font-size:.65rem;color:var(--text3);display:block;margin-bottom:.3rem;">TEXT COLOUR</label>
              <select id="wfmsg-color"
                style="width:100%;background:var(--field);border:1px solid var(--border);
                       color:var(--text);font-family:'Share Tech Mono',monospace;
                       font-size:.8rem;padding:.4rem .6rem;border-radius:2px;outline:none;">
                <option value="#ffffff">⬜ White</option>
                <option value="#ffff00">🟡 Yellow</option>
                <option value="#00ffff">🩵 Cyan</option>
                <option value="#00ff41">🟢 Green</option>
                <option value="#ffb000">🟠 Amber</option>
              </select>
            </div>

            <div style="display:flex;gap:.5rem;">
              <button class="btn btn-amber" onclick="sendWfMsg()" style="flex:1;">📢 BROADCAST</button>
              <button class="btn btn-red" onclick="clearWfMsg()">✕ CLEAR</button>
            </div>
            <div id="wfmsg-status" style="margin-top:.6rem;font-size:.7rem;color:var(--text3);min-height:1.4em;padding:.2rem 0;"></div>
          </div>

          <div class="card">
            <div class="card-header"><div class="dot"></div>STATUS &amp; NOTES</div>
            <div style="font-size:.75rem;color:var(--text2);line-height:2;">
              <p>The message appears as a <span style="color:var(--green)">fixed dark banner at the top of the waterfall</span> for all connected users.</p>
              <br>
              <p>&#9679; Stays visible until you click <strong style="color:var(--red)">CLEAR</strong>.</p>
              <p>&#9679; Browsers poll every 10 s — message appears within 10 s of BROADCAST.</p>
              <p>&#9679; Disappears within 10 s of CLEAR.</p>
              <p>&#9679; Users who connect after CLEAR never see it.</p>
              <p>&#9679; No page refresh required on either side.</p>
            </div>

            <div style="margin-top:1rem;padding:.6rem .8rem;border-radius:3px;border:1px solid var(--border);background:var(--deep);">
              <div style="font-size:.6rem;color:var(--text3);letter-spacing:.15em;margin-bottom:.4rem;">CURRENT ACTIVE MESSAGE</div>
              <div id="wfmsg-active" style="font-size:.85rem;color:var(--text3);word-break:break-word;min-height:1.4em;">—</div>
            </div>

            <div style="margin-top:.8rem;display:flex;gap:.5rem;">
              <button class="btn btn-blue" onclick="loadWfMsgStatus()" style="flex:1;">↻ REFRESH STATUS</button>
            </div>
          </div>

        </div>
      </div>
      <!-- /WATERFALL MESSAGE PAGE -->

    </div><!-- /content -->
  </div><!-- /main -->
</div><!-- /layout -->

<!-- Mobile bottom navigation bar -->
<nav class="bottom-nav" id="bottom-nav">
  <a href="#" onclick="showPage('dashboard',this);return false;" class="active" data-page="dashboard">
    <span class="bi">⬡</span><span>DASH</span>
  </a>
  <a href="#" onclick="showPage('receivers',this);return false;" data-page="receivers">
    <span class="bi">📡</span><span>RX</span>
  </a>
  <a href="#" onclick="showPage('users',this);return false;" data-page="users">
    <span class="bi">👥</span><span>USERS</span>
  </a>
  <a href="#" onclick="showPage('graphs',this);return false;" data-page="graphs">
    <span class="bi">📈</span><span>GRAPHS</span>
  </a>
  <a href="#" onclick="showPage('logs',this);return false;" data-page="logs">
    <span class="bi">▤</span><span>LOGS</span>
  </a>
  <a href="#" onclick="toggleMenu();return false;" id="bottom-menu">
    <span class="bi">☰</span><span>MENU</span>
  </a>
</nav>
<div class="sidebar-backdrop" id="sidebar-backdrop" onclick="toggleMenu(false)"></div>

<div id="toast"></div>

<script>
// ─── State ──────────────────────────────────────────────────────────────────
let currentPage = 'dashboard';
let autoRefresh = false;
let autoRefreshTimer = null;
let statusTimer = null;
let currentLogTab = 'logwebsdr.txt';

const LOG_TAB_TARGETS = {
  'logwebsdr.txt': 'main-log-logwebsdr',
  'spectrumserver.log': 'main-log-spectrumserver',
  'admin.log': 'main-log-admin',
  'rade.log': 'main-log-rade',
  'drm.log': 'main-log-drm',
  'crash.log': 'main-log-crash',
  'autorun.log': 'main-log-autorun',
  'proxy.log': 'main-log-proxy',
};

const LOG_TAB_PANES = {
  'logwebsdr.txt': 'log-pane-logwebsdr',
  'spectrumserver.log': 'log-pane-spectrumserver',
  'admin.log': 'log-pane-admin',
  'rade.log': 'log-pane-rade',
  'drm.log': 'log-pane-drm',
  'crash.log': 'log-pane-crash',
  'autorun.log': 'log-pane-autorun',
  'proxy.log': 'log-pane-proxy',
};

// ─── Page navigation ────────────────────────────────────────────────────────
// Phone: the sidebar is a drawer, opened from the bottom bar's MENU.
function toggleMenu(open) {
  const sb = document.getElementById('sidebar'), bd = document.getElementById('sidebar-backdrop');
  if (!sb) return;
  const want = open === undefined ? !sb.classList.contains('open') : !!open;
  sb.classList.toggle('open', want);
  if (bd) bd.classList.toggle('open', want);
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') toggleMenu(false); });

// Narrow screens show each data-table row as a card. Every cell gets its
// column's name in data-label; the CSS (max-width:600px) does the rest.
// Editing tables (Markers, the spot matrix) keep their grid.
function stackTables(root) {
  (root || document).querySelectorAll('.page table').forEach(t => {
    if (t.classList.contains('markers') || t.id === 'ar-matrix' || t.hasAttribute('data-nostack')) return;
    let head = t.tHead && t.tHead.rows[0];
    if (!head && t.rows.length && [...t.rows[0].cells].every(c => c.tagName === 'TH')) {
      head = t.rows[0];
      head.classList.add('stack-head');
    }
    if (!head) return;
    const names = [];
    [...head.cells].forEach(c => { for (let k = 0; k < (c.colSpan || 1); k++) names.push(c.textContent.trim()); });
    for (const tr of t.tBodies.length ? [...t.tBodies].flatMap(b => [...b.rows]) : [...t.rows]) {
      if (tr === head) continue;
      let col = 0;
      for (const td of tr.cells) {
        if (td.tagName === 'TD' && !td.hasAttribute('data-label')) td.setAttribute('data-label', names[col] || '');
        col += td.colSpan || 1;
      }
    }
    t.classList.add('stack');
  });
}
let _stackQueued = false;
new MutationObserver(() => {
  if (_stackQueued) return;
  _stackQueued = true;
  requestAnimationFrame(() => { _stackQueued = false; stackTables(); });
}).observe(document.documentElement, {childList: true, subtree: true});

function showPage(name, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  el.classList.add('active');
  // Get label from either sidebar nav-item or bottom-nav link
  const labelEl = el.querySelector('span:last-child') || el.querySelector('span.bi + span') || el;
  document.getElementById('page-title').textContent = (labelEl.textContent || name).toUpperCase();
  currentPage = name;
  // Sync bottom nav active state
  let inBar = false;
  document.querySelectorAll('.bottom-nav a[data-page]').forEach(a => {
    a.classList.toggle('active', a.dataset.page === name);
    inBar = inBar || a.dataset.page === name;
  });
  const bm = document.getElementById('bottom-menu');
  if (bm) bm.classList.toggle('active', !inBar);
  document.querySelectorAll('.sidebar .nav-item').forEach(n => {
    if ((n.getAttribute('onclick') || '').indexOf("'" + name + "'") >= 0) n.classList.add('active');
  });
  toggleMenu(false);
  if (name === 'dashboard') { loadDashboard(); }
  if (name === 'config') { loadConfigList(); }
  if (name === 'receivers') { loadReceiversPage(); }
  if (name === 'siteinfo') { loadJsonList(); }
  if (name === 'markers') { loadMarkers(); }
  if (name === 'reporting') { autorunLoad(); }
  if (name === 'logs') { loadCurrentLogTab(); }
  if (name === 'chat') { loadChat(); }
  if (name === 'settings') { loadSettingsPage(); }
  if (name === 'graphs')   { initGraphs(); }
  if (name === 'users')    { loadUsers(); }
  if (name === 'visitors') { loadVisitors(); }
  if (name === 'wfmsg')    { loadWfMsgStatus(); }
  return false;
}

// ─── System health (Dashboard) ───────────────────────────────────────────────
let _healthTick = 0;
const _HL_KIND = {up: 'var(--ok)', restart: 'var(--amber)', down: 'var(--red)', crash: 'var(--red)'};
function _fmtBytes(b) {
  if (b >= 1073741824) return (b / 1073741824).toFixed(1) + ' GB';
  if (b >= 1048576) return (b / 1048576).toFixed(0) + ' MB';
  return Math.round(b / 1024) + ' kB';
}
function _fmtDur(s) {
  if (s == null) return '--';
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return (d ? d + 'd ' : '') + (d || h ? h + 'h ' : '') + m + 'm';
}
function _fmtWhen(t) {
  const d = new Date(t * 1000);
  return d.toLocaleDateString(undefined, {day: '2-digit', month: 'short'}) + ' ' +
         d.toLocaleTimeString(undefined, {hour: '2-digit', minute: '2-digit'});
}
async function loadHealth() {
  let d;
  try { d = await fetch('/admin/api/health').then(r => r.json()); } catch (e) { return; }
  if (!d || !d.ok) return;
  let allUp = true;
  document.getElementById('hl-rx').innerHTML = d.receivers.map(r => {
    if (!r.up) allUp = false;
    const c = r.up ? 'var(--ok)' : 'var(--red)';
    return '<span style="color:' + c + '">●</span> ' + escHtml(r.label) +
      ' <span style="color:var(--text3)">:' + r.port + '</span> — ' +
      (r.up ? 'on air, up ' + _fmtDur(r.uptime_s) : '<b style="color:var(--red)">OFF THE AIR</b>');
  }).join('<br>');
  document.getElementById('hl-rade').innerHTML = (d.rade || []).map(r => {
    const c = {ready: 'var(--ok)', starting: 'var(--amber)', missing: 'var(--text3)'}[r.state] || 'var(--red)';
    const txt = r.state === 'ready' ? 'ready to decode, up ' + _fmtDur(r.uptime_s)
              : r.state === 'off' ? '<b style="color:var(--red)">NOT RUNNING</b>' : escHtml(r.detail);
    return '<span style="color:' + c + '">●</span> ' + escHtml(r.label) + ' — ' + txt;
  }).join('<br>');
  const dot = document.getElementById('hl-dot');
  dot.style.background = allUp ? 'var(--ok)' : 'var(--red)';
  dot.style.boxShadow = '0 0 6px ' + (allUp ? 'var(--ok)' : 'var(--red)');
  const pct = d.disk.total ? Math.round(d.disk.used * 100 / d.disk.total) : 0;
  const fc = pct >= 90 ? 'var(--red)' : pct >= 80 ? 'var(--amber)' : 'var(--text2)';
  document.getElementById('hl-disk').innerHTML =
    '<span style="color:' + fc + '">' + _fmtBytes(d.disk.free) + ' free</span> of ' + _fmtBytes(d.disk.total) + ' (' + pct + '% used)<br>' +
    d.folders.map(f => escHtml(f.path) + ': ' + _fmtBytes(f.bytes)).join('<br>');
  document.getElementById('hl-events').innerHTML = d.events.length
    ? d.events.map(e => '<span style="color:var(--text3)">' + _fmtWhen(e.t) + '</span> ' +
        '<span style="color:' + (_HL_KIND[e.kind] || 'inherit') + '">' + escHtml(e.text) + '</span>').join('<br>')
    : '<span style="color:var(--text3)">none since the panel started</span>';
  const cr = d.crash;
  document.getElementById('hl-crash-when').textContent = cr ? '— ' + cr.label + ', ' + _fmtWhen(cr.mtime) : '';
  document.getElementById('hl-crash').textContent = cr ? cr.lines.join(String.fromCharCode(10)) : 'empty';
}

// ─── Alerts (Settings) ───────────────────────────────────────────────────────
const AL_EVENTS = ['down', 'up', 'restart', 'thermal', 'crash'];
async function loadAlerts() {
  let d;
  try { d = await fetch('/admin/api/alerts').then(r => r.json()); } catch (e) { return; }
  if (!d || !d.ok) return;
  const a = d.alerts;
  AL_EVENTS.forEach(e => { document.getElementById('al-ev-' + e).checked = a.events[e] !== false; });
  document.getElementById('al-tg-on').checked = !!a.telegram.enabled;
  document.getElementById('al-tg-token').value = a.telegram.token || '';
  document.getElementById('al-tg-chat').value = a.telegram.chat_id || '';
  document.getElementById('al-em-on').checked = !!a.email.enabled;
  document.getElementById('al-em-host').value = a.email.host || '';
  document.getElementById('al-em-port').value = a.email.port || 465;
  document.getElementById('al-em-sec').value = a.email.security || 'ssl';
  document.getElementById('al-em-user').value = a.email.user || '';
  document.getElementById('al-em-pass').value = a.email.password || '';
  document.getElementById('al-em-from').value = a.email.from || '';
  document.getElementById('al-em-to').value = a.email.to || '';
}
async function saveAlerts(quiet) {
  const v = id => document.getElementById(id).value.trim();
  const body = {
    events: Object.fromEntries(AL_EVENTS.map(e => [e, document.getElementById('al-ev-' + e).checked])),
    telegram: {enabled: document.getElementById('al-tg-on').checked, token: v('al-tg-token'), chat_id: v('al-tg-chat')},
    email: {enabled: document.getElementById('al-em-on').checked, host: v('al-em-host'), port: v('al-em-port'),
            security: v('al-em-sec'), user: v('al-em-user'), password: document.getElementById('al-em-pass').value,
            from: v('al-em-from'), to: v('al-em-to')}
  };
  const d = await fetch('/admin/api/alerts', {method: 'POST', headers: {'Content-Type': 'application/json'},
                                              body: JSON.stringify(body)}).then(r => r.json());
  if (!quiet || !d.ok) toast(d.msg || 'Saved', d.ok ? 'ok' : 'err');
  if (d.ok) loadAlerts();
  return d.ok;
}
async function testAlerts() {
  const m = document.getElementById('al-msg');
  m.style.color = 'var(--text3)';
  m.textContent = 'Saving and sending...';
  if (!(await saveAlerts(true))) { m.textContent = 'Could not save the settings'; return; }
  const d = await fetch('/admin/api/alerts/test', {method: 'POST'}).then(r => r.json());
  m.textContent = d.msg;
  m.style.color = d.ok ? 'var(--green)' : 'var(--red)';
}

// ─── Backup / restore (Settings) ─────────────────────────────────────────────
async function restoreBackup() {
  const f = document.getElementById('rs-file').files[0];
  const m = document.getElementById('rs-msg');
  if (!f) { toast('Choose a backup zip first', 'err'); return; }
  if (!confirm('Restore the station settings from ' + f.name + '? The current files are copied to admin-backups/ first.')) return;
  const fd = new FormData();
  fd.append('file', f);
  const d = await fetch('/admin/api/restore', {method: 'POST', body: fd}).then(r => r.json());
  m.textContent = d.msg + (d.kept ? ' Previous files: ' + d.kept + '/' : '');
  m.style.color = d.ok ? 'var(--green)' : 'var(--red)';
  toast(d.ok ? 'Settings restored' : d.msg, d.ok ? 'ok' : 'err');
}

// ─── Visitor statistics ──────────────────────────────────────────────────────
function _vsTable(head, rows) {
  return '<table class="top-procs" style="width:100%;"><thead><tr>' + head.map(h => '<th>' + h + '</th>').join('') +
         '</tr></thead><tbody>' + rows.map(r => '<tr>' + r.map(c => '<td>' + c + '</td>').join('') + '</tr>').join('') +
         '</tbody></table>';
}
async function loadVisitors() {
  const days = document.getElementById('vs-days').value;
  document.getElementById('vs-totals').innerHTML = '<div class="card">Loading...</div>';
  let d;
  try { d = await fetch('/admin/api/visitor-stats?days=' + days).then(r => r.json()); } catch (e) { return; }
  if (!d || !d.ok) return;
  const t = d.total;
  const tile = (v, l) => '<div class="card"><div class="stat-val">' + v + '</div><div class="stat-label">' + l + '</div></div>';
  document.getElementById('vs-totals').innerHTML =
    tile(t.visitors, 'VISITORS (addresses)') + tile(t.sessions, 'SESSIONS') +
    tile(t.hours, 'LISTENING HOURS') + tile(t.peak, 'MOST AT THE SAME TIME');
  document.getElementById('vs-days-tbl').innerHTML = _vsTable(['DATE', 'VISITORS', 'SESSIONS', 'HOURS', 'PEAK'],
    d.per_day.slice().reverse().map(x => [x.date, x.visitors, x.sessions, x.hours, x.peak]));
  const mx = Math.max(1, ...d.hours);
  document.getElementById('vs-hours').innerHTML = d.hours.map((n, h) =>
    '<div title="' + String(h).padStart(2, '0') + ':00 UTC — ' + n + ' sessions" style="flex:1;background:var(--amber);opacity:.8;height:' +
    Math.max(2, Math.round(n * 100 / mx)) + '%;"></div>').join('');
  document.getElementById('vs-cc').innerHTML = d.countries.length
    ? d.countries.map(c => '<span style="display:inline-block;min-width:3.2rem;">' + escHtml(c[0]) + '</span>' + c[1]).join('<br>')
    : '<span style="color:var(--text3)">no visitors</span>';
  document.getElementById('vs-dec').innerHTML = (d.decoders || []).length
    ? d.decoders.map(c => '<span style="display:inline-block;min-width:4.5rem;">' + escHtml(c[0]) + '</span>' + c[1]).join('<br>')
    : '<span style="color:var(--text3)">no decoder used</span>';
  document.getElementById('vs-addr').innerHTML = d.addresses.length ? _vsTable(
    ['ADDRESS', 'WHERE', 'SESSIONS', 'AT ONCE', 'HOURS', 'RECEIVERS', 'LAST SEEN', ''],
    d.addresses.map(a => [escHtml(a.ip), escHtml(a.geo || ''), a.sessions,
      '<b style="color:' + (a.peak > 3 ? 'var(--red)' : 'inherit') + '">' + a.peak + '</b>',
      a.hours, escHtml(a.rx.join(', ')), _fmtWhen(a.last),
      '<button class="btn btn-red" style="padding:.1rem .4rem;font-size:.6rem;" onclick="vsBan(' + "'" + escHtml(a.ip) + "'" + ', this)">BAN ▾</button>']))
    : '<span style="color:var(--text3)">no visitors</span>';
}
function vsBan(ip, btn) {
  openBanMenu(btn, function(h) { vsBanFor(ip, h); });
}
async function vsBanFor(ip, hours) {
  if (!confirm('Ban ' + ip + ' for ' + hours + ' hours and disconnect it now?')) return;
  const d = await fetch('/admin/api/ban', {method: 'POST', headers: {'Content-Type': 'application/json'},
                                           body: JSON.stringify({ip: ip, hours: hours})}).then(r => r.json());
  toast(d.msg || (d.ok ? 'Banned' : 'Ban failed'), d.ok ? 'ok' : 'err');
}

// ─── Theme (Settings → Appearance) ───────────────────────────────────────────
function _adminThemeResolve(t) {
  if (t === 'auto') return _adminAutoTheme();
  return ['green', 'amber', 'metal', 'dark', 'light'].indexOf(t) >= 0 ? t : 'green';
}
function _adminThemeSaved() {
  try { return localStorage.getItem('adminTheme') || 'green'; } catch (e) { return 'green'; }
}
function setAdminTheme(t, keep) {
  if (!keep) { try { localStorage.setItem('adminTheme', t); } catch (e) {} }
  var want = _adminThemeResolve(t);
  if (keep && document.documentElement.getAttribute('data-theme') === want) return;
  document.documentElement.setAttribute('data-theme', want);
  ['theme-sel', 'theme-sel-top'].forEach(function (id) { var el = document.getElementById(id); if (el) el.value = t; });
  graphThemeColors();
  if (currentPage === 'graphs' && typeof drawGraphs === 'function') drawGraphs();
}
(function () {
  ['theme-sel', 'theme-sel-top'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.value = _adminThemeSaved();
  });
  // Station position for "auto", from the Site Info locator
  fetch('/admin/api/station-grid').then(function (r) { return r.json(); }).then(function (d) {
    var p = _umapLocator(d && d.grid);
    try {
      if (p) localStorage.setItem('adminThemeLoc', JSON.stringify(p));
      else localStorage.removeItem('adminThemeLoc');
    } catch (e) {}
    if (_adminThemeSaved() === 'auto') setAdminTheme('auto', true);
  }).catch(function () {});
  // sunrise / sunset while the page stays open
  setInterval(function () { if (_adminThemeSaved() === 'auto') setAdminTheme('auto', true); }, 60000);
})();

// ─── Toast ───────────────────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const t = document.getElementById('toast');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = (type==='ok'?'✓ ':'✗ ') + msg;
  t.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ─── Clock ───────────────────────────────────────────────────────────────────
function updateClock() {
  document.getElementById('clock').textContent = new Date().toLocaleTimeString('en-GB');
}
setInterval(updateClock, 1000); updateClock();

// ─── Status polling ──────────────────────────────────────────────────────────
async function updateStatus() {
  try {
    const r = await fetch('/admin/api/status');
    const d = await r.json();
    const pill = document.getElementById('sdr-status');
    const dot  = pill ? pill.querySelector('.status-dot') : null;
    if (pill && dot) {
      if (d.process && d.process.running) {
        pill.className = 'status-pill online'; dot.className = 'status-dot online';
        pill.querySelector('span').textContent = 'ONLINE';
        document.getElementById('stat-status').textContent = 'RUNNING';
        document.getElementById('stat-status').style.color = 'var(--green)';
      } else {
        pill.className = 'status-pill offline'; dot.className = 'status-dot offline';
        pill.querySelector('span').textContent = 'OFFLINE';
        document.getElementById('stat-status').textContent = 'STOPPED';
        document.getElementById('stat-status').style.color = 'var(--red)';
      }
    }
    const pidEl = document.getElementById('stat-pid');
    if (pidEl && d.process) pidEl.textContent = 'PID: ' + (d.process.pid || '--');
    const s = d.system;
    if (s && s.cpu !== undefined && s.cpu !== 'N/A') {
      document.getElementById('stat-cpu').textContent  = s.cpu + '%';
      setBar('bar-cpu', s.cpu);
      const memEl = document.getElementById('stat-mem');
      memEl.textContent = s.mem_used + ' / ' + s.mem_total + ' GB';
      memEl.style.color = s.mem_pct > 80 ? 'var(--stat-bad)' : '';
      setBar('bar-mem', s.mem_pct);
      document.getElementById('stat-disk').textContent = s.disk_used + ' / ' + s.disk_total + ' GB';
      setBar('bar-disk', s.disk_pct);
      const tempEl = document.getElementById('stat-temp');
      if (tempEl) {
        if (s.temp !== null && s.temp !== undefined) {
          tempEl.textContent = s.temp + '\u00b0C';
          tempEl.style.color = s.temp >= 80 ? 'var(--stat-bad)'
                             : s.temp >= 70 ? 'var(--stat-warn)' : '';
          setBar('bar-temp', Math.min(100, Math.max(0, (s.temp - 20) / 80 * 100)));
        } else { tempEl.textContent = 'N/A'; tempEl.style.color = ''; }
      }
    }
    const tbody = document.getElementById('top-procs-tbody');
    if (tbody) {
      if (d.top_procs && d.top_procs.length > 0) {
        tbody.innerHTML = '';
        d.top_procs.forEach(proc => {
          const cc = proc.cpu > 80 ? 'cpu-hi' : proc.cpu > 50 ? 'cpu-med' : 'cpu-ok';
          const tr = document.createElement('tr');
          tr.innerHTML =
            `<td style="color:var(--text3)">${proc.pid}</td>` +
            `<td style="color:var(--text)">${proc.name}</td>` +
            `<td style="color:var(--text3)">${proc.user||''}</td>` +
            `<td class="${cc}">${proc.cpu}%</td>` +
            `<td class="mem-col">${proc.mem}%</td>`;
          tbody.appendChild(tr);
        });
      } else {
        tbody.innerHTML = '<tr><td colspan="5" style="color:var(--text3);text-align:center;">No data</td></tr>';
      }
    }
  } catch(e) { console.error('updateStatus:', e); }
}

// ─── Thermal guard ───────────────────────────────────────────────────────────
async function updateThermal() {
  try {
    const t = await fetch('/admin/api/thermal').then(r => r.json());
    const card = document.getElementById('thermal-card');
    const sub  = document.getElementById('stat-temp-guard');
    if (!t.available) {
      if (card) card.style.display = 'none';
      if (sub) sub.textContent = 'GUARD: unavailable';
      return;
    }
    if (card) card.style.display = '';
    const th = t.thresholds || {};
    let state, color;
    if (!t.enabled)      { state = 'DISABLED'; color = 'var(--text3)'; }
    else if (t.locked)   { state = 'LOCKED OUT'; color = 'var(--red)'; }
    else if (!t.armed)   { state = 'NOT ARMED'; color = 'var(--amber)'; }
    else if (t.stage === 'stopped')  { state = 'STOP LEVEL'; color = 'var(--red)'; }
    else if (t.stage === 'throttle') { state = 'THROTTLING'; color = 'var(--amber)'; }
    else if (t.stage === 'warn')     { state = 'WARM'; color = 'var(--amber)'; }
    else                 { state = 'ARMED'; color = 'var(--green)'; }
    const set = (id, txt) => { const e = document.getElementById(id); if (e) e.textContent = txt; };
    set('tg-state', state);
    const st = document.getElementById('tg-state'); if (st) st.style.color = color;
    const dot = document.getElementById('tg-dot');
    if (dot) { dot.style.background = color; dot.style.boxShadow = '0 0 6px ' + color; }
    set('tg-mode', t.mode + (t.mode === 'log' ? ' (no action)' : ''));
    set('tg-stop',   th.stop   !== undefined ? th.stop + '°C' : '--');
    set('tg-resume', th.resume !== undefined ? th.resume + '°C' : '--');
    set('tg-sensor', (t.sensor || 'no sensor') +
        (t.crit ? '  crit ' + t.crit + '°C' : '') +
        (t.throttle_supported ? '' : '  cpufreq: n/a'));
    let reason = t.reason || '';
    if (t.test_temp !== null && t.test_temp !== undefined)
      reason += '   [TEST MODE: reading forced to ' + t.test_temp + '°C]';
    if (t.giveup) reason += '   [rate limit hit: auto-restart disabled]';
    set('tg-reason', reason);
    set('tg-last', t.last_event || '');
    if (sub) sub.textContent = 'GUARD: ' + state +
      (th.stop !== undefined && t.enabled ? ' · stop ' + th.stop + '°C' : '');
  } catch(e) { console.error('updateThermal:', e); }
}

async function thermalReset() {
  if (!confirm('Clear the thermal lockout and rate limit?' +
               String.fromCharCode(10) +
               'If the CPU is still too hot the guard will simply stop the server again.')) return;
  const d = await fetch('/admin/api/thermal', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({action: 'reset'})
  }).then(r => r.json());
  toast(d.msg || (d.ok ? 'Cleared' : 'Failed'), d.ok ? '' : 'err');
  updateThermal();
}

// ─── DRM decoder ─────────────────────────────────────────────────────────────
async function updateDrm() {
  try {
    const d = await fetch('/admin/api/drm').then(r => r.json());
    const card = document.getElementById('drm-card');
    if (!card) return;
    // Not installed and not running: nothing to show on this station.
    if (!d.installed && !d.running) { card.style.display = 'none'; return; }
    card.style.display = '';
    const set = (id, txt) => { const e = document.getElementById(id); if (e) e.textContent = txt; };
    const state = !d.running ? 'STOPPED' : (d.enabled ? 'RUNNING' : 'SWITCHED OFF');
    const color = !d.running ? 'var(--red)' : (d.enabled ? 'var(--green)' : 'var(--amber)');
    set('drm-state', state);
    const st = document.getElementById('drm-state'); if (st) st.style.color = color;
    const dot = document.getElementById('drm-dot');
    if (dot) { dot.style.background = color; dot.style.boxShadow = '0 0 6px ' + color; }
    const sess = d.sessions || [];
    set('drm-used', d.running ? (sess.length + ' / ' + d.max_sessions) : '--');
    set('drm-perip', d.per_ip ? String(d.per_ip) : '--');
    set('drm-port', d.port ? String(d.port) : '--');
    // Who is on which frequency, and what their decoder is doing.
    const list = document.getElementById('drm-sessions');
    if (list) {
      list.textContent = '';
      if (d.running && !sess.length) list.textContent = 'No one is listening to DRM.';
      for (const x of sess) {
        const row = document.createElement('div');
        const mins = Math.max(0, Math.round((Date.now() - x.since) / 60000));
        const what = x.decoding
          ? 'decoding ' + (x.service || '?') + (x.codec ? ' (' + x.codec + ')' : '') +
            (x.wmer !== null && x.wmer !== undefined ? ', WMER ' + Number(x.wmer).toFixed(1) + ' dB' : '')
          : (x.acquired ? 'syncing' : 'searching');
        row.textContent = (x.name ? x.name + ' \u00b7 ' : '') + x.ip + ' \u00b7 ' +
          (x.freq / 1000).toFixed(1) + ' kHz' + (x.rx ? ' (' + x.rx + ')' : '') +
          ' \u00b7 ' + what + ' \u00b7 ' + mins + ' min';
        list.appendChild(row);
      }
    }
    // The settings follow the helper, unless the sysop is changing them.
    const en = document.getElementById('drm-enabled'), mx = document.getElementById('drm-max');
    if (en && !en.dataset.dirty) en.checked = !!d.enabled;
    if (mx && !mx.dataset.dirty && document.activeElement !== mx) mx.value = d.max_sessions || 5;
    set('drm-reason', d.running
      ? (d.env_override ? 'DRM_MAX_SESSIONS or DRM_PER_IP is set in the environment of the start script and wins over these settings.' : '')
      : (d.reason || ''));
  } catch (e) { console.error('updateDrm:', e); }
}

async function saveDrm() {
  const en = document.getElementById('drm-enabled'), mx = document.getElementById('drm-max');
  const d = await fetch('/admin/api/drm', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({enabled: en.checked, max_sessions: parseInt(mx.value, 10)})
  }).then(r => r.json()).catch(() => ({ok: false, msg: 'request failed'}));
  delete en.dataset.dirty; delete mx.dataset.dirty;
  toast(d.msg || (d.ok ? 'Saved' : 'Failed'), d.ok ? '' : 'err');
  updateDrm();
}

// ─── WebSDR diversity relay ──────────────────────────────────────────────────
async function updateRelay() {
  try {
    const d = await fetch('/admin/api/websdr-relay').then(r => r.json());
    const card = document.getElementById('relay-card');
    if (!card) return;
    // Not set up at all: say nothing rather than show a permanently red card
    // on the many receivers that will never use this.
    if (!d.configured) { card.style.display = 'none'; return; }
    card.style.display = '';

    const set = (id, txt) => { const e = document.getElementById(id); if (e) e.textContent = txt; };
    const state = d.running ? 'RUNNING' : 'STOPPED';
    const color = d.running ? 'var(--green)' : 'var(--red)';
    set('rl-state', state);
    const st = document.getElementById('rl-state'); if (st) st.style.color = color;
    const dot = document.getElementById('rl-dot');
    if (dot) { dot.style.background = color; dot.style.boxShadow = '0 0 6px ' + color; }

    set('rl-port', d.port !== undefined ? String(d.port) : '--');
    set('rl-cap', (d.max_per_host !== undefined && d.max_per_host !== null)
                  ? d.max_per_host + ' / site' : '--');

    const sess = (d.sessions && d.sessions.hosts) ? d.sessions.hosts : {};
    const total = (d.sessions && d.sessions.total !== undefined) ? d.sessions.total : 0;
    set('rl-sessions', d.running ? (total + (d.max_total ? ' / ' + d.max_total : '')) : '--');

    // Which WebSDRs this station is currently relaying to, and how many
    // listeners on each. Empty is the normal resting state.
    const names = Object.keys(sess);
    const hosts = document.getElementById('rl-hosts');
    if (hosts) {
      if (!d.running) hosts.textContent = '';
      else if (!names.length) hosts.textContent = 'No active sessions.';
      else hosts.textContent = names.map(h => h + '  \u00d7' + sess[h]).join('     ');
    }

    // The User-Agent is what WebSDR operators see. Showing it here is the
    // quickest way to notice it still says "your-receiver.example".
    set('rl-ua', d.user_agent || d.site || '');
    set('rl-reason', d.running ? '' : (d.reason || ''));
  } catch(e) { console.error('updateRelay:', e); }
}

function setBar(id, pct) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.width = pct + '%';
  el.className = 'bar-fill' + (pct>80?' danger':pct>50?' warn':'');
}

statusTimer = setInterval(updateStatus, 3000);
updateStatus();
setInterval(updateThermal, 5000);
updateThermal();
setInterval(updateRelay, 10000);
updateRelay();

// ─── Receive diversity: who combines with which receiver ─────────────────────
// Each listener's page reports its partner (type + host) on /audio; the
// receivers give it only on the loopback /~~users, merged by sdr-users.
var DV_TYPES = {phantom: 'PhantomSDR+', kiwi: 'KiwiSDR', uber: 'UberSDR', websdr: 'WebSDR'};
async function updateDiversity() {
  var list = document.getElementById('dv-list');
  if (!list) return;
  try {
    var d = await fetch('/admin/api/sdr-users', {cache: 'no-store'}).then(function(r){ return r.json(); });
    var rows = (d.users || []).filter(function(u){ return u.diversity; });
    var dot = document.getElementById('dv-dot');
    var on = rows.length > 0;
    if (dot) {
      dot.style.background = on ? 'var(--green)' : 'var(--text3)';
      dot.style.boxShadow = on ? '0 0 6px var(--green)' : 'none';
    }
    if (!d.ok) { list.textContent = d.error || 'no receiver answered'; return; }
    if (!on) { list.textContent = 'Nobody is using receive diversity.'; return; }
    var multi = !!d.multi;
    var html = '<table style="width:100%;border-collapse:collapse;">';
    rows.forEach(function(u) {
      var sp = u.diversity.indexOf(' ');
      var type = sp > 0 ? u.diversity.slice(0, sp) : u.diversity;
      var host = sp > 0 ? u.diversity.slice(sp + 1) : '';
      var who = (u.name ? u.name + ' - ' : '') + (u.geo || u.ip || '');
      var freq = Number(u.freq_khz || 0).toFixed(2) + ' kHz ' + String(u.mode || '').toUpperCase();
      html += '<tr>' +
        (multi ? '<td style="padding:.15rem .4rem;color:var(--text3);">' + escHtml(String(u.rx || '')) + '</td>' : '') +
        '<td style="padding:.15rem .4rem;">' + escHtml(who) + '</td>' +
        '<td style="padding:.15rem .4rem;color:var(--text);">' + escHtml(freq) + '</td>' +
        '<td style="padding:.15rem .4rem;color:var(--amber);">' + escHtml(DV_TYPES[type] || type) + '</td>' +
        '<td style="padding:.15rem .4rem;">' + escHtml(host) + '</td>' +
        '</tr>';
    });
    list.innerHTML = html + '</table>';
  } catch(e) { console.error('updateDiversity:', e); }
}
setInterval(updateDiversity, 10000);
updateDiversity();
setInterval(updateDrm, 10000);
updateDrm();

// ─── Dashboard & Terminal ────────────────────────────────────────────────────
let _dashLogTimer = null;
let _termCwd  = '';
let _termHist = [];
let _termIdx  = -1;

async function loadDashboard() {
  updateStatus();
  updateThermal();
  loadHealth();
  loadLogs('dash-log', 'logwebsdr.txt');
  if (_dashLogTimer) clearInterval(_dashLogTimer);
  _dashLogTimer = setInterval(() => {
    if (currentPage === 'dashboard') {
      loadLogs('dash-log', 'logwebsdr.txt');
      if ((++_healthTick % 2) === 0) loadHealth();
    }
    else { clearInterval(_dashLogTimer); _dashLogTimer = null; }
  }, 5000);
  // Set terminal cwd to sdr base dir
  if (!_termCwd) {
    try {
      const cfg = await fetch('/admin/api/settings').then(r => r.json());
      _termCwd = cfg.sdr_base_dir || '.';
    } catch(e) { _termCwd = '.'; }
    termUpdatePrompt();
  }
}

function termUpdatePrompt() {
  const el = document.getElementById('term-cwd');
  if (el && _termCwd) {
    const parts = _termCwd.replace(/\\/+$/, '').split('/');
    el.textContent = parts.slice(-2).join('/') || _termCwd;
  }
}

function termPrint(text, cls) {
  const out = document.getElementById('term-output');
  if (!out) return;
  if (text === '__CLEAR__') { out.innerHTML = ''; return; }
  const div = document.createElement('div');
  if (cls === 'cmd') {
    div.style.cssText = 'color:var(--amber);margin-top:.3rem;font-weight:bold;';
  } else if (cls === 'err') {
    div.style.cssText = 'color:#ff6666;';
  } else {
    div.style.cssText = 'color:var(--text);';
  }
  div.textContent = text;
  out.appendChild(div);
  out.scrollTop = out.scrollHeight;
}

function termClear() {
  const out = document.getElementById('term-output');
  if (out) out.innerHTML = '';
}

async function termRun() {
  const inp = document.getElementById('term-input');
  if (!inp) return;
  const cmd = inp.value.trim();
  if (!cmd) return;
  inp.value = '';
  _termHist.unshift(cmd);
  if (_termHist.length > 100) _termHist.pop();
  _termIdx = -1;
  termPrint('$ ' + cmd, 'cmd');
  try {
    const r = await fetch('/admin/api/terminal/exec', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({cmd: cmd, cwd: _termCwd})
    });
    if (!r.ok) { termPrint('HTTP error: ' + r.status, 'err'); return; }
    const d = await r.json();
    if (d.cwd && d.cwd !== _termCwd) {
      _termCwd = d.cwd;
      termUpdatePrompt();
    }
    if (d.output) termPrint(d.output, d.ok ? '' : 'err');
  } catch(ex) {
    termPrint('Network error: ' + ex.message, 'err');
  }
}

function termKey(e) {
  const inp = document.getElementById('term-input');
  if (!inp) return;
  if (e.key === 'Enter') {
    e.preventDefault(); termRun();
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    if (_termIdx < _termHist.length - 1) { _termIdx++; inp.value = _termHist[_termIdx]; }
  } else if (e.key === 'ArrowDown') {
    e.preventDefault();
    if (_termIdx > 0) { _termIdx--; inp.value = _termHist[_termIdx]; }
    else { _termIdx = -1; inp.value = ''; }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const out = document.getElementById('term-output');
  if (out) out.addEventListener('click', () => {
    const inp = document.getElementById('term-input');
    if (inp) inp.focus();
  });
});


// ─── File Editor ─────────────────────────────────────────────────────────────
let configFiles = {};

async function loadConfigList(notify) {
  const sel = document.getElementById('config-file-sel');
  const prev = sel.value;                       // preserve current selection across a rescan
  const r = await fetch('/admin/api/editable-files');
  const nextFiles = await r.json();
  if (notify) {
    const before = Object.keys(configFiles);
    const after  = Object.keys(nextFiles);
    const added   = after.filter(f => !before.includes(f)).length;
    const removed = before.filter(f => !after.includes(f)).length;
    toast('Rescanned: ' + after.length + ' files (+' + added + ' / -' + removed + ')');
  }
  configFiles = nextFiles;
  sel.innerHTML = '<option value="">-- Select file --</option>';
  // Group by extension
  const groups = {};
  Object.keys(configFiles).forEach(rel => {
    const ext = rel.split('.').pop().toLowerCase();
    if (!groups[ext]) groups[ext] = [];
    groups[ext].push(rel);
  });
  const order = ['toml','sh','json','html','cpp','h','txt'];
  [...order, ...Object.keys(groups).filter(e => !order.includes(e))].forEach(ext => {
    if (!groups[ext]) return;
    const og = document.createElement('optgroup');
    og.label = '.' + ext.toUpperCase();
    groups[ext].forEach(rel => {
      const o = document.createElement('option');
      o.value = rel; o.textContent = rel;
      og.appendChild(o);  // ← append to optgroup, not directly to select
    });
    sel.appendChild(og);
  });
  if (prev && configFiles[prev]) sel.value = prev;   // keep selection if the file still exists
}

async function loadConfigFile() {
  const sel = document.getElementById('config-file-sel');
  const name = sel.value;
  if (!name) return;
  document.getElementById('config-filepath').textContent = configFiles[name] || name;
  const r = await fetch('/admin/api/read-file?path=' + encodeURIComponent(configFiles[name]));
  const d = await r.json();
  document.getElementById('config-editor').value = d.content || '';
}

async function saveConfigFile() {
  const sel = document.getElementById('config-file-sel');
  const name = sel.value;
  const content = document.getElementById('config-editor').value;
  const r = await fetch('/admin/api/write-file', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({path: configFiles[name], content})
  });
  const d = await r.json();
  const msg = document.getElementById('config-save-msg');
  if (d.ok) { toast('Config saved'); msg.textContent = '✓ Saved at ' + new Date().toLocaleTimeString(); msg.style.color = 'var(--green)'; }
  else { toast(d.msg, 'err'); msg.textContent = '✗ ' + d.msg; msg.style.color = 'var(--red)'; }
}

// ─── JSON / Site Info Editor ─────────────────────────────────────────────────
let jsonFiles = {};
let currentJsonData = {};
let currentJsonPath = '';

async function loadJsonList() {
  const r = await fetch('/admin/api/json-files');
  jsonFiles = await r.json();
  const sel = document.getElementById('json-file-sel');
  sel.innerHTML = '';
  Object.keys(jsonFiles).forEach(name => {
    const o = document.createElement('option');
    o.value = name; o.textContent = name;
    sel.appendChild(o);
  });
  if (Object.keys(jsonFiles).length > 0) loadJsonFile();
}

async function loadJsonFile() {
  const sel = document.getElementById('json-file-sel');
  const name = sel.value;
  if (!name) return;
  currentJsonPath = jsonFiles[name];
  const r = await fetch('/admin/api/read-file?path=' + encodeURIComponent(currentJsonPath));
  const d = await r.json();
  const raw = d.content || '{}';
  document.getElementById('json-raw-editor').value = raw;
  try {
    currentJsonData = JSON.parse(raw);
    renderJsonForm(currentJsonData);
  } catch(e) {
    document.getElementById('json-form-fields').innerHTML = '<p style="color:var(--red)">Invalid JSON: ' + e.message + '</p>';
  }
}

function renderJsonForm(data) {
  const container = document.getElementById('json-form-fields');
  container.innerHTML = '';
  Object.entries(data).forEach(([key, val]) => {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex;flex-direction:column;gap:.2rem;';
    const label = document.createElement('label');
    label.style.cssText = 'font-size:.6rem;color:var(--text3);letter-spacing:.1em;';
    label.textContent = key.toUpperCase();

    let input;
    if (typeof val === 'boolean') {
      input = document.createElement('select');
      input.className = 'script-select';
      input.style.marginBottom = '0';
      input.innerHTML = `<option value="true" ${val?'selected':''}>true</option><option value="false" ${!val?'selected':''}>false</option>`;
    } else if (typeof val === 'number') {
      input = document.createElement('input');
      input.type = 'number'; input.value = val;
      input.style.width = '100%';
    } else if (typeof val === 'object') {
      input = document.createElement('textarea');
      input.className = 'code';
      input.style.minHeight = '60px';
      input.style.width = '100%';
      input.value = JSON.stringify(val, null, 2);
    } else {
      input = document.createElement('input');
      input.type = 'text'; input.value = val;
      input.style.width = '100%';
    }
    input.dataset.key = key;
    wrap.appendChild(label);
    wrap.appendChild(input);
    container.appendChild(wrap);
  });
}

function getJsonFormData() {
  const container = document.getElementById('json-form-fields');
  const result = {};
  container.querySelectorAll('[data-key]').forEach(el => {
    const key = el.dataset.key;
    const orig = currentJsonData[key];
    if (typeof orig === 'boolean') result[key] = el.value === 'true';
    else if (typeof orig === 'number') result[key] = Number(el.value);
    else if (typeof orig === 'object') { try { result[key] = JSON.parse(el.value); } catch { result[key] = el.value; } }
    else result[key] = el.value;
  });
  return result;
}

function switchJsonTab(tab, el) {
  document.querySelectorAll('#page-siteinfo .tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('#page-siteinfo .tab-pane').forEach(p => p.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('json-' + tab + '-pane').classList.add('active');
  if (tab === 'raw') {
    // Sync form → raw
    try {
      const d = getJsonFormData();
      document.getElementById('json-raw-editor').value = JSON.stringify(d, null, 2);
    } catch(e) {}
  }
}

async function saveJsonForm() {
  const data = getJsonFormData();
  const content = JSON.stringify(data, null, 2);
  const r = await fetch('/admin/api/write-file', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({path: currentJsonPath, content})
  });
  const d = await r.json();
  const msg = document.getElementById('json-save-msg');
  if (d.ok) { toast('JSON saved'); msg.textContent = '✓ Saved'; msg.style.color = 'var(--green)'; }
  else { toast(d.msg, 'err'); msg.textContent = '✗ ' + d.msg; msg.style.color = 'var(--red)'; }
}

async function saveJsonRaw() {
  const content = document.getElementById('json-raw-editor').value;
  try { JSON.parse(content); } catch(e) { toast('Invalid JSON: ' + e.message, 'err'); return; }
  const r = await fetch('/admin/api/write-file', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({path: currentJsonPath, content})
  });
  const d = await r.json();
  if (d.ok) toast('JSON saved'); else toast(d.msg, 'err');
}

// ─── Markers Editor ──────────────────────────────────────────────────────────
let markersData = [];
let markersPath = '';

async function loadMarkers() {
  const r = await fetch('/admin/api/markers');
  const d = await r.json();
  markersData = d.data || [];
  markersPath = d.path || '';
  renderMarkersTable();
}

function renderMarkersTable() {
  const tbody = document.getElementById('markers-tbody');
  tbody.innerHTML = '';
  markersData.forEach((m, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input type="text" value="${m.frequency||m.freq||''}" data-i="${i}" data-f="frequency"></td>
      <td><input type="text" value="${m.name||m.label||''}" data-i="${i}" data-f="name"></td>
      <td><input type="text" value="${m.mode||m.modulation||''}" data-i="${i}" data-f="mode"></td>
      <td><input type="text" value="${m.color||''}" data-i="${i}" data-f="color" style="width:80px"></td>
      <td><button class="btn btn-red" style="padding:.2rem .5rem;font-size:.7rem;" onclick="deleteMarker(${i})">✕</button></td>
    `;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll('input').forEach(inp => {
    inp.addEventListener('input', () => {
      const i = parseInt(inp.dataset.i);
      const f = inp.dataset.f;
      if (!markersData[i]) return;
      markersData[i][f] = f === 'frequency' ? (isNaN(Number(inp.value)) ? inp.value : Number(inp.value)) : inp.value;
      document.getElementById('markers-raw').value = JSON.stringify(markersData, null, 2);
    });
  });
  document.getElementById('markers-raw').value = JSON.stringify(markersData, null, 2);
}

function addMarker() {
  markersData.push({frequency: 0, name: "New Marker", mode: "AM", color: "#00ff41"});
  renderMarkersTable();
}

function deleteMarker(i) {
  markersData.splice(i, 1);
  renderMarkersTable();
}

async function saveMarkers() {
  const r = await fetch('/admin/api/markers', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({data: markersData})
  });
  const d = await r.json();
  const msg = document.getElementById('markers-save-msg');
  if (d.ok) { toast('Markers saved'); msg.textContent = '✓ Saved'; msg.style.color = 'var(--green)'; }
  else { toast(d.msg, 'err'); msg.textContent = '✗ ' + d.msg; msg.style.color = 'var(--red)'; }
}

// ─── Spot Reporting (autorun) ─────────────────────────────────────────────────
let AR_BANDS = [], AR_MODES = {}, AR_POLL = null;

async function autorunLoad() {
  try {
    const d = await fetch('/admin/api/autorun/config').then(r => r.json());
    AR_BANDS = d.bands; AR_MODES = d.modes;
    const c = d.config;
    document.getElementById('ar-call').value = c.identity.callsign || '';
    document.getElementById('ar-grid').value = c.identity.grid || '';
    document.getElementById('ar-psk').checked = !!c.reporting.pskreporter;
    document.getElementById('ar-wspr').checked = !!c.reporting.wsprnet;
    document.getElementById('ar-max').value = c.maxSlots || 12;
    const enabled = new Set((c.slots || []).filter(s => s.enabled).map(s => s.mode + ':' + s.band));
    autorunBuildMatrix(enabled);
    autorunPoll();
    if (!AR_POLL) AR_POLL = setInterval(autorunPoll, 5000);
  } catch (e) { toast('load failed: ' + e.message, 'err'); }
}

function autorunBuildMatrix(enabledSet) {
  const modes = Object.keys(AR_MODES);
  // The badge is filled by autorunPoll; it is empty (and hidden) until the
  // daemon reports a count, so a rebuild never shows a stale number.
  let h = '<thead><tr><th>BAND</th>' + modes.map(m =>
    '<th>' + m.toUpperCase() + '<span class="ar-hdr-badge" id="ar-hdr-' + m + '"></span></th>').join('') +
    '</tr></thead><tbody>';
  for (const band of AR_BANDS) {
    h += '<tr><td style="color:var(--amber)">' + band + '</td>';
    for (const m of modes) {
      const key = m + ':' + band;
      if (AR_MODES[m].includes(band)) {
        h += '<td style="white-space:nowrap;"><input type="checkbox" data-key="' + key +
             '" onchange="autorunCount()"' + (enabledSet.has(key) ? ' checked' : '') + '>' +
             '<span class="ar-slot-tot" data-slot="' + key + '"></span></td>';
      } else {
        h += '<td><span style="color:var(--text3)">&#8211;</span></td>';
      }
    }
    h += '</tr>';
  }
  document.getElementById('ar-matrix').innerHTML = h + '</tbody>';
  autorunCount();
}

function autorunGatherSlots() {
  const slots = [];
  document.querySelectorAll('#ar-matrix input[type=checkbox]').forEach(cb => {
    const [mode, band] = cb.dataset.key.split(':');
    slots.push({ band, mode, enabled: cb.checked });
  });
  return slots;
}

function autorunCount() {
  const n = document.querySelectorAll('#ar-matrix input:checked').length;
  const max = parseInt(document.getElementById('ar-max').value || '12', 10);
  const el = document.getElementById('ar-count');
  el.textContent = n + ' slot(s) enabled (cap ' + max + ')';
  el.style.color = n > max ? 'var(--red)' : 'var(--text3)';
}

async function autorunSave() {
  const body = {
    identity: { callsign: document.getElementById('ar-call').value.trim(), grid: document.getElementById('ar-grid').value.trim() },
    reporting: { pskreporter: document.getElementById('ar-psk').checked, wsprnet: document.getElementById('ar-wspr').checked },
    maxSlots: parseInt(document.getElementById('ar-max').value || '12', 10),
    slots: autorunGatherSlots(),
  };
  const d = await fetch('/admin/api/autorun/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(r => r.json());
  toast(d.ok ? 'Config saved' : d.msg, d.ok ? 'ok' : 'err');
  document.getElementById('ar-msg').textContent = d.ok ? '✓ saved' : '✗ ' + d.msg;
  return d.ok;
}

async function autorunStart() {
  if (!(await autorunSave())) return;
  const d = await fetch('/admin/api/autorun/start', { method: 'POST' }).then(r => r.json());
  toast(d.msg, d.ok ? 'ok' : 'err'); setTimeout(autorunPoll, 800);
}
async function autorunStop() {
  const d = await fetch('/admin/api/autorun/stop', { method: 'POST' }).then(r => r.json());
  toast(d.msg, d.ok ? 'ok' : 'err'); setTimeout(autorunPoll, 500);
}
async function autorunFreeAll() {
  // Spell out the counter loss: the all-time totals are the one thing here
  // that a restart cannot bring back.
  if (!confirm('Clear all enabled bands/modes, stop the daemon, and erase the ' +
               'all-time spot counters next to every band?\\n\\n' +
               'The counters cannot be recovered.')) return;
  document.querySelectorAll('#ar-matrix input:checked').forEach(cb => cb.checked = false);
  document.getElementById('ar-psk').checked = false;
  document.getElementById('ar-wspr').checked = false;
  autorunCount();
  await autorunSave();
  // The endpoint stops the daemon itself and waits for it to exit before
  // deleting, because the daemon rewrites its totals on the way out.
  const d = await fetch('/admin/api/autorun/totals/reset', { method: 'POST' })
                    .then(r => r.json()).catch(e => ({ok: false, msg: e.message}));
  toast(d.ok ? 'Slots freed, counters cleared' : d.msg, d.ok ? 'ok' : 'err');
  autorunRenderSlotTotals({});          // clear the numbers without waiting for a poll
  setTimeout(autorunPoll, 600);
}

async function autorunPoll() {
  try {
    const d = await fetch('/admin/api/autorun/status').then(r => r.json());
    const dot = document.getElementById('ar-dot');
    if (!dot) return;
    dot.style.background = d.running ? 'var(--green)' : 'var(--text3)';
    document.getElementById('ar-state').textContent = d.running ? ('RUNNING (PID ' + (d.pids || []).join(',') + ')') : 'STOPPED';
    const s = d.status || {}, cn = s.counts || {}, rep = s.reporting || {};
    const fmt = t => t ? new Date(t * 1000).toLocaleTimeString('en-GB') : '—';
    const pending = (q, sent) => Math.max(0, (q || 0) - (sent || 0));
    document.getElementById('ar-status').innerHTML =
      'Reporting: PSK Reporter <b>' + (rep.pskreporter ? 'ON' : 'off') + '</b> &#183; wsprnet <b>' + (rep.wsprnet ? 'ON' : 'off') + '</b>' + (s.dryRun ? ' &#183; <span style="color:var(--amber)">DRY RUN</span>' : '') + '<br>' +
      'Decodes: ' + (cn.decodes || 0) + '<br>' +
      'PSK Reporter: <b>' + (cn.pskSent || 0) + '</b> sent, ' + pending(cn.pskQueued, cn.pskSent) + ' pending <span style="color:var(--text3)">(uploads every 5 min)</span><br>' +
      'wsprnet: <b>' + (cn.wsprSent || 0) + '</b> sent, ' + pending(cn.wsprQueued, cn.wsprSent) + ' pending <span style="color:var(--text3)">(every 2 min)</span><br>' +
      'Last decode: ' + fmt(s.lastDecodeAt) + ' &#183; Last upload: ' + fmt(s.lastUploadAt) + ' ' + (s.lastUploadMsg || '');
    autorunRenderSpots(s, d.running, rep);
    autorunRenderSlotTotals(d.totals || {});
  } catch (e) { /* ignore */ }
}

// All-time spots per band+mode, written next to that slot's checkbox.
// These come from autorun-totals.json, which the daemon keeps across restarts,
// so unlike the tiles above they are NOT reset by Stop/Start.
function autorunRenderSlotTotals(totals) {
  var any = false;
  document.querySelectorAll('.ar-slot-tot').forEach(function(el) {
    var t = totals[el.dataset.slot];
    var up = t ? (t.uploaded || 0) : 0;
    var dec = t ? (t.decodes || 0) : 0;
    // No entry at all = the daemon has never run this slot, so nothing to say.
    // An entry that is still all zeros DOES get a 0: the daemon seeds every
    // enabled slot at startup, and a blank cell there reads as a broken
    // counter rather than as "nothing heard yet". WSPR sits at zero for
    // minutes after a start — its cycle is 2 minutes — while FT8 is already
    // in the hundreds.
    if (!t) { el.textContent = ''; el.title = ''; return; }
    any = true;
    if (!up && !dec) {
      el.textContent = '0';
      el.classList.add('none');
      el.title = 'Enabled, nothing decoded yet — WSPR in particular can take ' +
                 'several minutes, since it transmits on a 2-minute cycle.';
      return;
    }
    // Uploaded is the headline; decodes explain a slot that hears plenty but
    // uploads nothing because its destination is off.
    el.textContent = up ? String(up) : '·' + dec;
    el.classList.toggle('none', !up);
    el.title = up + ' spots uploaded, ' + dec + ' decodes — all time for this band and mode' +
               (t.lastSpotAt ? '\\nlast upload ' + new Date(t.lastSpotAt * 1000).toLocaleString('en-GB') : '');
  });
  var note = document.getElementById('ar-slot-note');
  if (note) note.style.display = any ? 'block' : 'none';
}

// Fill the per-decoder tiles and the badges in the bands/modes header.
function autorunRenderSpots(s, running, rep) {
  const bm = (s && s.byMode) || {};
  // Which destination carries each decoder — a mode whose destination is off
  // decodes but never uploads, and saying "0" without that context reads as a
  // fault rather than a setting.
  const dest = {ft8: 'pskreporter', ft4: 'pskreporter', js8: 'pskreporter', wspr: 'wsprnet'};
  ['ft8', 'ft4', 'js8', 'wspr'].forEach(function(m) {
    const t   = bm[m] || null;
    const el  = document.getElementById('ar-up-' + m);
    const sub = document.getElementById('ar-sub-' + m);
    const hdr = document.getElementById('ar-hdr-' + m);
    if (!el) return;
    const up      = t ? (t.uploaded || 0) : 0;
    const dec     = t ? (t.decodes  || 0) : 0;
    const pending = t ? Math.max(0, (t.queued || 0) - up) : 0;
    const on      = !!(rep || {})[dest[m]];

    el.textContent = t ? up : '—';
    el.classList.toggle('idle', !t || up === 0);
    if (sub) {
      if (!t)              sub.textContent = running ? 'no slot enabled' : 'daemon stopped';
      else if (!on)        sub.innerHTML = dec + ' decodes · <span style="color:var(--amber)">reporting off</span>';
      else                 sub.textContent = dec + ' decodes · ' + pending + ' pending';
    }
    // Badge shows uploads only, and only once there are some — an empty badge
    // is hidden by CSS, keeping the header clean before the first upload.
    if (hdr) {
      hdr.textContent = (t && up) ? String(up) : '';
      hdr.title = (t && up) ? (up + ' spots uploaded since the daemon started') : '';
    }
  });
}

// ─── Logs ────────────────────────────────────────────────────────────────────
function getLogTargetId(logName) {
  return LOG_TAB_TARGETS[logName] || 'main-log-logwebsdr';
}

async function loadLogs(targetId, logName) {
  const id = targetId || 'dash-log';
  const name = logName || 'logwebsdr.txt';
  const r = await fetch('/admin/api/logs?name=' + encodeURIComponent(name));
  const d = await r.json();
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = '';
  (d.lines || []).forEach(line => {
    const div = document.createElement('div');
    div.className = line.match(/error|fail|crash/i) ? 'log-line-err' :
                    line.match(/warn/i) ? 'log-line-warn' :
                    line.match(/ok|success|started/i) ? 'log-line-ok' : '';
    div.textContent = line;
    el.appendChild(div);
  });
  if (!(d.lines || []).length) {
    const div = document.createElement('div');
    div.textContent = 'No log output found.';
    el.appendChild(div);
  }
  el.scrollTop = el.scrollHeight;
}

function switchLogTab(logName, el) {
  currentLogTab = logName;
  document.querySelectorAll('.log-tab').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('.log-tab-pane').forEach(pane => pane.classList.remove('active'));
  if (el) el.classList.add('active');
  const paneId = LOG_TAB_PANES[logName];
  const pane = document.getElementById(paneId);
  if (pane) pane.classList.add('active');
  loadLogs(getLogTargetId(logName), logName);
}

function loadCurrentLogTab() {
  loadLogs(getLogTargetId(currentLogTab), currentLogTab);
}

async function clearLogView() {
  if (autoRefresh) toggleAutoRefresh();
  let d = {};
  try {
    const r = await fetch('/admin/api/logs/clear', {method: 'POST'});
    d = await r.json();
  } catch (e) {
    toast('Clear failed: ' + e, 'err');
    return;
  }
  const failed  = d.failed  || [];
  const skipped = d.skipped || [];
  const cleared = d.cleared || [];
  // Blank only the panes whose file was actually emptied. A pane blanked over a
  // file that is still on disk fills again at the next refresh, which reads as
  // the button being broken — so a log the server kept or could not write keeps
  // its lines on screen. CLEAR_EXCLUDE is empty now, so in practice this only
  // covers failures, but it stays correct if a log is ever excluded again.
  const keptPanes = new Set(skipped.concat(failed.map(f => f.name))
                                   .map(n => LOG_TAB_TARGETS[n]));
  ['dash-log', ...Object.values(LOG_TAB_TARGETS)].forEach(id => {
    if (keptPanes.has(id)) return;
    const el = document.getElementById(id);
    if (el) el.innerHTML = '';
  });
  // Say which files were actually emptied: a silent "Logs cleared" over a pane
  // that still has lines in it is what made this look broken.
  if (failed.length) {
    toast('Could not clear ' + failed.map(f => f.name + ' (' + f.error + ')').join(', '), 'err');
  } else {
    let msg = 'Cleared ' + (cleared.length ? cleared.join(', ') : 'nothing');
    if (skipped.length) msg += ' — kept ' + skipped.join(', ') + ' (excluded)';
    toast(msg);
  }
}

function toggleAutoRefresh() {
  autoRefresh = !autoRefresh;
  const btn = document.getElementById('auto-refresh-btn');
  if (autoRefresh) {
    btn.textContent = '⏸ STOP AUTO';
    btn.className = 'btn btn-red';
    autoRefreshTimer = setInterval(() => loadCurrentLogTab(), 3000);
  } else {
    btn.textContent = '⏵ AUTO REFRESH';
    btn.className = 'btn btn-green';
    clearInterval(autoRefreshTimer);
  }
}

// ─── Chat ────────────────────────────────────────────────────────────────────
async function loadChat() {
  const r = await fetch('/admin/api/chat');
  const d = await r.json();
  const el = document.getElementById('chat-log');
  el.innerHTML = '';
  (d.messages || []).forEach(m => {
    const div = document.createElement('div');
    div.className = 'chat-msg';

    const txt = document.createElement('span');
    txt.className = 'chat-msg-text';
    const rxTag = (d.multi && m.rx) ? `<span class="chat-time">${escHtml(m.rx)}</span> ` : '';
    txt.innerHTML = `${rxTag}<span class="chat-time">[${m.time||'?'}]</span> <span class="chat-nick">&lt;${m.nick||'?'}&gt;</span> ${escHtml(m.msg||'')}`;

    const delBtn = document.createElement('button');
    delBtn.className = 'chat-del-btn';
    delBtn.title = 'Delete this message';
    delBtn.textContent = '✕ DEL';
    delBtn.onclick = async function() {
      if (!confirm('Delete this message?\\n\\n' + (m.time ? '[' + m.time + '] ' : '') + '<' + m.nick + '> ' + m.msg)) return;
      try {
        const res = await fetch('/admin/api/chat/delete', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({line: m.raw, rx: m.rx || ''})
        });
        const rd = await res.json();
        if (rd.ok) { div.remove(); toast('Message deleted'); }
        else toast(rd.msg || 'Delete failed', 'err');
      } catch(e) { toast('Network error: ' + e.message, 'err'); }
    };

    div.appendChild(txt);
    div.appendChild(delBtn);
    el.appendChild(div);
  });
  if (!d.messages?.length) el.textContent = 'No chat history found.';
  el.scrollTop = el.scrollHeight;
}

async function clearChat() {
  if (!confirm('Clear chat history?')) return;
  const r = await fetch('/admin/api/chat/clear', {method:'POST'});
  const d = await r.json();
  if (d.ok) { toast('Chat cleared'); loadChat(); } else toast(d.msg, 'err');
}

// ─── Settings ────────────────────────────────────────────────────────────────
// The help line above the spectrumserver port names this station's
// real ports — the one typed in the box and proxy_port from admin_config.json.
function renderPortHelp() {
  const el = document.getElementById('public-port-help');
  if (!el) return;
  const sdr = parseInt((document.getElementById('public-port') || {}).value) || 0;
  const px  = window._proxyPort || 0;
  const b = function(v) { return '<b>' + (v || '—') + '</b>'; };
  el.innerHTML = px
    ? 'Port spectrumserver listens on:<br>' + b(sdr) + ' behind proxy.py;<br>listeners use the public (proxy) port ' + b(px) + '.<br>With no proxy, this is also the port listeners connect to.<br>Used for Kick and connection counts.'
    : 'Port spectrumserver listens on:<br>' + b(sdr) + '.<br>With no proxy (as on this station), this is also the port listeners connect to.<br>Used for Kick and connection counts.';
}

async function loadPorts() {
  const el = document.getElementById('ports-list');
  if (!el) return;
  try {
    const d = await (await fetch('/admin/api/ports')).json();
    const esc = function(t) { const x = document.createElement('span'); x.textContent = t; return x.innerHTML; };
    let h = '<table style="width:100%;border-collapse:collapse;">';
    d.ports.forEach(function(p) {
      const dot = p.listening
        ? '<span style="color:var(--green);" title="listening">&#9679;</span>'
        : '<span style="color:var(--text3);" title="nothing listens on it now">&#9675;</span>';
      const pub = p.public ? ' <span style="color:var(--amber);">&#183; open on the router</span>' : '';
      h += '<tr style="border-top:1px solid var(--border);">'
         + '<td style="padding:.3rem .4rem .3rem 0;width:1rem;vertical-align:top;">' + dot + '</td>'
         + '<td style="padding:.3rem .6rem .3rem 0;font-weight:bold;white-space:nowrap;vertical-align:top;color:var(--text);">' + esc(String(p.port)) + '</td>'
         + '<td style="padding:.3rem 0;">' + esc(p.what) + '<br><span style="opacity:.7;">' + esc(p.how) + '</span>' + pub + '</td></tr>';
    });
    h += '</table><p style="margin-top:.5rem;opacity:.7;">&#9679; listening now &#183; &#9675; not running. Only the ports marked "open on the router" need forwarding.</p>';
    el.innerHTML = h;
  } catch (e) { el.textContent = 'Could not read the ports: ' + e.message; }
}

async function loadSettingsPage() {
  loadAlerts();
  loadPorts();
  const r = await fetch('/admin/api/settings');
  const d = await r.json();
  document.getElementById('sdr-dir').value = d.sdr_base_dir || '';
  const ppEl = document.getElementById('public-port');
  if (ppEl) ppEl.value = d.public_port || 8900;
  const pxEl = document.getElementById('proxy-port-ro');
  if (pxEl) pxEl.textContent = d.proxy_port || 'none — no proxy, listeners use the port above';
  window._proxyPort = parseInt(d.proxy_port) || 0;
  renderPortHelp();
  // Populate start/stop script selectors
  const sh = await fetch('/admin/api/scripts').then(r => r.json());
  const all = sh.all || [];
  ['default-start-sel','default-stop-sel'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">-- None --</option>';
    all.forEach(s => {
      const o = document.createElement('option');
      o.value = s; o.textContent = s;
      sel.appendChild(o);
    });
  });
  if (document.getElementById('default-start-sel'))
    document.getElementById('default-start-sel').value = d.start_script || '';
  if (document.getElementById('default-stop-sel'))
    document.getElementById('default-stop-sel').value = d.stop_script || '';
  _savedScripts = {start: d.start_script || '', stop: d.stop_script || ''};
  loadThermalSettings(d);
  loadHttpsCard();
}

// ─── Thermal guard settings ──────────────────────────────────────────────────
const TG_FIELDS = {
  'tg-cfg-warn':        'thermal_warn',
  'tg-cfg-throttle':    'thermal_throttle',
  'tg-cfg-stop':        'thermal_stop',
  'tg-cfg-resume':      'thermal_resume',
  'tg-cfg-sustain':     'thermal_sustain_s',
  'tg-cfg-warnsustain': 'thermal_warn_sustain_s',
  'tg-cfg-resumes':     'thermal_resume_s',
  'tg-cfg-maxstops':    'thermal_max_stops_hour',
  'tg-cfg-test':        'thermal_test_temp',
};

function loadThermalSettings(d) {
  const mode = document.getElementById('tg-cfg-mode');
  if (!mode) return;
  if (d.thermal_mode === undefined) return;   // guard not loaded server-side
  mode.value = d.thermal_mode || 'log';
  const en = document.getElementById('tg-cfg-enabled');
  if (en) en.value = (d.thermal_enabled === false) ? '0' : '1';
  for (const [id, key] of Object.entries(TG_FIELDS)) {
    const el = document.getElementById(id);
    if (el) el.value = (d[key] === null || d[key] === undefined) ? '' : d[key];
  }
  fetch('/admin/api/thermal').then(r => r.json()).then(t => {
    const c = document.getElementById('tg-cfg-crit');
    if (!c) return;
    if (!t.available)   { c.textContent = 'guard not loaded'; return; }
    if (!t.sensor)      { c.textContent = 'no trusted CPU sensor found'; return; }
    c.textContent = t.crit ? (t.sensor + ', crit ' + t.crit + '°C')
                           : (t.sensor + ', no crit published — set STOP manually');
  }).catch(() => {});
}

async function saveThermal() {
  const body = {
    thermal_mode: document.getElementById('tg-cfg-mode').value,
    thermal_enabled: document.getElementById('tg-cfg-enabled').value === '1',
  };
  for (const [id, key] of Object.entries(TG_FIELDS)) {
    const el = document.getElementById(id);
    if (!el) continue;
    const v = el.value.trim();
    body[key] = (v === '') ? null : parseFloat(v);
  }
  const d = await fetch('/admin/api/settings', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify(body)
  }).then(r => r.json());
  if (d.ok) {
    toast('Thermal settings saved');
    document.getElementById('tg-cfg-msg').textContent =
      'Saved — applied on the next sample (within a few seconds), no restart needed';
    loadSettingsPage();
    updateThermal();
  } else toast(d.msg || 'Failed', 'err');
}

async function saveSettings(confirmPort) {
  const dir   = document.getElementById('sdr-dir').value.trim();
  const start = document.getElementById('default-start-sel')?.value || '';
  const stop  = document.getElementById('default-stop-sel')?.value || '';
  const pp    = parseInt(document.getElementById('public-port')?.value || '8900', 10);
  const r = await fetch('/admin/api/settings', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({sdr_base_dir: dir, start_script: start, stop_script: stop, public_port: pp,
                          confirm_port: !!confirmPort})
  });
  const d = await r.json();
  if (!d.ok && d.confirm) {
    if (confirm(d.msg)) return saveSettings(true);
    document.getElementById('settings-msg').textContent = 'Not saved — the port was left as it was.';
    return;
  }
  if (!d.ok) document.getElementById('settings-msg').textContent = d.msg || '';
  if (d.ok) {
    toast('Settings saved');
    document.getElementById('settings-msg').textContent = 'Saved';
    _savedScripts = {start: start, stop: stop};
  } else toast(d.msg, 'err');
}

// ─── Receivers page ──────────────────────────────────────────────────────────
let _rxList = [], _rxEdit = null, _rxAdd = null;
function _mhz(hz) { return (hz / 1e6).toFixed(hz % 1000 ? 4 : 3).replace(/0+$/, '').replace(/[.]$/, ''); }
function _rate(sps) { return sps >= 1e6 ? (sps / 1e6) + ' MHz' : (sps / 1e3) + ' kHz'; }
async function loadReceiversPage() {
  const tb = document.getElementById('rx-table');
  if (!tb) return;
  let d;
  try { d = await fetch('/admin/api/receivers-info', {cache: 'no-store'}).then(r => r.json()); }
  catch (e) { tb.innerHTML = '<tr><td>could not read the receivers</td></tr>'; return; }
  _rxList = d.receivers || [];
  let h = '<thead><tr><th>Receiver</th><th>?rx=</th><th>Hardware</th><th>Covers</th><th>Bandwidth</th>' +
          '<th>Starts on</th><th>State</th><th></th></tr></thead><tbody>';
  _rxList.forEach((r, i) => {
    let act = '<div style="display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;">';
    if (r.changeable || r.settable) act += '<button class="btn btn-amber" onclick="rxShowChange(' + i + ')">✎ CHANGE SETTINGS</button>';
    // A receiver with the change form renames there; RENAME is for the others (HF direct sampling, main).
    if (r.renamable && !r.changeable && !r.settable) act += '<button class="btn" onclick="rxShowRename(' + i + ')">🏷 RENAME BUTTON</button>';
    if (r.on_air) act += '<button class="btn btn-amber" id="rx-pw' + i + '" onclick="rxPower(' + i + ', ' + "'stop'" + ')">■ STOP</button>';
    else if (r.launcher) act += '<button class="btn btn-green" id="rx-pw' + i + '" onclick="rxPower(' + i + ', ' + "'start'" + ')">▶ START</button>';
    if (r.deletable) act += '<button class="btn btn-red" onclick="rxShowDelete(' + i + ')">🗑 DELETE</button>';
    act += '</div>';
    if (!r.changeable && r.direct) act += '<div style="color:var(--text3);">direct sampling — covers 0–' + _mhz(r.high) + ' MHz, no band to change</div>';
    else if (!r.changeable && !r.instance) act += '<div style="color:var(--text3);">main receiver — change its band in a terminal: <code>bash configure-station.sh</code></div>';
    h += '<tr><td>' + _esc(r.name) + '</td><td>' + _esc(r.id) + '</td><td>' + _esc(r.hardware) + (r.gain ? '<br><span style="color:var(--text3);">gain ' +
         (r.gain.kind === 'rx888' ? r.gain.gain + ' ' + r.gain.mode + (r.gain.pga ? ' +PGA' : '') + (r.gain.att ? ', att ' + r.gain.att : '')
                                  : (r.gain.gain === 'auto' ? 'auto' : r.gain.gain + ' dB')) + '</span>' : '') + '</td>' +
         '<td>' + _mhz(r.low) + ' – ' + _mhz(r.high) + ' MHz' + (r.direct ? '' : '<br><span style="color:var(--text3);">centre ' + _mhz(r.tune || r.frequency) + '</span>') + '</td>' +
         '<td>' + _rate(r.span) + '</td><td>' + (r.default_frequency ? _mhz(r.default_frequency) + ' MHz ' + _esc(r.modulation) : '') + '</td>' +
         '<td style="color:' + (r.on_air ? 'var(--green)' : 'var(--red)') + ';">' + (r.on_air ? '● on air' : '● off') + '</td><td>' + act + '</td></tr>';
  });
  tb.innerHTML = h + '</tbody>';
}
function _rxHideCards() {
  ['rx-change-card', 'rx-add-card', 'rx-rename-card', 'rx-delete-card'].forEach(id => {
    const c = document.getElementById(id); if (c) c.style.display = 'none'; });
}
async function rxPower(i, what) {
  const r = _rxList[i];
  if (what === 'stop' && !confirm('Stop ' + r.name + '? Its listeners are cut off and its button disappears from the picker. ' +
      (r.instance ? 'The other receivers keep running.' : 'This is the main receiver: RADE and DRM stop with it; the other receivers keep running.'))) return;
  const btn = document.getElementById('rx-pw' + i);
  if (btn) { btn.disabled = true; btn.textContent = what === 'stop' ? 'STOPPING …' : 'STARTING …'; }
  try {
    const d = await fetch('/admin/api/receivers-info/power', {method: 'POST',
      headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: r.id, action: what})}).then(x => x.json());
    toast(d.ok ? (what === 'stop' ? 'Stopped ' : 'Starting ') + r.id + (what === 'start' ? ' — about 20 s' : '') : (d.msg || 'Failed'), d.ok ? 'ok' : 'err');
    if (!d.ok) { loadReceiversPage(); return; }
  } catch (e) { toast(String(e), 'err'); loadReceiversPage(); return; }
  // A receiver needs ~20 s to come up (USB release, SDR, spectrumserver): keep
  // the row saying so and re-read until it is on air (or off), up to 90 s.
  const want = what === 'start', t0 = Date.now();
  const poll = async () => {
    await loadReceiversPage();
    const now = _rxList.find(x => x.id === r.id);
    if (now && now.on_air !== want && Date.now() - t0 < 90000) {
      const k = _rxList.indexOf(now), b = document.getElementById('rx-pw' + k);
      if (b) { b.disabled = true; b.textContent = want ? 'STARTING …' : 'STOPPING …'; }
      setTimeout(poll, 3000);
    } else if (now && now.on_air !== want) {
      toast(r.id + (want ? ' did not come on air — see logwebsdr-' + (r.instance || '') + '.txt' : ' is still running'), 'err');
    }
  };
  setTimeout(poll, want ? 3000 : 500);
}
function rxShowRename(i) {
  const r = _rxList[i];
  _rxEdit = r;
  _rxHideCards();
  document.getElementById('rx-rename-title').textContent = 'RENAME BUTTON — ' + r.name + ' (' + r.id + ')';
  document.getElementById('rx-r-name').value = r.name;
  document.getElementById('rx-r-out').textContent = '';
  const card = document.getElementById('rx-rename-card');
  card.style.display = '';
  card.scrollIntoView({behavior: 'smooth'});
  document.getElementById('rx-r-name').focus();
}
async function rxApplyRename() {
  const r = _rxEdit; if (!r) return;
  const out = document.getElementById('rx-r-out');
  try {
    const d = await fetch('/admin/api/receivers-info/rename', {method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({id: r.id, name: document.getElementById('rx-r-name').value.trim()})}).then(x => x.json());
    out.textContent = d.msg || '';
    toast(d.ok ? 'Renamed' : (d.msg || 'Failed'), d.ok ? 'ok' : 'err');
    if (d.ok) loadReceiversPage();
  } catch (e) { out.textContent = String(e); }
}
function rxShowDelete(i) {
  const r = _rxList[i];
  _rxEdit = r;
  _rxHideCards();
  document.getElementById('rx-delete-title').textContent = 'DELETE RECEIVER — ' + r.name + ' (' + r.id + ')';
  document.getElementById('rx-d-what').innerHTML =
    'This stops <b>' + _esc(r.name) + '</b> (its listeners are cut off), takes it out of <code>receivers.toml</code> ' +
    'so its button disappears from every page, and removes its folder <code>instances/' + _esc(r.instance) + '/</code> ' +
    '(config.toml, instance.env, its page settings, chat and markers). The other receivers keep running. ' +
    'The USB driver stays installed and the stick can stay plugged in.';
  document.getElementById('rx-d-confirm').value = '';
  document.getElementById('rx-d-confirm').placeholder = r.id;
  document.getElementById('rx-d-keep').checked = true;
  document.getElementById('rx-d-out').textContent = '';
  const card = document.getElementById('rx-delete-card');
  card.style.display = '';
  card.scrollIntoView({behavior: 'smooth'});
}
async function rxApplyDelete() {
  const r = _rxEdit; if (!r) return;
  const typed = document.getElementById('rx-d-confirm').value.trim();
  const out = document.getElementById('rx-d-out');
  if (typed !== r.id) { out.textContent = 'Type ' + r.id + ' in the box to confirm.'; return; }
  const btn = document.getElementById('rx-d-apply');
  btn.disabled = true; out.textContent = 'Stopping it and removing …';
  try {
    const d = await fetch('/admin/api/receivers-info/delete', {method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({id: r.id, confirm: typed, keep_copy: document.getElementById('rx-d-keep').checked})}).then(x => x.json());
    out.textContent = d.msg || '';
    toast(d.ok ? 'Receiver removed' : (d.msg || 'Failed'), d.ok ? 'ok' : 'err');
    if (d.ok) loadReceiversPage();
  } catch (e) { out.textContent = String(e); }
  finally { btn.disabled = false; }
}
function rxShowChange(i) {
  const r = _rxList[i];
  _rxEdit = r;
  _rxHideCards();
  document.getElementById('rx-change-title').textContent = 'CHANGE SETTINGS — ' + r.name + ' (' + r.id + ')';
  document.getElementById('rx-c-band-row').style.display = r.changeable ? '' : 'none';
  document.getElementById('rx-c-name-wrap').style.display = r.renamable ? '' : 'none';
  document.getElementById('rx-c-apply').textContent = r.changeable ? '✔ APPLY AND RESTART THIS RECEIVER' : '✔ APPLY';
  const g = r.gain;
  document.getElementById('rx-c-gain-wrap').style.display = g ? '' : 'none';
  if (g) {
    const x = g.kind === 'rx888';
    ['rx-c-g-rx888', 'rx-c-g-rx888b'].forEach(id => { document.getElementById(id).style.display = x ? '' : 'none'; });
    document.getElementById('rx-c-g-rtl').style.display = x ? 'none' : '';
    if (x) {
      document.getElementById('rx-c-g-gain').value = g.gain;
      document.getElementById('rx-c-g-mode').value = g.mode;
      document.getElementById('rx-c-g-att').value = g.att;
      document.getElementById('rx-c-g-pga').checked = g.pga;
    } else {
      const steps = g.steps.filter(v => v > 0);
      if (g.gain !== 'auto' && steps.indexOf(g.gain) < 0) { steps.push(g.gain); steps.sort((a, b) => a - b); }
      document.getElementById('rx-c-g-rtlgain').innerHTML = '<option value="auto">auto (AGC of the stick)</option>' +
        steps.map(v => '<option value="' + v + '"' + (v === g.gain ? ' selected' : '') + '>' + v.toFixed(1) + ' dB</option>').join('');
      if (g.gain === 'auto') document.getElementById('rx-c-g-rtlgain').value = 'auto';
    }
  }
  document.getElementById('rx-c-freq').value = _mhz(r.tune || r.frequency);
  const sel = document.getElementById('rx-c-sps');
  const rates = r.rates.slice();
  if (rates.indexOf(r.sps) < 0) rates.push(r.sps);
  rates.sort((a, b) => a - b);
  sel.innerHTML = rates.map(x => '<option value="' + x + '"' + (x === r.sps ? ' selected' : '') + '>' + _rate(x) + '</option>').join('');
  document.getElementById('rx-c-dflt').value = _mhz(r.default_frequency);
  document.getElementById('rx-c-mode').innerHTML = r.modes.map(m => '<option' + (m === r.modulation ? ' selected' : '') + '>' + m + '</option>').join('');
  document.getElementById('rx-c-name').value = r.name;
  document.getElementById('rx-c-out').textContent = '';
  document.getElementById('rx-change-card').style.display = '';
  rxChangePreview();
  document.getElementById('rx-change-card').scrollIntoView({behavior: 'smooth'});
}
function rxChangePreview() {
  const r = _rxEdit; if (!r) return;
  const f = Math.round(parseFloat(document.getElementById('rx-c-freq').value) * 1e6);
  const sps = parseInt(document.getElementById('rx-c-sps').value, 10);
  const dflt = Math.round(parseFloat(document.getElementById('rx-c-dflt').value) * 1e6);
  const pv = document.getElementById('rx-c-preview');
  if (!r.changeable) {
    let t = 'It covers ' + _mhz(r.low) + ' – ' + _mhz(r.high) + ' MHz. A new start frequency or mode restarts it (' +
            (r.instance ? 'the other receivers keep running' : 'RADE and DRM restart with it; the other receivers keep running') + '); a new name alone does not.';
    if (dflt && (dflt < r.low || dflt > r.high)) t += ' ✖ The start frequency is outside that range.';
    pv.textContent = t; return;
  }
  if (!f || !sps) { pv.textContent = ''; return; }
  const lo = f - sps / 2, hi = f + sps / 2;
  let t = 'It will cover ' + _mhz(lo) + ' – ' + _mhz(hi) + ' MHz.';
  const inRange = r.ranges.some(x => f >= x[0] && f <= x[1]);
  if (!inRange) t += ' ✖ ' + r.hardware + ' does not tune ' + _mhz(f) + ' MHz.';
  if (dflt && (dflt < lo || dflt > hi)) t += ' ✖ The start frequency is outside that range.';
  if (r.note) t += ' ' + r.note;
  pv.textContent = t;
}
function _rxGainForm(r) {
  const g = r.gain; if (!g) return null;
  if (g.kind === 'rx888') return {gain: parseInt(document.getElementById('rx-c-g-gain').value, 10),
    mode: document.getElementById('rx-c-g-mode').value, att: parseInt(document.getElementById('rx-c-g-att').value, 10),
    pga: document.getElementById('rx-c-g-pga').checked};
  const v = document.getElementById('rx-c-g-rtlgain').value;
  return {gain: v === 'auto' ? 'auto' : parseFloat(v)};
}
function _rxGainSame(r, f) {
  const g = r.gain; if (!g || !f) return true;
  if (g.kind === 'rx888') return f.gain === g.gain && f.mode === g.mode && f.att === g.att && f.pga === g.pga;
  return f.gain === g.gain;
}
async function rxApplyChange() {
  const r = _rxEdit; if (!r) return;
  const body = {
    id: r.id,
    frequency: r.changeable ? Math.round(parseFloat(document.getElementById('rx-c-freq').value) * 1e6) : (r.tune || r.frequency),
    sps: r.changeable ? parseInt(document.getElementById('rx-c-sps').value, 10) : r.sps,
    default_frequency: Math.round(parseFloat(document.getElementById('rx-c-dflt').value) * 1e6),
    modulation: document.getElementById('rx-c-mode').value,
    name: document.getElementById('rx-c-name').value.trim(),
    gain: _rxGainForm(r)
  };
  const btn = document.getElementById('rx-c-apply'), out = document.getElementById('rx-c-out');
  // Only the name changed: save it without restarting the receiver.
  if (body.frequency === (r.tune || r.frequency) && body.sps === r.sps &&
      body.default_frequency === r.default_frequency && body.modulation === r.modulation && _rxGainSame(r, body.gain)) {
    if (!body.name || body.name === r.name) { out.textContent = 'Nothing changed.'; return; }
    try {
      const d = await fetch('/admin/api/receivers-info/rename', {method: 'POST',
        headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: r.id, name: body.name})}).then(x => x.json());
      out.textContent = d.msg || '';
      toast(d.ok ? 'Renamed' : (d.msg || 'Failed'), d.ok ? 'ok' : 'err');
      if (d.ok) loadReceiversPage();
    } catch (e) { out.textContent = String(e); }
    return;
  }
  if (!confirm('Apply and restart ' + r.name + '? Its listeners are cut off for a few seconds; ' +
      (r.instance ? '' : 'RADE and DRM restart with it; ') + 'the other receivers keep running.')) return;
  btn.disabled = true; out.textContent = 'Writing the files and restarting …';
  try {
    const d = await fetch('/admin/api/receivers-info/retune', {method: 'POST',
      headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)}).then(x => x.json());
    out.textContent = d.msg || '';
    toast(d.ok ? 'Saved' : (d.msg || 'Failed'), d.ok ? 'ok' : 'err');
    if (d.ok) setTimeout(loadReceiversPage, 8000);
  } catch (e) { out.textContent = String(e); }
  finally { btn.disabled = false; }
}
async function rxShowAdd() {
  _rxHideCards();
  const card = document.getElementById('rx-add-card');
  card.style.display = '';
  document.getElementById('rx-a-out').innerHTML = '';
  try { _rxAdd = await fetch('/admin/api/receivers-info/add-defaults', {cache: 'no-store'}).then(r => r.json()); }
  catch (e) { toast('could not read the defaults', 'err'); return; }
  const u = _rxAdd.usb;
  document.getElementById('rx-a-usb').innerHTML = u === null ? 'lsusb is not installed, so the page cannot list the USB receivers.'
    : (u.length ? 'USB receivers this computer sees: <b>' + u.map(_esc).join('</b>, <b>') + '</b>' : 'No known USB receiver is plugged in.');
  document.getElementById('rx-a-host').value = _rxAdd.host || '';
  rxAddType();
  card.scrollIntoView({behavior: 'smooth'});
}
function rxAddType() {
  if (!_rxAdd) return;
  const t = document.getElementById('rx-a-type').value, d = _rxAdd.types[t];
  document.getElementById('rx-a-v4-wrap').style.visibility = t === '2' ? 'visible' : 'hidden';
  document.getElementById('rx-a-freq-wrap').style.visibility = d.direct ? 'hidden' : 'visible';
  document.getElementById('rx-a-freq').value = d.direct ? '' : _mhz(d.frequency);
  const sel = document.getElementById('rx-a-sps'), num = document.getElementById('rx-a-sps-num');
  if (d.rates && d.rates.length) {
    sel.style.display = ''; num.style.display = 'none';
    sel.innerHTML = d.rates.map(x => '<option value="' + x + '"' + (x === d.sps ? ' selected' : '') + '>' + _rate(x) + '</option>').join('');
  } else {
    sel.style.display = 'none'; num.style.display = ''; num.value = d.sps;
  }
  rxAddName();
}
function rxAddName() {
  const t = document.getElementById('rx-a-type').value, d = _rxAdd.types[t];
  const f = d.direct ? 0 : Math.round(parseFloat(document.getElementById('rx-a-freq').value || '0') * 1e6);
  let base = (d.direct || f < 30e6) ? 'hf2' : f < 300e6 ? 'vhf' : f < 3e9 ? 'uhf' : 'rx2';
  let n = base, k = 2;
  while (_rxAdd.taken.indexOf(n) >= 0) { n = base + k; k++; }
  document.getElementById('rx-a-name').value = n;
  const sel = document.getElementById('rx-a-type');
  const hw = sel.options[sel.selectedIndex].text.split(' (')[0].split(' — ')[0];
  document.getElementById('rx-a-label').value = d.direct ? 'HF (' + hw + ')' : _mhz(f) + ' MHz (' + hw + ')';
}
async function rxAddPrepare() {
  const t = document.getElementById('rx-a-type').value, d = _rxAdd.types[t];
  const body = {
    type: parseInt(t, 10), v4: document.getElementById('rx-a-v4').checked,
    frequency: d.direct ? 0 : Math.round(parseFloat(document.getElementById('rx-a-freq').value) * 1e6),
    sps: parseInt((d.rates && d.rates.length) ? document.getElementById('rx-a-sps').value : document.getElementById('rx-a-sps-num').value, 10),
    name: document.getElementById('rx-a-name').value.trim(), label: document.getElementById('rx-a-label').value.trim(),
    antenna: document.getElementById('rx-a-antenna').value.trim(), host: document.getElementById('rx-a-host').value.trim(),
    driver: document.getElementById('rx-a-driver').checked, picker: document.getElementById('rx-a-picker').checked,
    admin: document.getElementById('rx-a-admin').checked, start: document.getElementById('rx-a-start').checked,
    proxy: document.getElementById('rx-a-proxy').checked
  };
  const out = document.getElementById('rx-a-out');
  const r = await fetch('/admin/api/receivers-info/add-plan', {method: 'POST',
    headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)}).then(x => x.json());
  if (!r.ok) {
    out.innerHTML = (r.errors || []).map(e => '<div><span style="color:var(--red);">✖</span> ' + _esc(e) + '</div>').join('');
    return;
  }
  let h = '<div><span style="color:var(--green);">✔</span> Answers saved. Now open a terminal on this computer and run these two lines:</div>';
  r.commands.forEach((c, n) => {
    h += '<div style="display:flex;gap:.5rem;align-items:center;margin-top:.3rem;">' +
         '<code id="rx-cmd' + n + '" style="flex:1;min-width:0;padding:.3rem .5rem;border:1px solid var(--border);' +
         'border-radius:3px;overflow-x:auto;white-space:nowrap;">' + _esc(c) + '</code>' +
         '<button class="btn btn-amber" onclick="httpsCopy(' + "'rx-cmd" + n + "'" + ')">📋 COPY</button></div>';
  });
  (r.notes || []).forEach(n => { h += '<div style="margin-top:.4rem;color:var(--amber);">! ' + _esc(n) + '</div>'; });
  h += '<div style="margin-top:.6rem;color:var(--text3);">The script asks only what is not answered here (and your sudo password).' +
       ' When it has finished, reload this page — the new receiver appears in the list.</div>';
  out.innerHTML = h;
}

// ─── HTTPS card ──────────────────────────────────────────────────────────────
// An https station gets CHECK (setup-https.sh --status, no root needed); an
// http-only one gets SET UP HTTPS: what this page can verify, what it cannot
// (router, DNS), and the command to run in a terminal with the sysop's own sudo.
let _httpsInfo = null;
function _esc(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
async function loadHttpsCard() {
  const st = document.getElementById('https-state'), btn = document.getElementById('https-btn');
  if (!st || !btn) return;
  try {
    _httpsInfo = await fetch('/admin/api/https', {cache: 'no-store'}).then(r => r.json());
  } catch (e) { st.textContent = 'could not read the https state'; return; }
  const i = _httpsInfo;
  if (i.mode === 'y') st.innerHTML = 'https is <b>on</b> — https://' + _esc(i.host || '?') + '/';
  else if (i.mode === 'lan') st.innerHTML = 'https is <b>on</b> for the local network only';
  else st.innerHTML = 'https is <b>off</b> — this station is http only';
  btn.textContent = i.https ? '🔍 CHECK' : '🔒 SET UP HTTPS';
  btn.disabled = false;
}
function _copyText(t) {
  // navigator.clipboard needs a secure context, and this page is usually plain http.
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(t).then(() => true, () => false);
  const ta = document.createElement('textarea');
  ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch (e) {}
  document.body.removeChild(ta);
  return Promise.resolve(ok);
}
async function httpsCopy(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const ok = await _copyText(el.textContent);
  toast(ok ? 'Copied' : 'Copy failed — select the text by hand', ok ? 'ok' : 'err');
}
async function httpsAction() {
  const out = document.getElementById('https-out'), btn = document.getElementById('https-btn');
  if (!_httpsInfo) return;
  btn.disabled = true;
  out.textContent = _httpsInfo.https ? 'Checking … (up to 15 s)' : 'Checking what can be checked …';
  try {
    const d = await fetch('/admin/api/https/' + (_httpsInfo.https ? 'check' : 'precheck'),
                          {method: 'POST'}).then(r => r.json());
    if (_httpsInfo.https) {
      out.innerHTML = '<span style="color:' + (d.ok ? 'var(--green)' : 'var(--amber)') + ';">' +
                      (d.ok ? '✔ https works' : '! https needs attention') + '</span>' +
                      String.fromCharCode(10) + _esc(d.output || d.msg || '');
    } else {
      const mark = {ok: '✔', warn: '!', bad: '✖', todo: '☐'};
      const col  = {ok: 'var(--green)', warn: 'var(--amber)', bad: 'var(--red)', todo: 'var(--text2)'};
      let h = '';
      (d.items || []).forEach(it => {
        h += '<div style="margin-bottom:.25rem;"><span style="color:' + col[it.state] + ';">' + mark[it.state] +
             '</span> ' + _esc(it.text) + '</div>';
      });
      if (d.ready) {
        h += '<div style="margin-top:.6rem;">Then open a terminal on this computer and run these two lines' +
             ' (it asks for your sudo password):</div>';
        (d.commands || []).forEach((c, n) => {
          h += '<div style="display:flex;gap:.5rem;align-items:center;margin-top:.3rem;">' +
               '<code id="https-cmd' + n + '" style="flex:1;min-width:0;padding:.3rem .5rem;border:1px solid var(--border);' +
               'border-radius:3px;overflow-x:auto;white-space:nowrap;">' + _esc(c) + '</code>' +
               '<button class="btn btn-amber" onclick="httpsCopy(' + "'https-cmd" + n + "'" + ')">📋 COPY</button></div>';
        });
        h += '<div style="margin-top:.6rem;color:var(--text3);">For the local network only (browsers warn about the certificate):' +
             ' bash setup-https.sh --lan. When it has finished, reload this page — the button becomes CHECK.</div>';
      } else {
        h += '<div style="margin-top:.6rem;color:var(--amber);">Fix the ✖ line first, then press SET UP HTTPS again.</div>';
      }
      out.innerHTML = h;
    }
  } catch (e) {
    out.textContent = String(e);
  } finally {
    btn.disabled = false;
  }
}

// Run the SAVED default start/stop script — the same one the thermal guard uses.
let _savedScripts = {start: '', stop: ''};
async function runDefaultScript(which) {
  const sel = document.getElementById('default-' + which + '-sel');
  const name = _savedScripts[which];
  if (sel && sel.value !== name) { toast('Save settings first — the selection is not saved yet', 'err'); return; }
  if (which === 'start' && !name) { toast('No default start script set', 'err'); return; }
  const what = which === 'start'
    ? 'Run ' + name + ' now? Running receivers are restarted, so every listener is dropped.'
    : 'Run ' + (name || 'stop-websdr.sh') + ' now? Every receiver stops and every listener is dropped.';
  if (!confirm(what)) return;
  const btn = document.getElementById('run-' + which + '-btn');
  const msg = document.getElementById('settings-msg');
  if (btn) btn.disabled = true;
  msg.textContent = 'Running ' + (name || 'stop-websdr.sh') + ' …';
  try {
    const r = await fetch('/admin/api/run-default-script', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({which: which})
    });
    const d = await r.json();
    msg.textContent = d.msg || '';
    toast(d.ok ? (which === 'start' ? 'Start script launched' : 'Stop script launched') : (d.msg || 'Failed'), d.ok ? undefined : 'err');
  } catch (e) {
    msg.textContent = String(e);
    toast('Failed', 'err');
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function changePassword(e) {
  e.preventDefault();
  const old = document.getElementById('old-pwd').value;
  const n = document.getElementById('new-pwd').value;
  const n2 = document.getElementById('new-pwd2').value;
  if (n !== n2) { toast('Passwords do not match', 'err'); return; }
  if (n.length < 4) { toast('Password too short (min 4)', 'err'); return; }
  const r = await fetch('/admin/api/change-password', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({old, new_pwd: n})
  });
  const d = await r.json();
  if (d.ok) { toast('Password changed'); document.getElementById('old-pwd').value=''; document.getElementById('new-pwd').value=''; document.getElementById('new-pwd2').value=''; }
  else toast(d.msg, 'err');
}
function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function isLocalIp(ip) {
  if (!ip) return false;
  var raw = ip.startsWith('::ffff:') ? ip.slice(7) : ip;
  if (raw === '::1' || raw === 'localhost') return true;
  return /^127\\./.test(raw) || /^10\\./.test(raw) || /^192\\.168\\./.test(raw) ||
         /^172\\.(1[6-9]|2\\d|3[01])\\./.test(raw) || /^fc/i.test(raw) || /^fd/i.test(raw);
}

// ─── Users / Kick ────────────────────────────────────────────────────────────
let _usersAutoTimer = null;

var _uConnTimes = {};

function _uFmtFreq(khz) {
  if (khz == null || isNaN(khz)) return '--';
  if (khz >= 50) return (khz / 1000).toFixed(3) + ' MHz';
  return khz.toFixed(3) + ' kHz';
}

function _uFmtDur(ms) {
  var s  = Math.floor(ms / 1000);
  var h  = Math.floor(s / 3600);
  var m  = Math.floor((s % 3600) / 60);
  var ss = s % 60;
  if (h > 0) return h + ':' + String(m).padStart(2,'0') + ':' + String(ss).padStart(2,'0');
  return m + ':' + String(ss).padStart(2,'0');
}

function _uTickDurations() {
  var now = Date.now();
  document.querySelectorAll('td.u-dur-cell[data-uid]').forEach(function(td) {
    var t = _uConnTimes[td.dataset.uid];
    if (t) td.textContent = _uFmtDur(now - t);
  });
}

setInterval(function(){ if (currentPage === 'users') _uTickDurations(); }, 1000);

// ─── Graphs page ─────────────────────────────────────────────────────────────
// Four measures with four different units (GHz, %, degC, a head-count).  They
// are drawn as four stacked panels sharing one time axis rather than as one
// chart with several y-scales: a shared scale would imply the curves are
// comparable, and the crossings it produced would be an artefact of the scaling.
var _gPoints   = [];      // full history, oldest first
var _gRange    = 900;     // visible window, seconds
var _gLast     = 0;       // newest sample timestamp we hold
var _gMeta     = {interval: 2, freq_limit: null, cores: null, coarse: false};
var _gTimer    = null;
var _gHover    = null;    // index under the pointer, or null

var GRAPH_PANELS = [
  {key:'f', title:'CPU FREQUENCY', unit:'GHz', dec:2},
  {key:'l', title:'CPU LOAD',      unit:'%',   dec:0},
  {key:'c', title:'CPU TEMPERATURE', unit:'°C', dec:1},
  {key:'u', title:'USERS ONLINE',  unit:'',    dec:0, step:true}
];

// One hue for every panel: each panel holds a single series that its own title
// names, so colour is not carrying identity here and four competing hues would
// only add noise.  Colour is kept in reserve for temperature, where it means
// something specific.
var G_LINE = '#00ff41', G_FILL = 'rgba(0,255,65,0.10)';
var G_WARN = '#ffb000', G_CRIT = '#ff4040';
// Theme colours for the canvas, re-read whenever the theme changes.
var G_FHEAD = 'Orbitron, monospace', G_FMONO = '"Share Tech Mono", monospace';
var G_TXT2 = '#7ab87a', G_TXT3 = '#4a8a4a', G_GRID = 'rgba(26,58,26,0.9)', G_CUR = 'rgba(200,255,200,0.35)', G_BG = '#0a150a';
function graphThemeColors() {
  var cs = getComputedStyle(document.documentElement);
  var v = function(n) { return cs.getPropertyValue(n).trim(); };
  G_LINE = v('--green'); G_FILL = 'rgba(' + v('--accent-rgb') + ',0.10)';
  G_WARN = v('--amber'); G_CRIT = v('--red');
  G_TXT2 = v('--text2'); G_TXT3 = v('--text3'); G_GRID = v('--border'); G_BG = v('--panel');
  G_CUR = v('--text3');
  G_FHEAD = v('--font-head') || G_FHEAD; G_FMONO = v('--font-mono') || G_FMONO;
}
var TEMP_WARN = 70, TEMP_CRIT = 80;

function graphTempColor(v) {
  if (v === null || v === undefined) return G_LINE;
  if (v >= TEMP_CRIT) return G_CRIT;
  if (v >= TEMP_WARN) return G_WARN;
  return G_LINE;
}

function graphSetRange(sec, el) {
  _gRange = sec;
  document.querySelectorAll('.graph-range').forEach(function(b) {
    b.classList.toggle('active', b === el);
  });
  // Ranges are served from different tiers (2s live, 30s averages beyond an
  // hour), so the held points are not interchangeable — refetch rather than
  // splice two resolutions into one series.
  _gPoints = []; _gLast = 0;
  loadGraphs(false);
}

async function loadGraphs(incremental) {
  var want = _gRange;
  try {
    var url = '/admin/api/graph-stats?range=' + want +
              (incremental && _gLast ? '&since=' + _gLast : '');
    var r = await fetch(url, {cache: 'no-store'});
    var d = await r.json();
    if (!d.ok) return;
    // A slow reply that lands after the range changed again would mix
    // resolutions; drop it and let the newer request stand.
    if (want !== _gRange) return;
    var restart = _gMeta.interval && d.interval !== _gMeta.interval;
    _gMeta = {interval: d.interval, freq_limit: d.freq_limit, cores: d.cores, coarse: d.coarse};
    var pts = d.points || [];
    if (incremental && _gLast) {
      if (pts.length) _gPoints = _gPoints.concat(pts);
    } else {
      _gPoints = pts;
    }
    if (_gPoints.length) _gLast = _gPoints[_gPoints.length - 1].t;
    // Drop anything older than the window so the buffer here cannot grow
    // without bound over a long-lived session.
    var cutoff = _gLast - want;
    _gPoints = _gPoints.filter(function(p) { return p.t >= cutoff; });
    // Poll on the tier's cadence: 2s on the live view, no faster than new
    // points appear on the aggregated ones.
    if (restart) graphSchedulePoll();
    drawGraphs();
  } catch (e) { /* transient fetch error: keep what we have and retry next tick */ }
}

function graphSchedulePoll() {
  if (_gTimer) clearInterval(_gTimer);
  _gTimer = setInterval(function() {
    if (currentPage === 'graphs' && !document.hidden) loadGraphs(true);
  }, (_gMeta.interval || 2) * 1000);
}

function graphVisible() {
  var cut = (_gPoints.length ? _gPoints[_gPoints.length - 1].t : 0) - _gRange;
  return _gPoints.filter(function(p) { return p.t >= cut; });
}

function graphFmt(v, p) {
  if (v === null || v === undefined) return '--';
  return v.toFixed(p.dec) + (p.unit ? ' ' + p.unit : '');
}

// Top of a panel's y-scale.  Single source of truth: the plot and the hover
// markers must agree, and computing it twice is how they stop agreeing.
// Every scale starts at zero, so curve height stays proportional to the value.
function graphTop(p, pts) {
  var vals = pts.map(function(q) { return q[p.key]; })
                .filter(function(v) { return v !== null && v !== undefined; });
  if (p.key === 'l') return 100;
  if (p.key === 'f') return _gMeta.freq_limit ||
                            (vals.length ? Math.max.apply(null, vals) * 1.15 : 1);
  if (p.key === 'c') return Math.max(80, vals.length
                            ? Math.ceil(Math.max.apply(null, vals) / 10) * 10 : 80);
  return Math.ceil(Math.max(4, vals.length ? Math.max.apply(null, vals) : 1));
}

function drawGraphs() {
  var cv = document.getElementById('graph-canvas');
  var empty = document.getElementById('graph-empty');
  if (!cv) return;
  var pts = graphVisible();

  var info = document.getElementById('graph-info-label');
  if (info) {
    // Say plainly when a view is averaged: a 30s mean and a 2s reading are not
    // the same measurement, and the peaks differ between them.
    info.textContent = (_gMeta.coarse ? _gMeta.interval + 's averages' : 'sampling every ' + _gMeta.interval + 's') +
      ' · ' + pts.length + ' points shown' + (_gMeta.cores ? ' · ' + _gMeta.cores + ' cores' : '');
  }

  // Current-value tiles always reflect the newest sample, not the hover.
  var last = _gPoints.length ? _gPoints[_gPoints.length - 1] : null;
  var setTile = function(id, val, p) {
    var el = document.getElementById(id);
    if (el) el.textContent = (val === null || val === undefined) ? '--' : val.toFixed(p);
  };
  setTile('g-cur-freq', last ? last.f : null, 2);
  setTile('g-cur-load', last ? last.l : null, 0);
  setTile('g-cur-temp', last ? last.c : null, 1);
  setTile('g-cur-users', last ? last.u : null, 0);
  var tempEl = document.getElementById('g-cur-temp');
  if (tempEl && last) tempEl.style.color = graphTempColor(last.c);
  var fsub = document.getElementById('g-sub-freq');
  if (fsub) fsub.textContent = 'GHz average' + (last && last.fm ? ' · peak core ' + last.fm.toFixed(2) : '');
  var tsub = document.getElementById('g-sub-temp');
  if (tsub && last && last.c !== null && last.c !== undefined) {
    tsub.textContent = last.c >= TEMP_CRIT ? 'degrees C · CRITICAL'
                     : last.c >= TEMP_WARN ? 'degrees C · WARM' : 'degrees C';
  }

  if (pts.length < 2) {
    cv.style.display = 'none';
    if (empty) {
      empty.style.display = 'block';
      empty.textContent = _gMeta.coarse
        ? 'Collecting data — this view plots ' + _gMeta.interval + 's averages, so it fills in as the panel keeps running.'
        : 'Collecting data — a sample is taken every ' + _gMeta.interval + 's, so the first curve appears within a few seconds.';
    }
    return;
  }
  cv.style.display = 'block';
  if (empty) empty.style.display = 'none';

  // ── geometry ──
  var dpr = window.devicePixelRatio || 1;
  var cssW = cv.clientWidth || 800;
  // Type sizes are named once here: the panel geometry is sized around them,
  // so bumping a size and leaving the padding behind is not possible.
  var F_TITLE = '600 13px ' + G_FHEAD;                  // panel heading
  var F_AXIS  = '12px ' + G_FMONO;                      // tick + min/max labels
  var F_NOTE  = '11px ' + G_FMONO;                      // threshold legend
  var PANEL_H = 100, GAP = 36, PAD_L = 64, PAD_R = 14, PAD_T = 22, AXIS_H = 28;
  var cssH = PAD_T + GRAPH_PANELS.length * (PANEL_H + GAP) + AXIS_H;
  cv.style.height = cssH + 'px';
  cv.width = Math.round(cssW * dpr);
  cv.height = Math.round(cssH * dpr);
  var ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  var narrow = cssW < 680;
  var t0 = pts[0].t, t1 = pts[pts.length - 1].t;
  if (t1 === t0) t1 = t0 + 1;
  var plotW = cssW - PAD_L - PAD_R;
  var xOf = function(t) { return PAD_L + (t - t0) / (t1 - t0) * plotW; };

  GRAPH_PANELS.forEach(function(p, pi) {
    var top = PAD_T + pi * (PANEL_H + GAP);
    var bot = top + PANEL_H;
    var vals = pts.map(function(q) { return q[p.key]; })
                  .filter(function(v) { return v !== null && v !== undefined; });

    var hi = graphTop(p, pts);
    var yOf = function(v) { return bot - (v / hi) * PANEL_H; };

    // ── panel title + range label ──
    ctx.font = F_TITLE;
    ctx.fillStyle = G_TXT2;
    ctx.textAlign = 'left';
    ctx.fillText(p.title, PAD_L, top - 8);
    if (p.key === 'c' && !narrow) {
      // The threshold legend lives in the title row.  In the plot the two
      // guides can end up ~9px apart, where their labels would collide with
      // each other and with this title.  On a phone the row is only wide
      // enough for the title and the min/max, so the legend is dropped there
      // and the dashed guides speak for themselves.
      var tw = ctx.measureText(p.title).width;
      ctx.font = F_NOTE;
      ctx.fillStyle = G_WARN; ctx.fillText('– – ' + TEMP_WARN + '° warm', PAD_L + tw + 12, top - 8);
      var ww = ctx.measureText('– – ' + TEMP_WARN + '° warm').width;
      ctx.fillStyle = G_CRIT; ctx.fillText('– – ' + TEMP_CRIT + '° critical', PAD_L + tw + ww + 24, top - 8);
    }
    if (vals.length) {
      ctx.font = F_AXIS;
      ctx.fillStyle = G_TXT3;
      ctx.textAlign = 'right';
      var lo = Math.min.apply(null, vals), up = Math.max.apply(null, vals);
      // On a narrow canvas the spelled-out form runs into the panel title, so
      // it collapses to a range: same two numbers, roughly half the width.
      ctx.fillText(narrow ? (lo.toFixed(p.dec) + ' – ' + graphFmt(up, p))
                          : ('min ' + graphFmt(lo, p) + '   max ' + graphFmt(up, p)),
                   cssW - PAD_R, top - 8);
    }

    // ── recessive grid: baseline plus mid and top gridlines only ──
    ctx.strokeStyle = G_GRID;
    ctx.lineWidth = 1;
    ctx.font = F_AXIS;
    ctx.textAlign = 'right';
    [0, hi / 2, hi].forEach(function(gv) {
      var y = Math.round(yOf(gv)) + 0.5;
      ctx.beginPath(); ctx.moveTo(PAD_L, y); ctx.lineTo(cssW - PAD_R, y); ctx.stroke();
      ctx.fillStyle = G_TXT3;
      var lbl = (p.key === 'u') ? String(Math.round(gv)) : gv.toFixed(p.dec === 2 ? 1 : 0);
      ctx.fillText(lbl, PAD_L - 8, y + 4);
    });

    if (!vals.length) {
      ctx.font = F_AXIS;
      ctx.fillStyle = G_TXT3;
      ctx.textAlign = 'center';
      ctx.fillText('not available on this system', PAD_L + plotW / 2, top + PANEL_H / 2);
      return;
    }

    // ── segments: a null reading breaks the line instead of being bridged,
    // so a gap in the data never looks like a measured value. ──
    var segs = [], cur = [];
    pts.forEach(function(q) {
      var v = q[p.key];
      if (v === null || v === undefined) { if (cur.length) { segs.push(cur); cur = []; } }
      else cur.push(q);
    });
    if (cur.length) segs.push(cur);

    segs.forEach(function(seg) {
      // continueFrom: append to the current subpath instead of starting a new
      // one.  The fill has already moved to the baseline, and a moveTo there
      // would break the polygon into two subpaths and fill the space between.
      var trace = function(continueFrom) {
        seg.forEach(function(q, i) {
          var x = xOf(q.t), y = yOf(q[p.key]);
          if (i === 0) {
            if (continueFrom) ctx.lineTo(x, y); else ctx.moveTo(x, y);
            return;
          }
          if (p.step) ctx.lineTo(x, yOf(seg[i - 1][p.key]));   // hold, then move
          ctx.lineTo(x, y);
        });
      };
      if (seg.length > 1) {
        ctx.beginPath();
        ctx.moveTo(xOf(seg[0].t), bot);
        trace(true);
        ctx.lineTo(xOf(seg[seg.length - 1].t), bot);
        ctx.closePath();
        ctx.fillStyle = G_FILL;
        ctx.fill();
      }
      ctx.lineWidth = 2;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      if (p.key === 'c') {
        // Colour tracks each reading, so the line changes hue exactly where it
        // crosses a threshold.  Colouring the whole run by one value would
        // paint cool history as if it had been hot.
        for (var i = 1; i < seg.length; i++) {
          ctx.beginPath();
          ctx.moveTo(xOf(seg[i - 1].t), yOf(seg[i - 1].c));
          ctx.lineTo(xOf(seg[i].t), yOf(seg[i].c));
          ctx.strokeStyle = graphTempColor(Math.max(seg[i].c, seg[i - 1].c));
          ctx.stroke();
        }
      } else {
        ctx.beginPath();
        trace(false);
        ctx.strokeStyle = G_LINE;
        ctx.stroke();
      }
      if (seg.length === 1) {   // a lone sample still deserves to be visible
        ctx.beginPath();
        ctx.arc(xOf(seg[0].t), yOf(seg[0][p.key]), 2.5, 0, Math.PI * 2);
        ctx.fillStyle = (p.key === 'c') ? graphTempColor(seg[0].c) : G_LINE;
        ctx.fill();
      }
    });

    // Temperature thresholds are the one place colour means something, so the
    // line it refers to is drawn and labelled rather than left implicit.
    if (p.key === 'c') {
      [[TEMP_WARN, 'rgba(255,176,0,', 'warm'], [TEMP_CRIT, 'rgba(255,64,64,', 'critical']]
        .forEach(function(th) {
          if (hi < th[0]) return;
          var ty = Math.round(yOf(th[0])) + 0.5;
          ctx.save();
          ctx.setLineDash([3, 3]);
          ctx.strokeStyle = th[1] + '0.45)';
          ctx.beginPath(); ctx.moveTo(PAD_L, ty); ctx.lineTo(cssW - PAD_R, ty); ctx.stroke();
          ctx.restore();
        });
    }
  });

  // ── shared time axis ──
  var axisY = PAD_T + GRAPH_PANELS.length * (PANEL_H + GAP) - GAP + 14;
  ctx.font = F_AXIS;
  ctx.fillStyle = G_TXT3;
  ctx.textAlign = 'center';
  var TICKS = Math.max(2, Math.min(6, Math.floor(plotW / 130)));
  for (var i = 0; i <= TICKS; i++) {
    var tt = t0 + (t1 - t0) * i / TICKS;
    var lbl = new Date(tt * 1000).toLocaleTimeString('en-GB', {hour: '2-digit', minute: '2-digit'});
    var x = xOf(tt);
    ctx.textAlign = (i === 0) ? 'left' : (i === TICKS ? 'right' : 'center');
    ctx.fillText(lbl, x, axisY);
  }

  // ── crosshair + tooltip ──
  if (_gHover !== null && _gHover >= 0 && _gHover < pts.length) {
    var hp = pts[_gHover];
    var hx = xOf(hp.t);
    ctx.save();
    ctx.setLineDash([2, 3]);
    ctx.strokeStyle = G_CUR;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(hx + 0.5, PAD_T - 8);
    ctx.lineTo(hx + 0.5, PAD_T + GRAPH_PANELS.length * (PANEL_H + GAP) - GAP);
    ctx.stroke();
    ctx.restore();
    GRAPH_PANELS.forEach(function(p, pi) {
      var v = hp[p.key];
      if (v === null || v === undefined) return;
      var top = PAD_T + pi * (PANEL_H + GAP), bot = top + PANEL_H;
      var y = bot - (v / graphTop(p, pts)) * PANEL_H;
      ctx.beginPath();
      ctx.arc(hx, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = (p.key === 'c') ? graphTempColor(v) : G_LINE;
      ctx.fill();
      ctx.lineWidth = 2;                       // surface ring keeps the marker
      ctx.strokeStyle = G_BG;             // readable on top of the line
      ctx.stroke();
    });
  }
}

function graphHover(ev) {
  var cv = document.getElementById('graph-canvas');
  var tip = document.getElementById('graph-tooltip');
  if (!cv || !tip) return;
  var pts = graphVisible();
  if (pts.length < 2) return;
  var rect = cv.getBoundingClientRect();
  var x = ev.clientX - rect.left;
  var PAD_L = 52, PAD_R = 12;
  var plotW = rect.width - PAD_L - PAD_R;
  var t0 = pts[0].t, t1 = pts[pts.length - 1].t;
  var frac = Math.max(0, Math.min(1, (x - PAD_L) / plotW));
  var want = t0 + frac * (t1 - t0);
  var best = 0, bestD = Infinity;
  pts.forEach(function(p, i) {
    var d = Math.abs(p.t - want);
    if (d < bestD) { bestD = d; best = i; }
  });
  _gHover = best;
  var p = pts[best];
  var rows = GRAPH_PANELS.map(function(pl) {
    var v = p[pl.key];
    return '<div style="display:flex;gap:.8rem;justify-content:space-between;">' +
           '<span style="color:var(--text3);">' + pl.title + '</span>' +
           '<span style="color:' + ((pl.key === 'c') ? graphTempColor(v) : 'var(--text)') + ';">' +
           graphFmt(v === undefined ? null : v, pl) + '</span></div>';
  }).join('');
  tip.innerHTML = '<div style="color:var(--green);margin-bottom:.25rem;">' +
    new Date(p.t * 1000).toLocaleTimeString('en-GB') + '</div>' + rows;
  tip.style.display = 'block';
  // Flip the tooltip to the other side near the right edge so it never
  // overflows the card it lives in.
  var card = cv.parentElement;
  var cardRect = card.getBoundingClientRect();
  var tw = tip.offsetWidth || 150;
  var left = ev.clientX - cardRect.left + 14;
  if (left + tw > cardRect.width) left = ev.clientX - cardRect.left - tw - 14;
  tip.style.left = Math.max(4, left) + 'px';
  tip.style.top  = (ev.clientY - cardRect.top + 12) + 'px';
  drawGraphs();
}

function graphLeave() {
  _gHover = null;
  var tip = document.getElementById('graph-tooltip');
  if (tip) tip.style.display = 'none';
  drawGraphs();
}

function initGraphs() {
  graphThemeColors();
  var cv = document.getElementById('graph-canvas');
  if (cv && !cv._wired) {
    cv._wired = true;
    cv.parentElement.style.position = 'relative';
    cv.addEventListener('mousemove', graphHover);
    cv.addEventListener('mouseleave', graphLeave);
    window.addEventListener('resize', function() { if (currentPage === 'graphs') drawGraphs(); });
  }
  loadGraphs(false);
  graphSchedulePoll();
}

async function loadUsers() {
  var tbody = document.getElementById('users-tbody');
  var info  = document.getElementById('users-info-label');
  var errEl = document.getElementById('users-error');
  var CL = 'padding:.38rem .6rem;border-bottom:1px solid var(--border);vertical-align:middle;';
  function msgRow(msg, color) {
    tbody.innerHTML = '';
    var tr = document.createElement('tr'); var td = document.createElement('td');
    td.colSpan = 8;
    td.style.cssText = 'color:' + (color||'var(--text3)') + ';text-align:center;padding:.8rem;';
    td.textContent = msg; tr.appendChild(td); tbody.appendChild(tr);
  }
  if (tbody) msgRow('Loading...', 'var(--text3)');
  try {
    // Through the admin API, not /users: proxy.py would route that by the rx
    // cookie and show only the receiver last opened with ?rx=.
    var r = await fetch('/admin/api/sdr-users', {cache: 'no-store'});
    if (!r.ok) throw new Error('HTTP ' + r.status);
    var data = await r.json();
    if (!data.ok) throw new Error(data.error || 'no receiver answered');
    var users = data.users || [];
    var multi = !!data.multi;
    var rxTh = document.getElementById('users-rx-th');
    if (rxTh) rxTh.style.display = multi ? '' : 'none';
    if (errEl) errEl.style.display = 'none';
    if (info)  info.textContent = users.length + ' connected';
    umapUpdate(users);
    if (!tbody) return;
    if (!users.length) { msgRow('No users currently connected', ''); return; }
    var now = Date.now();
    tbody.innerHTML = '';
    users.forEach(function(u) {
      if (!_uConnTimes[u.id])
        _uConnTimes[u.id] = now - (u.duration_s || 0) * 1000;
      var tr = document.createElement('tr');
      // Name / callsign the listener typed next to Open Additional Info
      var tdName = document.createElement('td');
      tdName.style.cssText = CL + 'color:var(--text);font-weight:bold;white-space:nowrap;';
      tdName.textContent = u.name || '--';
      tr.appendChild(tdName);
      // IP / location — the IP only here: the public /users no longer has it
      var tdGeo = document.createElement('td');
      tdGeo.style.cssText = CL + 'color:var(--green);';
      if (isLocalIp(u.ip) || u.geo === 'Local') {
        tdGeo.textContent = 'Local';
      } else if (u.geo && u.geo !== u.ip) {
        tdGeo.textContent = u.geo;
      } else {
        tdGeo.textContent = '--';
      }
      if (u.ip) {
        var ipEl = document.createElement('div');
        ipEl.style.cssText = 'color:var(--text3);font-size:.65rem;';
        ipEl.textContent = u.ip.replace(/^::ffff:/, '');
        tdGeo.appendChild(ipEl);
      }
      tr.appendChild(tdGeo);
      // Receiver (only with several receivers)
      if (multi) {
        var tdRx = document.createElement('td');
        tdRx.style.cssText = CL + 'color:var(--text2);font-size:.7rem;';
        tdRx.textContent = u.rx || '--';
        tr.appendChild(tdRx);
      }
      // Frequency
      var tdF = document.createElement('td');
      tdF.style.cssText = CL + 'color:var(--amber);';
      tdF.textContent = _uFmtFreq(u.freq_khz);
      tr.appendChild(tdF);
      // Mode
      var tdM = document.createElement('td');
      tdM.style.cssText = CL + 'color:var(--text2);font-size:.7rem;';
      tdM.textContent = (u.mode || '--').toUpperCase() +
                        (u.decoder && u.mode !== 'drm' ? ' · ' + u.decoder : '');
      tr.appendChild(tdM);
      // Duration (live ticking)
      var tdDur = document.createElement('td');
      tdDur.className = 'u-dur-cell';
      tdDur.dataset.uid = u.id;
      tdDur.style.cssText = CL + 'color:var(--blue);font-variant-numeric:tabular-nums;';
      tdDur.textContent = _uFmtDur(now - _uConnTimes[u.id]);
      tr.appendChild(tdDur);
      // Kick button
      var tdK = document.createElement('td');
      tdK.style.cssText = CL;
      var rawIp = (u.ip||'').replace(/^::ffff:/,'');
      if (rawIp && rawIp !== '127.0.0.1' && rawIp !== '::1') {
        var btn = document.createElement('button');
        btn.className = 'btn btn-red';
        btn.style.cssText = 'padding:.25rem .6rem;font-size:.65rem;';
        btn.textContent = '⚡ KICK';
        btn.onclick = (function(ip){ return function(){ kickUser(ip); }; })(rawIp);
        tdK.appendChild(btn);
        var bb = document.createElement('button');
        bb.className = 'btn btn-amber';
        bb.style.cssText = 'padding:.25rem .6rem;font-size:.65rem;margin-left:.3rem;';
        bb.textContent = '⛔ BAN ▾';
        bb.onclick = (function(ip, nm){ return function(){
          openBanMenu(this, function(h){ banUser(ip, nm, h); });
        }; })(rawIp, u.name || '');
        tdK.appendChild(bb);
      }
      tdK.style.whiteSpace = 'nowrap';
      tr.appendChild(tdK);
      tbody.appendChild(tr);
    });
    loadBans();
    var liveIds = new Set(users.map(function(u){ return u.id; }));
    Object.keys(_uConnTimes).forEach(function(id){
      if (!liveIds.has(id)) delete _uConnTimes[id];
    });
  } catch(e) {
    if (errEl) { errEl.textContent = 'Cannot read the users list: ' + e.message; errEl.style.display = 'block'; }
    if (tbody)  msgRow('Error: ' + e.message, 'var(--red)');
  }
}

async function kickUser(ip) {
  if (!confirm('Kick ' + ip + '? This will disconnect all their connections.')) return;
  try {
    var r = await fetch('/admin/api/kick', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ip: ip})
    });
    var d = await r.json();
    if (d.ok) { toast('Kicked ' + ip); setTimeout(loadUsers, 1800); }
    else toast(d.msg || 'Kick failed', 'err');
  } catch(e) {
    toast('Kick sent — refreshing...', 'ok');
    setTimeout(loadUsers, 2000);
  }
}

// "⛔ BAN ▾" menu: 8/16/24 h under the button, in the theme's colours.
var BAN_HOURS = [8, 16, 24];
function closeBanMenu() {
  var m = document.getElementById('ban-menu');
  if (m) m.remove();
  document.removeEventListener('mousedown', _banMenuOutside, true);
  document.removeEventListener('keydown', _banMenuKey, true);
  window.removeEventListener('scroll', closeBanMenu, true);
}
function _banMenuOutside(e) {
  var m = document.getElementById('ban-menu');
  if (m && !m.contains(e.target)) closeBanMenu();
}
function _banMenuKey(e) { if (e.key === 'Escape') closeBanMenu(); }
function openBanMenu(btn, onPick) {
  var was = document.getElementById('ban-menu');
  closeBanMenu();
  if (was && was._btn === btn) return;          // second click closes it
  var m = document.createElement('div');
  m.id = 'ban-menu';
  m.className = 'ban-menu';
  m._btn = btn;
  BAN_HOURS.forEach(function(h) {
    var it = document.createElement('div');
    it.textContent = h + ' hours';
    it.onclick = function() { closeBanMenu(); onPick(h); };
    m.appendChild(it);
  });
  document.body.appendChild(m);
  var r = btn.getBoundingClientRect();
  var top = r.bottom + 2;
  if (top + m.offsetHeight > window.innerHeight) top = r.top - m.offsetHeight - 2;
  m.style.top = top + 'px';
  m.style.left = Math.max(4, Math.min(r.left, window.innerWidth - m.offsetWidth - 4)) + 'px';
  setTimeout(function() {
    document.addEventListener('mousedown', _banMenuOutside, true);
    document.addEventListener('keydown', _banMenuKey, true);
    window.addEventListener('scroll', closeBanMenu, true);
  }, 0);
}

async function banUser(ip, name, hours) {
  hours = hours || 24;
  var who = name ? name + ' (' + ip + ')' : ip;
  if (!confirm('Ban ' + who + ' for ' + hours + ' hours? They are disconnected from every receiver and refused until the ban runs out.')) return;
  try {
    var r = await fetch('/admin/api/ban', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ip: ip, name: name, hours: hours})
    });
    var d = await r.json();
    toast(d.msg || (d.ok ? 'Banned ' + ip : 'Ban failed'), d.ok ? 'ok' : 'err');
    setTimeout(loadUsers, 1800);
  } catch(e) {
    toast('Ban sent — refreshing...', 'ok');
    setTimeout(loadUsers, 2000);
  }
}

async function unbanUser(ip) {
  if (!confirm('Lift the ban on ' + ip + '?')) return;
  try {
    var r = await fetch('/admin/api/unban', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ip: ip})
    });
    var d = await r.json();
    toast(d.msg || 'Unbanned ' + ip, d.ok ? 'ok' : 'err');
  } catch(e) {
    toast('Unban failed: ' + e.message, 'err');
  }
  loadBans();
}

async function loadBans() {
  var card = document.getElementById('bans-card');
  var tbody = document.getElementById('bans-tbody');
  if (!card || !tbody) return;
  try {
    var r = await fetch('/admin/api/bans', {cache: 'no-store'});
    var d = await r.json();
    var bans = (d && d.bans) || [];
    card.style.display = bans.length ? '' : 'none';
    tbody.innerHTML = '';
    var CL = 'padding:.38rem .6rem;border-bottom:1px solid var(--border);vertical-align:middle;';
    bans.forEach(function(b) {
      var tr = document.createElement('tr');
      var tdN = document.createElement('td');
      tdN.style.cssText = CL + 'color:var(--text);font-weight:bold;';
      tdN.textContent = b.name || '--';
      tr.appendChild(tdN);
      var tdI = document.createElement('td');
      tdI.style.cssText = CL + 'color:var(--green);';
      tdI.textContent = b.ip;
      tr.appendChild(tdI);
      var tdU = document.createElement('td');
      tdU.style.cssText = CL + 'color:var(--text2);';
      tdU.textContent = 'until ' + new Date(b.until * 1000).toLocaleString();
      tr.appendChild(tdU);
      var tdB = document.createElement('td');
      tdB.style.cssText = CL + 'text-align:right;';
      var btn = document.createElement('button');
      btn.className = 'btn btn-green';
      btn.style.cssText = 'padding:.25rem .6rem;font-size:.65rem;';
      btn.textContent = 'UNBAN';
      btn.onclick = function(){ unbanUser(b.ip); };
      tdB.appendChild(btn);
      tr.appendChild(tdB);
      tbody.appendChild(tr);
    });
  } catch(e) { /* keep the last list */ }
}

function toggleUsersAutoRefresh() {
  var btn = document.getElementById('users-auto-btn');
  if (_usersAutoTimer) {
    clearInterval(_usersAutoTimer); _usersAutoTimer = null;
    if (btn) { btn.textContent = '▶ AUTO'; btn.classList.replace('btn-amber','btn-green'); }
  } else {
    loadUsers();
    _usersAutoTimer = setInterval(function(){
      if (currentPage === 'users') loadUsers();
      else { clearInterval(_usersAutoTimer); _usersAutoTimer = null; }
    }, 5000);
    if (btn) { btn.textContent = '⏸ AUTO ON'; btn.classList.replace('btn-green','btn-amber'); }
  }
}

// ── Listener map ──────────────────────────────────────────────────────────────
// Leaflet comes from unpkg and is loaded the first time the Users page opens.
// Coordinates come from /admin/api/users-geo (ip-api.com, cached server side);
// listeners in the same place share one marker. Popups are built with
// textContent — geo text is from an outside service.
var _umap = null, _umapLayer = null, _umapHome = null, _umapKeys = '', _umapLoading = null;

function _umapLoadLeaflet() {
  if (window.L) return Promise.resolve();
  if (_umapLoading) return _umapLoading;
  _umapLoading = new Promise(function(resolve, reject) {
    var css = document.createElement('link');
    css.rel = 'stylesheet';
    css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    css.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
    css.crossOrigin = '';
    document.head.appendChild(css);
    var js = document.createElement('script');
    js.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    js.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
    js.crossOrigin = '';
    js.onload = function() { resolve(); };
    js.onerror = function() { _umapLoading = null; reject(new Error('Leaflet did not load from unpkg.com')); };
    document.head.appendChild(js);
  });
  return _umapLoading;
}

// Centre of a Maidenhead locator of 2–10 characters (same as the APRS map).
function _umapLocator(loc) {
  var s = String(loc || '').trim().toUpperCase();
  if (!/^[A-R]{2}([0-9]{2}([A-X]{2}([0-9]{2}([A-X]{2})?)?)?)?$/.test(s)) return null;
  var lon = -180, lat = -90, w = 20, h = 10;
  lon += (s.charCodeAt(0) - 65) * w; lat += (s.charCodeAt(1) - 65) * h;
  var steps = [[10, 10, 48], [24, 24, 65], [10, 10, 48], [24, 24, 65]];
  for (var i = 2, k = 0; i < s.length; i += 2, k++) {
    w /= steps[k][0]; h /= steps[k][1];
    lon += (s.charCodeAt(i) - steps[k][2]) * w;
    lat += (s.charCodeAt(i + 1) - steps[k][2]) * h;
  }
  return [lat + h / 2, lon + w / 2];
}

function _umapInit() {
  _umap = L.map('umap', {worldCopyJump: true}).setView([30, 10], 2);
  // The same map, and below the same marker colours, as the APRS window
  // (frontend/src/lib/aprsMap.js).
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'
  }).addTo(_umap);
  _umapLayer = L.layerGroup().addTo(_umap);
}

async function umapUpdate(users) {
  var info = document.getElementById('umap-info');
  try {
    await _umapLoadLeaflet();
    if (!_umap) _umapInit();
    _umap.invalidateSize();
    var ips = users.map(function(u) { return (u.ip || '').replace(/^::ffff:/, ''); });
    var r = await fetch('/admin/api/users-geo', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ips: ips})
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    var d = await r.json();
    var geo = d.geo || {};
    _umapHome = _umapLocator(d.grid);
    // Group listeners by place
    var places = {}, local = 0, unknown = 0;
    users.forEach(function(u, i) {
      var g = geo[ips[i]];
      if (!g) { if (isLocalIp(u.ip) || u.geo === 'Local') local++; else unknown++; return; }
      var key = g.lat.toFixed(3) + ',' + g.lon.toFixed(3);
      if (!places[key]) places[key] = {g: g, list: []};
      places[key].list.push(u);
    });
    _umapLayer.clearLayers();
    var pts = [];
    if (_umapHome) {
      L.circleMarker(_umapHome, {radius: 7, color: '#f59e0b', weight: 2, fillColor: '#fbbf24', fillOpacity: .9})
        .bindTooltip('This station (' + d.grid + ')').addTo(_umapLayer);
      pts.push(_umapHome);
    }
    Object.keys(places).forEach(function(key) {
      var p = places[key], ll = [p.g.lat, p.g.lon];
      pts.push(ll);
      if (_umapHome)
        L.polyline([_umapHome, ll], {color: '#10b981', weight: 2, opacity: .7, dashArray: '4 6'}).addTo(_umapLayer);
      var box = document.createElement('div');
      var head = document.createElement('div');
      head.className = 'umap-pop-head';
      head.textContent = [p.g.city, p.g.country].filter(Boolean).join(', ') + '  (' + p.list.length + ')';
      box.appendChild(head);
      p.list.forEach(function(u) {
        var row = document.createElement('div');
        row.textContent = (u.rx ? u.rx + ' · ' : '') + _uFmtFreq(u.freq_khz) + ' ' +
                          (u.mode || '--').toUpperCase() +
                          (u.decoder && u.mode !== 'drm' ? ' · ' + u.decoder : '') +
                          ' · ' + (u.ip || '').replace(/^::ffff:/, '');
        box.appendChild(row);
      });
      L.circleMarker(ll, {radius: Math.min(5 + 2 * p.list.length, 16), color: '#065f46', weight: 2,
                          fillColor: '#34d399', fillOpacity: .9})
        .bindPopup(box).addTo(_umapLayer);
    });
    // Re-frame only when the set of places changes, so a manual zoom survives AUTO.
    var keys = Object.keys(places).sort().join('|');
    if (keys !== _umapKeys) {
      _umapKeys = keys;
      if (pts.length > 1) _umap.fitBounds(pts, {padding: [30, 30], maxZoom: 7});
      else if (pts.length === 1) _umap.setView(pts[0], 5);
    }
    if (info) info.textContent = Object.keys(places).length + ' places' +
      (local ? ' · ' + local + ' local' : '') + (unknown ? ' · ' + unknown + ' not located' : '');
  } catch(e) {
    if (info) info.textContent = 'Map: ' + e.message;
  }
}

// ── Waterfall Message ─────────────────────────────────────────────────────────
document.getElementById('wfmsg-text')?.addEventListener('input', function() {
  var n = this.value.length;
  var el = document.getElementById('wfmsg-charcount');
  if (el) { el.textContent = n + ' / 200'; el.style.color = n > 180 ? 'var(--amber)' : 'var(--text3)'; }
});

async function sendWfMsg() {
  var text  = (document.getElementById('wfmsg-text')?.value || '').trim();
  var color = document.getElementById('wfmsg-color')?.value || '#ffffff';
  var el    = document.getElementById('wfmsg-status');
  if (!text) { el.textContent = '⚠ Message cannot be empty.'; el.style.color = 'var(--red)'; return; }
  el.textContent = 'Broadcasting…'; el.style.color = 'var(--text3)';
  try {
    var r = await fetch('/admin/api/wf-message', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({text: text, color: color})
    });
    var d = await r.json();
    if (d.ok) {
      el.textContent = '✓ Live! All users will see it within 10 s.';
      el.style.color = 'var(--green)';
      var a = document.getElementById('wfmsg-active');
      if (a) { a.textContent = text; a.style.color = 'var(--green)'; }
      toast('WF message broadcast');
    } else {
      el.textContent = '✗ ' + (d.msg || 'Error'); el.style.color = 'var(--red)';
    }
  } catch(e) { el.textContent = '✗ Network error: ' + e.message; el.style.color = 'var(--red)'; }
}

async function clearWfMsg() {
  var el = document.getElementById('wfmsg-status');
  el.textContent = 'Clearing…'; el.style.color = 'var(--text3)';
  try {
    await fetch('/admin/api/wf-message', {method: 'DELETE'});
    el.textContent = '✓ Cleared. Banner disappears within 10 s.';
    el.style.color = 'var(--text3)';
    var a = document.getElementById('wfmsg-active');
    if (a) { a.textContent = '—'; a.style.color = 'var(--text3)'; }
    toast('WF message cleared');
  } catch(e) { el.textContent = '✗ Network error'; el.style.color = 'var(--red)'; }
}

async function loadWfMsgStatus() {
  try {
    var r = await fetch('/admin/api/wf-message');
    var d = await r.json();
    var a = document.getElementById('wfmsg-active');
    if (!a) return;
    a.textContent = d.text || '—';
    a.style.color  = d.text ? 'var(--green)' : 'var(--text3)';
  } catch(_) {}
}

// ─── Init ────────────────────────────────────────────────────────────────────
loadDashboard();
</script>
</body>
</html>"""

# ─── Routes ────────────────────────────────────────────────────────────────────

@app.route("/admin")
@app.route("/admin/")
def login():
    if session.get("authenticated"):
        return redirect(url_for("dashboard"))
    return render_template_string(LOGIN_HTML, error=None)

@app.route("/admin", methods=["POST"])
@app.route("/admin/", methods=["POST"])
def login_post():
    pwd = request.form.get("password", "")
    if check_password(pwd):
        session["authenticated"] = True
        session.permanent = True
        if is_first_run():
            return redirect(url_for("setup"))
        return redirect(url_for("dashboard"))
    return render_template_string(LOGIN_HTML, error="Invalid access code. Try again.")

@app.route("/admin/dashboard")
@login_required
def dashboard():
    from flask import make_response
    resp = make_response(render_template_string(MAIN_HTML, fork_origin=fork_origin(),
                                                origin_repo=ORIGIN_REPO))
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    resp.headers['Pragma'] = 'no-cache'
    return resp

@app.route("/admin/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/admin/setup")
def setup():
    if not session.get("authenticated"):
        return redirect(url_for("login"))
    if not is_first_run():
        return redirect(url_for("dashboard"))
    from flask import make_response
    cfg = load_admin_config()
    sdr_port = int(cfg.get("public_port") or PUBLIC_PORT)
    resp = make_response(render_template_string(
        SETUP_HTML,
        sdr_dir=cfg.get("sdr_base_dir") or str(BASE_DIR),
        sdr_port=sdr_port,
        listen_port=int(cfg.get("proxy_port") or sdr_port)))
    resp.headers["Cache-Control"] = "no-store"
    return resp

@app.route("/admin/api/autodetect")
def api_autodetect():
    if not session.get("authenticated"):
        return jsonify({"ok": False}), 403
    return jsonify({"ok": True, "candidates": auto_detect_sdr_candidates()})

@app.route("/admin/api/setup", methods=["POST"])
def api_setup():
    if not session.get("authenticated"):
        return jsonify({"ok": False, "msg": "Not authenticated"}), 403
    if not is_first_run():
        return jsonify({"ok": False, "msg": "Setup already complete"})
    data = request.get_json(silent=True) or {}
    new_password = data.get("new_password", "")
    if len(new_password) < 4:
        return jsonify({"ok": False, "msg": "Password must be at least 4 characters"})
    # Folder and ports come from setup_admin.sh (run by the installer), which is
    # their source of truth — the wizard only fills a gap, never overwrites.
    cfg = load_admin_config()
    if not cfg.get("sdr_base_dir"):
        cfg["sdr_base_dir"] = str(BASE_DIR)
    cfg.setdefault("sdr_process_name", "spectrumserver")
    cfg.setdefault("public_port", PUBLIC_PORT)
    cfg["password_hash"]    = hash_password(new_password)
    cfg["setup_complete"]   = True
    save_admin_config(cfg)
    return jsonify({"ok": True})


# ── API: Status ──────────────────────────────────────────────────────────────
@app.route("/admin/api/status")
@login_required
def api_status():
    try:
        return jsonify({"process": get_process_status(),
                        "system": get_system_stats(),
                        "top_procs": get_top_processes()})
    except Exception as e:
        return jsonify({"process": {"running": False, "pid": None, "name": None,
                                    "cpu": 0, "mem": 0, "uptime": None, "error": str(e)},
                        "system": {}, "top_procs": []})

# ── API: Scripts ─────────────────────────────────────────────────────────────
def _station_conf():
    """station.conf as {KEY: value} (configure-station.sh writes it), or None."""
    path = get_sdr_dir() / "station.conf"
    if not path.exists():
        return None
    out = {}
    for line in read_file_safe(path).splitlines():
        m = re.match(r'\s*([A-Z_][A-Z0-9_]*)=(.*)', line)
        if not m:
            continue
        v = m.group(2).strip()
        if v[:1] in ('"', "'"):
            v = v[1:].split(v[0], 1)[0]
        else:
            v = v.split("#", 1)[0].strip()
        out[m.group(1)] = v
    return out


@app.route("/admin/api/https")
@login_required
def api_https():
    sc = _station_conf()
    mode = (sc or {}).get("STATION_HTTPS", "n") or "n"
    return jsonify({"station_conf": sc is not None, "mode": mode,
                    "https": mode in ("y", "lan"),
                    "host": (sc or {}).get("STATION_PUBLIC_HOST", "")})


@app.route("/admin/api/https/check", methods=["POST"])
@login_required
def api_https_check():
    """setup-https.sh --status: reads state and probes the local Caddy, no root."""
    script = get_sdr_dir() / "setup-https.sh"
    if not script.exists():
        return jsonify({"ok": False, "msg": "setup-https.sh not found in " + str(script.parent)})
    try:
        r = subprocess.run(["bash", str(script), "--status"], cwd=str(script.parent),
                           capture_output=True, text=True, timeout=20, stdin=subprocess.DEVNULL,
                           env=dict(os.environ, PHANTOM_NONINTERACTIVE="1"))
        out = re.sub(r"\x1b\[[0-9;]*m", "", (r.stdout or "") + (r.stderr or "")).strip()
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "output": "setup-https.sh --status took longer than 20 s"})
    # A named station is fine when its certificate answers; a LAN one when Caddy runs.
    ok = r.returncode == 0 and "running" in out and ("✔" in out or "local network" in out) and "!" not in out
    return jsonify({"ok": ok, "output": out})


@app.route("/admin/api/https/precheck", methods=["POST"])
@login_required
def api_https_precheck():
    """What can be verified before setup-https.sh runs, and the command to run."""
    import socket, ipaddress, shlex
    base = get_sdr_dir()
    items, ready = [], True
    sc = _station_conf()
    if not (base / "setup-https.sh").exists():
        items.append({"state": "bad", "text": "setup-https.sh is missing from " + str(base) + " — update PhantomSDR-Plus first."})
        ready = False
    if sc is None:
        items.append({"state": "bad", "text": "No station.conf yet. Run once in a terminal: bash configure-station.sh "
                                             "(on an older station it keeps all your ports)."})
        return jsonify({"items": items, "ready": False})
    items.append({"state": "ok", "text": "station.conf found."})
    host = sc.get("STATION_PUBLIC_HOST", "")
    is_ip = False
    try:
        ipaddress.ip_address(host)
        is_ip = True
    except ValueError:
        pass
    if not host:
        items.append({"state": "bad", "text": "station.conf has no public address. Set your DNS name with: bash configure-station.sh"})
        ready = False
    elif is_ip:
        items.append({"state": "bad", "text": host + " is an IP address. Let's Encrypt certifies names only: get a free "
                                             "dynamic-DNS name, set it with bash configure-station.sh, then come back. "
                                             "(Or use --lan below, for the local network only.)"})
        ready = False
    else:
        try:
            addr = socket.gethostbyname(host)
            items.append({"state": "ok", "text": "DNS name " + host + " resolves (" + addr + ")."})
        except OSError:
            items.append({"state": "warn", "text": "DNS name " + host + " does not resolve yet — the certificate can only "
                                                  "be issued once it does."})
    for port in (443, 80):
        busy = ""
        try:
            busy = subprocess.run(["ss", "-ltnH", "sport = :%d" % port], capture_output=True,
                                  text=True, timeout=5).stdout.strip()
        except Exception:
            pass
        caddy = subprocess.run(["systemctl", "is-active", "--quiet", "caddy"]).returncode == 0
        if busy and caddy:
            items.append({"state": "ok", "text": "Caddy already runs and holds port %d — the script adds this station to it." % port})
        elif busy:
            items.append({"state": "warn", "text": "Something already listens on port %d on this computer. If it is "
                                                  "nginx or Apache, the script keeps it and prints what to add to it." % port})
        else:
            items.append({"state": "ok", "text": "Port %d is free on this computer." % port})
    items.append({"state": "todo", "text": "Router: forward TCP 443 and TCP 80 to this computer (80 is only used to "
                                          "prove the name is yours). This page cannot check it."})
    return jsonify({"items": items, "ready": ready,
                    "commands": ["cd " + shlex.quote(str(base)), "bash setup-https.sh"]})


# ── API: Receivers page ───────────────────────────────────────────────────────
# Every receiver of this station with what it covers; an extra receiver
# (instances/<name>/) can be moved to another band from here — the panel writes
# its four files in step and restarts only that receiver. Adding one, and
# changing the main receiver, need sudo or a page rebuild: the page gives the
# command for a terminal instead.

# Sample rates each launcher's receiver can do, and the frequencies it tunes.
_RX_HW = {
    "start-rtl.sh":     {"type": 2, "label": "RTL-SDR",
                         "rates": [1024000, 1400000, 1800000, 1920000, 2048000, 2400000, 2560000, 2880000, 3200000],
                         "ranges": [(500000, 1766000000)],
                         "note": "Below 24 MHz only an RTL-SDR Blog V4 (or a V3 in direct sampling) receives. Above 2.4 MHz of sample rate some sticks drop samples."},
    "start-airspyhf.sh": {"type": 6, "label": "Airspy HF+",
                         "rates": [192000, 256000, 384000, 456000, 768000, 912000],
                         "ranges": [(9000, 31000000), (60000000, 260000000)], "note": ""},
    "start-rsp1a.sh":   {"type": 3, "label": "SDRplay RSP1A",
                         "rates": [2000000, 4000000, 6000000, 8000000, 10000000],
                         "ranges": [(1000, 2000000000)], "note": ""},
    "start-fobos.sh":   {"type": 4, "label": "Fobos SDR",
                         "rates": [8000000, 10000000, 12500000, 16000000, 20000000, 25000000],
                         "ranges": [(50000000, 6000000000)], "note": ""},
    "start-hackrf.sh":  {"type": 7, "label": "HackRF One",
                         "rates": [2000000, 4000000, 8000000, 10000000, 12500000, 16000000, 20000000],
                         "ranges": [(1000000, 6000000000)], "note": ""},
    "start-rx888mk2.sh": {"type": 1, "label": "RX888 MkII", "rates": [], "ranges": [], "note": ""},
    "start-fobos-hf.sh": {"type": 5, "label": "Fobos SDR (HF direct)", "rates": [], "ranges": [], "note": ""},
}
_RX_TEMPLATES = {1: "config-rx888mk2.toml", 2: "config-rtl.toml", 3: "config-rsp1a.toml",
                 4: "config-fobos.toml", 5: "config-fobos-hf.toml", 6: "config-airspyhf.toml",
                 7: "config-hackrf.toml"}
_RX_ARGS_RE = re.compile(r'^(RX_ARGS|RX_ARGS_MIRI|RX_ARGS_SDRPLAY|RX888_ARGS)=')
_RX_MODES = ["AM", "FM", "WBFM", "USB", "LSB", "CW"]


def _toml_values(path):
    """{(section, key): value-string} — the same plain reading add-receiver.sh does."""
    vals, sect = {}, ""
    try:
        for line in open(path, encoding="utf-8"):
            t = line.split("#", 1)[0].strip()
            m = re.match(r"^\[([^\]]+)\]$", t)
            if m:
                sect = m.group(1)
                continue
            m = re.match(r"^(\w+)\s*=\s*(.+)$", t)
            if m:
                vals[(sect, m.group(1))] = m.group(2).strip().strip('"')
    except OSError:
        pass
    return vals


def _toml_set(lines, sect, key, value, comment=None):
    """Set key in [sect] of a list of lines; keeps the line's comment unless given."""
    start = end = None
    for i, l in enumerate(lines):
        m = re.match(r"^\s*\[([^\]]+)\]\s*(#.*)?$", l)
        if m:
            if start is not None:
                end = i
                break
            if m.group(1) == sect:
                start = i
    if start is None:
        return False
    end = end if end is not None else len(lines)
    for i in range(start + 1, end):
        m = re.match(r"^(\s*)" + re.escape(key) + r"(\s*)=(\s*)[^#]*?(\s*#.*)?$", lines[i])
        if m:
            tail = (" # " + comment) if comment is not None else (m.group(4) or "")
            lines[i] = m.group(1) + key + m.group(2) + "=" + m.group(3) + str(value) + tail
            return True
    lines.insert(start + 1, key + "=" + str(value) + ((" # " + comment) if comment else ""))
    return True


def _env_args(path):
    """[(line index, var, -f value or None, -s value or None)] from an instance.env."""
    out = []
    try:
        lines = read_file_safe(path).splitlines()
    except Exception:
        return out
    for i, l in enumerate(lines):
        m = _RX_ARGS_RE.match(l)
        if m:
            f = re.search(r"(?:^|\s|\")-f\s+(\d+)", l)
            sp = re.search(r"(?:^|\s|\")-s\s+(\d+)", l)
            out.append((i, m.group(1), int(f.group(1)) if f else None, int(sp.group(1)) if sp else None))
    return out


# ── Receiver gain (Receivers page → Change settings) ─────────────────────────
# Kept in the receiver's argument line: instances/<id>/instance.env for an
# extra receiver, main.env for the main one (the launchers read it last; the
# station wizard rewrites station.conf, so it cannot live there).
_RX_GAIN = {"start-rx888mk2.sh": "rx888", "start-rtl.sh": "rtl"}
_RTL_GAINS = [0.0, 0.9, 1.4, 2.7, 3.7, 7.7, 8.7, 12.5, 14.4, 15.7, 16.6, 19.7, 20.7, 22.9, 25.4,
              28.0, 29.7, 32.8, 33.8, 36.4, 37.2, 38.6, 40.2, 42.1, 43.4, 43.9, 44.5, 48.0, 49.6]


def _gain_env_path(rx):
    base = get_sdr_dir()
    return (base / "instances" / rx["instance"] / "instance.env") if rx["instance"] else (base / "main.env")


def _gain_var(kind):
    return "RX888_ARGS" if kind == "rx888" else "RX_ARGS"


def _gain_args(rx, lines):
    """(index of the argument line in lines or None, its value) — the
    launcher's built-in default when the env file has no such line."""
    kind = _RX_GAIN.get(rx.get("launcher", ""))
    var = _gain_var(kind)
    for i, l in enumerate(lines):
        m = re.match(r"^\s*" + var + r"=(.*)$", l)
        if m:
            v = m.group(1).split(" #", 1)[0].strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                v = v[1:-1]
            return i, v
    m = re.search(r"^" + var + r'="\$\{' + var + r':-(.*)\}"\s*$',
                  read_file_safe(get_sdr_dir() / rx["launcher"]), re.M)
    return None, (m.group(1) if m else "")


def _gain_read(rx):
    kind = _RX_GAIN.get(rx.get("launcher", ""))
    if not kind:
        return None
    p = _gain_env_path(rx)
    lines = read_file_safe(p).splitlines() if p.exists() else []
    _, args = _gain_args(rx, lines)
    if not args:
        return None
    flag = lambda f: (re.search(r"(?:^|\s)" + f + r"\s+(\S+)", args) or [None, None])[1]
    if kind == "rx888":
        try:
            return {"kind": kind, "gain": int(flag("-g") or 1), "mode": flag("-m") or "high",
                    "att": int(flag("-a") or 0), "pga": bool(re.search(r"(?:^|\s)--pga(?:\s|$)", args))}
        except ValueError:
            return None
    g = flag("-g")
    try:
        g = "auto" if g is None or float(g) == 0 else float(g)
    except ValueError:
        return None
    return {"kind": kind, "gain": g, "steps": _RTL_GAINS}


def _set_flag(args, f, v):
    """args with flag f set to v (None removes it); a new flag goes before the
    trailing output argument (' -' or ' -o -')."""
    pat = r"(^|\s)" + re.escape(f) + r"\s+\S+"
    if v is None:
        return re.sub(pat, r"\1", args).replace("  ", " ").strip()
    if re.search(pat, args):
        return re.sub(pat, lambda m: m.group(1) + f + " " + str(v), args, count=1)
    m = re.search(r"\s(-o\s+-|-)\s*$", args)
    if m:
        return args[:m.start()] + " " + f + " " + str(v) + args[m.start():]
    return args + " " + f + " " + str(v)


def _gain_apply(rx, lines, g):
    """(lines, changed, error) with the gain in g written into the argument line."""
    kind = _RX_GAIN.get(rx.get("launcher", ""))
    if not kind or not isinstance(g, dict):
        return lines, False, None
    idx, args = _gain_args(rx, lines)
    if not args:
        return lines, False, "cannot find the receiver's argument line"
    new = args
    try:
        if kind == "rx888":
            gain, att = int(g.get("gain")), int(g.get("att", 0))
            mode = str(g.get("mode", "high"))
            if not 0 <= gain <= 127:
                return lines, False, "RX888 gain must be 0 – 127"
            if not 0 <= att <= 63:
                return lines, False, "RX888 attenuation must be 0 – 63"
            if mode not in ("low", "high"):
                return lines, False, "gain mode must be low or high"
            new = _set_flag(_set_flag(_set_flag(new, "-g", gain), "-a", att), "-m", mode)
            new = re.sub(r"(^|\s)--pga(?=\s|$)", r"\1", new).replace("  ", " ").strip()
            if g.get("pga"):
                new = re.sub(r"(-m\s+\S+)", r"\1 --pga", new, count=1)
        else:
            v = g.get("gain")
            if v in (None, "", "auto"):
                new = _set_flag(new, "-g", None)
            else:
                v = float(v)
                if not 0 < v <= 50:
                    return lines, False, "RTL-SDR gain must be auto or 0.9 – 49.6 dB"
                new = _set_flag(new, "-g", ("%g" % v))
    except (TypeError, ValueError):
        return lines, False, "the gain must be a number"
    if new == args:
        return lines, False, None
    line = '%s="%s"' % (_gain_var(kind), new.replace('"', ""))
    lines = list(lines)
    if idx is None:
        if not lines:
            lines = ["# The main receiver's own settings, read last by its start-*.sh",
                     "# (like instances/<id>/instance.env). Written by the admin panel's",
                     "# Receivers page → Change settings."]
        lines.append(line)
    else:
        lines[idx] = line
    return lines, True, None


def _receivers_info():
    """Every receiver: id, name, port, launcher, instance, frequency, span, on air."""
    rt = _receivers_toml().get("receiver", [])
    entries = []
    if rt:
        for r in rt:
            entries.append({"id": str(r.get("id", "")), "name": str(r.get("name") or r.get("id") or ""),
                            "port": int(r.get("port") or 0), "launcher": str(r.get("launcher") or ""),
                            "instance": str(r.get("instance") or "").strip(),
                            "default": bool(r.get("default")), "in_toml": True})
    else:
        port, _ = _main_receiver_port()
        cfg = load_admin_config()
        entries.append({"id": "main", "name": "Main receiver", "port": port or int(cfg.get("public_port", PUBLIC_PORT)),
                        "launcher": "", "instance": "", "default": True, "in_toml": False})
    sc = _station_conf() or {}
    on_air = {r["port"]: r for r in _receiver_list()}
    base = get_sdr_dir()
    out = []
    for e in entries:
        inst = e["instance"]
        launcher = e["launcher"] or sc.get("STATION_LAUNCHER", "")
        if inst:
            conf = base / "instances" / inst / "config.toml"
        else:
            conf = None
            # The running main receiver names its config; else its launcher's CONFIG=.
            if HAS_PSUTIL:
                try:
                    for proc in psutil.process_iter(["name", "cmdline"]):
                        cmd = proc.info.get("cmdline") or []
                        if "spectrumserver" in (proc.info.get("name") or "") and "--config" in cmd:
                            c = Path(cmd[cmd.index("--config") + 1])
                            if "instances" not in c.parts:
                                conf = c
                                break
                except Exception:
                    pass
            if conf is None and launcher and (base / launcher).exists():
                m = re.search(r'^CONFIG="\$PHANTOMDIR/([^"]+)"', read_file_safe(base / launcher), re.M)
                if m:
                    conf = base / m.group(1)
        v = _toml_values(conf) if conf else {}
        try:
            sps = int(v.get(("input", "sps"), 0))
            freq = int(v.get(("input", "frequency"), 0))
            dflt = int(v.get(("input.defaults", "frequency"), 0))
        except ValueError:
            sps = freq = dflt = 0
        real = v.get(("input", "signal"), "iq") == "real" or (sps and freq == 0)
        tune = None
        if inst:
            for _, _, f, _ in _env_args(base / "instances" / inst / "instance.env"):
                if f is not None:
                    tune = f
                    break
        lo, hi = (0, sps // 2) if real else (freq - sps // 2, freq + sps // 2)
        hw = _RX_HW.get(launcher, {})
        st = on_air.get(e["port"], {})
        out.append(dict(e, launcher=launcher, config=str(conf.relative_to(base)) if conf and base in conf.parents else str(conf or ""),
                        hardware=hw.get("label", launcher or "?"), sps=sps, frequency=freq, tune=tune,
                        default_frequency=dflt, modulation=v.get(("input.defaults", "modulation"), ""),
                        direct=bool(real), low=max(lo, 0), high=hi, span=hi - max(lo, 0),
                        fft_size=int(v.get(("input", "fft_size"), 0) or 0),
                        on_air=bool(st.get("pid")), uptime_s=st.get("uptime_s"),
                        changeable=bool(inst) and not real and launcher in _RX_HW and bool(hw.get("rates")),
                        renamable=e["in_toml"],
                        gain=_gain_read({"launcher": launcher, "instance": inst}),
                        # Direct sampling / main: no band to change, but its name, start frequency and mode.
                        settable=bool(conf) and Path(conf).exists() and launcher in _RX_HW and bool(sps),
                        deletable=bool(inst) and not e["default"] and e["in_toml"] and len(entries) > 1,
                        rates=hw.get("rates", []), ranges=hw.get("ranges", []), note=hw.get("note", ""),
                        modes=_RX_MODES))
    return out


@app.route("/admin/api/receivers-info")
@login_required
def api_receivers_info():
    return jsonify({"receivers": _receivers_info(), "station_conf": _station_conf() is not None})


def _receivers_set_defaults(rx, data):
    """A receiver with no band to change (direct sampling, the main one): its
    start frequency and mode in its config, its button name in receivers.toml.
    Restarts only that receiver, and only when the start frequency or mode moved."""
    rid = rx["id"]
    try:
        dflt = int(data.get("default_frequency") or rx["default_frequency"])
    except (TypeError, ValueError):
        return jsonify({"ok": False, "msg": "the start frequency must be a number"})
    mod = str(data.get("modulation") or rx["modulation"] or "AM").upper()
    if mod not in _RX_MODES:
        return jsonify({"ok": False, "msg": "unknown mode " + mod})
    if not (rx["low"] <= dflt <= rx["high"]):
        return jsonify({"ok": False, "msg": "the start frequency must lie inside %.6g – %.6g MHz" % (rx["low"] / 1e6, rx["high"] / 1e6)})
    name = re.sub(r'[\r\n"\\]', "", str(data.get("name") or rx["name"])).strip() or rx["name"]
    base = get_sdr_dir()
    conf_p = Path(rx["config"]) if Path(rx["config"]).is_absolute() else base / rx["config"]
    rt_p = base / "receivers.toml"
    moved = dflt != rx["default_frequency"] or mod != rx["modulation"]
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    bdir = base / "admin-backups" / ("settings-%s-%s" % (rid, stamp))
    env_p = _gain_env_path(rx)
    el, gchanged, gerr = _gain_apply(rx, read_file_safe(env_p).splitlines() if env_p.exists() else [],
                                     data.get("gain"))
    if gerr:
        return jsonify({"ok": False, "msg": gerr})
    try:
        bdir.mkdir(parents=True, exist_ok=True)
        if gchanged:
            if env_p.exists():
                (bdir / env_p.name).write_bytes(env_p.read_bytes())
            env_p.write_text("\n".join(el) + "\n", encoding="utf-8")
        if moved:
            cl = read_file_safe(conf_p).splitlines()
            _toml_set(cl, "input.defaults", "frequency", dflt, "frequency shown first")
            _toml_set(cl, "input.defaults", "modulation", '"%s"' % mod)
            text = "\n".join(cl) + "\n"
            if tomllib is not None:
                tomllib.loads(text)
            (bdir / conf_p.name).write_bytes(conf_p.read_bytes())
            conf_p.write_text(text, encoding="utf-8")
        if rx["renamable"] and name != rx["name"]:
            text = "\n".join(_rt_set_name(read_file_safe(rt_p).splitlines(), rid, name)) + "\n"
            if tomllib is not None:
                tomllib.loads(text)
            (bdir / rt_p.name).write_bytes(rt_p.read_bytes())
            rt_p.write_text(text, encoding="utf-8")
    except Exception as e:
        return jsonify({"ok": False, "msg": "could not write the files: %s" % e})
    moved = moved or gchanged
    restarted, out = False, ""
    if moved and data.get("restart", True):
        restarted, out = run_script(rx["launcher"], args=["-q"],
                                    env={"INSTANCE": rx["instance"]} if rx["instance"] else None)
    with log_lock:
        log_buffer.append("[" + datetime.now().strftime("%H:%M:%S") + "] SETTINGS " + rid + ": %d Hz %s" % (dflt, mod))
    again = ("INSTANCE=%s ./%s" % (rx["instance"], rx["launcher"])) if rx["instance"] else ("./" + rx["launcher"])
    return jsonify({"ok": True, "restarted": restarted,
                    "msg": "Saved (old files in admin-backups/%s). %s" % (bdir.name,
                           ("Restarting " + rid + " — its listeners are back in a few seconds." + chr(10) + out) if restarted
                           else ("Restart it to apply: " + again) if moved else "Nothing to restart.")})


@app.route("/admin/api/receivers-info/retune", methods=["POST"])
@login_required
def api_receivers_retune():
    """Move an extra receiver to another band: instance.env, config.toml,
    www/site_information.json and its button name in receivers.toml, then
    restart it. Its directory-listing name and hardware name stay as they are."""
    data = request.get_json(silent=True) or {}
    rid = str(data.get("id", ""))
    rx = next((r for r in _receivers_info() if r["id"] == rid), None)
    if not rx:
        return jsonify({"ok": False, "msg": "no receiver " + rid})
    if not rx["changeable"]:
        if rx.get("settable"):
            return _receivers_set_defaults(rx, data)
        return jsonify({"ok": False, "msg": "this receiver cannot be changed from here"})
    try:
        f_new = int(data["frequency"])
        sps_new = int(data["sps"])
        dflt = int(data.get("default_frequency") or f_new)
    except (KeyError, TypeError, ValueError):
        return jsonify({"ok": False, "msg": "frequency, sample rate and start frequency must be numbers"})
    name = re.sub(r"[\r\n\"]", "", str(data.get("name") or rx["name"])).strip() or rx["name"]
    mod = str(data.get("modulation") or rx["modulation"] or "AM").upper()
    if mod not in _RX_MODES:
        return jsonify({"ok": False, "msg": "unknown mode " + mod})
    if sps_new not in rx["rates"] and sps_new != rx["sps"]:
        return jsonify({"ok": False, "msg": "%s cannot do %d samples per second" % (rx["hardware"], sps_new)})
    lo, hi = f_new - sps_new // 2, f_new + sps_new // 2
    if not any(a <= f_new <= b for a, b in rx["ranges"]):
        return jsonify({"ok": False, "msg": "%s does not tune %.6g MHz" % (rx["hardware"], f_new / 1e6)})
    if not (lo <= dflt <= hi):
        return jsonify({"ok": False, "msg": "the start frequency must lie inside %.6g – %.6g MHz" % (lo / 1e6, hi / 1e6)})

    base = get_sdr_dir()
    idir = base / "instances" / rx["instance"]
    env_p, conf_p, site_p = idir / "instance.env", idir / "config.toml", idir / "www" / "site_information.json"

    # The crystal correction is an error in ppm: keep it, scaled to the new band.
    tune_old = rx["tune"] or rx["frequency"]
    ppm = (rx["frequency"] - tune_old) / tune_old if tune_old else 0.0
    f_conf = int(round(f_new * (1 + ppm)))
    fft = rx["fft_size"]
    if fft and rx["sps"]:
        # Same Hz per bin as before, as a power of two.
        import math
        fft = int(2 ** round(math.log2(max(fft * sps_new / rx["sps"], 1))))
        fft = min(max(fft, 16384), 4194304)

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    try:
        # instance.env: -f and -s on every argument line
        el = read_file_safe(env_p).splitlines()
        for i, _, _, _ in _env_args(env_p):
            el[i] = re.sub(r"((?:^|\s|\")-f\s+)\d+", lambda m: m.group(1) + str(f_new), el[i])
            el[i] = re.sub(r"((?:^|\s|\")-s\s+)\d+", lambda m: m.group(1) + str(sps_new), el[i])
        el, _, gerr = _gain_apply(rx, el, data.get("gain"))
        if gerr:
            return jsonify({"ok": False, "msg": gerr})
        # config.toml
        cl = read_file_safe(conf_p).splitlines()
        corr = f_conf - f_new
        _toml_set(cl, "input", "frequency", f_conf,
                  "Baseband frequency: the receiver tunes %d (-f in instance.env)%s" % (
                      f_new, "; %+d Hz here keeps its crystal correction (%+.2f ppm)" % (corr, ppm * 1e6) if corr else ""))
        _toml_set(cl, "input", "sps", sps_new, "Input Sample Rate — must match -s in instance.env")
        if fft:
            _toml_set(cl, "input", "fft_size", fft)
        _toml_set(cl, "input.defaults", "frequency", dflt, "frequency shown first")
        _toml_set(cl, "input.defaults", "modulation", '"%s"' % mod)
        # www/site_information.json — read by the page when it opens, no rebuild
        site = json.loads(read_file_safe(site_p)) if site_p.exists() else {}
        site.update({"siteSDRBaseFrequency": max(lo, 0), "siteSDRBandwidth": sps_new})
        # receivers.toml: the button name
        rt_p = base / "receivers.toml"
        rtl = _rt_set_name(read_file_safe(rt_p).splitlines(), rid, name)
        # Keep the old files beside the new ones, then write.
        bdir = base / "admin-backups" / ("retune-%s-%s" % (rx["instance"], stamp))
        bdir.mkdir(parents=True, exist_ok=True)
        for src in (env_p, conf_p, site_p, rt_p):
            if src.exists():
                (bdir / src.name).write_bytes(src.read_bytes())
        env_p.write_text("\n".join(el) + "\n", encoding="utf-8")
        conf_p.write_text("\n".join(cl) + "\n", encoding="utf-8")
        site_p.write_text(json.dumps(site, indent="\t", ensure_ascii=False) + "\n", encoding="utf-8")
        rt_p.write_text("\n".join(rtl) + "\n", encoding="utf-8")
    except Exception as e:
        return jsonify({"ok": False, "msg": "could not write the files: %s" % e})

    restarted, out = False, ""
    if data.get("restart", True):
        restarted, out = run_script(rx["launcher"], args=["-q"], env={"INSTANCE": rx["instance"]})
    with log_lock:
        log_buffer.append("[" + datetime.now().strftime("%H:%M:%S") + "] RETUNE " + rid + ": %d Hz, %d sps" % (f_new, sps_new))
    return jsonify({"ok": True, "restarted": restarted,
                    "msg": "Saved (old files in admin-backups/%s). %s" % (bdir.name,
                           ("Restarting " + rid + " — its listeners are back in a few seconds." + chr(10) + out) if restarted
                           else "Restart it to apply: INSTANCE=%s ./%s" % (rx["instance"], rx["launcher"]))})


def _rt_blocks(lines):
    """[(first line, end line, id)] of every [[receiver]] block in receivers.toml.
    A block runs to the next table header; comment lines just above that header
    belong to the next block."""
    heads = [i for i, l in enumerate(lines) if re.match(r"^\s*\[", l)]
    out = []
    for n, i in enumerate(heads):
        if not re.match(r"^\s*\[\[receiver\]\]", lines[i]):
            continue
        end = heads[n + 1] if n + 1 < len(heads) else len(lines)
        while end > i + 1 and (not lines[end - 1].strip() or lines[end - 1].lstrip().startswith("#")) \
                and end < len(lines):
            end -= 1
        rid = None
        for l in lines[i + 1:end]:
            m = re.match(r'^\s*id\s*=\s*"([^"]*)"', l)
            if m:
                rid = m.group(1)
                break
        out.append((i, end, rid))
    return out


def _rt_set_name(lines, rid, name):
    """receivers.toml lines with the button name of receiver rid set to name
    (a name line is added when the block has none)."""
    name = re.sub(r'[\r\n"\\]', "", name)
    for a, b, r in _rt_blocks(lines):
        if r != rid:
            continue
        for i in range(a + 1, b):
            if re.match(r"^\s*name\s*=", lines[i]):
                lines[i] = re.sub(r'=\s*"[^"]*"', lambda m: '= "%s"' % name, lines[i], count=1)
                break
        else:
            for i in range(a + 1, b):
                if re.match(r"^\s*id\s*=", lines[i]):
                    lines.insert(i + 1, 'name = "%s"' % name)
                    break
        break
    return lines


def _rt_write(rt_p, lines, backup_name):
    """Write receivers.toml after checking it still parses; the old one goes to
    admin-backups/<backup_name>/. Returns the backup folder."""
    text = "\n".join(lines) + "\n"
    tomllib.loads(text)
    bdir = get_sdr_dir() / "admin-backups" / backup_name
    bdir.mkdir(parents=True, exist_ok=True)
    (bdir / rt_p.name).write_bytes(rt_p.read_bytes())
    rt_p.write_text(text, encoding="utf-8")
    return bdir


@app.route("/admin/api/receivers-info/rename", methods=["POST"])
@login_required
def api_receivers_rename():
    """The name on a receiver's button (receivers.toml). Nothing restarts: the
    proxy re-reads receivers.toml and open pages show it on their next look."""
    data = request.get_json(silent=True) or {}
    rid = str(data.get("id", ""))
    name = re.sub(r'[\r\n"\\]', "", str(data.get("name") or "")).strip()
    rx = next((r for r in _receivers_info() if r["id"] == rid), None)
    if not rx or not rx["renamable"]:
        return jsonify({"ok": False, "msg": "no receiver %s in receivers.toml" % rid})
    if not name:
        return jsonify({"ok": False, "msg": "give it a name"})
    if len(name) > 60:
        return jsonify({"ok": False, "msg": "60 characters at most"})
    rt_p = get_sdr_dir() / "receivers.toml"
    try:
        bdir = _rt_write(rt_p, _rt_set_name(read_file_safe(rt_p).splitlines(), rid, name),
                         "rename-%s-%s" % (rid, datetime.now().strftime("%Y%m%d-%H%M%S")))
    except Exception as e:
        return jsonify({"ok": False, "msg": "could not write receivers.toml: %s" % e})
    with log_lock:
        log_buffer.append("[" + datetime.now().strftime("%H:%M:%S") + "] RENAME " + rid + ": " + name)
    return jsonify({"ok": True, "msg": "Renamed to \"%s\" (old receivers.toml in admin-backups/%s). "
                    "Listeners see it the next time their page reads the receiver list." % (name, bdir.name)})


def _instance_pids(inst):
    """PIDs of this tree's processes started with INSTANCE=inst."""
    pids = []
    if not HAS_PSUTIL:
        return pids
    base = str(get_sdr_dir())
    for proc in psutil.process_iter(["pid"]):
        try:
            env = proc.environ()
        except Exception:
            continue
        if env.get("PHANTOMSDR_INSTANCE") == inst and env.get("PHANTOMSDR_TREE", base) == base:
            pids.append(proc.pid)
    return pids


@app.route("/admin/api/receivers-info/power", methods=["POST"])
@login_required
def api_receivers_power():
    """Stop or start one receiver; the others keep running. A stopped receiver
    comes back with ./start-all.sh, the panel's Restart or a thermal-guard
    restart (they start everything in receivers.toml)."""
    data = request.get_json(silent=True) or {}
    rid, action = str(data.get("id", "")), str(data.get("action", ""))
    rx = next((r for r in _receivers_info() if r["id"] == rid), None)
    if not rx:
        return jsonify({"ok": False, "msg": "no receiver " + rid})
    inst = rx["instance"] or "main"
    if not re.fullmatch(r"[A-Za-z0-9_-]+", inst):
        return jsonify({"ok": False, "msg": "odd instance name " + inst})
    base = get_sdr_dir()
    stamp = "[" + datetime.now().strftime("%H:%M:%S") + "] "
    if action == "stop":
        try:
            subprocess.run(["bash", str(base / "stop-websdr.sh"), inst], cwd=str(base),
                           capture_output=True, text=True, timeout=60, stdin=subprocess.DEVNULL)
        except Exception as e:
            return jsonify({"ok": False, "msg": "could not stop it: %s" % e})
        with log_lock:
            log_buffer.append(stamp + "STOP receiver " + rid)
        return jsonify({"ok": True, "msg": "Stopped " + rid})
    if action == "start":
        if not rx["launcher"] or rx["launcher"] not in _RX_HW:
            return jsonify({"ok": False, "msg": "no known launcher for " + rid})
        if rx["on_air"]:
            return jsonify({"ok": False, "msg": rid + " is already on air"})
        ok, out = run_script(rx["launcher"], args=["-q"], env={"INSTANCE": rx["instance"]} if rx["instance"] else None)
        with log_lock:
            log_buffer.append(stamp + "START receiver " + rid)
        return jsonify({"ok": ok, "msg": out})
    return jsonify({"ok": False, "msg": "action must be stop or start"})


@app.route("/admin/api/receivers-info/delete", methods=["POST"])
@login_required
def api_receivers_delete():
    """Remove an extra receiver for good: stop it (watchdog first), take its
    block out of receivers.toml and its instances/<id>/ folder away — moved to
    admin-backups/ unless keep_copy is false. The main receiver and the default
    one are never removed here."""
    data = request.get_json(silent=True) or {}
    rid = str(data.get("id", ""))
    rx = next((r for r in _receivers_info() if r["id"] == rid), None)
    if not rx:
        return jsonify({"ok": False, "msg": "no receiver " + rid})
    if not rx["deletable"]:
        return jsonify({"ok": False, "msg": "the main or default receiver cannot be removed from here"})
    if str(data.get("confirm", "")) != rid:
        return jsonify({"ok": False, "msg": "type the short name (%s) to confirm" % rid})
    inst = rx["instance"]
    if not re.fullmatch(r"[A-Za-z0-9_-]+", inst):
        return jsonify({"ok": False, "msg": "odd instance name " + inst})
    base = get_sdr_dir()
    idir = base / "instances" / inst
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")

    # 1. stop it, and make sure nothing of it is left running
    try:
        r = subprocess.run(["bash", str(base / "stop-websdr.sh"), inst], cwd=str(base),
                           capture_output=True, text=True, timeout=60, stdin=subprocess.DEVNULL)
    except Exception as e:
        return jsonify({"ok": False, "msg": "could not stop it: %s" % e})
    for _ in range(10):
        left = _instance_pids(inst)
        if not left:
            break
        time.sleep(0.5)
    if left:
        return jsonify({"ok": False, "msg": "it is still running (PID %s) — nothing was removed. "
                        "Stop it with ./stop-websdr.sh %s and try again." % (", ".join(map(str, left)), inst)})

    # 2. receivers.toml
    rt_p = base / "receivers.toml"
    try:
        lines = read_file_safe(rt_p).splitlines()
        blk = [(a, b) for a, b, r in _rt_blocks(lines) if r == rid]
        if not blk:
            return jsonify({"ok": False, "msg": "receivers.toml has no block for " + rid})
        a, b = blk[0]
        del lines[a:b]
        while a < len(lines) and a > 0 and not lines[a].strip() and not lines[a - 1].strip():
            del lines[a]
        bdir = _rt_write(rt_p, lines, "deleted-%s-%s" % (rid, stamp))
    except Exception as e:
        return jsonify({"ok": False, "msg": "could not write receivers.toml (it is stopped, nothing removed): %s" % e})

    # 3. its folder
    kept = ""
    try:
        if idir.is_dir():
            if data.get("keep_copy", True):
                shutil.move(str(idir), str(bdir / inst))
                kept = " Its folder is kept in admin-backups/%s/%s." % (bdir.name, inst)
            else:
                shutil.rmtree(idir)
    except Exception as e:
        return jsonify({"ok": True, "msg": "Removed from receivers.toml, but its folder instances/%s "
                        "could not be removed: %s" % (inst, e)})
    with log_lock:
        log_buffer.append("[" + datetime.now().strftime("%H:%M:%S") + "] DELETE receiver " + rid)
    return jsonify({"ok": True, "msg": "Receiver %s removed: stopped, out of receivers.toml (old one in "
                    "admin-backups/%s).%s Its button disappears from the pages; logwebsdr-%s.txt stays."
                    % (rid, bdir.name, kept, inst)})


def _usb_receivers():
    """Receivers lsusb can see, by USB id."""
    known = {"0bda:2838": "RTL-SDR (RTL2838)", "0bda:2832": "RTL-SDR (RTL2832U)",
             "04b4:00f1": "RX888 MkII", "04b4:00f3": "RX888 (not yet loaded with firmware)",
             "03eb:800c": "Airspy HF+", "1d50:6089": "HackRF One", "1d50:60a1": "Airspy",
             "1df7:3000": "SDRplay RSP1A", "1df7:3010": "SDRplay RSP1A"}
    try:
        txt = subprocess.run(["lsusb"], capture_output=True, text=True, timeout=5).stdout
    except Exception:
        return None
    found = []
    for line in txt.splitlines():
        m = re.search(r"ID ([0-9a-f]{4}:[0-9a-f]{4})", line)
        if m and (m.group(1) in known or m.group(1).startswith("1df7:")):
            found.append(known.get(m.group(1), "SDRplay receiver") + "  (" + m.group(1) + ")")
    return found


@app.route("/admin/api/receivers-info/add-defaults")
@login_required
def api_receivers_add_defaults():
    """Starting values for the Add form: per receiver type from its template."""
    base = get_sdr_dir()
    types = {}
    for t, tpl in _RX_TEMPLATES.items():
        v = _toml_values(base / tpl)
        types[t] = {"frequency": int(v.get(("input", "frequency"), 0) or 0),
                    "sps": int(v.get(("input", "sps"), 0) or 0),
                    "direct": t in (1, 5)}
        for hw in _RX_HW.values():
            if hw["type"] == t:
                types[t].update(rates=hw["rates"], ranges=hw["ranges"])
    sc = _station_conf() or {}
    host = sc.get("STATION_PUBLIC_HOST", "")
    if not host:
        for conf in sorted(base.glob("config*.toml")):
            h = _toml_values(conf).get(("websdr", "hostname"), "")
            if h and not h.isdigit():
                host = h
                break
    taken = [r["id"] for r in _receivers_info()] + [p.name for p in (base / "instances").glob("*") if p.is_dir()]
    return jsonify({"types": types, "host": host, "taken": taken, "usb": _usb_receivers(),
                    "has_receivers_toml": (base / "receivers.toml").exists(), "dir": str(base)})


@app.route("/admin/api/receivers-info/add-plan", methods=["POST"])
@login_required
def api_receivers_add_plan():
    """Check the Add form and write instances/.add-rx.env for add-receiver.sh."""
    d = request.get_json(silent=True) or {}
    base = get_sdr_dir()
    errs = []
    try:
        t = int(d.get("type"))
        assert t in _RX_TEMPLATES
    except Exception:
        return jsonify({"ok": False, "errors": ["choose the receiver type"]})
    name = str(d.get("name", "")).strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", name) or name == "main":
        errs.append("the name may only contain letters, digits, - and _ (and not be \"main\")")
    elif (base / "instances" / name).exists() or name in [r["id"] for r in _receivers_info()]:
        errs.append("a receiver called \"%s\" already exists" % name)
    direct = t in (1, 5)
    try:
        sps = int(d.get("sps"))
        freq = 0 if direct else int(d.get("frequency"))
    except (TypeError, ValueError):
        sps = freq = 0
        errs.append("frequency and sample rate must be numbers")
    hw = next((h for h in _RX_HW.values() if h["type"] == t), {})
    if not direct and hw.get("ranges") and freq and not any(a <= freq <= b for a, b in hw["ranges"]):
        errs.append("%s does not tune %.6g MHz" % (hw["label"], freq / 1e6))
    if sps <= 0:
        errs.append("the sample rate must be above 0")
    host = re.sub(r"\s", "", str(d.get("host", "")))
    host = re.sub(r"^[a-z]+://", "", host).split("/")[0]
    if not host or host.isdigit():
        errs.append("give the station's public address (a DNS name or an IP address)")
    if errs:
        return jsonify({"ok": False, "errors": errs})
    clean = lambda x: re.sub(r"[\r\n\"]", "", str(x or "")).strip()
    yn = lambda k, dflt: "y" if d.get(k, dflt) else "n"
    lines = ["# Written by the admin panel's Receivers page for add-receiver.sh --answers.",
             "# Removed by add-receiver.sh once the receiver is added.",
             "ADD_RX_TYPE=%d" % t, "ADD_RX_SPS=%d" % sps, "ADD_RX_NAME=" + name,
             'ADD_RX_LABEL="%s"' % (clean(d.get("label")) or name),
             'ADD_RX_ANTENNA="%s"' % (clean(d.get("antenna")) or "Antenna"),
             "ADD_RX_HOST=" + host,
             "ADD_RX_DRIVER=" + yn("driver", True), "ADD_RX_PICKER_MAIN=" + yn("picker", True),
             "ADD_RX_ADMIN=" + yn("admin", True), "ADD_RX_START=" + yn("start", True),
             "ADD_RX_PROXY=" + yn("proxy", True)]
    if not direct:
        lines.append("ADD_RX_FREQ=%d" % freq)
    if t == 2:
        lines.append("RTL_V4=" + yn("v4", False))
    path = base / "instances" / ".add-rx.env"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except Exception as e:
        return jsonify({"ok": False, "errors": ["could not write %s: %s" % (path, e)]})
    notes = []
    if t == 1:
        notes.append("An RX888 needs its Rust driver built first (installer, receiver option 1, then ./setup-rx888-udev.sh) — add-receiver.sh does not build it.")
    if not (base / "receivers.toml").exists():
        notes.append("This is the station's first extra receiver: the script also asks which start-*.sh starts your main receiver.")
    return jsonify({"ok": True, "commands": ["cd " + shlex.quote(str(base)),
                                             "./add-receiver.sh --answers instances/.add-rx.env"],
                    "file": "\n".join(lines), "notes": notes})


@app.route("/admin/api/run-default-script", methods=["POST"])
@login_required
def api_run_default_script():
    """Settings page buttons: run the saved default start or stop script."""
    which = (request.get_json(silent=True) or {}).get("which")
    if which == "start":
        name = (load_admin_config().get("start_script") or "").strip()
        if not name:
            return jsonify({"ok": False, "msg": "no default start script set"})
        ok, msg = run_script(name)
    elif which == "stop":
        ok, msg = stop_server()
    else:
        return jsonify({"ok": False, "msg": "which must be start or stop"})
    return jsonify({"ok": ok, "msg": msg})


@app.route("/admin/api/scripts")
@login_required
def api_scripts():
    sh = get_allowed_scripts()
    return jsonify({"start": [k for k in sh if "start" in k.lower()],
                    "stop":  [k for k in sh if "stop"  in k.lower()],
                    "all":   sorted(sh.keys()), "paths": sh})

@app.route("/admin/api/scripts/all-discovered")
@login_required
def api_scripts_all():
    sh     = find_sh_files()
    result = [{"label": k, "path": v, "enabled": True} for k, v in sh.items()]
    return jsonify({"scripts": result})

@app.route("/admin/api/scripts/debug")
@login_required
def api_scripts_debug():
    """Shows exactly which scripts were found and where it looked."""
    base = get_sdr_dir()
    sh = find_sh_files()
    freq_dir = base / "frequencylist"
    return jsonify({
        "base_dir": str(base),
        "frequencylist_exists": freq_dir.exists(),
        "frequencylist_contents": [str(f.name) for f in sorted(freq_dir.glob("*"))] if freq_dir.exists() else [],
        "found_scripts": sh,
    })

# ── API: Server control ───────────────────────────────────────────────────────
@app.route("/admin/api/terminal/exec", methods=["POST"])
@login_required
def api_terminal_exec():
    data = request.get_json(silent=True) or {}
    cmd  = (data.get("cmd") or "").strip()
    # Use sdr_base_dir as default cwd, fallback to /tmp
    default_cwd = str(get_sdr_dir())
    cwd = (data.get("cwd") or "").strip() or default_cwd
    if not os.path.isdir(cwd):
        cwd = default_cwd
    if not cmd:
        return jsonify({"ok": True, "output": "", "cwd": cwd})
    if cmd == "cd" or cmd.startswith("cd ") or cmd == "cd~":
        target = cmd[2:].strip() or "~"
        # Expand ~ and env vars
        target = os.path.expanduser(target)
        target = os.path.expandvars(target)
        if target == "-":
            target = os.environ.get("OLDPWD", cwd)
        new_dir = os.path.realpath(os.path.join(cwd, target) if not os.path.isabs(target) else target)
        if os.path.isdir(new_dir):
            return jsonify({"ok": True, "output": "", "cwd": new_dir})
        return jsonify({"ok": False, "output": "cd: no such directory: " + target, "cwd": cwd})
    if cmd.strip() in ("clear", "cls"):
        return jsonify({"ok": True, "output": "__CLEAR__", "cwd": cwd})
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=cwd,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, timeout=300, env={**os.environ, "TERM": "xterm"}
        )
        return jsonify({"ok": result.returncode == 0, "output": result.stdout or "(no output)", "cwd": cwd})
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "output": "(command timed out after 300s)", "cwd": cwd})
    except Exception as ex:
        return jsonify({"ok": False, "output": str(ex), "cwd": cwd})
# ── API: Config files ─────────────────────────────────────────────────────────
@app.route("/admin/api/config-files")
@login_required
def api_config_files():
    return jsonify(get_allowed_configs())

@app.route("/admin/api/editable-files")
@login_required
def api_editable_files():
    return jsonify(find_editable_files())

@app.route("/admin/api/config-files/all-discovered")
@login_required
def api_config_files_all():
    cf     = find_config_files_all()
    result = [{"label": k, "path": v, "enabled": True} for k, v in cf.items()]
    return jsonify({"configs": result})

@app.route("/admin/api/json-files")
@login_required
def api_json_files():
    return jsonify(find_json_files())

@app.route("/admin/api/read-file")
@login_required
def api_read_file():
    path = request.args.get("path", "")
    if not path:
        return jsonify({"content": ""})
    # Security: must be within base dir
    base = get_sdr_dir()
    try:
        p = Path(path).resolve()
        p.relative_to(base)  # raises if outside
    except (ValueError, Exception):
        return jsonify({"error": "Access denied"}), 403
    content = read_file_safe(path)
    return jsonify({"content": content})

@app.route("/admin/api/write-file", methods=["POST"])
@login_required
def api_write_file():
    data = request.get_json(silent=True) or {}
    path = data.get("path", "")
    content = data.get("content", "")
    base = get_sdr_dir()
    try:
        p = Path(path).resolve()
        p.relative_to(base)
    except (ValueError, Exception):
        return jsonify({"ok": False, "msg": "Access denied"}), 403
    ok, msg = write_file_safe(path, content)
    return jsonify({"ok": ok, "msg": msg})

# ── API: Markers ──────────────────────────────────────────────────────────────
@app.route("/admin/api/markers", methods=["GET", "POST"])
@login_required
def api_markers():
    base = get_sdr_dir()
    markers_file = base / "markers.json"
    if request.method == "GET":
        try:
            raw = json.loads(read_file_safe(markers_file))
            # Support both {"markers": [...]} and plain [...] formats
            if isinstance(raw, dict) and "markers" in raw:
                data = raw["markers"]
            elif isinstance(raw, list):
                data = raw
            else:
                data = []
        except Exception:
            data = []
        return jsonify({"data": data, "path": str(markers_file)})
    else:
        req = request.get_json(silent=True) or {}
        data = req.get("data", [])
        # Preserve the {"markers": [...]} wrapper format
        output = json.dumps({"markers": data}, indent=2)
        ok, msg = write_file_safe(markers_file, output)
        return jsonify({"ok": ok, "msg": msg})

# ── API: Autorun spot reporting ───────────────────────────────────────────────
# Band/mode matrix mirrors autorun/bandplan.js (kept here so the UI can render
# without importing the JS). 6m is absent: RX888 at 60 MHz → 30 MHz Nyquist.
AUTORUN_BANDS = ["2200m", "630m", "160m", "80m", "80mEU", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"]
AUTORUN_MODES = {
    "ft8":  ["160m", "80m", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"],
    "ft4":  ["80m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"],
    # JS8 Normal (15 s) only -- the calling speed, where heartbeats and CQs are.
    "js8":  ["160m", "80m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"],
    "wspr": ["2200m", "630m", "160m", "80m", "80mEU", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"],
}

def _autorun_paths():
    base = get_sdr_dir()
    return base, base / "autorun.json", base / "autorun-status.json", base / "autorun.log"


def _autorun_totals():
    """All-time per-slot spot totals, or {} if the daemon has never run.

    Written by the daemon and deliberately NOT deleted on shutdown, unlike the
    status file — these totals are cumulative across restarts.
    """
    path = get_sdr_dir() / "autorun-totals.json"
    try:
        if path.exists():
            d = json.loads(read_file_safe(path))
            return d if isinstance(d, dict) else {}
    except Exception:
        pass
    return {}

def _resolve_node():
    import shutil as _sh
    n = _sh.which("node")
    if n:
        return n
    for p in sorted(glob.glob(str(Path.home() / ".nvm/versions/node/*/bin/node")), reverse=True):
        return p
    return "node"

def _reporter_grid(g):
    """The locator PSK Reporter and WSPRnet accept: 4 or 6 characters. A finer
    one (KM17VX69JA) is cut to its square; anything else gives ""."""
    s = str(g or "").strip()
    for n in (6, 4):
        if len(s) >= n and re.fullmatch(r"[A-Ra-r]{2}[0-9]{2}([A-Xa-x]{2})?", s[:n]):
            return s[:n]
    return ""

def _autorun_default_identity():
    base = get_sdr_dir()
    call, grid = "", ""
    try:
        si = json.loads(read_file_safe(base / "frontend" / "site_information.json"))
        call = (si.get("siteSysop") or "")
        grid = _reporter_grid(si.get("siteGridSquare"))
    except Exception:
        pass
    return call, grid

def _autorun_running():
    try:
        r = subprocess.run(["pgrep", "-f", r"node .*autorun/index\.js"],
                           capture_output=True, text=True, timeout=3)
        pids = [p for p in r.stdout.split() if p.strip()]
        return (len(pids) > 0), pids
    except Exception:
        return False, []

@app.route("/admin/api/autorun/config", methods=["GET", "POST"])
@login_required
def api_autorun_config():
    base, cfg_path, _, _ = _autorun_paths()
    if request.method == "GET":
        cfg = {}
        if cfg_path.exists():
            try:
                cfg = json.loads(read_file_safe(cfg_path))
            except Exception:
                cfg = {}
        def_call, def_grid = _autorun_default_identity()
        ident = cfg.get("identity") or {}
        rep = cfg.get("reporting") or {}
        return jsonify({
            "config": {
                "identity": {
                    "callsign": ident.get("callsign") or def_call,
                    "grid": ident.get("grid") or def_grid,
                },
                "reporting": {"pskreporter": bool(rep.get("pskreporter", False)),
                              "wsprnet": bool(rep.get("wsprnet", False))},
                "maxSlots": int(cfg.get("maxSlots", 12)),
                "slots": cfg.get("slots", []),
            },
            "defaults": {"callsign": def_call, "grid": def_grid},
            "bands": AUTORUN_BANDS,
            "modes": AUTORUN_MODES,
        })
    req = request.get_json(silent=True) or {}
    slots = []
    for s in (req.get("slots") or []):
        band, mode = s.get("band"), s.get("mode")
        if mode in AUTORUN_MODES and band in AUTORUN_MODES[mode]:
            slots.append({"band": band, "mode": mode, "enabled": bool(s.get("enabled"))})
    try:
        max_slots = max(1, min(64, int(req.get("maxSlots", 12))))
    except Exception:
        max_slots = 12
    enabled_count = sum(1 for s in slots if s["enabled"])
    if enabled_count > max_slots:
        return jsonify({"ok": False, "msg": f"{enabled_count} slots enabled exceeds cap of {max_slots}"})
    ident = req.get("identity") or {}
    call = (ident.get("callsign") or "").strip().upper()
    grid_in = (ident.get("grid") or "").strip()
    grid = _reporter_grid(grid_in)
    if not re.match(r'^[A-Z0-9/]{3,12}$', call):
        return jsonify({"ok": False, "msg": "invalid callsign format"})
    # The reporters refuse spots with any other locator, so it is 4 or 6
    # characters (KM17 or KM17VX) or nothing.
    if grid_in and not grid:
        return jsonify({"ok": False, "msg": "grid must be a 4 or 6 character locator, e.g. KM17 or KM17VX"})
    rep = req.get("reporting") or {}
    out = {
        "identity": {"callsign": call, "grid": grid},
        "reporting": {"pskreporter": bool(rep.get("pskreporter", False)),
                      "wsprnet": bool(rep.get("wsprnet", False))},
        "maxSlots": max_slots,
        "slots": slots,
    }
    # Optional manual CPU-pin override (advanced; usually absent). Accept a
    # taskset core list or none/off/unpinned, else drop it. Preserve any value
    # already in autorun.json when the request doesn't carry one, so hand-edits
    # and the env/auto paths keep working across a Save.
    cores = req.get("cores")
    if cores is None and cfg_path.exists():
        try:
            cores = (json.loads(read_file_safe(cfg_path)) or {}).get("cores")
        except Exception:
            cores = None
    if cores is not None:
        cores = str(cores).strip()
        if cores.lower() in ("none", "off", "unpinned"):
            out["cores"] = "none"
        elif _CORELIST_RE.match(cores):
            out["cores"] = cores
        # anything else: silently omit (invalid)
    ok, msg = write_file_safe(cfg_path, json.dumps(out, indent=2))
    return jsonify({"ok": ok, "msg": msg if not ok else "saved"})

@app.route("/admin/api/autorun/status")
@login_required
def api_autorun_status():
    _, _, status_path, _ = _autorun_paths()
    running, pids = _autorun_running()
    status = {}
    if status_path.exists():
        try:
            status = json.loads(read_file_safe(status_path))
        except Exception:
            status = {}
    return jsonify({"running": running, "pids": pids, "status": status,
                    "totals": _autorun_totals()})

_CORELIST_RE = re.compile(r'^\d+([-,]\d+)*$')  # e.g. "2-3", "0,2,4", "0-2,5"

def _autorun_cores_override():
    """Manual core override for the autorun pin, or None if not set.

    Precedence: AUTORUN_CORES env var, else the "cores" field in autorun.json.
    Useful on CPUs where the auto-derived range isn't ideal (AMD CCX/CCD, ARM
    big.LITTLE, interleaved SMT). Accepts a taskset -c list ("2-3", "0,2,4") or
    one of none/off/unpinned to force no pinning. Malformed values are ignored
    (falls back to auto) so a typo can't stop the daemon from launching.
    """
    val = os.environ.get("AUTORUN_CORES")
    if val is None:
        try:
            _, cfg_path, _, _ = _autorun_paths()
            if cfg_path.exists():
                val = (json.loads(read_file_safe(cfg_path)) or {}).get("cores")
        except Exception:
            val = None
    if val is None:
        return None
    val = str(val).strip()
    if val.lower() in ("none", "off", "unpinned", ""):
        return ""  # explicit "do not pin"
    return val if _CORELIST_RE.match(val) else None

def _autorun_taskset_prefix():
    """taskset prefix (list) pinning the autorun daemon to the top CPU cores.

    A manual override (see _autorun_cores_override) wins if set: a core list
    pins there, an empty override forces unpinned. Otherwise auto-derive:
    returns [] (unpinned) when taskset is unavailable or the machine is too
    small to segregate — a 4-core i5 shares all cores with spectrumserver, and
    naming cores that don't exist would make taskset fail to launch. Otherwise
    reserves the top few cores for the daemon: 4 on a >=12-thread CPU (the E-cores
    on a 4P+HT/4E part -> 8-11, matching the original hardcode), fewer on smaller
    CPUs. spectrumserver is pinned to 0-7 by xgo.sh, so the top cores stay clear.
    """
    import shutil as _sh
    if not _sh.which("taskset"):
        return []
    override = _autorun_cores_override()
    if override is not None:
        return ["taskset", "-c", override] if override else []
    n = os.cpu_count() or 0
    if n <= 4:
        return []  # can't segregate — let the scheduler balance across cores
    count = 4 if n >= 12 else max(1, n // 4)
    lo, hi = n - count, n - 1
    spec = f"{lo}-{hi}" if count > 1 else str(lo)
    return ["taskset", "-c", spec]

@app.route("/admin/api/autorun/start", methods=["POST"])
@login_required
def api_autorun_start():
    base, cfg_path, _, log_path = _autorun_paths()
    running, _ = _autorun_running()
    if running:
        return jsonify({"ok": False, "msg": "already running"})
    if not cfg_path.exists():
        return jsonify({"ok": False, "msg": "save config first"})
    try:
        cfg = json.loads(read_file_safe(cfg_path))
        if not any(s.get("enabled") for s in cfg.get("slots", [])):
            return jsonify({"ok": False, "msg": "no bands/modes enabled"})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"bad config: {e}"})
    index_js = base / "autorun" / "index.js"
    if not index_js.exists():
        return jsonify({"ok": False, "msg": "autorun/index.js missing"})
    node = _resolve_node()
    # Pin the daemon to the top CPU cores so decode bursts stay off the lower
    # cores spectrumserver prefers (xgo.sh pins it to 0-7). Config-aware: on a
    # 4P+HT/4E box this yields the E-cores (8-11), on smaller CPUs it shrinks the
    # range, and on a 4-core (or fewer) machine it launches unpinned rather than
    # naming cores that don't exist (which would make taskset fail to start).
    cmd = _autorun_taskset_prefix() + [node, str(index_js)]
    try:
        logf = open(log_path, "a")
        proc = subprocess.Popen(cmd, cwd=str(base), stdout=logf,
                                stderr=subprocess.STDOUT, start_new_session=True)
        return jsonify({"ok": True, "msg": f"started (PID {proc.pid})", "pid": proc.pid})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)})

@app.route("/admin/api/autorun/totals/reset", methods=["POST"])
@login_required
def api_autorun_totals_reset():
    """Clear the all-time per-slot spot totals.

    The daemon holds these in memory and rewrites the file every 15s and again
    on shutdown, so deleting it under a live daemon just brings the numbers
    straight back. Stop first, wait for the process to actually exit — its
    shutdown handler writes the totals one last time — and only then delete.
    """
    running, pids = _autorun_running()
    if running:
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGTERM)
            except Exception:
                pass
        deadline = time.time() + 15
        while time.time() < deadline:
            time.sleep(0.5)
            if not _autorun_running()[0]:
                break
        else:
            return jsonify({"ok": False, "msg": "daemon did not stop; totals kept"})

    path = get_sdr_dir() / "autorun-totals.json"
    try:
        if path.exists():
            path.unlink()
        return jsonify({"ok": True, "msg": "counters cleared", "was_running": running})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"could not clear totals: {e}"})


@app.route("/admin/api/autorun/stop", methods=["POST"])
@login_required
def api_autorun_stop():
    running, pids = _autorun_running()
    if not running:
        return jsonify({"ok": False, "msg": "not running"})
    killed = []
    for pid in pids:
        try:
            os.kill(int(pid), signal.SIGTERM)
            killed.append(pid)
        except Exception:
            pass
    return jsonify({"ok": True, "msg": f"stopped PID(s) {','.join(killed)}"})

# ── API: Logs ─────────────────────────────────────────────────────────────────
@app.route("/admin/api/logs")
@login_required
def api_logs():
    log_name = request.args.get("name", "logwebsdr.txt")
    if log_name not in LOG_FILES:
        return jsonify({"ok": False, "msg": "Unknown log", "available": list(LOG_FILES.keys()), "lines": []}), 400
    lines = tail_log(150, log_name)
    return jsonify({"ok": True, "name": log_name, "available": list(LOG_FILES.keys()), "lines": lines})

@app.route("/admin/api/logs/clear", methods=["POST"])
@login_required
def api_logs_clear():
    global log_buffer
    # Clear in-memory buffer
    with log_lock:
        log_buffer.clear()
    # Truncate the log files defined in LOG_FILES, except CLEAR_EXCLUDE
    base = get_sdr_dir()
    cleared = []
    skipped = []
    failed = []
    for log_name, log_path in LOG_FILES.items():
        if log_name in CLEAR_EXCLUDE:
            skipped.append(log_name)
            continue
        lf = base / log_path
        if not lf.exists():
            continue
        try:
            # Truncate in place rather than unlink: systemd holds these open
            # with StandardOutput=append: (O_APPEND), so a deleted file would
            # keep filling an unlinked inode until the service restarts.
            with open(lf, "r+") as f:
                f.truncate(0)
            cleared.append(log_name)
        except Exception as e:
            failed.append({"name": log_name, "error": str(e)})
    return jsonify({"ok": not failed, "cleared": cleared,
                    "skipped": skipped, "failed": failed})

# ── Chat admin IPC ────────────────────────────────────────────────────────────
# Communicates with the Unix domain socket started by ChatClient::start_admin_listener()
# inside spectrumserver.  This lets the admin panel send real-time commands
# (currently: DELETE) to the running C++ process without restarting it.

import socket as _socket

CHAT_ADMIN_SOCK = "/tmp/phantomsdr_chat.sock"

def _send_chat_admin_cmd(cmd: str, sock_path: str = CHAT_ADMIN_SOCK):
    """Send a single newline-terminated command to spectrumserver's chat socket.

    Returns (True, "ok") on success, or (False, error_message) on failure.
    """
    try:
        with _socket.socket(_socket.AF_UNIX, _socket.SOCK_STREAM) as s:
            s.settimeout(2.0)
            s.connect(sock_path)
            s.sendall((cmd + "\n").encode())
        return True, "ok"
    except FileNotFoundError:
        return False, "Chat admin socket not found — is spectrumserver running?"
    except _socket.timeout:
        return False, "Timed out connecting to chat admin socket"
    except Exception as e:
        return False, str(e)


# ── API: Chat ─────────────────────────────────────────────────────────────────
def _chat_sources():
    """(label, chat_history.txt, admin socket) for every receiver. Each
    spectrumserver writes chat_history.txt in its own working directory: the
    main receiver in the base dir, a named instance in instances/<name>/, with
    its admin socket at /tmp/phantomsdr_chat-<name>.sock (spectrumserver.cpp)."""
    base = get_sdr_dir()
    rxs = _receivers_toml().get("receiver", [])
    main_label = ""
    out = []
    for r in rxs:
        inst = str(r.get("instance") or "").strip()
        label = str(r.get("id") or inst).upper()
        if not inst or inst == "main":
            main_label = label
            continue
        out.append((label, base / "instances" / inst / "chat_history.txt",
                    "/tmp/phantomsdr_chat-%s.sock" % inst))
    return [(main_label, base / "chat_history.txt", CHAT_ADMIN_SOCK)] + out

def _chat_source(rx):
    """The _chat_sources() entry for label rx; the main receiver when empty."""
    srcs = _chat_sources()
    for src in srcs:
        if src[0] == (rx or "").upper():
            return src
    return srcs[0] if not rx else None

def _parse_chat_line(line):
    # Try parse: [time] <nick> msg  or  nick: msg
    m = re.match(r'\[([^\]]+)\]\s+<([^>]+)>\s+(.*)', line)
    if m:
        return {"time": m.group(1), "nick": m.group(2), "msg": m.group(3), "raw": line}
    m2 = re.match(r'(\S+):\s+(.*)', line)
    if m2:
        return {"time": "", "nick": m2.group(1), "msg": m2.group(2), "raw": line}
    return {"time": "", "nick": "system", "msg": line, "raw": line}

@app.route("/admin/api/chat")
@login_required
def api_chat():
    """Every receiver's chat history, each message tagged with its receiver."""
    messages = []
    srcs = _chat_sources()
    for label, chat_file, _sock in srcs:
        if not chat_file.exists():
            continue
        try:
            with open(chat_file, encoding="utf-8", errors="replace") as f:
                for line in f.readlines()[-200:]:
                    line = line.strip()
                    if line:
                        m = _parse_chat_line(line)
                        m["rx"] = label
                        messages.append(m)
        except Exception as e:
            messages.append({"time": "", "nick": "error", "msg": "%s: %s" % (label or "chat", e), "rx": label})
    # The lines start with "YYYY-MM-DD HH:MM:SS", so a stable sort on the raw
    # text interleaves the receivers in time order.
    if len(srcs) > 1:
        messages.sort(key=lambda m: m.get("raw", ""))
    return jsonify({"messages": messages, "multi": len(srcs) > 1})

@app.route("/admin/api/chat/clear", methods=["POST"])
@login_required
def api_chat_clear():
    data = request.get_json(silent=True) or {}
    src = _chat_source(data.get("rx", ""))
    if not src:
        return jsonify({"ok": False, "msg": "Unknown receiver"})
    try:
        with open(src[1], "w") as f:
            f.write("")
        return jsonify({"ok": True, "msg": "Chat history cleared"})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)})

@app.route("/admin/api/chat/delete", methods=["POST"])
@login_required
def api_chat_delete():
    """Delete a single chat message in real time.

    Expects JSON body: {"line": "<full formatted message string>"}
    The 'line' value must match exactly what is stored in chat_history.txt
    (i.e. the 'raw' field returned by /admin/api/chat).

    Sends a DELETE command to spectrumserver via the admin Unix socket.
    spectrumserver removes the message from its in-memory deque, rewrites
    chat_history.txt, and broadcasts a __CHAT_DELETE__ frame to all connected
    chat clients so their UI updates instantly.
    """
    data = request.get_json(silent=True) or {}
    line = data.get("line", "").strip()
    if not line:
        return jsonify({"ok": False, "msg": "No line specified"})
    # Each receiver has its own spectrumserver and its own admin socket.
    src = _chat_source(data.get("rx", ""))
    if not src:
        return jsonify({"ok": False, "msg": "Unknown receiver"})
    ok, msg = _send_chat_admin_cmd("DELETE:" + line, src[2])
    return jsonify({"ok": ok, "msg": msg})

# ── Waterfall Message — static file helper ─────────────────────────────────────
# The message is written as wf-message.json into the frontend/dist directory
# (the same folder spectrumserver already serves statically).
# The browser fetches /wf-message.json directly from spectrumserver — no proxy,
# no auth, no routing issues whatsoever.

def _wf_write_file(text: str, color: str) -> str:
    """Write wf-message.json to every likely web-root location.
    Returns a summary string of files written (for logging).
    """
    import json as _json
    payload = _json.dumps({"text": text, "color": color})
    candidates = [
        BASE_DIR / "frontend" / "dist",
        BASE_DIR / "frontend" / "public",
        BASE_DIR / "public",
        BASE_DIR / "dist",
        get_sdr_dir() / "frontend" / "dist",
        get_sdr_dir() / "frontend" / "public",
        get_sdr_dir() / "public",
    ]
    written = []
    seen = set()
    for d in candidates:
        d = d.resolve()
        if d in seen or not d.is_dir():
            continue
        seen.add(d)
        try:
            target = d / "wf-message.json"
            target.write_text(payload, encoding="utf-8")
            written.append(str(target))
        except Exception as e:
            print(f"[wf-msg] Could not write {d}/wf-message.json: {e}")
    return ", ".join(written) if written else "nowhere (no candidate dir found)"


# ── API: Waterfall Message ─────────────────────────────────────────────────────
@app.route("/admin/api/wf-message", methods=["GET"])
def api_wf_message_get():
    """Public fallback — no @login_required.  The frontend normally reads the
    static /wf-message.json; this endpoint is kept for diagnostics.
    """
    with _wf_message_lock:
        m = dict(_wf_message)
    return jsonify({"text": m.get("text", ""), "color": m.get("color", "#ffffff")})


@app.route("/admin/api/wf-message", methods=["POST"])
@login_required
def api_wf_message_post():
    """Set the waterfall message (admin only).
    Body JSON: {"text": "...", "color": "#ffffff"}
    """
    data  = request.get_json(silent=True) or {}
    text  = (data.get("text") or "").strip()[:200]
    color = data.get("color", "#ffffff")
    if not text:
        return jsonify({"ok": False, "msg": "Empty message"})
    with _wf_message_lock:
        _wf_message.update({"text": text, "color": color})
    written = _wf_write_file(text, color)
    print(f"[wf-msg] SET '{text}' → {written}")
    return jsonify({"ok": True, "written": written})


@app.route("/admin/api/wf-message", methods=["DELETE"])
@login_required
def api_wf_message_delete():
    """Clear the waterfall message (admin only)."""
    with _wf_message_lock:
        _wf_message.update({"text": "", "color": "#ffffff"})
    written = _wf_write_file("", "#ffffff")
    print(f"[wf-msg] CLEARED → {written}")
    return jsonify({"ok": True})


# ── API: Settings ─────────────────────────────────────────────────────────────
# ── API: Ports (Settings → PORTS) ────────────────────────────────────────────
def _port_listening(port, host="127.0.0.1"):
    """True when something accepts a TCP connection on host:port."""
    try:
        with _socket.create_connection((host, int(port)), timeout=0.3):
            return True
    except Exception:
        return False


def _station_ports():
    """Every port this station uses, for Settings → PORTS.

    The same sources proxy.py reads: admin_config.json first, station.conf for
    the side services, receivers.toml for further receivers and the front port.
    Optional services are listed only when configured or actually listening."""
    cfg = load_admin_config()
    sc = _station_conf() or {}

    def sc_port(key):
        try:
            return int(sc.get(key) or 0)
        except ValueError:
            return 0

    proxy = int(cfg.get("proxy_port") or 0)
    sdr = int(cfg.get("public_port") or PUBLIC_PORT)
    rows = []

    def add(port, what, how, public=False):
        if port and not any(r["port"] == port for r in rows):
            rows.append({"port": port, "what": what, "how": how, "public": public})

    if proxy:
        add(proxy, "Public port — proxy.py",
            "the address listeners use; carries the page, /admin and the services below", True)
    rt = _receivers_toml()
    try:
        front = int((rt.get("front") or {}).get("port") or 0)
    except (TypeError, ValueError):
        front = 0
    add(front, "Second public port — proxy.py ([front] in receivers.toml)",
        "an older public address, kept for listeners and directories", True)
    https = (sc.get("STATION_HTTPS") or "n").lower()
    if https in ("y", "lan"):
        add(443, "https — Caddy",
            "the station's https:// address" + (" (local network only)" if https == "lan" else ""),
            https == "y")
        if https == "y":
            add(80, "http — Caddy", "Let's Encrypt certificate renewal; redirects to https", True)
        add(sc_port("PORT_TLS"), "https hand-over — proxy.py",
            "loopback only: Caddy passes visitors to the proxy here")
    receivers = rt.get("receiver", [])
    main_name = "main receiver"
    for r in receivers:
        if int(r.get("port") or 0) == sdr:
            main_name = str(r.get("name") or r.get("id") or main_name)
    add(sdr, "spectrumserver — " + main_name,
        "loopback, behind proxy.py" if proxy else "the address listeners use (no proxy on this station)",
        not proxy)
    for r in receivers:
        port = int(r.get("port") or 0)
        if port and port != sdr:
            add(port, "spectrumserver — " + str(r.get("name") or r.get("id") or "receiver"),
                ("behind proxy.py, reached with ?rx=" + str(r.get("id", ""))) if proxy else "extra receiver")
    add(int(cfg.get("port") or ADMIN_PORT), "Admin panel",
        "loopback, reached as /admin on the public port" if proxy else "loopback")
    for key, default, what, path in (("PORT_STATS", 0, "Statistics server", "/stats"),
                                     ("PORT_RADE", 8074, "RADE decoder (rade_helper.py)", "/rade"),
                                     ("PORT_DRM", 8075, "DRM decoder (drm-helper.js)", "/drm"),
                                     ("PORT_RELAY", 0, "WebSDR diversity relay", "/relay")):
        port = sc_port(key)
        if port:
            add(port, what, ("reached as " + path + " on the public port") if proxy else "its own port")
            continue
        if key == "PORT_RELAY":
            try:
                port = int(json.loads(read_file_safe(BASE_DIR / "websdr_relay.json") or "{}").get("port") or 0)
            except Exception:
                port = 0
            add(port, what, "its own port")
        elif default and _port_listening(default):
            add(default, what, "its own port — forward it on the router for listeners outside", True)
    for r in rows:
        r["listening"] = _port_listening(r["port"])
    return rows


@app.route("/admin/api/ports")
@login_required
def api_ports():
    return jsonify({"ports": _station_ports()})


@app.route("/admin/api/settings", methods=["GET", "POST"])
@login_required
def api_settings():
    cfg = load_admin_config()
    if request.method == "GET":
        out = {
            "sdr_base_dir":  cfg.get("sdr_base_dir", str(BASE_DIR)),
            "start_script":  cfg.get("start_script", ""),
            "stop_script":   cfg.get("stop_script", ""),
            "public_port":   cfg.get("public_port", 8900),
            "proxy_port":    cfg.get("proxy_port"),
        }
        if HAS_THERMAL:
            for k, v in thermal_guard.DEFAULTS.items():
                out[k] = cfg.get(k, v)
        return jsonify(out)
    data = request.get_json(silent=True) or {}
    if HAS_THERMAL:
        # Temperatures are floats and may be left blank ("auto" = derive from the
        # machine's own critical trip point); the rest are whole seconds/counts.
        temp_keys = {"thermal_warn", "thermal_throttle", "thermal_stop",
                     "thermal_resume", "thermal_test_temp"}
        for k in thermal_guard.DEFAULTS:
            if k not in data:
                continue
            v = data[k]
            if k == "thermal_enabled":
                cfg[k] = bool(v)
            elif k == "thermal_mode":
                if str(v) in thermal_guard.MODE_RANK:
                    cfg[k] = str(v)
            elif v in (None, "", "auto"):
                cfg[k] = None
            else:
                try:
                    cfg[k] = float(v) if k in temp_keys else int(v)
                except (TypeError, ValueError):
                    pass
    if "sdr_base_dir" in data:
        cfg["sdr_base_dir"] = data["sdr_base_dir"]
    if "start_script" in data:
        cfg["start_script"] = data["start_script"]
    if "stop_script" in data:
        cfg["stop_script"] = data["stop_script"]
    if "public_port" in data:
        try:
            pp = int(data["public_port"])
        except (ValueError, TypeError):
            pp = None
        if pp is not None:
            # proxy.py forwards to public_port: the proxy's own port would make
            # it forward to itself, and any port the receiver does not listen on
            # takes the station down at the proxy's next restart.
            proxy_port = cfg.get("proxy_port")
            if proxy_port and pp == int(proxy_port):
                return jsonify({"ok": False, "msg": "Port %d is the proxy's own port (the one listeners use). "
                                "The spectrumserver port must be different — proxy.py would forward to "
                                "itself and refuse to start. Nothing saved." % pp})
            real, source = _main_receiver_port()
            if real and pp != real and not data.get("confirm_port"):
                return jsonify({"ok": False, "confirm": True,
                                "msg": "Port %d does not match the receiver: spectrumserver listens on %d "
                                       "(%s). With %d, proxy.py forwards listeners to a port where nothing "
                                       "answers from its next restart on, and the station is down. "
                                       "Save anyway?" % (pp, real, source, pp)})
            cfg["public_port"] = pp
    save_admin_config(cfg)
    return jsonify({"ok": True})

# ── API: WebSDR diversity relay ──────────────────────────────────────────────
# The relay is a separate process (websdr_relay.py) that lets receive diversity
# use a WebSDR as the second receiver. It is optional and often not installed,
# so every failure here is reported as a state to show, never as an error: a
# missing config file means "not set up", a refused connection means "not
# running", and both are normal.
@app.route("/admin/api/websdr-relay")
@login_required
def api_websdr_relay():
    import urllib.request
    import urllib.error

    cfg_path = BASE_DIR / "websdr_relay.json"
    if not cfg_path.exists():
        return jsonify({"configured": False,
                        "reason": "websdr_relay.json not found — "
                                  "run ./setup_websdr_relay.sh"})
    try:
        with open(cfg_path) as f:
            cfg = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        return jsonify({"configured": False, "reason": f"websdr_relay.json: {e}"})

    port = int(cfg.get("port", 8898))
    out = {"configured": True, "port": port, "running": False,
           "site": cfg.get("site", ""), "operator": cfg.get("operator", ""),
           "max_per_host": cfg.get("max_per_host"), "max_total": cfg.get("max_total")}

    # Always loopback: the relay binds every interface, but asking it through
    # the public address would depend on the router's hairpin NAT and could
    # report "down" for a relay that is perfectly healthy.
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/status", timeout=2) as r:
            live = json.loads(r.read().decode("utf-8"))
        out["running"] = True
        out["user_agent"] = live.get("user_agent", "")
        out["sessions"] = live.get("sessions", {})
        # The live values win: someone may have edited the config without
        # restarting, and what the relay is actually enforcing is what matters.
        for k in ("max_per_host", "max_total"):
            if live.get(k) is not None:
                out[k] = live[k]
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError) as e:
        out["reason"] = str(getattr(e, "reason", e))

    return jsonify(out)


# ── DRM decoder (autorun/drm-helper.js) ────────────────────────────────────────
# The helper's port is PORT_DRM in station.conf (wizard stations), else 8075.
# Its settings live in drm.json, which the helper re-reads within 5 s; an
# environment variable in the start script (DRM_MAX_SESSIONS, DRM_PER_IP)
# still wins over the file. GET /status on the helper answers direct loopback
# callers only, because the sessions carry listeners' addresses.
DRM_SETTINGS = BASE_DIR / "drm.json"

def _drm_port():
    try:
        m = re.search(r'^PORT_DRM=["\']?(\d+)', (BASE_DIR / "station.conf").read_text(), re.M)
        if m:
            return int(m.group(1))
    except OSError:
        pass
    return 8075

def _drm_status():
    """The helper's live /status, or None when it is not running."""
    import urllib.request
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/status" % _drm_port(), timeout=2) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None

def _drm_settings_file():
    try:
        d = json.loads(DRM_SETTINGS.read_text())
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}

@app.route("/admin/api/drm", methods=["GET", "POST"])
@login_required
def api_drm():
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        try:
            mx = int(data.get("max_sessions"))
        except (TypeError, ValueError):
            return jsonify({"ok": False, "msg": "Maximum listeners must be a number"})
        if not 1 <= mx <= 20:
            return jsonify({"ok": False, "msg": "Maximum listeners: 1 to 20"})
        cur = _drm_settings_file()
        cur.update({"enabled": bool(data.get("enabled")), "max_sessions": mx,
                    "per_ip": int(cur.get("per_ip") or 1)})
        tmp = DRM_SETTINGS.with_name(DRM_SETTINGS.name + ".tmp")
        tmp.write_text(json.dumps(cur, indent=1) + "\n")
        os.replace(tmp, DRM_SETTINGS)
        return jsonify({"ok": True, "msg": "DRM %s, at most %d listener%s — applied within 5 s"
                        % ("on" if cur["enabled"] else "off", mx, "" if mx == 1 else "s")})
    f = _drm_settings_file()
    out = {"installed": (BASE_DIR / "drm" / "bin" / "ubersdr-drm").exists(), "port": _drm_port(),
           "running": False, "enabled": f.get("enabled", True) is not False,
           "max_sessions": int(f.get("max_sessions") or 5), "per_ip": int(f.get("per_ip") or 1),
           "sessions": [], "env_override": False}
    live = _drm_status()
    if live is None:
        out["reason"] = ("helper not running — it starts with the receiver" if out["installed"]
                         else "decoder not built — run ./setup-drm.sh")
        return jsonify(out)
    out["running"] = True
    for k in ("enabled", "max_sessions", "per_ip"):
        if k in live:
            out[k] = live[k]
    out["env_override"] = (int(live.get("max_sessions") or 0) != int(f.get("max_sessions") or 5)
                           or int(live.get("per_ip") or 0) != int(f.get("per_ip") or 1))
    # Listener names, from the receivers' own user lists.
    names = {}
    for port in _sdr_ports():
        try:
            for u in _sdr_users_with_ip(port).get("users", []):
                ip = (u.get("ip") or "").replace("::ffff:", "")
                if ip and u.get("name"):
                    names[ip] = u["name"]
        except Exception:
            continue
    for x in live.get("sessions", []):
        x = dict(x)
        x["name"] = names.get(x.get("ip", ""), "")
        out["sessions"].append(x)
    return jsonify(out)

@app.route("/admin/api/thermal", methods=["GET", "POST"])
@login_required
def api_thermal():
    if not HAS_THERMAL:
        return jsonify({"available": False, "reason": "thermal_guard.py not loaded"})
    if request.method == "POST":
        act = (request.get_json(silent=True) or {}).get("action")
        if act == "reset":
            thermal_guard.reset()
            return jsonify({"ok": True, "msg": "Thermal lockout cleared"})
        return jsonify({"ok": False, "msg": "Unknown action"})
    st = thermal_guard.status()
    st["available"] = True
    return jsonify(st)


@app.route("/admin/api/change-password", methods=["POST"])
@login_required
def api_change_password():
    data = request.get_json(silent=True) or {}
    old = data.get("old", "")
    new_pwd = data.get("new_pwd", "")
    if not check_password(old):
        return jsonify({"ok": False, "msg": "Current password incorrect"})
    if len(new_pwd) < 4:
        return jsonify({"ok": False, "msg": "Password too short"})
    cfg = load_admin_config()
    cfg["password_hash"] = hash_password(new_pwd)
    save_admin_config(cfg)
    return jsonify({"ok": True})

# ── API: Stats history (Graphs page) ──────────────────────────────────────────
@app.route("/admin/api/graph-stats")
@login_required
def api_graph_stats():
    """Sampled CPU/user history for the Graphs page.

    ?since=<epoch> returns only newer points so the page polls incrementally
    instead of re-downloading the whole buffer every tick.
    """
    def _arg(name, default):
        try:
            return int(request.args.get(name, default))
        except (TypeError, ValueError):
            return default

    since = _arg("since", 0)
    rng   = max(60, min(GRAPH_HISTORY_S, _arg("range", GRAPH_FINE_S)))

    # A range the fine tier cannot cover in full has to come from the coarse
    # tier, otherwise the plot would silently stop at the fine tier's horizon
    # and look like the server had been down.
    coarse = rng > GRAPH_FINE_S
    interval = GRAPH_COARSE_INTERVAL_S if coarse else GRAPH_INTERVAL_S
    cutoff = int(time.time()) - rng

    with _graph_lock:
        src = _graph_coarse if coarse else _graph_history
        pts = [p for p in src if p["t"] >= cutoff and p["t"] > since]

    _, _, limit = get_cpu_frequency()
    return jsonify({
        "ok": True,
        "interval": interval,
        "retention": rng,
        "coarse": coarse,
        "freq_limit": limit,
        "cores": (psutil.cpu_count() if HAS_PSUTIL else os.cpu_count()),
        "points": pts,
    })


# ── API: Connected users / Kick ───────────────────────────────────────────────
def _get_public_port():
    """Return the PUBLIC port users connect to for 'ss' connection counting.

    When running behind proxy.py this must be proxy_port (e.g. 8900), because
    all connections to spectrumserver's internal port (public_port, e.g. 8901)
    come from 127.0.0.1 (the proxy itself) — real client IPs are invisible there.
    Falls back to public_port for standalone (no-proxy) deployments.
    """
    cfg = load_admin_config()
    return int(cfg.get("proxy_port") or cfg.get("public_port", 8900))

def _sdr_users_with_ip(port):
    """One receiver's user list WITH the IP addresses.

    The public /users has none since the listener-identity change, as on a
    WebSDR; spectrumserver gives them only to a loopback caller on /~~users.
    A receiver still running an older binary has no /~~users (404), and its
    /users still carries the IPs, so that is the fallback.
    """
    import urllib.request, urllib.error
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/~~users" % port, timeout=2) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
    with urllib.request.urlopen("http://127.0.0.1:%d/users" % port, timeout=2) as r:
        return json.loads(r.read().decode())

@app.route("/admin/api/sdr-users")
@login_required
def api_sdr_users():
    """Every receiver's /users list merged into one, each listener tagged with
    its receiver. Asked of each spectrumserver directly on loopback: the page
    used to fetch /users through proxy.py, which routes by the listener's rx
    cookie — so after the sysop once opened ?rx=vhf the panel kept showing the
    2 m listeners, even back on HF."""
    import urllib.request
    labels = {}
    for r in _receivers_toml().get("receiver", []):
        try:
            labels[int(r.get("port"))] = str(r.get("id") or "").upper()
        except (TypeError, ValueError):
            continue
    users, seen, errors = [], 0, []
    for port in _sdr_ports():
        label = labels.get(port, "")
        try:
            d = _sdr_users_with_ip(port)
        except Exception as e:
            errors.append("%s: %s" % (label or port, e))
            continue
        seen += 1
        for u in d.get("users", []):
            u = dict(u)
            u["rx"] = label
            # Session ids are per server; keep them unique across receivers.
            u["id"] = "%d:%s" % (port, u.get("id", ""))
            users.append(u)
    if not seen:
        return jsonify({"ok": False, "users": [], "error": "; ".join(errors) or "no receiver"})
    # A DRM listener's own stream is AM (that is what the server demodulates);
    # the DRM helper knows who is really decoding DRM, and where.
    drm = _drm_status()
    if drm:
        for u in users:
            ip = (u.get("ip") or "").replace("::ffff:", "")
            for x in drm.get("sessions", []):
                if x.get("ip") == ip and abs(float(u.get("freq_hz") or 0) - float(x.get("freq") or 0)) <= 10000:
                    u["mode"] = "drm"
                    break
    return jsonify({"ok": True, "users": users, "multi": len(labels) > 1, "errors": errors})

# ── Listener map: IP → coordinates ────────────────────────────────────────────
# spectrumserver's own lookup keeps only "city, CC", so the map asks ip-api.com
# again for lat/lon — one batch request for every IP not yet cached. The free
# batch endpoint allows 15 requests/min, 100 IPs each; a found IP is kept for a
# day, a failed one retried after 10 minutes. Memory only, nothing on disk.
_geo_cache = {}            # ip -> (expires_monotonic, dict or None)
_geo_lock = threading.Lock()

def _geo_public(ip):
    import ipaddress
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False

@app.route("/admin/api/users-geo", methods=["POST"])
@login_required
def api_users_geo():
    import urllib.request
    data = request.get_json(silent=True) or {}
    ips = []
    for ip in data.get("ips") or []:
        ip = str(ip).strip()
        if ip.startswith("::ffff:"):
            ip = ip[7:]
        if ip and ip not in ips and _geo_public(ip):
            ips.append(ip)
    ips = ips[:100]
    now = time.monotonic()
    with _geo_lock:
        missing = [ip for ip in ips if _geo_cache.get(ip, (0, None))[0] <= now]
    if missing:
        found = {}
        try:
            req = urllib.request.Request(
                "http://ip-api.com/batch?fields=status,query,lat,lon,city,country,countryCode",
                data=json.dumps(missing).encode(),
                headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=5) as r:
                for g in json.loads(r.read().decode()):
                    if g.get("status") == "success":
                        found[g.get("query")] = {
                            "lat": g.get("lat"), "lon": g.get("lon"),
                            "city": g.get("city") or "", "country": g.get("country") or "",
                            "cc": g.get("countryCode") or ""}
        except Exception as e:
            logging.warning("users-geo: ip-api.com lookup failed: %s", e)
        with _geo_lock:
            for ip in missing:
                g = found.get(ip)
                _geo_cache[ip] = (now + (86400 if g else 600), g)
            if len(_geo_cache) > 5000:
                for k in [k for k, v in _geo_cache.items() if v[0] <= now]:
                    del _geo_cache[k]
    with _geo_lock:
        out = {ip: _geo_cache[ip][1] for ip in ips if _geo_cache.get(ip, (0, None))[1]}
    # The station itself, drawn from its locator like the APRS map does.
    try:
        si = json.loads(read_file_safe(get_sdr_dir() / "frontend" / "site_information.json"))
        grid = str(si.get("siteGridSquare") or "")
    except Exception:
        grid = ""
    return jsonify({"ok": True, "geo": out, "grid": grid})

@app.route("/admin/api/station-grid")
@login_required
def api_station_grid():
    """The station locator from Site Info — the admin page's "auto" theme
    turns it into a position for sunrise and sunset."""
    try:
        si = json.loads(read_file_safe(get_sdr_dir() / "frontend" / "site_information.json"))
        grid = str(si.get("siteGridSquare") or "")
    except Exception:
        grid = ""
    return jsonify({"ok": True, "grid": grid})

@app.route("/admin/api/users")
@login_required
def api_users():
    """Return IPs with active connections to the WebSDR.

    Scans BOTH the proxy port (proxy.py) AND the public spectrumserver port,
    because in practice most clients connect straight to spectrumserver and
    bypass the proxy — their real IPs appear as the peer on the SDR port.
    Uses 'ss -tn sport = :PORT' (no -p flag; no privilege needed).

    Loopback and the proxy's own relay IP (sdr_host) are filtered out so the
    proxy's upstream connections to spectrumserver aren't listed as a "user".
    """
    cfg = load_admin_config()
    proxy_port  = int(cfg.get("proxy_port") or 0)
    public_port = int(cfg.get("public_port", 8900))
    # With receivers.toml the listeners' sockets end on its [front] port (the
    # proxy now owns the public port), so that one is scanned as well.
    front_port  = int((_receivers_toml().get("front") or {}).get("port") or 0)
    ports = [p for p in {proxy_port, public_port, front_port} if p]
    # Connections the proxy itself opens to spectrumserver originate from
    # sdr_host — never a real client, so drop them.
    relay_ip = (cfg.get("sdr_host") or "").strip()
    exclude = {"127.0.0.1", "::1", "*", "", relay_ip}
    try:
        ips = {}
        for port in ports:
            # sport and = and :PORT must be SEPARATE argv tokens — a single
            # string like "sport = :8900" is silently ignored by ss execvp.
            r = subprocess.run(
                ["ss", "-tn", "sport", "=", ":%d" % port],
                capture_output=True, text=True, timeout=5
            )
            for line in r.stdout.splitlines()[1:]:   # skip header row
                parts = line.split()
                if len(parts) < 5:
                    continue
                # Column layout: State  Recv-Q  Send-Q  Local:Port  Peer:Port
                peer = parts[4]
                # Handle IPv6-mapped IPv4 like [::ffff:1.2.3.4]:PORT
                ip = peer.rsplit(":", 1)[0].strip("[]")
                if ip.startswith("::ffff:"):
                    ip = ip[7:]
                if ip not in exclude:
                    ips[ip] = ips.get(ip, 0) + 1
        users = [{"ip": ip, "connections": cnt} for ip, cnt in sorted(ips.items())]
        return jsonify({"ok": True, "users": users, "ports": ports})
    except Exception as e:
        return jsonify({"ok": False, "users": [], "error": str(e)})

def _proxy_kick(ip):
    """Ask proxy.py to close all WebSockets from `ip`.

    proxy.py owns every client WebSocket, so it disconnects the user by closing
    the socket from inside its own process — no CAP_NET_ADMIN / 'ss -K' needed.
    Returns (ok: bool, count: int|None, err: str|None). count is None when the
    proxy is unreachable (standalone deployment → caller falls back to ss -K).
    """
    import urllib.request
    cfg = load_admin_config()
    proxy_port = cfg.get("proxy_port")
    if not proxy_port:
        return (False, None, "no proxy_port configured")
    url = "http://127.0.0.1:%d/__proxy_control/kick" % int(proxy_port)
    body = json.dumps({"ip": ip}).encode()
    req = urllib.request.Request(url, data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            d = json.loads(resp.read().decode())
        return (bool(d.get("ok")), int(d.get("count", 0)), None)
    except Exception as e:
        # Connection refused / timeout ⇒ no proxy running ⇒ signal fallback.
        return (False, None, str(e))


def _server_kick(ip, ban_s=0):
    """Ask spectrumserver itself to disconnect and ban `ip`.

    This is the one that actually works on a normal station. Listeners reach
    spectrumserver directly on public_port, so proxy.py never sees their
    sockets, and 'ss -K' only destroys the TCP connection — which every page
    treats as a network drop and reconnects from. spectrumserver closes with
    code 4001, which the browser knows not to retry.

    ban_s is 0: a kick disconnects, it does not lock anyone out. Someone who
    wants back in reloads the page and is a normal listener again.

    Returns (ok: bool, count: int|None, err: str|None); count is None when the
    endpoint is unreachable (an older spectrumserver has no /~~kick).
    """
    import urllib.request, urllib.parse
    cfg = load_admin_config()
    if not cfg.get("public_port"):
        return (False, None, "no public_port configured")
    # Every receiver: the listener may be on any of them, or on several.
    query = urllib.parse.urlencode({"ip": ip, "secs": int(ban_s)})
    ok, count, err = False, None, None
    for port in _sdr_ports():
        url = "http://127.0.0.1:%d/~~kick?%s" % (port, query)
        try:
            with urllib.request.urlopen(url, timeout=5) as resp:
                d = json.loads(resp.read().decode())
        except Exception as e:
            err = err or str(e)
            continue
        ok = ok or bool(d.get("ok"))
        count = (count or 0) + int(d.get("count", 0))
    return (ok, count, None if count is not None else err)


# ── 8/16/24-hour ban ───────────────────────────────────────────────────────────────
# A ban is a kick with a refusal attached: spectrumserver closes the sockets
# (code 4001, which the page does not retry) and refuses the address for 8, 16 or 24 h
# (24 h is the most /~~kick allows). That refusal lives in spectrumserver's memory, so
# a receiver restart would forget it — the bans are kept in admin_bans.json
# and re-sent to every receiver once a minute (_ban_keeper). Renewing a ban
# that is still in force is silent in the spectrumserver log.
BANS_FILE   = BASE_DIR / "admin_bans.json"
BAN_HOURS   = (8, 16, 24)       # the admin's drop-down; 24 h is /~~kick's ceiling
_bans_lock  = threading.Lock()

def _valid_listener_ip(ip):
    """`ip` normalised, or None when it is not one a sysop may kick or ban."""
    ip = (ip or "").strip()
    if not re.match(r'^[\d.a-fA-F:]+$', ip) or ip in ("127.0.0.1", "::1"):
        return None
    if ip.startswith("::ffff:"):
        ip = ip[7:]
    return ip or None

def _load_bans():
    """{ip: {"until": epoch_s, "name": str}} for the bans still in force."""
    try:
        d = json.loads(BANS_FILE.read_text())
    except Exception:
        return {}
    now = time.time()
    return {ip: b for ip, b in d.items()
            if isinstance(b, dict) and float(b.get("until") or 0) > now}

def _save_bans(bans):
    tmp = BANS_FILE.with_name(BANS_FILE.name + ".tmp")
    tmp.write_text(json.dumps(bans, indent=1))
    os.replace(tmp, BANS_FILE)

def _ban_keeper():
    """Re-send every ban still in force, so a restarted receiver has it too."""
    while True:
        time.sleep(60)
        try:
            # Held for the whole pass, so an unban cannot land in between
            # and be undone by the re-send.
            with _bans_lock:
                bans = _load_bans()
                if bans or BANS_FILE.exists():
                    _save_bans(bans)      # drops the expired ones
                now = time.time()
                for ip, b in bans.items():
                    left = int(float(b["until"]) - now)
                    if left > 0:
                        _server_kick(ip, left)
        except Exception as e:
            logging.warning("ban keeper: %s", e)

def start_ban_keeper():
    threading.Thread(target=_ban_keeper, name="ban-keeper", daemon=True).start()

@app.route("/admin/api/bans")
@login_required
def api_bans():
    with _bans_lock:
        bans = _load_bans()
    out = [{"ip": ip, "until": int(b["until"]), "name": b.get("name", "")}
           for ip, b in sorted(bans.items(), key=lambda kv: kv[1]["until"])]
    return jsonify({"ok": True, "bans": out})

@app.route("/admin/api/ban", methods=["POST"])
@login_required
def api_ban():
    """Disconnect `ip` from every receiver and refuse it for 8, 16 or 24 hours."""
    data = request.get_json(silent=True) or {}
    ip = _valid_listener_ip(data.get("ip"))
    if not ip:
        return jsonify({"ok": False, "msg": "Invalid or disallowed IP"})
    name = str(data.get("name") or "")[:14]
    try:
        hours = int(data.get("hours") or 24)
    except (TypeError, ValueError):
        hours = 24
    if hours not in BAN_HOURS:
        return jsonify({"ok": False, "msg": "Ban length must be 8, 16 or 24 hours"})
    ban_s = hours * 3600
    with _bans_lock:
        bans = _load_bans()
        bans[ip] = {"until": time.time() + ban_s, "name": name}
        _save_bans(bans)
    _pok, proxy_count, _perr = _proxy_kick(ip)
    _sok, server_count, serr = _server_kick(ip, ban_s)
    if server_count is None:
        return jsonify({"ok": True, "msg": "Ban on %s saved for %d h, but no receiver "
                        "answered (%s) — it is applied when one does" % (ip, hours, serr)})
    total = (server_count or 0) + (proxy_count or 0)
    return jsonify({"ok": True, "msg": "Banned %s for %d h — %d connection%s closed" % (
        ip, hours, total, "s" if total != 1 else "")})

@app.route("/admin/api/unban", methods=["POST"])
@login_required
def api_unban():
    import urllib.request, urllib.parse
    data = request.get_json(silent=True) or {}
    ip = _valid_listener_ip(data.get("ip"))
    if not ip:
        return jsonify({"ok": False, "msg": "Invalid IP"})
    with _bans_lock:
        bans = _load_bans()
        bans.pop(ip, None)
        _save_bans(bans)
    query = urllib.parse.urlencode({"ip": ip})
    for port in _sdr_ports():
        try:
            urllib.request.urlopen("http://127.0.0.1:%d/~~unban?%s" % (port, query),
                                   timeout=5).read()
        except Exception:
            pass        # an older binary has no /~~unban; the ban then runs out
    return jsonify({"ok": True, "msg": "Unbanned %s" % ip})

@app.route("/admin/api/kick", methods=["POST"])
@login_required
def api_kick():
    """Disconnect all connections from a given IP.

    Most clients connect straight to spectrumserver (a separate C++ process),
    so the only way to drop those sockets from here is 'ss -K', which requires
    CAP_NET_ADMIN on the ss binary ('setcap cap_net_admin+ep <ss>'). We also
    ask proxy.py to close any WebSockets it owns (privilege-free) so users who
    DO go through the proxy are covered even when ss lacks the capability.
    """
    data = request.get_json(silent=True) or {}
    ip = data.get("ip", "").strip()
    if not re.match(r'^[\d.a-fA-F:]+$', ip) or ip in ("127.0.0.1", "::1", ""):
        return jsonify({"ok": False, "msg": "Invalid or disallowed IP"})
    if ip.startswith("::ffff:"):
        ip = ip[7:]  # normalize IPv4-mapped IPv6 so it matches ss / proxy keys

    # ── Privilege-free part: close WebSockets proxy.py owns (proxy users) ─────
    _pok, proxy_count, _perr = _proxy_kick(ip)
    proxy_count = proxy_count or 0

    # ── The real kick: spectrumserver closes its own sockets, with a close
    # code the browser does not reconnect from. No ban — a kick is a
    # disconnect, and coming back is the listener's own move. ────────────────
    _sok, server_count, _serr = _server_kick(ip)
    server_count = server_count or 0
    if server_count or proxy_count:
        total = server_count + proxy_count
        return jsonify({
            "ok": True,
            "msg": "Kicked %s — %d connection%s closed" % (
                ip, total, "s" if total != 1 else ""),
        })

    import shutil as _shutil
    ss_bin = _shutil.which("ss") or "/usr/bin/ss"
    try:
        # Count ALL of this IP's connections (direct 8900 + proxied 8899).
        before = subprocess.run([ss_bin, "-tn", "dst", ip],
                                capture_output=True, text=True, timeout=3)
        count_before = max(0, len(before.stdout.strip().splitlines()) - 1)

        if count_before == 0 and proxy_count == 0:
            return jsonify({"ok": False,
                            "msg": "No active connections from %s" % ip})

        # 'ss -K' (SOCK_DESTROY) needs CAP_NET_ADMIN. Without it the kernel
        # replies "Operation not permitted" but ss still exits 0, so the kick
        # silently no-ops. Verify the capability directly (never by killing the
        # target socket — that could drop the admin's own connection).
        has_perm = (os.geteuid() == 0)
        if not has_perm:
            real_ss = os.path.realpath(ss_bin)
            getcap_bin = (_shutil.which("getcap") or "/usr/sbin/getcap")
            try:
                cap = subprocess.run([getcap_bin, real_ss],
                                     capture_output=True, text=True, timeout=3)
                has_perm = "cap_net_admin" in (cap.stdout or "").lower()
            except FileNotFoundError:
                has_perm = True  # can't verify; let ss attempt it

        if not has_perm:
            # Direct spectrumserver connections cannot be closed without the
            # capability. Report the proxy streams we DID close (if any) and
            # tell the operator exactly how to enable full kicks.
            if proxy_count:
                return jsonify({
                    "ok": True,
                    "msg": ("Closed %d proxy stream%s from %s. Direct "
                            "connections still need: sudo setcap "
                            "cap_net_admin+ep %s" % (
                                proxy_count, "s" if proxy_count != 1 else "",
                                ip, os.path.realpath(ss_bin))),
                })
            return jsonify({
                "ok": False,
                "msg": ("Kick has no effect — these users connect directly to "
                        "spectrumserver and closing those sockets needs "
                        "CAP_NET_ADMIN. Run once: sudo setcap cap_net_admin+ep "
                        "%s  (then restart nothing — takes effect immediately)"
                        % os.path.realpath(ss_bin)),
            })

        # Deferred so the admin browser receives the response before ss -K can
        # terminate the admin's own connection (if it shares the kicked IP/NAT).
        def _kick_later():
            import time
            time.sleep(0.3)
            try:
                subprocess.run([ss_bin, "-K", "dst", ip],
                               capture_output=True, timeout=5)
            except Exception:
                pass

        threading.Thread(target=_kick_later, daemon=True).start()
        total = max(count_before, proxy_count)
        return jsonify({
            "ok":  True,
            "msg": "Kicked %s — %d connection%s terminated" % (
                ip, total, "s" if total != 1 else ""),
        })
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)})

# ── Receivers on this computer ────────────────────────────────────────────────
# Each receiver is the spectrumserver listening on one of _sdr_ports(); its
# working folder holds its own logs/ and crash.log (the main folder for the
# first receiver, instances/<id> for the others).
def _receiver_labels():
    labels, folders = {}, {}
    for r in _receivers_toml().get("receiver", []):
        try:
            port = int(r.get("port"))
        except (TypeError, ValueError):
            continue
        labels[port] = str(r.get("name") or r.get("id") or "")
        inst = str(r.get("instance") or "").strip()
        folders[port] = BASE_DIR / "instances" / inst if inst else BASE_DIR
    return labels, folders


def _receiver_list():
    """[{label, port, pid, folder, uptime_s}] — pid None when nothing listens."""
    labels, folders = _receiver_labels()
    listen = {}
    if HAS_PSUTIL:
        try:
            for c in psutil.net_connections(kind="tcp"):
                if c.status == psutil.CONN_LISTEN and c.pid and c.laddr:
                    listen.setdefault(c.laddr.port, c.pid)
        except Exception:
            pass
    out = []
    for port in _sdr_ports():
        pid, folder, up = listen.get(port), folders.get(port, BASE_DIR), None
        if pid:
            try:
                p = psutil.Process(pid)
                folder = Path(p.cwd())
                up = int(time.time() - p.create_time())
            except Exception:
                pid = None
        out.append({"label": labels.get(port) or "port %d" % port, "port": port,
                    "pid": pid, "folder": str(folder), "uptime_s": up})
    return out


def _receiver_answers(port):
    import urllib.request
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/users" % port, timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def _rade_status():
    """[{key, label, state, detail, uptime_s}] for RADE V1 and V2 (beta).

    state: "ready" (helper listening and that version's files present),
    "starting" (helper running, port not open yet), "missing" (helper up but
    that version is not installed) or "off" (no rade_helper.py running).
    Paths and port come from the running helper's own environment, with the
    same defaults rade_helper.py uses."""
    import socket as _so
    proc = None
    if HAS_PSUTIL:
        for p in psutil.process_iter(["pid", "cmdline", "create_time"]):
            try:
                if any(a.endswith("rade_helper.py") for a in (p.info["cmdline"] or [])):
                    proc = p
                    break
            except Exception:
                continue
    env = {}
    if proc:
        try:
            env = proc.environ()
        except Exception:
            env = {}
    home = Path.home()
    radae = Path(env.get("RADAE_DIR", home / "radae")).expanduser()
    rade_c = Path(env.get("RADE_C_DIR", home / "rade_c")).expanduser()
    need = {
        "v1": [radae / "radae_rxe.py",
               Path(env.get("RADE_MODEL", radae / "model19_check3" / "checkpoints" / "checkpoint_epoch_100.pth")),
               Path(env.get("LPCNET_DEMO", radae / "build" / "src" / "lpcnet_demo"))],
        "v2": [Path(env.get("RADE_C_RX", rade_c / "build" / "src" / "radae_rx")),
               Path(env.get("RADE_C_LPCNET", rade_c / "build" / "src" / "lpcnet_demo"))],
    }
    port = int(env.get("RADE_HELPER_PORT", 8074) or 8074)
    listening = False
    if proc:
        try:
            with _so.create_connection(("127.0.0.1", port), timeout=1):
                listening = True
        except OSError:
            pass
    up = int(time.time() - proc.info["create_time"]) if proc else None
    out = []
    for key, label in (("v1", "RADE V1"), ("v2", "RADE V2 (beta)")):
        missing = [str(f) for f in need[key] if not f.exists()]
        if not proc:
            state, detail = "off", "helper not running"
        elif not listening:
            state, detail = "starting", "helper starting (port %d not open yet)" % port
        elif missing:
            state, detail = "missing", "not installed — " + missing[0] + " not found"
        else:
            state, detail = "ready", "ready on port %d" % port
        out.append({"key": key, "label": label, "state": state, "detail": detail, "uptime_s": up})
    return out


# ── 1. Alerts (email / Telegram) ──────────────────────────────────────────────
# A monitor thread looks every 30 s at each receiver (down / back up /
# restarted), the thermal guard's stage and every receiver's crash.log, and
# sends what it finds by email and/or Telegram. The settings live in
# admin_config.json under "alerts" (that file is the panel's private one and
# never leaves the station). The first pass after the panel starts only
# learns the current state, so restarting the panel sends nothing.
ALERT_EVENTS = ("down", "up", "restart", "thermal", "crash")
ALERT_DEFAULTS = {
    "events": {e: True for e in ALERT_EVENTS},
    "email": {"enabled": False, "host": "", "port": 465, "security": "ssl",
              "user": "", "password": "", "from": "", "to": ""},
    "telegram": {"enabled": False, "token": "", "chat_id": ""},
}
ALERT_SECRET = "********"
ALERT_REPEAT_S = 300              # the same alert at most once per 5 minutes
_alert_events = deque(maxlen=60)  # recent events, shown on the Dashboard
_alert_last = {}
_alert_lock = threading.Lock()


def _alert_cfg():
    cfg = json.loads(json.dumps(ALERT_DEFAULTS))
    saved = load_admin_config().get("alerts") or {}
    for k in ("events", "email", "telegram"):
        if isinstance(saved.get(k), dict):
            cfg[k].update(saved[k])
    return cfg


def _station_name():
    try:
        si = json.loads(read_file_safe(BASE_DIR / "frontend" / "site_information.json"))
        return str(si.get("siteSysop") or "").strip() or "PhantomSDR-Plus"
    except Exception:
        return "PhantomSDR-Plus"


def _alert_send(subject, body):
    """Send to every enabled channel. Returns [(channel, ok, message)]."""
    import urllib.request, urllib.parse
    cfg, res = _alert_cfg(), []
    title = "[%s] %s" % (_station_name(), subject)
    tg = cfg["telegram"]
    if tg.get("enabled") and tg.get("token") and tg.get("chat_id"):
        try:
            data = urllib.parse.urlencode({"chat_id": tg["chat_id"],
                                           "text": title + "\n\n" + body}).encode()
            url = "https://api.telegram.org/bot%s/sendMessage" % tg["token"]
            with urllib.request.urlopen(url, data=data, timeout=10) as r:
                ok = json.loads(r.read().decode()).get("ok", False)
            res.append(("telegram", bool(ok), "sent" if ok else "Telegram refused it"))
        except Exception as e:
            res.append(("telegram", False, str(e)))
    em = cfg["email"]
    if em.get("enabled") and em.get("host") and em.get("to"):
        try:
            import smtplib
            from email.message import EmailMessage
            from email.utils import formataddr, parseaddr
            # FROM may be an address, "Name <address>", or just a name — a
            # name alone is shown as the sender's name over the USER address.
            frm = str(em.get("from") or "").strip()
            user = str(em.get("user") or "").strip()
            name, addr = parseaddr(frm)
            if "@" not in addr:
                name, addr = frm, user
            if "@" not in addr:
                raise ValueError("the sender needs a full email address: put it in "
                                 "FROM, or use your full address as USER")
            msg = EmailMessage()
            msg["Subject"], msg["To"] = title, em["to"]
            msg["From"] = formataddr((name, addr)) if name else addr
            msg.set_content(body)
            port = int(em.get("port") or (465 if em.get("security") == "ssl" else 587))
            if em.get("security") == "ssl":
                s = smtplib.SMTP_SSL(em["host"], port, timeout=15)
            else:
                s = smtplib.SMTP(em["host"], port, timeout=15)
                if em.get("security") == "starttls":
                    s.starttls()
            if em.get("user"):
                s.login(em["user"], em.get("password", ""))
            s.send_message(msg, from_addr=addr)
            s.quit()
            res.append(("email", True, "sent"))
        except Exception as e:
            res.append(("email", False, str(e)))
    return res


def _alert_event(kind, key, subject, body, send=True):
    """Record an event; send it if that kind is enabled and not just sent.
    send=False only puts it on the Dashboard."""
    now = time.time()
    with _alert_lock:
        _alert_events.appendleft({"t": int(now), "kind": kind, "text": subject})
        if not send or not _alert_cfg()["events"].get(kind, True):
            return
        if now - _alert_last.get(key, 0) < ALERT_REPEAT_S:
            return
        _alert_last[key] = now
    try:
        for ch, ok, m in _alert_send(subject, body):
            if not ok:
                logging.warning("alert via %s failed: %s", ch, m)
    except Exception as e:
        logging.warning("alert failed: %s", e)


def _crash_files(receivers=None):
    seen, out = set(), []
    for r in (receivers if receivers is not None else _receiver_list()):
        f = Path(r["folder"]) / "crash.log"
        if str(f) not in seen:
            seen.add(str(f)); out.append((r["label"], f))
    f = BASE_DIR / "crash.log"
    if str(f) not in seen:
        out.append(("station", f))
    return out


def _alert_monitor():
    state, first = {}, True
    while True:
        try:
            receivers = _receiver_list()
            for r in receivers:
                port, label = r["port"], r["label"]
                up = bool(r["pid"]) and _receiver_answers(port)
                st = state.setdefault(port, {"up": up, "pid": r["pid"], "fails": 0, "down": False})
                if up:
                    if st["down"] and not first:
                        _alert_event("up", "up%d" % port, "%s is back on air" % label,
                                     "%s (port %d) answers again." % (label, port))
                    elif st["pid"] and r["pid"] and r["pid"] != st["pid"] and not first:
                        _alert_event("restart", "restart%d" % port, "%s was restarted" % label,
                                     "%s (port %d) is running again as a new process "
                                     "(pid %s, was %s) — restarted by the watchdog, a "
                                     "start script or the thermal guard." % (label, port, r["pid"], st["pid"]))
                    st.update(up=True, pid=r["pid"], fails=0, down=False)
                else:
                    st["fails"] += 1
                    if st["fails"] == 2 and not st["down"]:       # about a minute
                        st["down"] = True
                        if not first:
                            _alert_event("down", "down%d" % port, "%s is OFF the air" % label,
                                         "%s (port %d) has not answered for about a minute." % (label, port))
            # RADE V1 / V2: every change into "ready" goes on the Dashboard;
            # email/Telegram only when it had been out for about a minute,
            # like the receivers above. "missing" (not installed) is quiet.
            for r in _rade_status():
                k = "rade:" + r["key"]
                ready = r["state"] == "ready"
                st = state.setdefault(k, {"ready": ready, "fails": 0, "down": False})
                if ready:
                    if not st["ready"] and not first:
                        _alert_event("up", k + "up", "%s is ready" % r["label"],
                                     "%s: %s." % (r["label"], r["detail"]), send=st["down"])
                    st.update(ready=True, fails=0, down=False)
                elif r["state"] != "missing":
                    st["ready"] = False
                    st["fails"] += 1
                    if st["fails"] == 2 and not st["down"]:
                        st["down"] = True
                        if not first:
                            _alert_event("down", k + "down", "%s is not available" % r["label"],
                                         "%s: %s." % (r["label"], r["detail"]))
            for label, f in _crash_files(receivers):
                try:
                    size = f.stat().st_size
                except OSError:
                    size = 0
                key = "crash:" + str(f)
                old = state.get(key)
                state[key] = size
                if old is not None and size > old and not first:
                    with open(f, "rb") as fh:
                        fh.seek(max(old, size - 4000))
                        new = fh.read().decode("utf-8", "replace").strip()
                    _alert_event("crash", key, "New crash.log entry (%s)" % label,
                                 "\n".join(new.splitlines()[-25:]))
            if HAS_THERMAL:
                try:
                    tg = thermal_guard.status()
                    stage = tg.get("stage")
                    old = state.get("thermal")
                    state["thermal"] = stage
                    if old is not None and stage != old and not first:
                        _alert_event("thermal", "thermal:" + str(stage),
                                     "Thermal guard: %s (was %s)" % (stage, old),
                                     "CPU %s °C. %s" % (tg.get("temp"), tg.get("last_event") or ""))
                except Exception:
                    pass
            first = False
        except Exception as e:
            logging.warning("alert monitor: %s", e)
        time.sleep(30)


def start_alert_monitor():
    threading.Thread(target=_alert_monitor, name="alert-monitor", daemon=True).start()


@app.route("/admin/api/alerts", methods=["GET", "POST"])
@login_required
def api_alerts():
    if request.method == "GET":
        cfg = _alert_cfg()
        for ch, k in (("email", "password"), ("telegram", "token")):
            cfg[ch]["has_" + k] = bool(cfg[ch].get(k))
            cfg[ch][k] = ALERT_SECRET if cfg[ch].get(k) else ""
        return jsonify({"ok": True, "alerts": cfg})
    data = request.get_json(silent=True) or {}
    cur = _alert_cfg()
    new = {"events": {e: bool((data.get("events") or {}).get(e, True)) for e in ALERT_EVENTS}}
    for ch in ("email", "telegram"):
        d = dict(cur[ch])
        for k, v in (data.get(ch) or {}).items():
            if k in d and not k.startswith("has_"):
                if k in ("password", "token") and v == ALERT_SECRET:
                    continue                      # unchanged secret
                d[k] = v
        d["enabled"] = bool(d.get("enabled"))
        new[ch] = d
    try:
        new["email"]["port"] = int(new["email"].get("port") or 0) or 465
    except (TypeError, ValueError):
        new["email"]["port"] = 465
    if new["email"].get("security") not in ("ssl", "starttls", "none"):
        new["email"]["security"] = "ssl"
    cfg = load_admin_config()
    cfg["alerts"] = new
    save_admin_config(cfg)
    return jsonify({"ok": True, "msg": "Alert settings saved"})


@app.route("/admin/api/alerts/test", methods=["POST"])
@login_required
def api_alerts_test():
    res = _alert_send("Test alert", "This is a test from the PhantomSDR-Plus admin panel. "
                      "If you can read it, alerts reach you.")
    if not res:
        cfg = _alert_cfg()
        miss = []
        if not (cfg["telegram"].get("enabled") or cfg["email"].get("enabled")):
            miss.append("tick TELEGRAM or EMAIL")
        if cfg["telegram"].get("enabled") and not (cfg["telegram"].get("token") and cfg["telegram"].get("chat_id")):
            miss.append("Telegram needs both the bot token and the chat ID")
        if cfg["email"].get("enabled") and not (cfg["email"].get("host") and cfg["email"].get("to")):
            miss.append("email needs the SMTP server and the To address")
        return jsonify({"ok": False, "msg": "Nothing to send to: " + "; ".join(miss)})
    ok = all(r[1] for r in res)
    return jsonify({"ok": ok, "msg": "; ".join("%s: %s" % (c, m) for c, _, m in res)})


# ── 2. Backup and restore of the station's own settings ───────────────────────
# Exactly the files that make this station what it is — configs, receiver
# list, station wizard answers, site information, markers, band tuning, relay,
# spot reporting and bans. Not admin_config.json (password, alert secrets),
# not logs, not the program. A restore takes only these same paths, and every
# file it replaces is copied first to admin-backups/restore-<time>/.
BACKUP_PATTERNS = (
    "*.toml", "station.conf", "markers.json", "autorun.json", "websdr_relay.json", "drm.json", "drm-heard.json",
    "admin_bans.json", "frontend/site_information.json", "frontend/src/bands-config.js",
    "instances/*/config.toml", "instances/*/instance.env", "instances/*/markers.json",
)
BACKUP_MAX_BYTES = 10 * 1024 * 1024


def _backup_allowed(rel):
    import fnmatch
    rel = rel.replace("\\", "/")
    if rel.startswith("/") or ".." in rel.split("/") or not rel:
        return False
    return any(fnmatch.fnmatchcase(rel, p) and rel.count("/") == p.count("/") for p in BACKUP_PATTERNS)


def _backup_files():
    files = []
    for pat in BACKUP_PATTERNS:
        for f in sorted(BASE_DIR.glob(pat)):
            if f.is_file():
                rel = str(f.relative_to(BASE_DIR))
                if _backup_allowed(rel) and rel not in files:
                    files.append(rel)
    return files


@app.route("/admin/api/backup")
@login_required
def api_backup():
    import io, zipfile, socket as _s
    from flask import send_file
    buf = io.BytesIO()
    files = _backup_files()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in files:
            z.write(BASE_DIR / rel, rel)
        z.writestr("BACKUP-INFO.json", json.dumps({
            "made": datetime.now().isoformat(timespec="seconds"),
            "host": _s.gethostname(), "station": _station_name(), "files": files}, indent=1))
    buf.seek(0)
    name = "phantomsdr-settings-%s-%s.zip" % (_station_name().replace("/", "-"),
                                              datetime.now().strftime("%Y%m%d-%H%M"))
    return send_file(buf, mimetype="application/zip", as_attachment=True, download_name=name)


@app.route("/admin/api/restore", methods=["POST"])
@login_required
def api_restore():
    import io, zipfile, shutil as _sh
    up = request.files.get("file")
    if not up:
        return jsonify({"ok": False, "msg": "No file"})
    raw = up.read(BACKUP_MAX_BYTES + 1)
    if len(raw) > BACKUP_MAX_BYTES:
        return jsonify({"ok": False, "msg": "File too large for a settings backup"})
    try:
        z = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile:
        return jsonify({"ok": False, "msg": "Not a zip file"})
    keep = BASE_DIR / "admin-backups" / ("restore-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
    restored, skipped = [], []
    for info in z.infolist():
        rel = info.filename
        if info.is_dir() or rel == "BACKUP-INFO.json":
            continue
        if not _backup_allowed(rel) or info.file_size > BACKUP_MAX_BYTES:
            skipped.append(rel)
            continue
        dest = BASE_DIR / rel
        if dest.exists():
            (keep / rel).parent.mkdir(parents=True, exist_ok=True)
            _sh.copy2(dest, keep / rel)
        dest.parent.mkdir(parents=True, exist_ok=True)
        with z.open(info) as src, open(dest, "wb") as out:
            _sh.copyfileobj(src, out)
        restored.append(rel)
    need = []
    if any(r.endswith(".toml") or r.endswith("instance.env") or r == "station.conf" for r in restored):
        need.append("restart the receivers")
    if any(r.startswith("frontend/") for r in restored):
        need.append("rebuild the page (./recompile.sh --frontend)")
    if any(r in ("websdr_relay.json",) for r in restored):
        need.append("restart phantomsdr-websdr-relay")
    msg = "Restored %d file%s" % (len(restored), "" if len(restored) == 1 else "s")
    if skipped:
        msg += "; skipped %d that are not station settings" % len(skipped)
    if need:
        msg += ". Then " + ", ".join(need) + "."
    return jsonify({"ok": bool(restored), "msg": msg, "restored": restored, "skipped": skipped,
                    "kept": str(keep.relative_to(BASE_DIR)) if keep.exists() else ""})


# ── 3. Visitor statistics (private, with the addresses) ───────────────────────
# From every receiver's logs/users_YYYY-MM-DD.jsonl as written on disk — the
# copies with the IP addresses, which the public /logs/ no longer serves. A
# session is one listener id, from its first to its last logged event. Names
# are not in these logs. "decoder" (the decoder running in the listener's
# page) is in the lines written since the field was added.
_vstats_cache = {}


def _cc_of(geo):
    geo = (geo or "").strip()
    if geo == "Local":
        return "Local"
    m = re.search(r",\s*([A-Za-z]{2})\s*$", geo)
    return m.group(1).upper() if m else ""


@app.route("/admin/api/visitor-stats")
@login_required
def api_visitor_stats():
    try:
        days = max(1, min(31, int(request.args.get("days", 7))))
    except ValueError:
        days = 7
    hit = _vstats_cache.get(days)
    if hit and time.time() - hit[0] < 60:
        return jsonify(hit[1])
    labels, folders = _receiver_labels()
    dirs = {}
    for port in _sdr_ports():
        dirs[labels.get(port) or "port %d" % port] = folders.get(port, BASE_DIR) / "logs"
    today = datetime.utcnow().date()
    dates = [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]
    sess = {}                                   # (rx, id) -> session
    for rx, d in dirs.items():
        for ds in dates:
            f = d / ("users_%s.jsonl" % ds)
            try:
                fh = open(f, encoding="utf-8", errors="replace")
            except OSError:
                continue
            with fh:
                for line in fh:
                    try:
                        ev = json.loads(line)
                        t = datetime.strptime(ev["ts"], "%Y-%m-%dT%H:%M:%SZ").timestamp()
                    except Exception:
                        continue
                    key = (rx, ev.get("id"))
                    s = sess.get(key)
                    if s is None:
                        s = sess[key] = {"rx": rx, "ip": "", "geo": "", "start": t, "end": t, "dec": set()}
                    if ev.get("decoder"):
                        s["dec"].add(str(ev["decoder"])[:12])
                    s["end"] = max(s["end"], t)
                    s["start"] = min(s["start"], t)
                    if ev.get("event") == "disconnect":
                        try:
                            s["start"] = min(s["start"], t - float(ev.get("duration_s") or 0))
                        except (TypeError, ValueError):
                            pass
                    ip = (ev.get("ip") or "").replace("::ffff:", "")
                    if ip:
                        s["ip"] = ip
                    g = ev.get("geo") or ""
                    if g and g != ip and not re.match(r"^[0-9a-fA-F.:]+$", g):
                        s["geo"] = g
    S = [s for s in sess.values() if s["ip"] not in ("127.0.0.1", "::1", "")]
    for s in S:
        s["end"] = min(s["end"], s["start"] + 12 * 3600)   # a stuck session counts at most 12 h
    def peak(items):
        pts = sorted([(s["start"], 1) for s in items] + [(s["end"], -1) for s in items])
        cur = best = 0
        for _, d in pts:
            cur += d
            best = max(best, cur)
        return best
    per_day = []
    for ds in dates:
        ds_s = [s for s in S if datetime.utcfromtimestamp(s["start"]).date().isoformat() == ds]
        per_day.append({"date": ds, "sessions": len(ds_s), "visitors": len({s["ip"] for s in ds_s}),
                        "hours": round(sum(s["end"] - s["start"] for s in ds_s) / 3600, 1),
                        "peak": peak(ds_s)})
    hours = [0] * 24
    for s in S:
        hours[datetime.utcfromtimestamp(s["start"]).hour] += 1
    by_cc = {}
    for s in S:
        by_cc.setdefault(_cc_of(s["geo"]) or "?", set()).add(s["ip"])
    countries = sorted(([cc, len(v)] for cc, v in by_cc.items()), key=lambda x: -x[1])[:20]
    by_dec = {}
    for s in S:
        for name in s["dec"]:
            by_dec[name] = by_dec.get(name, 0) + 1
    decoders = sorted(([n, c] for n, c in by_dec.items()), key=lambda x: -x[1])
    by_ip = {}
    for s in S:
        by_ip.setdefault(s["ip"], []).append(s)
    addrs = []
    for ip, ss in by_ip.items():
        geo = next((s["geo"] for s in ss if s["geo"]), "")
        addrs.append({"ip": ip, "geo": geo, "sessions": len(ss), "peak": peak(ss),
                      "hours": round(sum(s["end"] - s["start"] for s in ss) / 3600, 1),
                      "last": int(max(s["end"] for s in ss)),
                      "rx": sorted({s["rx"] for s in ss})})
    addrs.sort(key=lambda a: (-a["peak"], -a["sessions"]))
    out = {"ok": True, "days": days, "receivers": list(dirs.keys()),
           "total": {"sessions": len(S), "visitors": len(by_ip),
                     "hours": round(sum(s["end"] - s["start"] for s in S) / 3600, 1),
                     "peak": max([d["peak"] for d in per_day] or [0])},
           "per_day": per_day, "hours": hours, "countries": countries, "decoders": decoders,
           "addresses": addrs[:20]}
    _vstats_cache[days] = (time.time(), out)
    return jsonify(out)


# ── 4. System health ──────────────────────────────────────────────────────────
_health_cache = {}


def _folder_size(p):
    total = 0
    for root, _dirs, files in os.walk(p):
        for fn in files:
            try:
                total += os.path.getsize(os.path.join(root, fn))
            except OSError:
                pass
    return total


@app.route("/admin/api/health")
@login_required
def api_health():
    import shutil as _sh
    du = _sh.disk_usage(BASE_DIR)
    hit = _health_cache.get("folders")
    if hit and time.time() - hit[0] < 120:
        folders = hit[1]
    else:
        folders = []
        cand = [BASE_DIR / "logs", BASE_DIR / "logproxy"] + sorted(BASE_DIR.glob("instances/*/logs"))
        for p in cand:
            if p.is_dir():
                folders.append({"path": str(p.relative_to(BASE_DIR)), "bytes": _folder_size(p)})
        _health_cache["folders"] = (time.time(), folders)
    rx, receivers = [], _receiver_list()
    for r in receivers:
        rx.append({"label": r["label"], "port": r["port"], "pid": r["pid"],
                   "uptime_s": r["uptime_s"], "up": bool(r["pid"]) and _receiver_answers(r["port"])})
    newest = None
    for label, f in _crash_files(receivers):
        try:
            st = f.stat()
        except OSError:
            continue
        if st.st_size and (newest is None or st.st_mtime > newest["mtime"]):
            lines = tail_file_lines(f, 12)
            newest = {"label": label, "path": str(f.relative_to(BASE_DIR)) if str(f).startswith(str(BASE_DIR)) else str(f),
                      "mtime": int(st.st_mtime), "lines": lines}
    with _alert_lock:
        events = list(_alert_events)[:15]
    return jsonify({"ok": True,
                    "disk": {"total": du.total, "used": du.used, "free": du.free},
                    "folders": folders, "receivers": rx, "rade": _rade_status(),
                    "crash": newest, "events": events})


# ── Access-log noise filter ───────────────────────────────────────────────────
# The dashboard polls these paths every 3-5s for as long as a browser tab is
# open, so werkzeug's access log fills admin.log with hundreds of identical
# successful GETs an hour and buries the entries worth reading (logins, POSTed
# actions, errors). Successful polls are dropped; anything that is not a plain
# 200 still gets logged, so failures on these paths remain visible. proxy.py
# filters the same traffic on its own side (see QuietPollFilter there) — this
# is the second half of that, for requests reaching Flask directly.
# /admin/api/logs/clear is here for a different reason than the pollers: its own
# access line is written to admin.log *after* the truncate, so a successful clear
# always left one fresh line behind and the pane looked like it had not cleared.
_QUIET_PATHS = ("/admin/api/status", "/admin/api/thermal", "/admin/api/logs",
                "/admin/api/logs/clear", "/admin/api/health",
                "/admin/api/autorun/status", "/admin/api/users", "/admin/api/sdr-users",
                "/admin/api/graph-stats", "/admin/api/chat", "/admin/api/bans",
                "/admin/api/websdr-relay", "/admin/api/drm",
                # every open listener page polls these every few seconds; who
                # listened is in the /audio and /waterfall lines and logs/users_*.jsonl
                "/users", "/wf-message.json", "/receivers.json", "/api/dxspots",
                "/logo.jpg", "/favicon.ico", "/stats/api/system-stats",
                # websdr.org's registration check, every 10 s while listed
                "/~~orgstatus")
# 404 is the normal answer here (no waterfall message set), so it is quiet too.
_QUIET_404 = ("/wf-message.json",)
_ACCESS_RE = re.compile(r'"[A-Z]+ (?P<path>[^ ?"]+)[^"]*" (?P<status>\d{3})')


class QuietPollFilter(logging.Filter):
    def filter(self, record):
        m = _ACCESS_RE.search(record.getMessage())
        if not m:
            return True
        if m.group("status") == "404":
            return m.group("path") not in _QUIET_404
        if m.group("status") != "200":
            return True
        return m.group("path") not in _QUIET_PATHS


# ─── Startup ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not ADMIN_CONFIG_FILE.exists():
        save_admin_config(DEFAULT_CONFIG)
        print("[PhantomSDR Admin] Created admin_config.json with default password 'admin'")

    cfg = load_admin_config()
    port = cfg.get("port", ADMIN_PORT)
    bind = ADMIN_BIND
    proxy_port = cfg.get("proxy_port", PUBLIC_PORT)
    sdr_port = cfg.get("public_port", PUBLIC_PORT)

    print("=" * 60)
    print("  PhantomSDR-Plus Admin Panel  [INTERNAL SERVICE]")
    print(f"  Listening : http://{bind}:{port}/admin")
    print(f"  Public URL: via proxy.py -> http://SERVER_IP:{proxy_port}/admin")
    print(f"  Password  : admin  (CHANGE THIS IMMEDIATELY)")
    print(f"  Dir       : {BASE_DIR}")
    print("=" * 60)
    print("  NOTE: Run proxy.py separately to share the main SDR port.")
    print(f"        spectrumserver must use port {sdr_port} in your .toml")
    print("=" * 60)

    # Arm the thermal guard before the sampler that ticks it.
    if start_thermal_guard():
        _tg = thermal_guard.status()
        _tt = thermal_guard.read_cpu_temp()
        print("  Thermal   : %s, mode=%s, sensor=%s" % (
            "enabled" if _tg.get("enabled") else "disabled",
            _tg.get("mode"), (_tt[2] if _tt else "NONE — guard cannot act")))
        if _tt and _tt[1]:
            print("              crit=%.0fC -> stop at %.0fC (override in Settings)"
                  % (_tt[1], _tt[1] - thermal_guard.OFF_STOP))
    else:
        print("  Thermal   : guard unavailable (thermal_guard.py missing)")

    # Start sampling immediately, not on first visit to the Graphs page, so the
    # page opens onto existing history rather than an empty plot.
    start_graph_sampler()
    start_ban_keeper()
    start_alert_monitor()
    print(f"  Graphs    : sampling every {GRAPH_INTERVAL_S}s, "
          f"{GRAPH_HISTORY_S // 3600}h history (in memory)")

    if not HAS_PSUTIL:
        print("[WARN] psutil not installed - system stats limited. pip3 install psutil")
    if tomllib is None:
        print("[WARN] tomllib unavailable - TOML editing is text-only")

    logging.getLogger("werkzeug").addFilter(QuietPollFilter())

    app.run(host=bind, port=port, debug=False, threaded=True)
