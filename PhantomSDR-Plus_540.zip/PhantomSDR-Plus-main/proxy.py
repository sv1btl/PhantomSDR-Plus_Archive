#!/usr/bin/env python3
"""
PhantomSDR-Plus Reverse Proxy
==============================
Reads all configuration from admin_config.json (written by setup_admin.sh):

  proxy_port   → port this proxy listens on          (e.g. 8900, the listener port)
  port         → admin panel internal port           (e.g. 3000)
  public_port  → spectrumserver port                 (e.g. 8901)
  sdr_host     → host used to reach spectrumserver   (127.0.0.1)

Routes:
  /admin*  → Admin panel     (localhost:{port})
  /*       → Spectrumserver  ({sdr_host}:{public_port})

Several receivers on one port: see receivers.toml.example. With a
receivers.toml next to this file, /* goes to one of the receivers listed there
(chosen by ?rx=, the rx cookie, the Host header, else the default), and the
proxy can also listen on the public port the listeners already use.

Note on sdr_host
----------------
Older versions had to set this to the machine's LAN IP because spectrumserver
closed WebSockets arriving from 127.0.0.1.  That filter is gone, so the upstream
is plain loopback: no DHCP lease change or downed interface can break the proxy,
and setup no longer has to guess which of docker0 / vmnet* / a VPN is the "real"
interface.  Override sdr_host in admin_config.json only if spectrumserver runs
on a different machine.

Run:  python3 proxy.py            (foreground)
      bash manage_admin.sh start  (background with logging)
"""

import asyncio
import logging
import re
import sys
import json
from pathlib import Path

try:
    import aiohttp
    from aiohttp import web, ClientSession, ClientTimeout, WSMsgType
except ImportError:
    print("[ERROR] aiohttp is not installed. Run:", file=sys.stderr)
    print("        pip3 install aiohttp --break-system-packages", file=sys.stderr)
    sys.exit(1)

# ── Load configuration ─────────────────────────────────────────────────────────
# Two sources. station.conf is written by configure-station.sh on a station set
# up with it, and gives the ports of the whole station. admin_config.json is
# written by setup_admin.sh and wins wherever both name the same port, so a
# station installed before station.conf existed behaves exactly as it did.
_STATION_KEYS = {
    "PORT_PUBLIC": "proxy_port",   # the one port listeners use
    "PORT_SDR":    "public_port",  # spectrumserver, on loopback behind us
    "PORT_ADMIN":  "port",         # admin panel, on loopback behind us
    "PORT_RADE":   "rade_port",
    "PORT_DRM":    "drm_port",     # autorun/drm-helper.js
    "PORT_STATS":  "stats_port",
    "PORT_RELAY":  "relay_port",
    "PORT_TLS":    "tls_port",     # loopback port the https front (Caddy) uses
}


def _read_station_conf(path: Path) -> dict:
    """The ports in station.conf (shell KEY=value lines), as admin_config keys."""
    out = {}
    try:
        lines = path.read_text().splitlines()
    except OSError:
        return out
    for line in lines:
        m = re.match(r'\s*([A-Z_]+)=["\']?(\d+)["\']?\s*(#.*)?$', line)
        if m and m.group(1) in _STATION_KEYS:
            out[_STATION_KEYS[m.group(1)]] = int(m.group(2))
    return out


_cfg = _read_station_conf(Path(__file__).parent / "station.conf")
_cfg_path = Path(__file__).parent / "admin_config.json"
try:
    with open(_cfg_path) as _f:
        _cfg.update(json.load(_f))
except FileNotFoundError:
    if not _cfg:
        print(f"[ERROR] admin_config.json not found at {_cfg_path}", file=sys.stderr)
        print("        Run configure-station.sh or setup_admin.sh first.", file=sys.stderr)
        sys.exit(1)
except json.JSONDecodeError as _e:
    print(f"[ERROR] admin_config.json is invalid JSON: {_e}", file=sys.stderr)
    sys.exit(1)

for _key in ("port", "public_port", "proxy_port"):
    if _key not in _cfg:
        print(f"[ERROR] Missing '{_key}' in admin_config.json.", file=sys.stderr)
        print("        Re-run configure-station.sh or setup_admin.sh.", file=sys.stderr)
        sys.exit(1)


# sdr_host: loopback by default — spectrumserver serves local connections now
# (see src/websocket.cpp on_open). An explicit sdr_host in admin_config.json is
# still honoured for the unusual case of spectrumserver running on another host.
_sdr_host = _cfg.get("sdr_host") or "127.0.0.1"
_sdr_port = int(_cfg["public_port"])

LISTEN_HOST    = "0.0.0.0"
LISTEN_PORT    = int(_cfg["proxy_port"])
ADMIN_UPSTREAM = f"http://127.0.0.1:{int(_cfg['port'])}"
SDR_UPSTREAM   = f"http://{_sdr_host}:{_sdr_port}"
if _sdr_port == LISTEN_PORT and _sdr_host in ("127.0.0.1", "localhost", "::1"):
    print(f"[ERROR] admin_config.json: public_port (spectrumserver) and proxy_port are "
          f"both {LISTEN_PORT} — the proxy would forward to itself.", file=sys.stderr)
    print("        Give spectrumserver its own port: bash configure-station.sh", file=sys.stderr)
    sys.exit(1)

# ── Side services behind the same public port ──────────────────────────────────
# A station set up with configure-station.sh forwards ONE port on its router.
# The RADE sidecar, the DRM helper, the statistics server and the WebSDR relay
# then listen on loopback, and the page reaches each of them here under a path
# prefix that is
# stripped on the way through (/stats/api/system-stats → /api/system-stats).
# A station whose config names none of these ports gets no such route, and
# those paths go to spectrumserver exactly as before.
SIDE_SERVICES: "dict[str, str]" = {}
for _prefix, _key in (("/rade", "rade_port"), ("/drm", "drm_port"),
                      ("/stats", "stats_port"), ("/relay", "relay_port")):
    if _cfg.get(_key):
        SIDE_SERVICES[_prefix] = f"http://127.0.0.1:{int(_cfg[_key])}"


def _side_service(request: web.Request) -> "tuple[str, str] | None":
    """(upstream, path for it) when the request is for a side service."""
    path = request.path
    for prefix, upstream in SIDE_SERVICES.items():
        if path == prefix or path.startswith(prefix + "/"):
            rest = path[len(prefix):] or "/"
            qs = request.rel_url.query_string
            return upstream, rest + ("?" + qs if qs else "")
    return None

# ── Several receivers behind one port (receivers.toml) ─────────────────────────
# Optional. Without the file there is one SDR upstream, exactly as before. With
# it, every non-admin request goes to one of the receivers listed there, chosen
# in this order:
#   1. ?rx=<id> in the URL — the page, and every socket and poll it opens
#      (frontend/src/lib/rx.js adds it)
#   2. the rx cookie, set on any response to a request with a valid ?rx=
#   3. the receiver whose `hostnames` list holds the Host header's name
#   4. the default receiver
# A Kiwi client carries none of these, so it always lands on the default.
# [front] port is a second listening port next to proxy_port: the public port
# the listeners, the directories and websdr.org already know.
RX_COOKIE   = "rx"
RECEIVERS: "dict[str, dict]" = {}
DEFAULT_RX  = ""
FRONT_PORT  = 0
_rx_path = Path(__file__).parent / "receivers.toml"
_rx_mtime = None           # receivers.toml's mtime when it was last read
_MAIN_UPSTREAM = SDR_UPSTREAM


class _RxError(Exception):
    pass


def _parse_receivers(warn) -> "tuple[dict, str, int]":
    """(receivers, default id, front port) from receivers.toml; _RxError when
    it cannot be used. warn(msg) reports a receiver that was left out."""
    try:
        try:
            import tomllib
        except ImportError:          # Python < 3.11: setup_admin.sh installs tomli
            import tomli as tomllib
        with open(_rx_path, "rb") as _f:
            _rxcfg = tomllib.load(_f)
    except Exception as _e:
        raise _RxError(f"{_rx_path.name}: {_e}")
    # Ports this proxy itself listens on. A receiver on this computer that
    # names one of them would make the proxy forward to itself: every request
    # opens another connection to us until nothing answers (2026-10-11, after
    # the main receiver moved behind the proxy and receivers.toml kept 8900).
    _front = int(_rxcfg.get("front", {}).get("port", 0) or 0)
    _own_ports = {LISTEN_PORT, _front}
    rxs, dflt = {}, ""
    for _r in _rxcfg.get("receiver", []):
        _id = str(_r.get("id", "")).strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]+", _id) or "port" not in _r:
            raise _RxError(f"{_rx_path.name}: every [[receiver]] needs an id "
                           f"(letters, digits, - and _) and a port")
        _port = int(_r["port"])
        if (str(_r.get("host", _sdr_host)) in ("127.0.0.1", "localhost", "::1")
                and _port in _own_ports):
            if "instance" not in _r and _sdr_port not in _own_ports:
                warn(f"[WARN]  {_rx_path.name}: receiver '{_id}' names port {_port}, "
                     f"which is this proxy's — using spectrumserver's {_sdr_port} "
                     f"(fix it with: bash configure-station.sh --apply)")
                _port = _sdr_port
            else:
                warn(f"[ERROR] {_rx_path.name}: receiver '{_id}' names port {_port}, "
                     f"which is this proxy's — left out; give it its own port")
                continue
        rxs[_id] = {
            "name":      str(_r.get("name", _id)),
            "upstream":  f"http://{_r.get('host', _sdr_host)}:{_port}",
            "host":      str(_r.get("host", _sdr_host)),
            "port":      _port,
            "hostnames": [str(h).lower() for h in _r.get("hostnames", [])],
            # Where the page's receiver picker sends a visitor. Absolute when
            # the receiver has its own public port; else this proxy + ?rx=.
            "url":       str(_r.get("url") or ("/?rx=" + _id)),
        }
        if _r.get("default"):
            if dflt:
                raise _RxError(f"{_rx_path.name}: more than one default receiver")
            dflt = _id
    if not rxs:
        raise _RxError(f"{_rx_path.name}: no [[receiver]] entries")
    return rxs, dflt or next(iter(rxs)), _front


def _apply_receivers(rxs, dflt):
    global RECEIVERS, DEFAULT_RX, SDR_UPSTREAM
    RECEIVERS, DEFAULT_RX = rxs, dflt
    SDR_UPSTREAM = rxs[dflt]["upstream"] if rxs else _MAIN_UPSTREAM


if _rx_path.exists():
    try:
        _rx_mtime = _rx_path.stat().st_mtime_ns
        _rxs, _dflt, FRONT_PORT = _parse_receivers(lambda m: print(m, file=sys.stderr))
    except _RxError as _e:
        print(f"[ERROR] {_e}", file=sys.stderr)
        sys.exit(1)
    _apply_receivers(_rxs, _dflt)


def _reload_receivers():
    """Pick up an edited receivers.toml (the admin panel's Receivers page
    renames and removes receivers) without a proxy restart. A file that no
    longer parses keeps the receivers we have. [front] port is a listening
    socket and changes only with a restart. A station that started with no
    receivers.toml stays a one-receiver proxy until it is restarted."""
    global _rx_mtime, _UP_CACHE_AT
    if _rx_mtime is None:
        return
    try:
        m = _rx_path.stat().st_mtime_ns
    except OSError:
        return
    if m == _rx_mtime:
        return
    _rx_mtime = m
    try:
        rxs, dflt, _front = _parse_receivers(lambda msg: print(msg, file=sys.stderr))
    except _RxError as e:
        print(f"[ERROR] {e} — keeping the receivers read before", file=sys.stderr)
        return
    _apply_receivers(rxs, dflt)
    _UP_CACHE.clear()
    _UP_CACHE_AT = 0.0
    print(f"[INFO]  {_rx_path.name} re-read: " + ", ".join(rxs), file=sys.stderr)


def _pick_receiver(request: web.Request) -> "tuple[str, str]":
    """Return (upstream, id to remember in the rx cookie, or "")."""
    _reload_receivers()
    if not RECEIVERS:
        return SDR_UPSTREAM, ""
    rid = request.query.get("rx", "")
    if rid in RECEIVERS:
        return RECEIVERS[rid]["upstream"], rid
    rid = request.cookies.get(RX_COOKIE, "")
    if rid in RECEIVERS:
        return RECEIVERS[rid]["upstream"], ""
    host = (request.host or "").lower()
    host = host[:host.rfind(":")] if host.rfind(":") > host.rfind("]") else host
    for rid, r in RECEIVERS.items():
        if host in r["hostnames"]:
            return r["upstream"], ""
    return SDR_UPSTREAM, ""


def _upstream_path(request: web.Request) -> str:
    """The request path and query for the upstream, minus our own rx=: it
    only picks the receiver, and spectrumserver matches some paths (/users)
    exactly, query and all."""
    url = request.rel_url
    if "rx" in url.query:
        rest = [(k, v) for k, v in url.query.items() if k != "rx"]
        url = url.with_query(rest or None)
    return str(url)


# Which receivers answer right now, for /receivers.json: a stopped receiver
# drops out of the page's picker instead of leading to an error page. One TCP
# connect per receiver, half a second at most, and the answer is reused for
# a few seconds so that every open page re-reading the list costs nothing.
_UP_CACHE: "dict[str, bool]" = {}
_UP_CACHE_AT = 0.0
_UP_CACHE_S = 5.0


async def _receiver_up(r: dict) -> bool:
    try:
        _reader, writer = await asyncio.wait_for(
            asyncio.open_connection(r["host"], r["port"]), timeout=0.5)
        writer.close()
        return True
    except Exception:
        return False


async def _receivers_up() -> "dict[str, bool]":
    global _UP_CACHE, _UP_CACHE_AT
    now = asyncio.get_running_loop().time()
    if now - _UP_CACHE_AT > _UP_CACHE_S:
        ids = list(RECEIVERS)
        results = await asyncio.gather(*(_receiver_up(RECEIVERS[i]) for i in ids))
        _UP_CACHE, _UP_CACHE_AT = dict(zip(ids, results)), now
    return _UP_CACHE


def _local_port(request: web.Request) -> int:
    """The port this request arrived on (proxy_port or the front port)."""
    try:
        return int(request.transport.get_extra_info("sockname")[1])
    except Exception:
        return LISTEN_PORT

# ── Active WebSocket registry (powers the admin "kick") ─────────────────────────
# proxy.py owns every client WebSocket, so it can disconnect a user simply by
# closing the matching ws_client — no CAP_NET_ADMIN / 'ss -K' privilege needed.
# admin_server.py calls the localhost-only /__proxy_control/kick endpoint below.
ACTIVE_WS: "dict[str, set]" = {}

# Close code sent to a kicked listener. A plain 1000 is indistinguishable from
# an ordinary dropped connection, and audio.js reconnects after one of those —
# so the kicked browser came straight back with sound while its waterfall, which
# has no reconnect, stayed frozen. 4001 is in the private range and the frontend
# treats it as terminal (KICKED_CLOSE_CODE in frontend/src/refused.js).
KICK_CLOSE_CODE = 4001


def _norm_ip(ip: str) -> str:
    ip = (ip or "").strip()
    if ip.startswith("::ffff:"):
        ip = ip[7:]  # IPv4-mapped IPv6 → plain IPv4, so keys match ss/admin list
    return ip


def _register_ws(ip: str, ws) -> None:
    ACTIVE_WS.setdefault(ip, set()).add(ws)


def _unregister_ws(ip: str, ws) -> None:
    conns = ACTIVE_WS.get(ip)
    if conns is not None:
        conns.discard(ws)
        if not conns:
            ACTIVE_WS.pop(ip, None)


async def handle_kick(request: web.Request) -> web.Response:
    """Localhost-only control endpoint: close all WebSockets from a given IP.

    Called by admin_server.py's /admin/api/kick. Restricted to loopback so it
    can never be reached by an external client through the public proxy port.
    """
    if not _is_local(request):
        return web.json_response({"ok": False, "msg": "forbidden"}, status=403)
    try:
        data = await request.json()
    except Exception:
        data = {}
    ip = _norm_ip(data.get("ip", ""))
    if not ip:
        return web.json_response({"ok": False, "msg": "no ip"}, status=400)

    closed = 0
    for ws in list(ACTIVE_WS.get(ip, ())):
        try:
            if not ws.closed:
                await ws.close(code=KICK_CLOSE_CODE,
                               message=b"disconnected by the sysop")
                closed += 1
        except Exception:
            pass
    return web.json_response({"ok": True, "count": closed})

# ── Client-identity headers ───────────────────────────────────────────────────
# spectrumserver believes X-Forwarded-For / X-Real-IP from a loopback peer, and
# every connection this proxy makes to it IS loopback. Whatever a client sends
# in these headers is therefore dropped (in any letter case) before ours are
# added, or a visitor could claim to be 127.0.0.1 and skip the per-IP limits.
_CLIENT_ID_HEADERS = frozenset(("x-forwarded-for", "x-forwarded-host",
                                "x-forwarded-proto", "x-forwarded-port",
                                "x-real-ip", "forwarded"))


# ── The https front ───────────────────────────────────────────────────────────
# setup-https.sh puts Caddy on port 443 and points it at tls_port, a second
# listener of this proxy on loopback only. Everything arriving there comes from
# Caddy, so request.remote is 127.0.0.1 for every visitor — which this proxy
# (and spectrumserver behind it) would otherwise take for "this computer":
# allowed to kick, exempt from the per-IP limits. On that listener the visitor
# is the address Caddy reports in X-Forwarded-For (the last entry, the one
# Caddy itself appended), and the request is never local.
TLS_PORT = int(_cfg.get("tls_port") or 0)


def _via_tls(request: web.Request) -> bool:
    return bool(TLS_PORT) and _local_port(request) == TLS_PORT


def _client(request: web.Request) -> str:
    """The visitor's address, whichever listener the request came in on."""
    if _via_tls(request):
        fwd = request.headers.get("X-Forwarded-For", "")
        last = fwd.split(",")[-1].strip() if fwd else ""
        return last or "0.0.0.0"
    return request.remote or ""


def _is_local(request: web.Request) -> bool:
    if _via_tls(request):
        return False
    return _norm_ip(request.remote) in ("127.0.0.1", "::1")

# ─────────────────────────────────────────────────────────────────────────────

async def proxy_request(request: web.Request, upstream: str,
                        set_rx: str = "", path: str = "") -> web.StreamResponse:
    url = upstream + (path or _upstream_path(request))
    headers = {k: v for k, v in request.headers.items()
               if k.lower() not in ("host", "content-length", "accept-encoding")
               and k.lower() not in _CLIENT_ID_HEADERS}
    headers["Accept-Encoding"]   = "identity"
    headers["X-Forwarded-For"]   = _client(request)
    headers["X-Forwarded-Host"]  = request.headers.get("Host", "")
    headers["X-Forwarded-Proto"] = "https" if _via_tls(request) else "http"
    headers["X-Forwarded-Port"]  = "443" if _via_tls(request) else str(_local_port(request))
    try:
        timeout = ClientTimeout(total=60)
        async with ClientSession(timeout=timeout) as session:
            body = await request.read()
            async with session.request(
                method=request.method,
                url=url,
                headers=headers,
                data=body,
                allow_redirects=False,
                ssl=False,
            ) as resp:
                response = web.StreamResponse(
                    status=resp.status,
                    headers={k: v for k, v in resp.headers.items()
                             if k.lower() not in ("transfer-encoding", "connection")},
                )
                if set_rx:
                    response.set_cookie(RX_COOKIE, set_rx, max_age=31536000,
                                        path="/", samesite="Lax")
                await response.prepare(request)
                async for chunk in resp.content.iter_chunked(65536):
                    await response.write(chunk)
                await response.write_eof()
                return response
    except aiohttp.ClientConnectorError:
        names = {u: p.strip("/").upper() + " service" for p, u in SIDE_SERVICES.items()}
        target = ("Admin panel" if upstream == ADMIN_UPSTREAM
                  else names.get(upstream, "Spectrumserver"))
        return web.Response(
            status=502,
            text=f"502 Bad Gateway — {target} is not running on {upstream}",
        )
    except Exception as e:
        return web.Response(status=500, text=f"Proxy error: {e}")


async def proxy_websocket(request: web.Request, upstream: str,
                          path: str = "") -> web.WebSocketResponse:
    """Bidirectional WebSocket tunnel.

    Key fixes vs the original:
      • max_msg_size=0 on both sides — removes the 4 MB default cap that
        silently kills large FFT frames from the RX-888 at 60 MSPS.
      • heartbeat=30 — keeps long-lived connections alive through NAT.
      • Sec-WebSocket-Protocol forwarded — correct subprotocol negotiation.
      • X-Forwarded-* on WS upgrade — real client IP visible in server logs.
      • Close codes propagated — browser gets a meaningful disconnect reason.
    """
    raw_protocols = request.headers.get("Sec-WebSocket-Protocol", "")
    protocol_list = [p.strip() for p in raw_protocols.split(",") if p.strip()]

    ws_client = web.WebSocketResponse(
        max_msg_size=0,
        protocols=protocol_list,
        autoping=True,
        heartbeat=30.0,
    )
    await ws_client.prepare(request)

    # Register for the admin kick (see handle_kick). request.remote is the real
    # client IP because the browser connects to this proxy directly.
    client_ip = _norm_ip(_client(request))
    _register_ws(client_ip, ws_client)

    ws_url = upstream.replace("http://", "ws://") + (path or _upstream_path(request))

    _skip = frozenset(("host", "upgrade", "connection",
                        "sec-websocket-key", "sec-websocket-version",
                        "sec-websocket-protocol", "sec-websocket-extensions"))
    fwd_headers = {k: v for k, v in request.headers.items()
                   if k.lower() not in _skip
                   and k.lower() not in _CLIENT_ID_HEADERS}
    fwd_headers["X-Forwarded-For"]   = _client(request)
    fwd_headers["X-Forwarded-Host"]  = request.headers.get("Host", "")
    fwd_headers["X-Forwarded-Proto"] = "wss" if _via_tls(request) else "ws"
    fwd_headers["X-Forwarded-Port"]  = "443" if _via_tls(request) else str(_local_port(request))

    try:
        async with ClientSession() as session:
            try:
                async with session.ws_connect(
                    ws_url,
                    headers=fwd_headers,
                    protocols=protocol_list,
                    max_msg_size=0,
                    heartbeat=30.0,
                    autoclose=True,
                    autoping=True,
                ) as ws_upstream:

                    async def forward_up():
                        """Browser → Spectrumserver"""
                        async for msg in ws_client:
                            if msg.type == WSMsgType.TEXT:
                                await ws_upstream.send_str(msg.data)
                            elif msg.type == WSMsgType.BINARY:
                                await ws_upstream.send_bytes(msg.data)
                            elif msg.type == WSMsgType.ERROR:
                                break
                        # The loop ends at the browser's close frame without
                        # yielding it (aiohttp's iterator swallows it), so the
                        # close is passed on here, code and all.
                        if not ws_upstream.closed:
                            await ws_upstream.close(
                                code=ws_client.close_code or 1000)

                    async def forward_down():
                        """Spectrumserver → Browser"""
                        # receive() rather than `async for`: the iterator
                        # swallows the server's close frame, and with it the
                        # reason, which aiohttp does not keep anywhere else.
                        reason = b"upstream closed"
                        while True:
                            msg = await ws_upstream.receive()
                            if msg.type == WSMsgType.TEXT:
                                await ws_client.send_str(msg.data)
                            elif msg.type == WSMsgType.BINARY:
                                await ws_client.send_bytes(msg.data)
                            else:
                                if msg.type == WSMsgType.CLOSE and msg.extra:
                                    # 123 bytes is the protocol's cap; never
                                    # cut a multi-byte character in half.
                                    reason = (msg.extra.encode("utf-8")[:123]
                                              .decode("utf-8", "ignore")
                                              .encode("utf-8"))
                                break
                        # The server's close code AND reason are what the page
                        # acts on (4003 refused by a limit, 4003 "out of date"
                        # from the version gate, 4001 kicked by the sysop), so
                        # both must reach the browser — a diversity client
                        # tells the version gate from the limit by the reason.
                        if not ws_client.closed:
                            await ws_client.close(
                                code=ws_upstream.close_code or 1000,
                                message=reason)

                    task_up   = asyncio.ensure_future(forward_up())
                    task_down = asyncio.ensure_future(forward_down())
                    done, pending = await asyncio.wait(
                        {task_up, task_down},
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                    for task in pending:
                        task.cancel()
                        try:
                            await task
                        except asyncio.CancelledError:
                            pass

            except aiohttp.ClientConnectorError:
                if not ws_client.closed:
                    await ws_client.close(code=1014, message=b"upstream unreachable")
            except aiohttp.WSServerHandshakeError:
                if not ws_client.closed:
                    await ws_client.close(code=1014, message=b"upstream handshake failed")
            except Exception:
                if not ws_client.closed:
                    await ws_client.close(code=1011, message=b"proxy error")

    except Exception:
        pass

    if not ws_client.closed:
        await ws_client.close()
    _unregister_ws(client_ip, ws_client)
    return ws_client


async def handle(request: web.Request) -> web.StreamResponse:
    if request.path == "/__proxy_control/kick":
        return await handle_kick(request)
    # spectrumserver's /~~kick is allowed for a loopback TCP peer — and to it,
    # everything relayed from here is loopback. Without this check anyone who
    # could reach this port could disconnect and ban any listener. /~~users
    # (the list with IP addresses) and /~~unban are the sysop's in the same way.
    if (any(p in request.path for p in ("~~kick", "~~users", "~~unban"))
            and not _is_local(request)):
        return web.json_response({"ok": False, "msg": "forbidden"}, status=403)
    side = _side_service(request)
    if side:
        upstream, path = side
        if request.headers.get("Upgrade", "").lower() == "websocket":
            return await proxy_websocket(request, upstream, path)
        return await proxy_request(request, upstream, path=path)
    if request.path.startswith("/admin"):
        upstream, set_rx = ADMIN_UPSTREAM, ""
    elif request.path == "/receivers.json" and (_reload_receivers() or RECEIVERS):
        # The receiver list for the page's picker: ids, names and public URLs,
        # never the internal ports — and only the receivers that are running,
        # so a stopped one's button disappears. Readable cross-origin, because
        # a receiver with its own public port serves its page from another
        # origin.
        up = await _receivers_up()
        return web.json_response(
            [{"id": rid, "name": r["name"], "url": r["url"],
              "default": rid == DEFAULT_RX}
             for rid, r in RECEIVERS.items() if up.get(rid, True)],
            headers={"Cache-Control": "no-cache",
                     "Access-Control-Allow-Origin": "*"})
    else:
        upstream, set_rx = _pick_receiver(request)
    if request.headers.get("Upgrade", "").lower() == "websocket":
        return await proxy_websocket(request, upstream)
    return await proxy_request(request, upstream, set_rx)


# ── Access-log noise filter ───────────────────────────────────────────────────
# The admin dashboard polls these paths every few seconds. Logging each poll
# buries the interesting traffic and inflates proxy.log roughly tenfold, so
# successful polls are dropped. Anything that is not a plain 200 still gets
# logged, so failures on these paths remain visible.
# /admin/api/logs/clear is quiet for a different reason: the admin panel
# truncates proxy.log while serving it, and this access line would be written
# afterwards — leaving one line behind and making the clear look like it failed.
#
# Keep this list (and _QUIET_404) identical in admin_server.py. It drifted once:
# the panel silenced eight paths while the proxy silenced three, so admin.log
# stayed readable and proxy.log filled with the same polls the panel had already
# decided were noise — /admin/api/thermal alone was 72 of 78 lines, ~3 MB/day
# from a single open dashboard tab. These are the sysop's own polls; they say
# nothing about who used the receiver, which is the point of an access log.
_QUIET_PATHS = ("/admin/api/status", "/admin/api/thermal", "/admin/api/logs",
                "/admin/api/logs/clear", "/admin/api/health",
                "/admin/api/autorun/status", "/admin/api/users", "/admin/api/sdr-users",
                "/admin/api/graph-stats", "/admin/api/chat", "/admin/api/bans",
                "/admin/api/websdr-relay", "/admin/api/drm",
                # every open listener page polls these every few seconds; who
                # listened is in the /audio and /waterfall lines and logs/users_*.jsonl
                "/users", "/wf-message.json", "/receivers.json", "/api/dxspots",
                "/logo.jpg", "/favicon.ico", "/stats/api/system-stats",
                # websdr.org's registration check, every 10 s while listed
                "/~~orgstatus")
# 404 is the normal answer here (no waterfall message set), so it is quiet too.
_QUIET_404 = ("/wf-message.json",)
_ACCESS_RE = re.compile(r'"[A-Z]+ (?P<path>[^ ?"]+)[^"]*" (?P<status>\d{3})')


class QuietPollFilter(logging.Filter):
    def filter(self, record):
        m = _ACCESS_RE.search(record.getMessage())
        if not m:
            return True
        if m.group("status") == "404":
            return m.group("path") not in _QUIET_404
        if m.group("status") != "200":
            return True
        return m.group("path") not in _QUIET_PATHS


# ── websdr.org callback: HTTP/1.1 without a Host header ────────────────────────
# websdr.org confirms a registration by connecting back and sending
# "GET /~~orgstatus HTTP/1.1" with no Host line. aiohttp refuses that (400,
# "Missing 'Host' header") in both its C and Python parsers, so the request
# never reached spectrumserver and the station was never listed. The first
# request on each connection is inspected: when it carries a Host header (every
# browser does) the connection is left alone from then on; when it does not,
# "Host: localhost" is added, and for as long as that client sends bodiless
# GET/HEADs on the kept-alive connection, each of them gets the same treatment.
from aiohttp import web_protocol as _wp

_HOSTFIX_MAX = 16384
_orig_data_received = _wp.RequestHandler.data_received
_orig_connection_lost = _wp.RequestHandler.connection_lost
_hostfix_state: "dict[int, dict]" = {}   # RequestHandler has __slots__: keyed by id()


def _hostfix_data_received(self, data: bytes) -> None:
    st = _hostfix_state.setdefault(id(self), {"on": True, "buf": b""})
    if not st["on"]:
        return _orig_data_received(self, data)
    buf = st["buf"] + data
    out = b""
    while st["on"]:
        end = buf.find(b"\r\n\r\n")
        sep = 4
        if end < 0:
            end, sep = buf.find(b"\n\n"), 2
        if end < 0:
            if len(buf) > _HOSTFIX_MAX:      # not a header we can read: let aiohttp judge
                st["on"] = False
            break
        head, buf = buf[:end], buf[end + sep:]
        lines = [l.rstrip(b"\r") for l in head.split(b"\n")]
        names = [l.split(b":", 1)[0].strip().lower() for l in lines[1:]]
        if b"host" in names:
            st["on"] = False                 # an ordinary client
        elif lines[0].rstrip().endswith(b"HTTP/1.1"):
            lines.insert(1, b"Host: localhost")
        bodiless = (lines[0].split(b" ", 1)[0] in (b"GET", b"HEAD")
                    and b"content-length" not in names
                    and b"transfer-encoding" not in names
                    and b"upgrade" not in names)
        if not bodiless:
            st["on"] = False
        out += b"\r\n".join(lines) + b"\r\n\r\n"
    if not st["on"]:
        out, buf = out + buf, b""
        _hostfix_state[id(self)] = {"on": False, "buf": b""}
    else:
        st["buf"] = buf
    if out:
        _orig_data_received(self, out)


def _hostfix_connection_lost(self, exc) -> None:
    _hostfix_state.pop(id(self), None)
    _orig_connection_lost(self, exc)


_wp.RequestHandler.data_received   = _hostfix_data_received
_wp.RequestHandler.connection_lost = _hostfix_connection_lost


async def main():
    # AppRunner (unlike web.run_app) never calls basicConfig, so aiohttp's
    # access logger stays unconfigured and every request line is discarded.
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    logging.getLogger("aiohttp.access").addFilter(QuietPollFilter())

    app = web.Application()
    app.router.add_route("*", "/{path_info:.*}", handle)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, LISTEN_HOST, LISTEN_PORT)
    await site.start()
    if FRONT_PORT and FRONT_PORT != LISTEN_PORT:
        await web.TCPSite(runner, LISTEN_HOST, FRONT_PORT).start()
    if TLS_PORT:
        # loopback only: nothing but the https front may reach it
        await web.TCPSite(runner, "127.0.0.1", TLS_PORT).start()

    print(f"╔══════════════════════════════════════════════════════╗")
    print(f"║  PhantomSDR-Plus Reverse Proxy                       ║")
    print(f"║  Listening : http://0.0.0.0:{LISTEN_PORT:<5}                ║")
    print(f"║  /admin*   → Admin panel  (localhost:{int(_cfg['port']):<5})        ║")
    print(f"║  /*        → SDR server   ({_sdr_host}:{_sdr_port:<5})  ║")
    print(f"╚══════════════════════════════════════════════════════╝")
    for prefix, upstream in SIDE_SERVICES.items():
        print(f"  {prefix + '/*':<9} → {upstream}")
    if TLS_PORT:
        print(f"  https front (Caddy) → 127.0.0.1:{TLS_PORT}, visitors by X-Forwarded-For")
    if RECEIVERS:
        if FRONT_PORT and FRONT_PORT != LISTEN_PORT:
            print(f"  also listening on :{FRONT_PORT} (receivers.toml [front])")
        for rid, r in RECEIVERS.items():
            mark = "  (default)" if rid == DEFAULT_RX else ""
            print(f"  ?rx={rid:<8} → {r['upstream']}  {r['name']}{mark}")

    await asyncio.Event().wait()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[stopped]")
