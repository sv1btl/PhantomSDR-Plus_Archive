# Guide d'installation de PhantomSDR-Plus pour les opérateurs système

Ce guide complet vous accompagne dans l'installation et la configuration de PhantomSDR-Plus sur votre serveur.

---

## Table des matières

1. [Configuration système requise](#configuration-système-requise)
2. [Préparation avant installation](#préparation-avant-installation)
3. [Installation des dépendances](#installation-des-dépendances)
4. [Installation de Node.js et npm](#installation-de-nodejs-et-npm)
5. [Installation d'OpenCL (facultatif mais recommandé)](#installation-dopencl-facultatif-mais-recommandé)
6. [Installation de PhantomSDR-Plus](#installation-de-phantomsdr-plus)
7. [Installation du codec audio Opus](#installation-du-codec-audio-opus)
8. [Rapporteur de spots autorun (FT8/FT4/WSPR)](#rapporteur-de-spots-autorun-ft8ft4wspr)
9. [Configuration](#configuration)
10. [Configuration propre à chaque appareil SDR](#configuration-propre-à-chaque-appareil-sdr)
11. [Tests et vérification](#tests-et-vérification)
12. [Mise en place du démarrage automatique](#mise-en-place-du-démarrage-automatique)
13. [Dépannage](#dépannage)

---

## Configuration système requise

### Systèmes d'exploitation pris en charge

**Principal (recommandé) :**
- Ubuntu 24.04 LTS (x86_64) (recommandé)

**Alternative :**
- Fedora (dernière version stable)

### Configuration matérielle requise

**Configuration minimale :**
- Processeur : double cœur (2 GHz ou plus)
- RAM : 4 Go
- Stockage : 10 Go d'espace libre
- Réseau : connexion 100 Mbit/s

**Configuration recommandée :**
- Processeur : quadricœur ou mieux (Ryzen 5 2600, Intel i5-6500T ou supérieur)
- RAM : 8 Go ou plus
- Stockage : SSD de 20 Go ou plus
- GPU : AMD/NVIDIA compatible OpenCL (vivement recommandé)
- Réseau : connexion 1 Gbit/s

**Configuration hautes performances :**
- Processeur : 6 cœurs ou plus (Ryzen 7, Intel i7 ou mieux)
- RAM : 16 Go ou plus
- Stockage : SSD NVMe
- GPU : GPU dédié compatible OpenCL/CUDA
- Réseau : 1 Gbit/s ou mieux

---

## Préparation avant installation

### 1. Mettez votre système à jour

```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade -y
sudo reboot

# Fedora
sudo dnf update -y
sudo reboot
```

### 2. Vérifiez la version d'Ubuntu

```bash
lsb_release -a
```

**La sortie attendue doit indiquer :** Ubuntu 24.04 LTS

### 3. Vérifiez l'espace disque disponible

```bash
df -h
```

Assurez-vous d'avoir au moins 10 Go libres dans votre répertoire personnel.

### 4. Vérifiez les informations du processeur

```bash
lscpu
```

Notez le nombre de cœurs/threads pour optimiser la configuration.

---

## Installation des dépendances

### Ubuntu 24.04 LTS

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  git \
  psmisc \
  wget \
  curl
```

### Fedora

```bash
sudo dnf install -y \
  g++ \
  meson \
  cmake \
  fftw3-devel \
  websocketpp-devel \
  flac-devel \
  zlib-devel \
  boost-devel \
  libzstd-devel \
  opus-devel \
  liquid-dsp-devel \
  git \
  psmisc \
  wget \
  curl
```

### Vérifiez l'installation

```bash
# Check if key dependencies are installed
pkg-config --modversion fftw3
cmake --version
meson --version
```

---

## Installation de Node.js et npm

PhantomSDR-Plus a besoin de Node.js pour compiler l'interface. Nous utiliserons NVM (Node Version Manager) pour l'installation.

### 1. Installez NVM

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
```

### 2. Chargez NVM

**IMPORTANT :** fermez et rouvrez votre terminal, ou exécutez :

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

### 3. Vérifiez l'installation de NVM

```bash
nvm --version
```

Sortie attendue : `0.40.4` ou similaire

### 4. Installez Node.js

```bash
# Install Node.js 22 - the version every install script requires
nvm install 22

# Make it the default, so systemd units and cron see it too
nvm alias default 22

# Verify installation
node --version
npm --version
```

### 5. Facultatif : installez d'autres versions de Node

```bash
# Install latest version
nvm install node

# Install specific version (if needed)
nvm install 22.22.3

# List installed versions
nvm list

# Use specific version
nvm use 22
```

---

## Installation d'OpenCL (facultatif mais recommandé)

OpenCL améliore considérablement les performances en déportant les calculs de FFT sur le GPU. Cette section traite des graphiques intégrés Intel. Pour les GPU AMD/NVIDIA, reportez-vous à la documentation du fabricant.

### Processeur Intel avec graphiques intégrés

#### 1. Installez les composants OpenCL de base

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  libclfft-dev \
  ocl-icd-opencl-dev \
  clinfo
```

#### 2. Téléchargez Intel Compute Runtime

```bash
mkdir -p ~/neo
cd ~/neo

wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
```

#### 3. Installez le runtime OpenCL d'Intel

```bash
sudo dpkg -i *.deb
```

En cas d'erreurs de dépendances :

```bash
sudo apt --fix-broken install
```

#### 4. Installez le chargeur ICD OpenCL

```bash
sudo apt update
sudo apt install intel-opencl-icd
```

En cas d'erreurs :

```bash
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
```

#### 5. Vérifiez l'installation d'OpenCL

```bash
sudo clinfo
```

Vous devriez voir des informations sur votre plateforme et vos appareils OpenCL. Cherchez :
- Nombre de plateformes : 1 (ou plus)
- Nom de la plateforme : Intel(R) OpenCL (ou similaire)
- Type d'appareil : GPU ou CPU

#### 6. Redémarrez

```bash
sudo reboot
```

### OpenCL sur GPU AMD

Pour les GPU AMD, installez ROCm :

```bash
# Add ROCm repository
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list

# Install ROCm
sudo apt update
sudo apt install rocm-opencl rocm-clinfo

# Add user to video group
sudo usermod -a -G video $USER

# Reboot
sudo reboot

# Verify
clinfo
```

### OpenCL sur GPU NVIDIA

Pour les GPU NVIDIA, installez CUDA :

```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-525

# Install CUDA toolkit
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt update
sudo apt install cuda

# Reboot
sudo reboot

# Verify
nvidia-smi
clinfo
```

---

## Installation de PhantomSDR-Plus

### Cloner le dépôt, rendre les scripts exécutables, installation automatique

```bash
cd ~
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```
**⚠️ IMPORTANT :** une fois `install.sh` terminé, **redémarrez votre terminal** avant de continuer.

### 4. Option B : installation manuelle

Si vous préférez l'installation manuelle ou si l'installation automatique échoue :

#### Compiler le backend

```bash
# Clean any previous builds, Configure build with optimization, Compile
rm -rf build
meson setup build --buildtype=release --optimization=3
meson compile -C build

# Verify binary was created
ls -lh build/spectrumserver
```

#### Compiler le frontend

```bash
cd frontend

# Install dependencies, Fix any vulnerabilities, Build the frontend
npm install
npm audit fix
npm run build

# Return to project root
cd ..
```

### Vérifiez l'installation

```bash
# Check if binary exists
ls -lh build/spectrumserver

# Check if frontend was built
ls -lh frontend/dist/

# List important files
ls -lh *.sh *.toml
```

---

## Installation du codec audio Opus

Opus offre une meilleure qualité audio et une latence plus faible que FLAC.

### 1. Installez la bibliothèque système libopus

```bash
sudo apt-get update
sudo apt-get install -y libopus0 libopus-dev
```

### 2. Installez le décodeur Opus pour le frontend

```bash
cd PhantomSDR-Plus/frontend

# Install npm dependencies if not already done, Install Opus WASM decoder, Fix any vulnerabilities, Rebuild frontend
npm install
npm install @wasm-audio-decoders/opus-ml
npm audit fix
npm run build

# Return to project root
cd ..
```

### 3. Vérifiez l'installation d'Opus

```bash
# Check if Opus system library is installed
pkg-config --modversion opus

# Check if Opus npm package is installed
cd frontend
npm list @wasm-audio-decoders/opus-ml
cd ..
```

---

## Rapporteur de spots autorun (FT8/FT4/WSPR)

PhantomSDR-Plus est livré avec un **rapporteur de spots autorun** facultatif (dans le
répertoire `autorun/`). Il décode FT8/FT4/WSPR côté serveur, directement à partir du
récepteur, et téléverse les spots vers les réseaux de report :

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

Il se pilote entièrement depuis l'onglet **panneau d'administration → « Spot Reporting »**,
et **le report est DÉSACTIVÉ par défaut** — rien n'est transmis ni téléversé tant que vous
ne l'activez pas là. Le décodeur s'exécute comme un démon Node.js distinct et prélève
l'audio du récepteur localement : il n'ajoute donc aucun matériel RF supplémentaire.

### Prérequis

| Prérequis | Remarques |
|-----------|-----------|
| **Node.js 22+** | Le même environnement d'exécution que la compilation du frontend — installé à l'[étape Node.js](#installation-de-nodejs-et-npm). |
| **Paquets npm `ws` + `cbor-x`** | Résolus via `autorun/node_modules`, un lien symbolique vers le `node_modules` du frontend (les deux paquets sont déclarés dans `frontend/package.json`). |
| **`util-linux`** (`taskset`) | Le bouton « Start » de l'admin épingle le démon sur les E-cores avec `taskset`. Présent sur pratiquement toutes les distributions ; les installateurs l'ajoutent explicitement. |
| **Indicatif + locator** | Lus dans `frontend/site_information.json` (`siteSysop` / `siteGridSquare`) sauf s'ils sont remplacés dans l'onglet d'administration. Les spots sont téléversés sous cet indicatif. |

> ⚠️ **Ne rapportez que ce que vous recevez réellement.** Les spots sont téléversés vers des
> réseaux publics sous votre indicatif — n'activez que les bandes/modes que votre récepteur
> entend véritablement, et utilisez le bon locator.

### Installation automatique

`install.sh` (et les variantes par distribution : `install-Deb12.sh`, `install_arch.sh`,
`install_fedora.sh`, `install_opensuse.sh`) s'occupent de tout : ils installent Node.js 22
et `util-linux`, exécutent le `npm install` du frontend, puis créent automatiquement le lien
symbolique `autorun/node_modules`. Aucune étape supplémentaire n'est nécessaire — la
fonction est prête dès que `install.sh` se termine.

### Installation manuelle

Si vous avez installé manuellement (option B), créez vous-même le lien symbolique après le
`npm install` du frontend, afin que le démon puisse résoudre ses dépendances :

```bash
cd ~/PhantomSDR-Plus

# 1. Frontend deps must be installed first (ws + cbor-x live there)
cd frontend && npm install && cd ..

# 2. Link the autorun daemon to the frontend's node_modules
ln -sfn ../frontend/node_modules autorun/node_modules

# 3. Ensure taskset is available (Debian/Ubuntu shown; use your package manager)
sudo apt install -y util-linux
```

> **Remarque :** `autorun/node_modules` est ignoré par git : un `git clone` frais ne le
> contient donc jamais — le lien symbolique doit être (re)créé après chaque récupération
> propre. Les installateurs le font pour vous ; la commande ci-dessus ne concerne que les
> installations manuelles.

### Vérification

```bash
# The symlink should point at ../frontend/node_modules
ls -l autorun/node_modules

# ws + cbor-x must resolve
ls -d frontend/node_modules/ws frontend/node_modules/cbor-x

# taskset must be on PATH
command -v taskset
```

Ouvrez ensuite le panneau d'administration, allez dans l'onglet **Spot Reporting**,
renseignez votre identité, cochez les bandes/modes à décoder, activez la ou les
destinations, puis appuyez sur **Start**. Un badge « 📶 REPORTING » apparaît sur la cascade
principale chaque fois que le report est actif. (PSK Reporter téléverse par lots toutes les
5 minutes et wsprnet toutes les 2 minutes : un démon fraîchement démarré affiche donc
« 0 sent » pendant les premières minutes — c'est normal.)

Deux compteurs différents sont ensuite affichés, et il est facile de les confondre.
Les tuiles **SPOTS UPLOADED PER DECODER** ne comptent que l'exécution en cours :
Stop/Start les remet à zéro. Le nombre à côté de chaque case bande/mode est le
total **depuis toujours** de cet emplacement, conservé dans `autorun-totals.json`
et donc préservé au redémarrage. Voir le [guide du panneau d'administration](ADMIN_PANEL_SETUP.md)
pour les deux, ainsi que pour la page **Graphiques**, qui trace la fréquence du
processeur, la charge, la température et les utilisateurs connectés sur 15 minutes
à 24 heures.

> **Le port du serveur est détecté automatiquement.** Le démon se branche directement sur
> le `[server] port` de spectrumserver (boucle locale + jeton, en contournant le proxy). Il
> lit ce port dans le fichier de configuration avec lequel le spectrumserver en cours a été
> lancé, ce qui lui permet de fonctionner sur n'importe quel port sans configuration — la
> ligne `[autorun] tap backend: …` dans `autorun.log` indique ce qu'il a résolu. Si votre
> serveur ne tournait pas au démarrage du démon, ou si votre installation est atypique,
> fixez-le dans `autorun.json` :
> ```json
> "server": { "host": "127.0.0.1", "port": 9002 }
> ```
> Un mauvais port se traduit par `504` / `tap closed 1006` dans `autorun.log`, avec
> `decodes` bloqué à 0.

---

## Configuration

### 1. Choisissez votre fichier de configuration

Sélectionnez le fichier de configuration adapté à votre SDR :

- `config-rtl.toml` – clés RTL-SDR
- `config-rsp1a.toml` – SDRplay RSP1A
- `config-airspyhf.toml` – Airspy HF+ Discovery
- `config-rx888mk2.toml` – RX888 MK2
- `config.example.hackrf.toml` – HackRF One

Pour cet exemple, nous utiliserons le RTL-SDR.

### 2. Modifiez le fichier de configuration

```bash
nano config-rtl.toml
```

#### Réglages clés à configurer

```toml
[server]
port = 9002                      # Web interface port (or everything else)
html_root = "frontend/dist/"     # Frontend location
otherusers = 1                   # Show other users (1=yes, 0=no)
threads = 2                      # Number of server threads

[websdr]
register_online = true           # Register on sdr-list.xyz (true/false)
name = "Your WebSDR Name"        # Display name
antenna = "Your Antenna Type"    # e.g., "Vertical", "Loop", "Dipole"
grid_locator = "AB12cd"          # Your Maidenhead grid square
hostname = "your.domain.com"     # Your domain or IP address

[input]
sps = 2048000                    # Sample rate (adjust for your coverage)
fft_size = 131072                # FFT size (higher = better resolution)
brightness_offset = -10          # Waterfall brightness adjustment
frequency = 145000000            # Base frequency in Hz (145 MHz for 2m)
signal = "iq"                    # "iq" for complex, "real" for real sampling
fft_threads = 2                  # FFT processing threads
accelerator = "opencl"           # "none", "cuda", or "opencl"
audio_sps = 12000                # Audio sample rate (keep at 12000)
audio_compression = "opus"       # "flac" or "opus"
smeter_offset = -2               # S-meter calibration
waterfall_size = 1024            # Waterfall FFT size
waterfall_compression = "zstd"   # Waterfall compression

[input.driver]
name = "stdin"                   # Input driver
format = "u8"                    # Sample format for RTL-SDR

[input.defaults]
frequency = 145500000            # Default tuning frequency
modulation = "FM"                # Default modulation mode
```

#### Repères pour le taux d'échantillonnage

| Couverture | Taux d'échantillonnage | Taille de FFT |
|------------|------------------------|---------------|
| 2 MHz | 2048000 | 131072 |
| 3.2 MHz | 3200000 | 131072 |
| 10 MHz | 10000000 | 1048576 |
| 30 MHz | 30000000 | 2097152 |
| 60 MHz | 60000000 | 8388608 |

### 3. Configurez les informations du site

```bash
nano frontend/site-information.json
```

Modifiez les champs suivants :

```json
{
  "siteSysop": "YourCallsign",
  "siteSysopEmailAddress": "your@email.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "Your City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Computer specifications",
  "siteSoftware": "PhantomSDR-Plus v3.6.1",
  "siteReceiver": "Your SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional information",
  "siteIP": "http://your.domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

**Régions IARU :**
- **1** : Europe, Afrique, Moyen-Orient, Asie du Nord
- **2** : Amériques (Nord, Centre, Sud), Caraïbes
- **3** : Asie-Pacifique, Océanie

### 4. Personnalisez les marqueurs de fréquence (facultatif)

```bash
nano markers.json
```

Ajoutez vos fréquences préférées, relais et stations de radiodiffusion.

### 5. Modifiez le script de démarrage

```bash
nano start-rtl.sh
```

Le script de démarrage est un lanceur autonome doublé d'un chien de garde. Ne modifiez que
le bloc **RECEIVER CONFIGURATION** près du début, afin que les arguments du récepteur
correspondent à votre installation :

```bash
# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═══
RX_LABEL="RTL-SDR"
RX_COMM="rtl_sdr"                       # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rtl.toml"    # your .toml
FIFO="$PHANTOMDIR/rtl.fifo"
RX_ARGS="${RX_ARGS:--f 145000000 -s 2048000 -}"   # receiver args (edit these)
```

Paramètres à l'intérieur de `RX_ARGS` :
- `-f 145000000` : fréquence centrale (145 MHz)
- `-s 2048000` : taux d'échantillonnage (2,048 MSPS)

`CONFIG` pointe vers votre `.toml`. Vous n'avez **pas** besoin de modifier autre chose dans
le script — la logique de démarrage/redémarrage/chien de garde/journalisation est générique.
Vous pouvez aussi remplacer les arguments du récepteur au lancement sans modifier le
fichier : `RX_ARGS="-f 145000000 -s 2048000 -" ./start-rtl.sh`
(`RX888_ARGS` pour `start-rx888mk2.sh`).

---

## Configuration propre à chaque appareil SDR

### RTL-SDR

#### Installez les outils RTL-SDR

```bash
sudo apt install -y rtl-sdr
```

#### Testez le RTL-SDR

```bash
rtl_test
```

Appuyez sur Ctrl+C pour arrêter. Vous devriez voir des informations sur le taux d'échantillonnage.

#### Modifiez la configuration

```bash
nano config-rtl.toml
```

Réglages courants pour le RTL-SDR :
```toml
sps = 2048000
frequency = 145000000
signal = "iq"
format = "u8"
```

### SDRplay RSP1A

#### Installez SoapySDR et la prise en charge SDRplay

```bash
# Install SoapySDR
sudo apt install -y soapysdr-tools

# Download SDRplay API
cd ~/Downloads
wget https://www.sdrplay.com/software/SDRplay_RSP_API-Linux-3.07.1.run
chmod +x SDRplay_RSP_API-Linux-3.07.1.run
sudo ./SDRplay_RSP_API-Linux-3.07.1.run

# Install SoapySDRPlay
git clone https://github.com/pothosware/SoapySDRPlay.git
cd SoapySDRPlay
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig
```

#### Testez le SDRplay

```bash
SoapySDRUtil --find="driver=sdrplay"
```

#### Instructions complémentaires

Voir le fichier inclus : `instractions-for-rsp1a`

### Airspy HF+

#### Installez les outils Airspy

```bash
sudo apt install -y airspy
```

#### Testez l'Airspy

```bash
airspy_info
```

#### Instructions complémentaires

Voir le fichier inclus : `instractions-for-airspy`

### RX888 MK2

#### Installez les outils RX888

```bash
# Install rx_tools
git clone https://github.com/rxseger/rx_tools.git
cd rx_tools
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig

# Install RX888 firmware and support
# Follow manufacturer instructions
```

#### Exécuter rx888_stream sans sudo (règles udev)

Par défaut, le périphérique USB Cypress FX3 du RX-888 n'est accessible qu'à root, donc
`rx888_stream` nécessiterait `sudo`. Exécutez une fois l'assistant fourni pour installer les
règles udev et vous ajouter au groupe `plugdev` :

```bash
./setup-rx888-udev.sh          # re-runs itself with sudo automatically
```

Il écrit `/etc/udev/rules.d/99-rx888.rules` pour les trois identifiants de produit Cypress
FX3 (`04b4:00f1`/`00f3` bootloader et `04b4:8613` firmware chargé), recharge udev et crée un
lien symbolique stable `/dev/rx888`. **Déconnectez-vous puis reconnectez-vous** (pour le
changement de groupe) et **rebranchez l'appareil** une fois ; ensuite `rx888_stream` — et le
lanceur `start-rx888mk2.sh` — s'exécutent sans `sudo`. Le script est idempotent : vous pouvez
le relancer sans risque. Pour configurer un autre compte :
`RX888_USER=<nom> ./setup-rx888-udev.sh`.

#### Modifiez la configuration

```bash
nano config-rx888mk2.toml
```

Réglages courants pour le RX888 :
```toml
sps = 60000000
frequency = 0
signal = "real"
format = "s16"
fft_size = 8388608
```

### HackRF One

#### Installez les outils HackRF

```bash
sudo apt install -y hackrf
```

#### Testez le HackRF

```bash
hackrf_info
```

---

## Tests et vérification

### 1. Essai

```bash
# For RTL-SDR
./start-rtl.sh
```

Cela démarre le serveur **en arrière-plan** (il se détache et rend la main immédiatement) et
commence à journaliser dans `logwebsdr.txt`.

### 2. Recherchez d'éventuelles erreurs

Le script journalise sa progression dans `logwebsdr.txt` — suivez-la en direct :

```bash
tail -f logwebsdr.txt
```

Cherchez :
- ✅ `Starting the initialization script of the PhantomSDR Server`
- ✅ `<receiver> running (PID …)`
- ✅ `Server started normally`
- ❌ `Server … FAILED …` ou `ERROR: receiver binary '…' not found` (corrigez les arguments du
  récepteur ou le `.toml`, ou installez l'outil du récepteur, puis relancez le script de démarrage)

### 3. Accédez à l'interface web

Ouvrez votre navigateur sur :
```
http://localhost:9002
```

(Remplacez le numéro de port par celui que vous avez configuré)

### 4. Vérifiez le fonctionnement

- La cascade doit s'afficher
- L'audio doit jouer lorsque vous cliquez sur des signaux
- Le S-mètre doit réagir aux signaux
- Le nombre d'utilisateurs doit indiquer « 1 »

### 5. Testez depuis un autre appareil

Depuis un autre ordinateur de votre réseau :
```
http://YOUR_SERVER_IP:9002
```

### 6. Vérifiez l'utilisation des ressources

```bash
# Monitor CPU usage
htop

# Monitor GPU usage (if OpenCL/CUDA enabled)
nvidia-smi  # For NVIDIA
radeontop   # For AMD

# Monitor network usage
iftop
```

### 7. Arrêtez le serveur

Le serveur s'exécute en arrière-plan sous la surveillance d'un chien de garde : **Ctrl+C ne
l'arrêtera donc pas** (et le chien de garde le relancerait). Utilisez le script d'arrêt
partagé, valable pour tous les récepteurs — il arrête d'abord le chien de garde, puis le
récepteur et `spectrumserver` :

```bash
./stop-websdr.sh
```

---

## Mise en place du démarrage automatique

### Avec systemd (recommandé)

#### 1. Créez le fichier de service

```bash
sudo nano /etc/systemd/system/phantomsdr.service
```

Ajoutez le contenu suivant (ajustez les chemins et l'utilisateur) :

```ini
[Unit]
Description=PhantomSDR-Plus WebSDR Server
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/PhantomSDR-Plus
# Run the watchdog in the FOREGROUND (note the --watchdog flag) so systemd can
# track it. Do NOT use the plain "./start-rtl.sh" here — that form detaches into
# the background and exits, which systemd would treat as the service stopping.
ExecStart=/home/youruser/PhantomSDR-Plus/start-rtl.sh --watchdog
ExecStop=/home/youruser/PhantomSDR-Plus/stop-websdr.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

> Le processus `--watchdog` relance déjà de lui-même le récepteur et `spectrumserver` ;
> `Restart=always` n'est qu'un filet de sécurité pour le cas rare où le chien de garde
> s'arrêterait lui-même. Comme systemd supervise ici le serveur, vous pouvez utiliser
> `systemctl start/stop/restart` et `journalctl -u phantomsdr -f` au lieu de lancer les
> scripts à la main.

#### 2. Activez et démarrez le service

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable phantomsdr.service

# Start service now
sudo systemctl start phantomsdr.service

# Check status
sudo systemctl status phantomsdr.service
```

#### 3. Gérez le service

```bash
# Start
sudo systemctl start phantomsdr

# Stop
sudo systemctl stop phantomsdr

# Restart
sudo systemctl restart phantomsdr

# View logs
sudo journalctl -u phantomsdr -f
```

### Avec Screen (alternative)

> Généralement inutile : `./start-rtl.sh` se détache déjà en arrière-plan (via `setsid`) et
> continue de tourner après votre déconnexion, avec son propre chien de garde. Screen n'est
> utile que si vous voulez expressément une session interactive pour exécuter la forme au
> premier plan `./start-rtl.sh --watchdog`.

#### 1. Installez Screen

```bash
sudo apt install -y screen
```

#### 2. Démarrez dans une session Screen

```bash
screen -S phantomsdr
./start-rtl.sh
```

Appuyez sur Ctrl+A, puis D pour détacher.

#### 3. Rattachez-vous à la session

```bash
screen -r phantomsdr
```

---

## Dépannage

### Erreurs de compilation

#### Problèmes de dépendances

```bash
# Ubuntu: Install missing dependencies
sudo apt install --fix-broken

# Fedora: Install missing dependencies
sudo dnf install <package-name>
```

#### La configuration Meson échoue

```bash
# Clean and reconfigure
rm -rf build
meson setup build --buildtype=release
```

### Erreurs d'exécution

#### Port déjà utilisé

```bash
# Find process using port
sudo lsof -i :9002

# Kill process
sudo kill -9 <PID>
```

#### Permission refusée pour le SDR

```bash
# Add user to plugdev group
sudo usermod -a -G plugdev $USER

# Reload groups (or log out and back in)
newgrp plugdev
```

Pour un **RX-888 MkII**, cela ne suffit pas à soi seul — le périphérique Cypress FX3 a aussi
besoin de règles udev. Exécutez l'assistant fourni (il installe les règles *et* vous ajoute
à `plugdev`), puis déconnectez-vous/reconnectez-vous et rebranchez l'appareil :

```bash
./setup-rx888-udev.sh
```

#### Problèmes audio

```bash
# Try different codec
# Edit config file and change:
audio_compression = "flac"  # or "opus"

# Rebuild
cd frontend && npm run build && cd ..
```

### Problèmes OpenCL

#### clinfo n'affiche aucun appareil

```bash
# Verify drivers are loaded
sudo clinfo

# Check OpenCL ICD files
ls /etc/OpenCL/vendors/

# Reinstall drivers (Intel example)
sudo apt remove --purge intel-opencl-icd
sudo apt install intel-opencl-icd
```

#### Aucune amélioration des performances

```bash
# Verify OpenCL is enabled in config
accelerator = "opencl"

# Try different device
# Add to config file:
[input.opencl]
device_id = 0  # Try 0, 1, 2, etc.
```

### Problèmes réseau

#### Impossible d'accéder depuis d'autres appareils

```bash
# Check firewall
sudo ufw status
sudo ufw allow 9002/tcp

# Or disable firewall temporarily for testing
sudo ufw disable
```

#### Latence élevée

```bash
# Reduce waterfall size in config
waterfall_size = 512

# Increase buffer size
buffer_size = 16384

# Use Opus instead of FLAC
audio_compression = "opus"
```

### Problèmes d'appareil SDR

#### RTL-SDR introuvable

```bash
# Check if device is recognized
lsusb | grep Realtek

# Test with rtl_test
rtl_test

# Try blacklisting DVB-T drivers
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo rmmod dvb_usb_rtl28xxu
```

#### SDRplay introuvable

```bash
# Check API installation
systemctl status sdrplay

# Restart API
sudo systemctl restart sdrplay

# Test with SoapySDR
SoapySDRUtil --find
```

---

## Optimisation des performances

### Optimisation du processeur

```toml
# Adjust thread counts based on CPU cores
[server]
threads = 4  # Set to number of cores

[input]
fft_threads = 4  # Set to number of cores
```

### Optimisation de la mémoire

```toml
# Reduce memory usage
[input]
waterfall_size = 512  # Lower value = less memory
fft_size = 65536      # Lower value = less memory
```

### Optimisation du réseau

```toml
# Optimize for limited bandwidth
[input]
audio_compression = "opus"  # More efficient than FLAC
waterfall_compression = "zstd"  # Efficient compression
```

---

## Mise à jour de PhantomSDR-Plus

### Mise à jour manuelle

```bash
cd PhantomSDR-Plus

# Backup your configuration
cp config-rtl.toml config-rtl.toml.backup
cp frontend/site-information.json frontend/site-information.json.backup

# Pull latest changes
git pull origin main
git submodule update --init --recursive

# Rebuild
meson compile -C build
cd frontend && npm install && npm run build && cd ..
```

### Script de mise à jour automatique

Créez `update.sh` :

```bash
#!/bin/bash
cd ~/PhantomSDR-Plus
./stop-websdr.sh
git pull origin main
git submodule update --init --recursive
meson compile -C build
cd frontend && npm install && npm run build && cd ..
./start-rtl.sh
```

---

## Sauvegarde et restauration

### Fichiers à sauvegarder

- Fichiers de configuration : `*.toml`
- Informations du site : `frontend/site-information.json`
- Marqueurs : `markers.json`
- Scripts personnalisés : `start-*.sh`, `stop-*.sh`
- Historique du chat : `chat_history.txt`
- Image de fond : `frontend/src/assets/background.jpg`

### Commande de sauvegarde

```bash
cd ~/PhantomSDR-Plus
tar -czf phantomsdr-backup-$(date +%Y%m%d).tar.gz \
  *.toml \
  *.sh \
  markers.json \
  chat_history.txt \
  frontend/site-information.json \
  frontend/src/assets/background.jpg
```

### Commande de restauration

```bash
tar -xzf phantomsdr-backup-YYYYMMDD.tar.gz
```

---

## Considérations de sécurité

### Configuration du pare-feu

```bash
# Allow only necessary ports
sudo ufw allow 9002/tcp
sudo ufw enable
```

### Proxy inverse (facultatif)

Envisagez d'utiliser nginx ou Apache comme proxy inverse pour :
- le chiffrement SSL/TLS
- l'association d'un nom de domaine
- la répartition de charge
- le contrôle d'accès

### Limites d'utilisateurs

Modifiez `config.toml` :
```toml
[server]
max_users = 100  # Limit concurrent users
```

---

## Obtenir de l'aide

### Ressources

- **Documentation** : ce guide, README.md, USER_GUIDE.md
- **GitHub Issues** : https://github.com/sv1btl/PhantomSDR-Plus/issues
- **Démo en direct** : http://phantomsdr.no-ip.org:8900/

### Signaler un problème

Lorsque vous signalez un problème, indiquez :
1. le système d'exploitation et sa version
2. le modèle d'appareil SDR
3. le contenu du fichier de configuration
4. les messages d'erreur
5. l'utilisation des ressources système (CPU, RAM, GPU)

### Soutien de la communauté

- Consultez les issues GitHub existantes avant d'en créer de nouvelles
- Fournissez des informations détaillées sur votre installation
- Joignez les journaux et les messages d'erreur
- Soyez patient et respectueux

---

## Annexe A : liste complète des dépendances

### Liste des paquets Ubuntu 24.04

```
build-essential
cmake
pkg-config
meson
libfftw3-dev
libwebsocketpp-dev
libflac++-dev
zlib1g-dev
libzstd-dev
libboost-all-dev
libopus-dev
libliquid-dev
git
util-linux (taskset — for the autorun spot reporter)
psmisc
wget
curl
rtl-sdr (for RTL-SDR)
airspy (for Airspy)
hackrf (for HackRF)
libclfft-dev (for OpenCL)
ocl-icd-opencl-dev (for OpenCL)
clinfo (for OpenCL)
```

---

## Annexe B : exemples de configuration

### Exemple 1 : RTL-SDR pour VHF/UHF

```toml
[input]
sps = 2048000
frequency = 145000000
signal = "iq"

[input.driver]
format = "u8"

[input.defaults]
frequency = 145500000
modulation = "FM"
```

### Exemple 2 : RX888 pour HF (0-30 MHz)

```toml
[input]
sps = 60000000
frequency = 0
signal = "real"
fft_size = 8388608

[input.driver]
format = "s16"

[input.defaults]
frequency = 7100000
modulation = "LSB"
```

### Exemple 3 : HackRF pour la FM à large bande

```toml
[input]
sps = 10000000
frequency = 100900000
signal = "iq"

[input.driver]
format = "s8"

[input.defaults]
frequency = 100900000
modulation = "WBFM"
```

---

**Installation terminée ! Vous devriez maintenant disposer d'un serveur PhantomSDR-Plus pleinement fonctionnel.**

**73 de SV1BTL & SV2AMK**
