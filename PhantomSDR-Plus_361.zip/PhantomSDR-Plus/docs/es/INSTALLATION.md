# Guía de instalación de PhantomSDR-Plus para operadores de sistema

Esta guía completa le acompañará en la instalación y configuración de PhantomSDR-Plus en su servidor.

---

## Índice

1. [Requisitos del sistema](#requisitos-del-sistema)
2. [Preparación previa a la instalación](#preparación-previa-a-la-instalación)
3. [Instalación de dependencias](#instalación-de-dependencias)
4. [Instalación de Node.js y npm](#instalación-de-nodejs-y-npm)
5. [Instalación de OpenCL (opcional pero recomendable)](#instalación-de-opencl-opcional-pero-recomendable)
6. [Instalación de PhantomSDR-Plus](#instalación-de-phantomsdr-plus)
7. [Instalación del códec de audio Opus](#instalación-del-códec-de-audio-opus)
8. [Autorun Spot Reporter (FT8/FT4/WSPR)](#autorun-spot-reporter-ft8ft4wspr)
9. [Configuración](#configuración)
10. [Configuración específica por dispositivo SDR](#configuración-específica-por-dispositivo-sdr)
11. [Pruebas y verificación](#pruebas-y-verificación)
12. [Configuración del arranque automático](#configuración-del-arranque-automático)
13. [Resolución de problemas](#resolución-de-problemas)

---

## Requisitos del sistema

### Sistemas operativos compatibles

**Principal (recomendado):**
- Ubuntu 24.04 LTS (x86_64) (recomendado)

**Alternativa:**
- Fedora (última versión estable)

### Requisitos de hardware

**Configuración mínima:**
- CPU: procesador de doble núcleo (2 GHz o más)
- RAM: 4 GB
- Almacenamiento: 10 GB libres
- Red: conexión de 100 Mbps

**Configuración recomendada:**
- CPU: cuatro núcleos o mejor (Ryzen 5 2600, Intel i5-6500T o superior)
- RAM: 8 GB o más
- Almacenamiento: SSD de 20 GB o más
- GPU: AMD/NVIDIA compatible con OpenCL (muy recomendable)
- Red: conexión de 1 Gbps

**Configuración de alto rendimiento:**
- CPU: 6 núcleos o más (Ryzen 7, Intel i7 o mejor)
- RAM: 16 GB o más
- Almacenamiento: SSD NVMe
- GPU: GPU dedicada compatible con OpenCL/CUDA
- Red: 1 Gbps o superior

---

## Preparación previa a la instalación

### 1. Actualice el sistema

```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade -y
sudo reboot

# Fedora
sudo dnf update -y
sudo reboot
```

### 2. Compruebe la versión de Ubuntu

```bash
lsb_release -a
```

**La salida esperada debería mostrar:** Ubuntu 24.04 LTS

### 3. Compruebe el espacio libre en disco

```bash
df -h
```

Asegúrese de tener al menos 10 GB libres en su directorio personal.

### 4. Consulte la información de la CPU

```bash
lscpu
```

Anote el número de núcleos/hilos para optimizar la configuración.

---

## Instalación de dependencias

### Ubuntu 24.04 LTS

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  git \
  psmisc \
  wget \
  curl
```

### Fedora

```bash
sudo dnf install -y \
  g++ \
  meson \
  cmake \
  fftw3-devel \
  websocketpp-devel \
  flac-devel \
  zlib-devel \
  boost-devel \
  libzstd-devel \
  opus-devel \
  liquid-dsp-devel \
  git \
  psmisc \
  wget \
  curl
```

### Verifique la instalación

```bash
# Check if key dependencies are installed
pkg-config --modversion fftw3
cmake --version
meson --version
```

---

## Instalación de Node.js y npm

PhantomSDR-Plus necesita Node.js para compilar la interfaz web. Usaremos NVM (Node Version Manager) para instalarlo.

### 1. Instale NVM

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
```

### 2. Cargue NVM

**IMPORTANTE:** cierre y vuelva a abrir el terminal, o ejecute:

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

### 3. Compruebe la instalación de NVM

```bash
nvm --version
```

Salida esperada: `0.40.4` o similar

### 4. Instale Node.js

```bash
# Install Node.js 22 - the version every install script requires
nvm install 22

# Make it the default, so systemd units and cron see it too
nvm alias default 22

# Verify installation
node --version
npm --version
```

### 5. Opcional: instale otras versiones de Node

```bash
# Install latest version
nvm install node

# Install specific version (if needed)
nvm install 22.22.3

# List installed versions
nvm list

# Use specific version
nvm use 22
```

---

## Instalación de OpenCL (opcional pero recomendable)

OpenCL mejora enormemente el rendimiento al trasladar los cálculos de FFT a la GPU. Esta sección cubre la gráfica integrada de Intel. Para GPU de AMD/NVIDIA, consulte la documentación del fabricante.

### CPU Intel con gráficos integrados

#### 1. Instale los componentes básicos de OpenCL

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  libclfft-dev \
  ocl-icd-opencl-dev \
  clinfo
```

#### 2. Descargue Intel Compute Runtime

```bash
mkdir -p ~/neo
cd ~/neo

wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
```

#### 3. Instale el entorno de ejecución OpenCL de Intel

```bash
sudo dpkg -i *.deb
```

Si aparecen errores de dependencias:

```bash
sudo apt --fix-broken install
```

#### 4. Instale el cargador ICD de OpenCL

```bash
sudo apt update
sudo apt install intel-opencl-icd
```

Si aparecen errores:

```bash
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
```

#### 5. Verifique la instalación de OpenCL

```bash
sudo clinfo
```

Debería ver información sobre su plataforma y dispositivos OpenCL. Busque:
- Número de plataformas: 1 (o más)
- Nombre de la plataforma: Intel(R) OpenCL (o similar)
- Tipo de dispositivo: GPU o CPU

#### 6. Reinicie

```bash
sudo reboot
```

### OpenCL en GPU AMD

Para GPU de AMD, instale ROCm:

```bash
# Add ROCm repository
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list

# Install ROCm
sudo apt update
sudo apt install rocm-opencl rocm-clinfo

# Add user to video group
sudo usermod -a -G video $USER

# Reboot
sudo reboot

# Verify
clinfo
```

### OpenCL en GPU NVIDIA

Para GPU de NVIDIA, instale CUDA:

```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-525

# Install CUDA toolkit
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt update
sudo apt install cuda

# Reboot
sudo reboot

# Verify
nvidia-smi
clinfo
```

---

## Instalación de PhantomSDR-Plus

### Clonar el repositorio, dar permisos de ejecución e instalación automática

```bash
cd ~
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```
**⚠️ IMPORTANTE:** cuando `install.sh` termine, **reinicie el terminal** antes de continuar.

### 4. Opción B: instalación manual

Si prefiere la instalación manual o la automática falla:

#### Compilar el backend

```bash
# Clean any previous builds, Configure build with optimization, Compile
rm -rf build
meson setup build --buildtype=release --optimization=3
meson compile -C build

# Verify binary was created
ls -lh build/spectrumserver
```

#### Compilar el frontend

```bash
cd frontend

# Install dependencies, Fix any vulnerabilities, Build the frontend
npm install
npm audit fix
npm run build

# Return to project root
cd ..
```

### Verifique la instalación

```bash
# Check if binary exists
ls -lh build/spectrumserver

# Check if frontend was built
ls -lh frontend/dist/

# List important files
ls -lh *.sh *.toml
```

---

## Instalación del códec de audio Opus

Opus ofrece mejor calidad de audio y menor latencia que FLAC.

### 1. Instale la biblioteca de sistema libopus

```bash
sudo apt-get update
sudo apt-get install -y libopus0 libopus-dev
```

### 2. Instale el decodificador Opus para el frontend

```bash
cd PhantomSDR-Plus/frontend

# Install npm dependencies if not already done, Install Opus WASM decoder, Fix any vulnerabilities, Rebuild frontend
npm install
npm install @wasm-audio-decoders/opus-ml
npm audit fix
npm run build

# Return to project root
cd ..
```

### 3. Verifique la instalación de Opus

```bash
# Check if Opus system library is installed
pkg-config --modversion opus

# Check if Opus npm package is installed
cd frontend
npm list @wasm-audio-decoders/opus-ml
cd ..
```

---

## Autorun Spot Reporter (FT8/FT4/WSPR)

PhantomSDR-Plus incluye un **autorun spot reporter** opcional (en el directorio `autorun/`).
Decodifica FT8/FT4/WSPR en el servidor, directamente del receptor, y sube los spots a las
redes de reporte:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

Se controla íntegramente desde la pestaña **panel de administración → «Spot Reporting»**, y
**el reporte está DESACTIVADO por defecto**: no se transmite ni se sube nada hasta que lo
active ahí. El decodificador se ejecuta como un demonio Node.js aparte y toma el audio del
receptor localmente, por lo que no añade hardware de RF adicional.

### Requisitos

| Requisito | Notas |
|-----------|-------|
| **Node.js 22+** | El mismo entorno de ejecución que ya necesita la compilación del frontend; se instala en el [paso de Node.js](#instalación-de-nodejs-y-npm). |
| **Paquetes npm `ws` + `cbor-x`** | Se resuelven a través de `autorun/node_modules`, un enlace simbólico al `node_modules` del frontend (ambos paquetes están declarados en `frontend/package.json`). |
| **`util-linux`** (`taskset`) | El botón «Start» del panel fija el demonio a los E-cores con `taskset`. Está presente en prácticamente todas las distribuciones; los instaladores lo añaden de forma explícita. |
| **Indicativo + localizador** | Se leen de `frontend/site_information.json` (`siteSysop` / `siteGridSquare`) salvo que se sustituyan en la pestaña de administración. Los spots se suben con ese indicativo. |

> ⚠️ **Reporte solo lo que realmente recibe.** Los spots se suben a redes públicas con su
> indicativo: active únicamente las bandas y modos que su receptor oye de verdad, y use su
> localizador correcto.

### Instalación automática

`install.sh` (y las variantes por distribución: `install-Deb12.sh`, `install_arch.sh`,
`install_fedora.sh`, `install_opensuse.sh`) se encargan de todo: instalan Node.js 22 y
`util-linux`, ejecutan el `npm install` del frontend y después crean automáticamente el
enlace simbólico `autorun/node_modules`. No hacen falta pasos adicionales: la función está
lista en cuanto termina `install.sh`.

### Instalación manual

Si instaló manualmente (opción B), cree usted mismo el enlace simbólico tras el
`npm install` del frontend para que el demonio pueda resolver sus dependencias:

```bash
cd ~/PhantomSDR-Plus

# 1. Frontend deps must be installed first (ws + cbor-x live there)
cd frontend && npm install && cd ..

# 2. Link the autorun daemon to the frontend's node_modules
ln -sfn ../frontend/node_modules autorun/node_modules

# 3. Ensure taskset is available (Debian/Ubuntu shown; use your package manager)
sudo apt install -y util-linux
```

> **Nota:** `autorun/node_modules` está excluido por git, así que un `git clone` nuevo nunca
> lo contiene: el enlace debe (re)crearse después de cada descarga limpia. Los instaladores
> lo hacen por usted; el comando anterior es solo para instalaciones manuales.

### Comprobación

```bash
# The symlink should point at ../frontend/node_modules
ls -l autorun/node_modules

# ws + cbor-x must resolve
ls -d frontend/node_modules/ws frontend/node_modules/cbor-x

# taskset must be on PATH
command -v taskset
```

Después abra el panel de administración, vaya a la pestaña **Spot Reporting**, indique su
identidad, marque las bandas y modos que desea decodificar, active los destinos y pulse
**Start**. Aparecerá un distintivo «📶 REPORTING» en la cascada principal mientras el reporte
esté activo. (PSK Reporter sube por lotes cada 5 minutos y wsprnet cada 2 minutos, así que un
demonio recién iniciado muestra «0 sent» durante los primeros minutos: es normal.)

A partir de ahí se muestran dos contadores distintos, fáciles de confundir. Los
paneles **SPOTS UPLOADED PER DECODER** cuentan solo la ejecución actual, de modo
que Stop/Start los pone a cero; el número junto a cada casilla de banda/modo es el
total **histórico** de esa ranura, guardado en `autorun-totals.json` para que
sobreviva a los reinicios. Consulte la [guía del panel de administración](ADMIN_PANEL_SETUP.md)
para ambos, y para la página **Gráficos**, que representa la frecuencia de CPU, la
carga, la temperatura y los usuarios conectados desde 15 minutos hasta 24 horas.

> **El puerto del servidor se detecta automáticamente.** El demonio se conecta directamente
> al `[server] port` del propio spectrumserver (bucle local + token, sin pasar por el proxy).
> Lee ese puerto del archivo de configuración con el que se lanzó el spectrumserver en
> ejecución, de modo que funciona en cualquier puerto sin configuración; la línea
> `[autorun] tap backend: …` de `autorun.log` muestra lo que ha resuelto. Si su servidor no
> estaba en marcha cuando arrancó el demonio, o si tiene una instalación poco habitual,
> fíjelo en `autorun.json`:
> ```json
> "server": { "host": "127.0.0.1", "port": 9002 }
> ```
> Un puerto incorrecto se manifiesta como `504` / `tap closed 1006` en `autorun.log`, con
> `decodes` atascado en 0.

---

## Configuración

### 1. Elija su archivo de configuración

Seleccione el archivo de configuración adecuado para su SDR:

- `config-rtl.toml`: llaves RTL-SDR
- `config-rsp1a.toml`: SDRplay RSP1A
- `config-airspyhf.toml`: Airspy HF+ Discovery
- `config-rx888mk2.toml`: RX888 MK2
- `config.example.hackrf.toml`: HackRF One

En este ejemplo usaremos el RTL-SDR.

### 2. Edite el archivo de configuración

```bash
nano config-rtl.toml
```

#### Ajustes clave

```toml
[server]
port = 9002                      # Web interface port (or everything else)
html_root = "frontend/dist/"     # Frontend location
otherusers = 1                   # Show other users (1=yes, 0=no)
threads = 2                      # Number of server threads

[websdr]
register_online = true           # Register on sdr-list.xyz (true/false)
name = "Your WebSDR Name"        # Display name
antenna = "Your Antenna Type"    # e.g., "Vertical", "Loop", "Dipole"
grid_locator = "AB12cd"          # Your Maidenhead grid square
hostname = "your.domain.com"     # Your domain or IP address

[input]
sps = 2048000                    # Sample rate (adjust for your coverage)
fft_size = 131072                # FFT size (higher = better resolution)
brightness_offset = -10          # Waterfall brightness adjustment
frequency = 145000000            # Base frequency in Hz (145 MHz for 2m)
signal = "iq"                    # "iq" for complex, "real" for real sampling
fft_threads = 2                  # FFT processing threads
accelerator = "opencl"           # "none", "cuda", or "opencl"
audio_sps = 12000                # Audio sample rate (keep at 12000)
audio_compression = "opus"       # "flac" or "opus"
smeter_offset = -2               # S-meter calibration
waterfall_size = 1024            # Waterfall FFT size
waterfall_compression = "zstd"   # Waterfall compression

[input.driver]
name = "stdin"                   # Input driver
format = "u8"                    # Sample format for RTL-SDR

[input.defaults]
frequency = 145500000            # Default tuning frequency
modulation = "FM"                # Default modulation mode
```

#### Orientación sobre la tasa de muestreo

| Cobertura | Tasa de muestreo | Tamaño de FFT |
|-----------|------------------|---------------|
| 2 MHz | 2048000 | 131072 |
| 3.2 MHz | 3200000 | 131072 |
| 10 MHz | 10000000 | 1048576 |
| 30 MHz | 30000000 | 2097152 |
| 60 MHz | 60000000 | 8388608 |

### 3. Configure la información del sitio

```bash
nano frontend/site-information.json
```

Edite los siguientes campos:

```json
{
  "siteSysop": "YourCallsign",
  "siteSysopEmailAddress": "your@email.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "Your City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Computer specifications",
  "siteSoftware": "PhantomSDR-Plus v3.6.1",
  "siteReceiver": "Your SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional information",
  "siteIP": "http://your.domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

**Regiones de la IARU:**
- **1**: Europa, África, Oriente Medio, norte de Asia
- **2**: América (Norte, Centro y Sur), Caribe
- **3**: Asia-Pacífico, Oceanía

### 4. Personalice los marcadores de frecuencia (opcional)

```bash
nano markers.json
```

Añada sus frecuencias favoritas, repetidores y emisoras de radiodifusión.

### 5. Edite el script de arranque

```bash
nano start-rtl.sh
```

El script de arranque es un lanzador autónomo con watchdog integrado. Edite únicamente el
bloque **RECEIVER CONFIGURATION** cerca del principio, para que los argumentos del receptor
coincidan con su instalación:

```bash
# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═══
RX_LABEL="RTL-SDR"
RX_COMM="rtl_sdr"                       # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rtl.toml"    # your .toml
FIFO="$PHANTOMDIR/rtl.fifo"
RX_ARGS="${RX_ARGS:--f 145000000 -s 2048000 -}"   # receiver args (edit these)
```

Parámetros dentro de `RX_ARGS`:
- `-f 145000000`: frecuencia central (145 MHz)
- `-s 2048000`: tasa de muestreo (2,048 MSPS)

`CONFIG` apunta a su `.toml`. **No** necesita editar nada más en el script: la lógica de
arranque/reinicio/watchdog/registro es genérica. También puede sustituir los argumentos del
receptor al lanzarlo sin editar el archivo:
`RX_ARGS="-f 145000000 -s 2048000 -" ./start-rtl.sh`
(`RX888_ARGS` para `start-rx888mk2.sh`).

---

## Configuración específica por dispositivo SDR

### RTL-SDR

#### Instale las herramientas RTL-SDR

```bash
sudo apt install -y rtl-sdr
```

#### Pruebe el RTL-SDR

```bash
rtl_test
```

Pulse Ctrl+C para detenerlo. Debería ver información sobre la tasa de muestreo.

#### Edite la configuración

```bash
nano config-rtl.toml
```

Ajustes habituales para RTL-SDR:
```toml
sps = 2048000
frequency = 145000000
signal = "iq"
format = "u8"
```

### SDRplay RSP1A

#### Instale SoapySDR y la compatibilidad con SDRplay

```bash
# Install SoapySDR
sudo apt install -y soapysdr-tools

# Download SDRplay API
cd ~/Downloads
wget https://www.sdrplay.com/software/SDRplay_RSP_API-Linux-3.07.1.run
chmod +x SDRplay_RSP_API-Linux-3.07.1.run
sudo ./SDRplay_RSP_API-Linux-3.07.1.run

# Install SoapySDRPlay
git clone https://github.com/pothosware/SoapySDRPlay.git
cd SoapySDRPlay
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig
```

#### Pruebe el SDRplay

```bash
SoapySDRUtil --find="driver=sdrplay"
```

#### Instrucciones adicionales

Consulte el archivo incluido: `instractions-for-rsp1a`

### Airspy HF+

#### Instale las herramientas Airspy

```bash
sudo apt install -y airspy
```

#### Pruebe el Airspy

```bash
airspy_info
```

#### Instrucciones adicionales

Consulte el archivo incluido: `instractions-for-airspy`

### RX888 MK2

#### Instale las herramientas RX888

```bash
# Install rx_tools
git clone https://github.com/rxseger/rx_tools.git
cd rx_tools
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig

# Install RX888 firmware and support
# Follow manufacturer instructions
```

#### Ejecutar rx888_stream sin sudo (reglas udev)

Por defecto, el dispositivo USB Cypress FX3 del RX-888 solo es accesible para root, de modo
que `rx888_stream` necesitaría `sudo`. Ejecute una vez el asistente incluido para instalar
las reglas udev y añadirse al grupo `plugdev`:

```bash
./setup-rx888-udev.sh          # re-runs itself with sudo automatically
```

Escribe `/etc/udev/rules.d/99-rx888.rules` para los tres identificadores de producto Cypress
FX3 (`04b4:00f1`/`00f3` gestor de arranque y `04b4:8613` con el firmware cargado), recarga
udev y crea un enlace estable `/dev/rx888`. **Cierre la sesión y vuelva a entrar** (por el
cambio de grupo) y **reconecte el dispositivo** una vez; después, `rx888_stream` —y el
lanzador `start-rx888mk2.sh`— funcionan sin `sudo`. Es idempotente, así que puede volver a
ejecutarlo sin problema. Para configurar otra cuenta:
`RX888_USER=<nombre> ./setup-rx888-udev.sh`.

#### Edite la configuración

```bash
nano config-rx888mk2.toml
```

Ajustes habituales para el RX888:
```toml
sps = 60000000
frequency = 0
signal = "real"
format = "s16"
fft_size = 8388608
```

### HackRF One

#### Instale las herramientas HackRF

```bash
sudo apt install -y hackrf
```

#### Pruebe el HackRF

```bash
hackrf_info
```

---

## Pruebas y verificación

### 1. Prueba de arranque

```bash
# For RTL-SDR
./start-rtl.sh
```

Esto inicia el servidor **en segundo plano** (se desvincula y devuelve el control de
inmediato) y empieza a registrar en `logwebsdr.txt`.

### 2. Compruebe si hay errores

El script registra su progreso en `logwebsdr.txt`; obsérvelo en directo:

```bash
tail -f logwebsdr.txt
```

Busque:
- ✅ `Starting the initialization script of the PhantomSDR Server`
- ✅ `<receiver> running (PID …)`
- ✅ `Server started normally`
- ❌ `Server … FAILED …` o `ERROR: receiver binary '…' not found` (corrija los argumentos del
  receptor o el `.toml`, o instale la herramienta del receptor, y vuelva a ejecutar el script)

### 3. Acceda a la interfaz web

Abra el navegador en:
```
http://localhost:9002
```

(Sustituya el número de puerto por el que haya configurado)

### 4. Verifique el funcionamiento

- La cascada debe mostrarse
- El audio debe sonar al hacer clic en las señales
- El S-metro debe responder a las señales
- El contador de usuarios debe mostrar «1»

### 5. Pruebe desde otro dispositivo

Desde otro ordenador de su red:
```
http://YOUR_SERVER_IP:9002
```

### 6. Compruebe el uso de recursos

```bash
# Monitor CPU usage
htop

# Monitor GPU usage (if OpenCL/CUDA enabled)
nvidia-smi  # For NVIDIA
radeontop   # For AMD

# Monitor network usage
iftop
```

### 7. Detenga el servidor

El servidor se ejecuta en segundo plano bajo un watchdog, así que **Ctrl+C no lo detendrá**
(y el watchdog volvería a arrancarlo). Use el script de parada compartido, que sirve para
cualquier receptor: primero detiene el watchdog y después el receptor y `spectrumserver`:

```bash
./stop-websdr.sh
```

---

## Configuración del arranque automático

### Con systemd (recomendado)

#### 1. Cree el archivo de servicio

```bash
sudo nano /etc/systemd/system/phantomsdr.service
```

Añada el siguiente contenido (ajuste rutas y usuario):

```ini
[Unit]
Description=PhantomSDR-Plus WebSDR Server
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/PhantomSDR-Plus
# Run the watchdog in the FOREGROUND (note the --watchdog flag) so systemd can
# track it. Do NOT use the plain "./start-rtl.sh" here — that form detaches into
# the background and exits, which systemd would treat as the service stopping.
ExecStart=/home/youruser/PhantomSDR-Plus/start-rtl.sh --watchdog
ExecStop=/home/youruser/PhantomSDR-Plus/stop-websdr.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

> El proceso `--watchdog` ya reinicia por su cuenta el receptor y `spectrumserver`;
> `Restart=always` es solo una red de seguridad para el caso raro de que el propio watchdog
> termine. Como aquí systemd supervisa el servidor, puede usar `systemctl start/stop/restart`
> y `journalctl -u phantomsdr -f` en lugar de ejecutar los scripts a mano.

#### 2. Active e inicie el servicio

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable phantomsdr.service

# Start service now
sudo systemctl start phantomsdr.service

# Check status
sudo systemctl status phantomsdr.service
```

#### 3. Gestione el servicio

```bash
# Start
sudo systemctl start phantomsdr

# Stop
sudo systemctl stop phantomsdr

# Restart
sudo systemctl restart phantomsdr

# View logs
sudo journalctl -u phantomsdr -f
```

### Con Screen (alternativa)

> Normalmente innecesario: `./start-rtl.sh` ya se desvincula al segundo plano (mediante
> `setsid`) y sigue funcionando después de cerrar la sesión, con su propio watchdog. Screen
> solo resulta útil si quiere específicamente una sesión interactiva para ejecutar la forma
> en primer plano `./start-rtl.sh --watchdog`.

#### 1. Instale Screen

```bash
sudo apt install -y screen
```

#### 2. Arranque en una sesión de Screen

```bash
screen -S phantomsdr
./start-rtl.sh
```

Pulse Ctrl+A y después D para desvincularse.

#### 3. Vuelva a la sesión

```bash
screen -r phantomsdr
```

---

## Resolución de problemas

### Errores de compilación

#### Problemas de dependencias

```bash
# Ubuntu: Install missing dependencies
sudo apt install --fix-broken

# Fedora: Install missing dependencies
sudo dnf install <package-name>
```

#### Falla la configuración de Meson

```bash
# Clean and reconfigure
rm -rf build
meson setup build --buildtype=release
```

### Errores en ejecución

#### El puerto ya está en uso

```bash
# Find process using port
sudo lsof -i :9002

# Kill process
sudo kill -9 <PID>
```

#### Permiso denegado para el SDR

```bash
# Add user to plugdev group
sudo usermod -a -G plugdev $USER

# Reload groups (or log out and back in)
newgrp plugdev
```

Para un **RX-888 MkII** esto no basta por sí solo: el dispositivo Cypress FX3 necesita además
reglas udev. Ejecute el asistente incluido (instala las reglas *y* le añade a `plugdev`),
después cierre la sesión, vuelva a entrar y reconecte el dispositivo:

```bash
./setup-rx888-udev.sh
```

#### Problemas de audio

```bash
# Try different codec
# Edit config file and change:
audio_compression = "flac"  # or "opus"

# Rebuild
cd frontend && npm run build && cd ..
```

### Problemas con OpenCL

#### clinfo no muestra dispositivos

```bash
# Verify drivers are loaded
sudo clinfo

# Check OpenCL ICD files
ls /etc/OpenCL/vendors/

# Reinstall drivers (Intel example)
sudo apt remove --purge intel-opencl-icd
sudo apt install intel-opencl-icd
```

#### El rendimiento no mejora

```bash
# Verify OpenCL is enabled in config
accelerator = "opencl"

# Try different device
# Add to config file:
[input.opencl]
device_id = 0  # Try 0, 1, 2, etc.
```

### Problemas de red

#### No se puede acceder desde otros dispositivos

```bash
# Check firewall
sudo ufw status
sudo ufw allow 9002/tcp

# Or disable firewall temporarily for testing
sudo ufw disable
```

#### Latencia alta

```bash
# Reduce waterfall size in config
waterfall_size = 512

# Increase buffer size
buffer_size = 16384

# Use Opus instead of FLAC
audio_compression = "opus"
```

### Problemas con el dispositivo SDR

#### No se encuentra el RTL-SDR

```bash
# Check if device is recognized
lsusb | grep Realtek

# Test with rtl_test
rtl_test

# Try blacklisting DVB-T drivers
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo rmmod dvb_usb_rtl28xxu
```

#### No se encuentra el SDRplay

```bash
# Check API installation
systemctl status sdrplay

# Restart API
sudo systemctl restart sdrplay

# Test with SoapySDR
SoapySDRUtil --find
```

---

## Optimización del rendimiento

### Optimización de la CPU

```toml
# Adjust thread counts based on CPU cores
[server]
threads = 4  # Set to number of cores

[input]
fft_threads = 4  # Set to number of cores
```

### Optimización de la memoria

```toml
# Reduce memory usage
[input]
waterfall_size = 512  # Lower value = less memory
fft_size = 65536      # Lower value = less memory
```

### Optimización de la red

```toml
# Optimize for limited bandwidth
[input]
audio_compression = "opus"  # More efficient than FLAC
waterfall_compression = "zstd"  # Efficient compression
```

---

## Actualización de PhantomSDR-Plus

### Actualización manual

```bash
cd PhantomSDR-Plus

# Backup your configuration
cp config-rtl.toml config-rtl.toml.backup
cp frontend/site-information.json frontend/site-information.json.backup

# Pull latest changes
git pull origin main
git submodule update --init --recursive

# Rebuild
meson compile -C build
cd frontend && npm install && npm run build && cd ..
```

### Script de actualización automática

Cree `update.sh`:

```bash
#!/bin/bash
cd ~/PhantomSDR-Plus
./stop-websdr.sh
git pull origin main
git submodule update --init --recursive
meson compile -C build
cd frontend && npm install && npm run build && cd ..
./start-rtl.sh
```

---

## Copia de seguridad y restauración

### Archivos que conviene respaldar

- Archivos de configuración: `*.toml`
- Información del sitio: `frontend/site-information.json`
- Marcadores: `markers.json`
- Scripts personalizados: `start-*.sh`, `stop-*.sh`
- Historial del chat: `chat_history.txt`
- Imagen de fondo: `frontend/src/assets/background.jpg`

### Comando de copia de seguridad

```bash
cd ~/PhantomSDR-Plus
tar -czf phantomsdr-backup-$(date +%Y%m%d).tar.gz \
  *.toml \
  *.sh \
  markers.json \
  chat_history.txt \
  frontend/site-information.json \
  frontend/src/assets/background.jpg
```

### Comando de restauración

```bash
tar -xzf phantomsdr-backup-YYYYMMDD.tar.gz
```

---

## Consideraciones de seguridad

### Configuración del cortafuegos

```bash
# Allow only necessary ports
sudo ufw allow 9002/tcp
sudo ufw enable
```

### Proxy inverso (opcional)

Considere usar nginx o Apache como proxy inverso para:
- cifrado SSL/TLS
- asignación de nombre de dominio
- equilibrio de carga
- control de acceso

### Límite de usuarios

Edite `config.toml`:
```toml
[server]
max_users = 100  # Limit concurrent users
```

---

## Cómo obtener ayuda

### Recursos

- **Documentación**: esta guía, README.md, USER_GUIDE.md
- **GitHub Issues**: https://github.com/sv1btl/PhantomSDR-Plus/issues
- **Demostración en directo**: http://phantomsdr.no-ip.org:8900/

### Cómo informar de problemas

Al informar de un problema, incluya:
1. sistema operativo y versión
2. modelo del dispositivo SDR
3. contenido del archivo de configuración
4. mensajes de error
5. uso de recursos del sistema (CPU, RAM, GPU)

### Soporte de la comunidad

- Consulte las incidencias existentes en GitHub antes de crear otras nuevas
- Aporte información detallada sobre su instalación
- Incluya registros y mensajes de error
- Sea paciente y respetuoso

---

## Apéndice A: lista completa de dependencias

### Lista de paquetes de Ubuntu 24.04

```
build-essential
cmake
pkg-config
meson
libfftw3-dev
libwebsocketpp-dev
libflac++-dev
zlib1g-dev
libzstd-dev
libboost-all-dev
libopus-dev
libliquid-dev
git
util-linux (taskset — for the autorun spot reporter)
psmisc
wget
curl
rtl-sdr (for RTL-SDR)
airspy (for Airspy)
hackrf (for HackRF)
libclfft-dev (for OpenCL)
ocl-icd-opencl-dev (for OpenCL)
clinfo (for OpenCL)
```

---

## Apéndice B: ejemplos de configuración

### Ejemplo 1: RTL-SDR para VHF/UHF

```toml
[input]
sps = 2048000
frequency = 145000000
signal = "iq"

[input.driver]
format = "u8"

[input.defaults]
frequency = 145500000
modulation = "FM"
```

### Ejemplo 2: RX888 para HF (0-30 MHz)

```toml
[input]
sps = 60000000
frequency = 0
signal = "real"
fft_size = 8388608

[input.driver]
format = "s16"

[input.defaults]
frequency = 7100000
modulation = "LSB"
```

### Ejemplo 3: HackRF para FM de banda ancha

```toml
[input]
sps = 10000000
frequency = 100900000
signal = "iq"

[input.driver]
format = "s8"

[input.defaults]
frequency = 100900000
modulation = "WBFM"
```

---

**¡Instalación completada! Ya debería tener un servidor PhantomSDR-Plus plenamente funcional.**

**73 de SV1BTL & SV2AMK**
