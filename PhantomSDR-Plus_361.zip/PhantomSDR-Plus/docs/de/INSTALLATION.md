# PhantomSDR-Plus Installationsanleitung für Systembetreiber

Diese ausführliche Anleitung führt Sie durch Installation und Konfiguration von PhantomSDR-Plus auf Ihrem Server.

---

## Inhaltsverzeichnis

1. [Systemanforderungen](#systemanforderungen)
2. [Vorbereitung vor der Installation](#vorbereitung-vor-der-installation)
3. [Abhängigkeiten installieren](#abhängigkeiten-installieren)
4. [Node.js und npm installieren](#nodejs-und-npm-installieren)
5. [OpenCL installieren (optional, aber empfohlen)](#opencl-installieren-optional-aber-empfohlen)
6. [PhantomSDR-Plus installieren](#phantomsdr-plus-installieren)
7. [Opus-Audiocodec installieren](#opus-audiocodec-installieren)
8. [Autorun-Spot-Reporter (FT8/FT4/WSPR)](#autorun-spot-reporter-ft8ft4wspr)
9. [Konfiguration](#konfiguration)
10. [Gerätespezifische SDR-Einrichtung](#gerätespezifische-sdr-einrichtung)
11. [Test und Überprüfung](#test-und-überprüfung)
12. [Automatischen Start einrichten](#automatischen-start-einrichten)
13. [Fehlerbehebung](#fehlerbehebung)

---

## Systemanforderungen

### Unterstützte Betriebssysteme

**Primär (empfohlen):**
- Ubuntu 24.04 LTS (x86_64) (empfohlen)

**Alternative:**
- Fedora (aktuelle stabile Version)

### Hardwareanforderungen

**Mindestkonfiguration:**
- CPU: Zweikernprozessor (2 GHz oder mehr)
- RAM: 4 GB
- Speicher: 10 GB freier Platz
- Netzwerk: 100-Mbit/s-Verbindung

**Empfohlene Konfiguration:**
- CPU: Vierkerner oder besser (Ryzen 5 2600, Intel i5-6500T oder besser)
- RAM: 8 GB oder mehr
- Speicher: SSD ab 20 GB
- GPU: AMD/NVIDIA mit OpenCL-Unterstützung (sehr empfehlenswert)
- Netzwerk: 1-Gbit/s-Verbindung

**Hochleistungskonfiguration:**
- CPU: 6 Kerne oder mehr (Ryzen 7, Intel i7 oder besser)
- RAM: 16 GB oder mehr
- Speicher: NVMe-SSD
- GPU: dedizierte GPU mit OpenCL-/CUDA-Unterstützung
- Netzwerk: 1 Gbit/s oder besser

---

## Vorbereitung vor der Installation

### 1. System aktualisieren

```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade -y
sudo reboot

# Fedora
sudo dnf update -y
sudo reboot
```

### 2. Ubuntu-Version prüfen

```bash
lsb_release -a
```

**Die erwartete Ausgabe sollte zeigen:** Ubuntu 24.04 LTS

### 3. Verfügbaren Speicherplatz prüfen

```bash
df -h
```

Stellen Sie sicher, dass in Ihrem Heimatverzeichnis mindestens 10 GB frei sind.

### 4. CPU-Informationen prüfen

```bash
lscpu
```

Notieren Sie die Anzahl der Kerne/Threads zur Optimierung der Konfiguration.

---

## Abhängigkeiten installieren

### Ubuntu 24.04 LTS

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  git \
  psmisc \
  wget \
  curl
```

### Fedora

```bash
sudo dnf install -y \
  g++ \
  meson \
  cmake \
  fftw3-devel \
  websocketpp-devel \
  flac-devel \
  zlib-devel \
  boost-devel \
  libzstd-devel \
  opus-devel \
  liquid-dsp-devel \
  git \
  psmisc \
  wget \
  curl
```

### Installation überprüfen

```bash
# Check if key dependencies are installed
pkg-config --modversion fftw3
cmake --version
meson --version
```

---

## Node.js und npm installieren

PhantomSDR-Plus benötigt Node.js, um das Frontend zu bauen. Wir verwenden dafür NVM (Node Version Manager).

### 1. NVM installieren

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
```

### 2. NVM laden

**WICHTIG:** Schließen Sie Ihr Terminal und öffnen Sie es erneut, oder führen Sie aus:

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

### 3. NVM-Installation überprüfen

```bash
nvm --version
```

Erwartete Ausgabe: `0.40.4` oder ähnlich

### 4. Node.js installieren

```bash
# Install Node.js 22 - the version every install script requires
nvm install 22

# Make it the default, so systemd units and cron see it too
nvm alias default 22

# Verify installation
node --version
npm --version
```

### 5. Optional: weitere Node-Versionen installieren

```bash
# Install latest version
nvm install node

# Install specific version (if needed)
nvm install 22.22.3

# List installed versions
nvm list

# Use specific version
nvm use 22
```

---

## OpenCL installieren (optional, aber empfohlen)

OpenCL verbessert die Leistung erheblich, indem es FFT-Berechnungen auf die GPU auslagert. Dieser Abschnitt behandelt integrierte Intel-Grafik. Für AMD-/NVIDIA-GPUs beachten Sie die Dokumentation des Herstellers.

### Intel-CPU mit integrierter Grafik

#### 1. OpenCL-Basiskomponenten installieren

```bash
sudo apt install -y \
  build-essential \
  cmake \
  pkg-config \
  meson \
  libfftw3-dev \
  libwebsocketpp-dev \
  libflac++-dev \
  zlib1g-dev \
  libzstd-dev \
  libboost-all-dev \
  libopus-dev \
  libliquid-dev \
  libclfft-dev \
  ocl-icd-opencl-dev \
  clinfo
```

#### 2. Intel Compute Runtime herunterladen

```bash
mkdir -p ~/neo
cd ~/neo

wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-gmmlib_18.4.1_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-core_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-igc-opencl_18.50.1270_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-opencl_19.07.12410_amd64.deb
wget https://github.com/intel/compute-runtime/releases/download/19.07.12410/intel-ocloc_19.07.12410_amd64.deb
```

#### 3. Intel-OpenCL-Runtime installieren

```bash
sudo dpkg -i *.deb
```

Falls Abhängigkeitsfehler auftreten:

```bash
sudo apt --fix-broken install
```

#### 4. OpenCL-ICD-Loader installieren

```bash
sudo apt update
sudo apt install intel-opencl-icd
```

Falls Fehler auftreten:

```bash
sudo apt --fix-broken install
sudo apt install intel-opencl-icd
```

#### 5. OpenCL-Installation überprüfen

```bash
sudo clinfo
```

Sie sollten Informationen zu Ihrer OpenCL-Plattform und den Geräten sehen. Achten Sie auf:
- Anzahl der Plattformen: 1 (oder mehr)
- Plattformname: Intel(R) OpenCL (oder ähnlich)
- Gerätetyp: GPU oder CPU

#### 6. Neu starten

```bash
sudo reboot
```

### OpenCL auf AMD-GPU

Installieren Sie für AMD-GPUs ROCm:

```bash
# Add ROCm repository
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list

# Install ROCm
sudo apt update
sudo apt install rocm-opencl rocm-clinfo

# Add user to video group
sudo usermod -a -G video $USER

# Reboot
sudo reboot

# Verify
clinfo
```

### OpenCL auf NVIDIA-GPU

Installieren Sie für NVIDIA-GPUs CUDA:

```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-525

# Install CUDA toolkit
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt update
sudo apt install cuda

# Reboot
sudo reboot

# Verify
nvidia-smi
clinfo
```

---

## PhantomSDR-Plus installieren

### Repository klonen, Skripte ausführbar machen, automatische Installation

```bash
cd ~
git clone --recursive https://github.com/sv1btl/PhantomSDR-Plus
cd PhantomSDR-Plus
chmod +x *.sh
./install.sh
```
**⚠️ WICHTIG:** Nachdem `install.sh` abgeschlossen ist, **starten Sie Ihr Terminal neu**, bevor Sie fortfahren.

### 4. Option B: manuelle Installation

Falls Sie die manuelle Installation bevorzugen oder die automatische fehlschlägt:

#### Backend bauen

```bash
# Clean any previous builds, Configure build with optimization, Compile
rm -rf build
meson setup build --buildtype=release --optimization=3
meson compile -C build

# Verify binary was created
ls -lh build/spectrumserver
```

#### Frontend bauen

```bash
cd frontend

# Install dependencies, Fix any vulnerabilities, Build the frontend
npm install
npm audit fix
npm run build

# Return to project root
cd ..
```

### Installation überprüfen

```bash
# Check if binary exists
ls -lh build/spectrumserver

# Check if frontend was built
ls -lh frontend/dist/

# List important files
ls -lh *.sh *.toml
```

---

## Opus-Audiocodec installieren

Opus bietet gegenüber FLAC bessere Tonqualität und geringere Latenz.

### 1. Systembibliothek libopus installieren

```bash
sudo apt-get update
sudo apt-get install -y libopus0 libopus-dev
```

### 2. Opus-Decoder für das Frontend installieren

```bash
cd PhantomSDR-Plus/frontend

# Install npm dependencies if not already done, Install Opus WASM decoder, Fix any vulnerabilities, Rebuild frontend
npm install
npm install @wasm-audio-decoders/opus-ml
npm audit fix
npm run build

# Return to project root
cd ..
```

### 3. Opus-Installation überprüfen

```bash
# Check if Opus system library is installed
pkg-config --modversion opus

# Check if Opus npm package is installed
cd frontend
npm list @wasm-audio-decoders/opus-ml
cd ..
```

---

## Autorun-Spot-Reporter (FT8/FT4/WSPR)

PhantomSDR-Plus bringt einen optionalen **Autorun-Spot-Reporter** mit (im Verzeichnis
`autorun/`). Er dekodiert FT8/FT4/WSPR serverseitig direkt vom Empfänger und lädt die Spots
zu den Reporting-Netzwerken hoch:

- **FT8 / FT4 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

Er wird vollständig über den Reiter **Admin-Panel → „Spot Reporting"** gesteuert, und
**das Reporting ist standardmäßig AUS** — es wird nichts gesendet oder hochgeladen, bis Sie
es dort aktivieren. Der Decoder läuft als eigener Node.js-Daemon und greift den Ton des
Empfängers lokal ab, benötigt also keine zusätzliche HF-Hardware.

### Voraussetzungen

| Voraussetzung | Anmerkungen |
|---------------|-------------|
| **Node.js 22+** | Dieselbe Laufzeitumgebung, die der Frontend-Build ohnehin braucht — im [Node.js-Schritt](#nodejs-und-npm-installieren) installiert. |
| **npm-Pakete `ws` + `cbor-x`** | Werden über `autorun/node_modules` aufgelöst, einen Symlink auf das `node_modules` des Frontends (beide Pakete sind in `frontend/package.json` deklariert). |
| **`util-linux`** (`taskset`) | Die Schaltfläche „Start" im Admin-Bereich bindet den Daemon per `taskset` an die E-Cores. Praktisch auf jeder Distribution vorhanden; die Installer fügen es ausdrücklich hinzu. |
| **Rufzeichen + Locator** | Werden aus `frontend/site_information.json` gelesen (`siteSysop` / `siteGridSquare`), sofern nicht im Admin-Reiter überschrieben. Spots werden unter diesem Rufzeichen hochgeladen. |

> ⚠️ **Melden Sie nur, was Sie tatsächlich empfangen.** Spots werden unter Ihrem Rufzeichen
> in öffentliche Netze hochgeladen — aktivieren Sie nur Bänder/Betriebsarten, die Ihr
> Empfänger wirklich hört, und verwenden Sie Ihren korrekten Locator.

### Automatische Installation

`install.sh` (und die distributionsspezifischen Varianten `install-Deb12.sh`,
`install_arch.sh`, `install_fedora.sh`, `install_opensuse.sh`) erledigen alles für Sie: Sie
installieren Node.js 22 und `util-linux`, führen das `npm install` des Frontends aus und
legen anschließend den Symlink `autorun/node_modules` automatisch an. Weitere Schritte sind
nicht nötig — die Funktion ist einsatzbereit, sobald `install.sh` fertig ist.

### Manuelle Installation

Wenn Sie manuell installiert haben (Option B), legen Sie den Symlink nach dem `npm install`
des Frontends selbst an, damit der Daemon seine Abhängigkeiten auflösen kann:

```bash
cd ~/PhantomSDR-Plus

# 1. Frontend deps must be installed first (ws + cbor-x live there)
cd frontend && npm install && cd ..

# 2. Link the autorun daemon to the frontend's node_modules
ln -sfn ../frontend/node_modules autorun/node_modules

# 3. Ensure taskset is available (Debian/Ubuntu shown; use your package manager)
sudo apt install -y util-linux
```

> **Hinweis:** `autorun/node_modules` wird von git ignoriert, ein frisches `git clone`
> enthält es also nie — der Symlink muss nach jedem sauberen Checkout (neu) angelegt werden.
> Die Installer erledigen das für Sie; der obige Befehl gilt nur für manuelle Einrichtungen.

### Überprüfen

```bash
# The symlink should point at ../frontend/node_modules
ls -l autorun/node_modules

# ws + cbor-x must resolve
ls -d frontend/node_modules/ws frontend/node_modules/cbor-x

# taskset must be on PATH
command -v taskset
```

Öffnen Sie danach das Admin-Panel, wechseln Sie auf den Reiter **Spot Reporting**, tragen
Sie Ihre Identität ein, kreuzen Sie die zu dekodierenden Bänder/Betriebsarten an, aktivieren
Sie die Ziele und drücken Sie **Start**. Ein Abzeichen „📶 REPORTING" erscheint im
Hauptwasserfall, solange das Reporting aktiv ist. (PSK Reporter lädt gebündelt alle
5 Minuten hoch und wsprnet alle 2 Minuten, ein frisch gestarteter Daemon zeigt daher in den
ersten Minuten „0 sent" — das ist normal.)

Danach werden zwei verschiedene Zähler angezeigt, die leicht zu verwechseln sind.
Die Kacheln **SPOTS UPLOADED PER DECODER** zählen nur den aktuellen Lauf,
Stop/Start setzt sie also auf null zurück; die Zahl neben dem Kontrollkästchen
jedes Bands bzw. jeder Betriebsart ist der **Gesamtwert seit Beginn**, gespeichert
in `autorun-totals.json` und damit über Neustarts hinweg erhalten. Beides
beschreibt das [Admin-Panel-Handbuch](ADMIN_PANEL_SETUP.md), ebenso die Seite
**Graphen**, die CPU-Takt, CPU-Last, Temperatur und Nutzer online über 15 Minuten
bis 24 Stunden darstellt.

> **Der Serverport wird automatisch erkannt.** Der Daemon greift direkt auf den
> `[server] port` des spectrumservers zu (Loopback + Token, unter Umgehung des Proxys). Er
> liest diesen Port aus der Konfigurationsdatei, mit der der laufende spectrumserver
> gestartet wurde, und funktioniert damit ohne Konfiguration auf jedem Port — die Zeile
> `[autorun] tap backend: …` in `autorun.log` zeigt, was er ermittelt hat. Lief Ihr Server
> beim Start des Daemons nicht oder haben Sie eine ungewöhnliche Einrichtung, legen Sie ihn
> in `autorun.json` fest:
> ```json
> "server": { "host": "127.0.0.1", "port": 9002 }
> ```
> Ein falscher Port zeigt sich als `504` / `tap closed 1006` in `autorun.log`, wobei
> `decodes` bei 0 stehen bleibt.

---

## Konfiguration

### 1. Konfigurationsdatei auswählen

Wählen Sie die passende Konfigurationsdatei für Ihr SDR:

- `config-rtl.toml` – RTL-SDR-Sticks
- `config-rsp1a.toml` – SDRplay RSP1A
- `config-airspyhf.toml` – Airspy HF+ Discovery
- `config-rx888mk2.toml` – RX888 MK2
- `config.example.hackrf.toml` – HackRF One

In diesem Beispiel verwenden wir den RTL-SDR.

### 2. Konfigurationsdatei bearbeiten

```bash
nano config-rtl.toml
```

#### Wichtige Einstellungen

```toml
[server]
port = 9002                      # Web interface port (or everything else)
html_root = "frontend/dist/"     # Frontend location
otherusers = 1                   # Show other users (1=yes, 0=no)
threads = 2                      # Number of server threads

[websdr]
register_online = true           # Register on sdr-list.xyz (true/false)
name = "Your WebSDR Name"        # Display name
antenna = "Your Antenna Type"    # e.g., "Vertical", "Loop", "Dipole"
grid_locator = "AB12cd"          # Your Maidenhead grid square
hostname = "your.domain.com"     # Your domain or IP address

[input]
sps = 2048000                    # Sample rate (adjust for your coverage)
fft_size = 131072                # FFT size (higher = better resolution)
brightness_offset = -10          # Waterfall brightness adjustment
frequency = 145000000            # Base frequency in Hz (145 MHz for 2m)
signal = "iq"                    # "iq" for complex, "real" for real sampling
fft_threads = 2                  # FFT processing threads
accelerator = "opencl"           # "none", "cuda", or "opencl"
audio_sps = 12000                # Audio sample rate (keep at 12000)
audio_compression = "opus"       # "flac" or "opus"
smeter_offset = -2               # S-meter calibration
waterfall_size = 1024            # Waterfall FFT size
waterfall_compression = "zstd"   # Waterfall compression

[input.driver]
name = "stdin"                   # Input driver
format = "u8"                    # Sample format for RTL-SDR

[input.defaults]
frequency = 145500000            # Default tuning frequency
modulation = "FM"                # Default modulation mode
```

#### Richtwerte für die Abtastrate

| Abdeckung | Abtastrate | FFT-Größe |
|-----------|------------|-----------|
| 2 MHz | 2048000 | 131072 |
| 3.2 MHz | 3200000 | 131072 |
| 10 MHz | 10000000 | 1048576 |
| 30 MHz | 30000000 | 2097152 |
| 60 MHz | 60000000 | 8388608 |

### 3. Standortinformationen konfigurieren

```bash
nano frontend/site-information.json
```

Bearbeiten Sie die folgenden Felder:

```json
{
  "siteSysop": "YourCallsign",
  "siteSysopEmailAddress": "your@email.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "Your City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Computer specifications",
  "siteSoftware": "PhantomSDR-Plus v3.6.1",
  "siteReceiver": "Your SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional information",
  "siteIP": "http://your.domain.com:9002",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

**IARU-Regionen:**
- **1**: Europa, Afrika, Naher Osten, Nordasien
- **2**: Amerika (Nord, Mitte, Süd), Karibik
- **3**: Asien-Pazifik, Ozeanien

### 4. Frequenzmarker anpassen (optional)

```bash
nano markers.json
```

Fügen Sie Ihre bevorzugten Frequenzen, Relaisfunkstellen und Rundfunksender hinzu.

### 5. Startskript bearbeiten

```bash
nano start-rtl.sh
```

Das Startskript ist ein eigenständiger Starter mit Watchdog. Bearbeiten Sie nur den Block
**RECEIVER CONFIGURATION** nahe dem Anfang, damit die Empfängerargumente zu Ihrer
Einrichtung passen:

```bash
# ═══ RECEIVER CONFIGURATION (the only receiver-specific part) ═══
RX_LABEL="RTL-SDR"
RX_COMM="rtl_sdr"                       # process name to monitor/kill
CONFIG="$PHANTOMDIR/config-rtl.toml"    # your .toml
FIFO="$PHANTOMDIR/rtl.fifo"
RX_ARGS="${RX_ARGS:--f 145000000 -s 2048000 -}"   # receiver args (edit these)
```

Parameter innerhalb von `RX_ARGS`:
- `-f 145000000`: Mittenfrequenz (145 MHz)
- `-s 2048000`: Abtastrate (2,048 MSPS)

`CONFIG` verweist auf Ihre `.toml`. Sie müssen sonst **nichts** im Skript ändern — die
Logik für Start/Neustart/Watchdog/Protokollierung ist allgemeingültig. Sie können die
Empfängerargumente auch beim Start überschreiben, ohne die Datei zu bearbeiten:
`RX_ARGS="-f 145000000 -s 2048000 -" ./start-rtl.sh`
(`RX888_ARGS` für `start-rx888mk2.sh`).

---

## Gerätespezifische SDR-Einrichtung

### RTL-SDR

#### RTL-SDR-Werkzeuge installieren

```bash
sudo apt install -y rtl-sdr
```

#### RTL-SDR testen

```bash
rtl_test
```

Drücken Sie Strg+C zum Beenden. Sie sollten Informationen zur Abtastrate sehen.

#### Konfiguration bearbeiten

```bash
nano config-rtl.toml
```

Übliche Einstellungen für den RTL-SDR:
```toml
sps = 2048000
frequency = 145000000
signal = "iq"
format = "u8"
```

### SDRplay RSP1A

#### SoapySDR und SDRplay-Unterstützung installieren

```bash
# Install SoapySDR
sudo apt install -y soapysdr-tools

# Download SDRplay API
cd ~/Downloads
wget https://www.sdrplay.com/software/SDRplay_RSP_API-Linux-3.07.1.run
chmod +x SDRplay_RSP_API-Linux-3.07.1.run
sudo ./SDRplay_RSP_API-Linux-3.07.1.run

# Install SoapySDRPlay
git clone https://github.com/pothosware/SoapySDRPlay.git
cd SoapySDRPlay
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig
```

#### SDRplay testen

```bash
SoapySDRUtil --find="driver=sdrplay"
```

#### Weitere Hinweise

Siehe die mitgelieferte Datei: `instractions-for-rsp1a`

### Airspy HF+

#### Airspy-Werkzeuge installieren

```bash
sudo apt install -y airspy
```

#### Airspy testen

```bash
airspy_info
```

#### Weitere Hinweise

Siehe die mitgelieferte Datei: `instractions-for-airspy`

### RX888 MK2

#### RX888-Werkzeuge installieren

```bash
# Install rx_tools
git clone https://github.com/rxseger/rx_tools.git
cd rx_tools
mkdir build && cd build
cmake ..
make -j4
sudo make install
sudo ldconfig

# Install RX888 firmware and support
# Follow manufacturer instructions
```

#### rx888_stream ohne sudo ausführen (udev-Regeln)

Standardmäßig ist das Cypress-FX3-USB-Gerät des RX-888 nur für root zugänglich, sodass
`rx888_stream` `sudo` bräuchte. Führen Sie das mitgelieferte Hilfsskript einmal aus, um
udev-Regeln zu installieren und sich der Gruppe `plugdev` hinzuzufügen:

```bash
./setup-rx888-udev.sh          # re-runs itself with sudo automatically
```

Es schreibt `/etc/udev/rules.d/99-rx888.rules` für alle drei Cypress-FX3-Produkt-IDs
(`04b4:00f1`/`00f3` Bootloader und `04b4:8613` mit geladener Firmware), lädt udev neu und
legt einen stabilen Symlink `/dev/rx888` an. **Melden Sie sich ab und wieder an** (wegen der
Gruppenänderung) und **stecken Sie das Gerät einmal neu an**; danach laufen `rx888_stream` —
und der Starter `start-rx888mk2.sh` — ohne `sudo`. Das Skript ist idempotent und kann
gefahrlos erneut ausgeführt werden. Für ein anderes Konto:
`RX888_USER=<name> ./setup-rx888-udev.sh`.

#### Konfiguration bearbeiten

```bash
nano config-rx888mk2.toml
```

Übliche Einstellungen für den RX888:
```toml
sps = 60000000
frequency = 0
signal = "real"
format = "s16"
fft_size = 8388608
```

### HackRF One

#### HackRF-Werkzeuge installieren

```bash
sudo apt install -y hackrf
```

#### HackRF testen

```bash
hackrf_info
```

---

## Test und Überprüfung

### 1. Testlauf

```bash
# For RTL-SDR
./start-rtl.sh
```

Damit startet der Server **im Hintergrund** (er löst sich ab und kehrt sofort zurück) und
beginnt, in `logwebsdr.txt` zu protokollieren.

### 2. Auf Fehler prüfen

Das Skript protokolliert seinen Fortschritt in `logwebsdr.txt` — beobachten Sie ihn live:

```bash
tail -f logwebsdr.txt
```

Achten Sie auf:
- ✅ `Starting the initialization script of the PhantomSDR Server`
- ✅ `<receiver> running (PID …)`
- ✅ `Server started normally`
- ❌ `Server … FAILED …` oder `ERROR: receiver binary '…' not found` (korrigieren Sie die
  Empfängerargumente bzw. die `.toml` oder installieren Sie das Empfängerwerkzeug und führen
  Sie das Startskript erneut aus)

### 3. Weboberfläche aufrufen

Öffnen Sie im Browser:
```
http://localhost:9002
```

(Ersetzen Sie die Portnummer durch Ihren konfigurierten Port)

### 4. Funktion überprüfen

- Der Wasserfall sollte angezeigt werden
- Beim Klick auf Signale sollte Ton wiedergegeben werden
- Das S-Meter sollte auf Signale reagieren
- Die Nutzerzahl sollte „1" anzeigen

### 5. Von einem anderen Gerät testen

Von einem anderen Rechner in Ihrem Netzwerk:
```
http://YOUR_SERVER_IP:9002
```

### 6. Ressourcenverbrauch prüfen

```bash
# Monitor CPU usage
htop

# Monitor GPU usage (if OpenCL/CUDA enabled)
nvidia-smi  # For NVIDIA
radeontop   # For AMD

# Monitor network usage
iftop
```

### 7. Server stoppen

Der Server läuft im Hintergrund unter einem Watchdog, **Strg+C stoppt ihn also nicht** (und
der Watchdog würde ihn ohnehin neu starten). Verwenden Sie das gemeinsame Stopp-Skript, das
für jeden Empfänger funktioniert — es beendet zuerst den Watchdog, dann den Empfänger und
`spectrumserver`:

```bash
./stop-websdr.sh
```

---

## Automatischen Start einrichten

### Mit systemd (empfohlen)

#### 1. Service-Datei anlegen

```bash
sudo nano /etc/systemd/system/phantomsdr.service
```

Fügen Sie den folgenden Inhalt ein (Pfade und Benutzer anpassen):

```ini
[Unit]
Description=PhantomSDR-Plus WebSDR Server
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/PhantomSDR-Plus
# Run the watchdog in the FOREGROUND (note the --watchdog flag) so systemd can
# track it. Do NOT use the plain "./start-rtl.sh" here — that form detaches into
# the background and exits, which systemd would treat as the service stopping.
ExecStart=/home/youruser/PhantomSDR-Plus/start-rtl.sh --watchdog
ExecStop=/home/youruser/PhantomSDR-Plus/stop-websdr.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

> Der `--watchdog`-Prozess startet Empfänger und `spectrumserver` bereits selbst neu;
> `Restart=always` ist nur eine Rückfallebene für den seltenen Fall, dass der Watchdog
> selbst beendet wird. Da systemd den Server hier überwacht, können Sie
> `systemctl start/stop/restart` und `journalctl -u phantomsdr -f` verwenden, statt die
> Skripte von Hand auszuführen.

#### 2. Dienst aktivieren und starten

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable phantomsdr.service

# Start service now
sudo systemctl start phantomsdr.service

# Check status
sudo systemctl status phantomsdr.service
```

#### 3. Dienst verwalten

```bash
# Start
sudo systemctl start phantomsdr

# Stop
sudo systemctl stop phantomsdr

# Restart
sudo systemctl restart phantomsdr

# View logs
sudo journalctl -u phantomsdr -f
```

### Mit Screen (Alternative)

> Meist unnötig: `./start-rtl.sh` löst sich bereits in den Hintergrund ab (per `setsid`) und
> läuft nach dem Abmelden mit eigenem Watchdog weiter. Screen ist nur dann praktisch, wenn
> Sie ausdrücklich eine interaktive Sitzung für die Vordergrundform
> `./start-rtl.sh --watchdog` möchten.

#### 1. Screen installieren

```bash
sudo apt install -y screen
```

#### 2. In einer Screen-Sitzung starten

```bash
screen -S phantomsdr
./start-rtl.sh
```

Drücken Sie Strg+A und dann D zum Ablösen.

#### 3. Sitzung wieder aufnehmen

```bash
screen -r phantomsdr
```

---

## Fehlerbehebung

### Build-Fehler

#### Abhängigkeitsprobleme

```bash
# Ubuntu: Install missing dependencies
sudo apt install --fix-broken

# Fedora: Install missing dependencies
sudo dnf install <package-name>
```

#### Meson-Konfiguration schlägt fehl

```bash
# Clean and reconfigure
rm -rf build
meson setup build --buildtype=release
```

### Laufzeitfehler

#### Port bereits belegt

```bash
# Find process using port
sudo lsof -i :9002

# Kill process
sudo kill -9 <PID>
```

#### Zugriff auf das SDR verweigert

```bash
# Add user to plugdev group
sudo usermod -a -G plugdev $USER

# Reload groups (or log out and back in)
newgrp plugdev
```

Bei einem **RX-888 MkII** reicht das allein nicht — das Cypress-FX3-Gerät benötigt zusätzlich
udev-Regeln. Führen Sie das mitgelieferte Hilfsskript aus (es installiert die Regeln *und*
fügt Sie zu `plugdev` hinzu), melden Sie sich dann ab und wieder an und stecken Sie das Gerät
neu an:

```bash
./setup-rx888-udev.sh
```

#### Audioprobleme

```bash
# Try different codec
# Edit config file and change:
audio_compression = "flac"  # or "opus"

# Rebuild
cd frontend && npm run build && cd ..
```

### OpenCL-Probleme

#### clinfo zeigt keine Geräte

```bash
# Verify drivers are loaded
sudo clinfo

# Check OpenCL ICD files
ls /etc/OpenCL/vendors/

# Reinstall drivers (Intel example)
sudo apt remove --purge intel-opencl-icd
sudo apt install intel-opencl-icd
```

#### Keine Leistungsverbesserung

```bash
# Verify OpenCL is enabled in config
accelerator = "opencl"

# Try different device
# Add to config file:
[input.opencl]
device_id = 0  # Try 0, 1, 2, etc.
```

### Netzwerkprobleme

#### Kein Zugriff von anderen Geräten

```bash
# Check firewall
sudo ufw status
sudo ufw allow 9002/tcp

# Or disable firewall temporarily for testing
sudo ufw disable
```

#### Hohe Latenz

```bash
# Reduce waterfall size in config
waterfall_size = 512

# Increase buffer size
buffer_size = 16384

# Use Opus instead of FLAC
audio_compression = "opus"
```

### Probleme mit dem SDR-Gerät

#### RTL-SDR nicht gefunden

```bash
# Check if device is recognized
lsusb | grep Realtek

# Test with rtl_test
rtl_test

# Try blacklisting DVB-T drivers
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo rmmod dvb_usb_rtl28xxu
```

#### SDRplay nicht gefunden

```bash
# Check API installation
systemctl status sdrplay

# Restart API
sudo systemctl restart sdrplay

# Test with SoapySDR
SoapySDRUtil --find
```

---

## Leistungsoptimierung

### CPU-Optimierung

```toml
# Adjust thread counts based on CPU cores
[server]
threads = 4  # Set to number of cores

[input]
fft_threads = 4  # Set to number of cores
```

### Speicheroptimierung

```toml
# Reduce memory usage
[input]
waterfall_size = 512  # Lower value = less memory
fft_size = 65536      # Lower value = less memory
```

### Netzwerkoptimierung

```toml
# Optimize for limited bandwidth
[input]
audio_compression = "opus"  # More efficient than FLAC
waterfall_compression = "zstd"  # Efficient compression
```

---

## PhantomSDR-Plus aktualisieren

### Manuelle Aktualisierung

```bash
cd PhantomSDR-Plus

# Backup your configuration
cp config-rtl.toml config-rtl.toml.backup
cp frontend/site-information.json frontend/site-information.json.backup

# Pull latest changes
git pull origin main
git submodule update --init --recursive

# Rebuild
meson compile -C build
cd frontend && npm install && npm run build && cd ..
```

### Automatisches Update-Skript

Erstellen Sie `update.sh`:

```bash
#!/bin/bash
cd ~/PhantomSDR-Plus
./stop-websdr.sh
git pull origin main
git submodule update --init --recursive
meson compile -C build
cd frontend && npm install && npm run build && cd ..
./start-rtl.sh
```

---

## Sichern und Wiederherstellen

### Zu sichernde Dateien

- Konfigurationsdateien: `*.toml`
- Standortinformationen: `frontend/site-information.json`
- Marker: `markers.json`
- Eigene Skripte: `start-*.sh`, `stop-*.sh`
- Chatverlauf: `chat_history.txt`
- Hintergrundbild: `frontend/src/assets/background.jpg`

### Sicherungsbefehl

```bash
cd ~/PhantomSDR-Plus
tar -czf phantomsdr-backup-$(date +%Y%m%d).tar.gz \
  *.toml \
  *.sh \
  markers.json \
  chat_history.txt \
  frontend/site-information.json \
  frontend/src/assets/background.jpg
```

### Wiederherstellungsbefehl

```bash
tar -xzf phantomsdr-backup-YYYYMMDD.tar.gz
```

---

## Sicherheitsüberlegungen

### Firewall-Konfiguration

```bash
# Allow only necessary ports
sudo ufw allow 9002/tcp
sudo ufw enable
```

### Reverse-Proxy (optional)

Erwägen Sie nginx oder Apache als Reverse-Proxy für:
- SSL-/TLS-Verschlüsselung
- Zuordnung eines Domainnamens
- Lastverteilung
- Zugriffssteuerung

### Nutzerbegrenzung

Bearbeiten Sie `config.toml`:
```toml
[server]
max_users = 100  # Limit concurrent users
```

---

## Hilfe erhalten

### Ressourcen

- **Dokumentation**: diese Anleitung, README.md, USER_GUIDE.md
- **GitHub Issues**: https://github.com/sv1btl/PhantomSDR-Plus/issues
- **Live-Demo**: http://phantomsdr.no-ip.org:8900/

### Probleme melden

Geben Sie beim Melden von Problemen an:
1. Betriebssystem und Version
2. Modell des SDR-Geräts
3. Inhalt der Konfigurationsdatei
4. Fehlermeldungen
5. Systemressourcenverbrauch (CPU, RAM, GPU)

### Unterstützung durch die Gemeinschaft

- Prüfen Sie vorhandene GitHub-Issues, bevor Sie neue anlegen
- Machen Sie ausführliche Angaben zu Ihrer Einrichtung
- Fügen Sie Protokolle und Fehlermeldungen bei
- Bleiben Sie geduldig und respektvoll

---

## Anhang A: vollständige Abhängigkeitsliste

### Paketliste für Ubuntu 24.04

```
build-essential
cmake
pkg-config
meson
libfftw3-dev
libwebsocketpp-dev
libflac++-dev
zlib1g-dev
libzstd-dev
libboost-all-dev
libopus-dev
libliquid-dev
git
util-linux (taskset — for the autorun spot reporter)
psmisc
wget
curl
rtl-sdr (for RTL-SDR)
airspy (for Airspy)
hackrf (for HackRF)
libclfft-dev (for OpenCL)
ocl-icd-opencl-dev (for OpenCL)
clinfo (for OpenCL)
```

---

## Anhang B: Konfigurationsbeispiele

### Beispiel 1: RTL-SDR für VHF/UHF

```toml
[input]
sps = 2048000
frequency = 145000000
signal = "iq"

[input.driver]
format = "u8"

[input.defaults]
frequency = 145500000
modulation = "FM"
```

### Beispiel 2: RX888 für Kurzwelle (0–30 MHz)

```toml
[input]
sps = 60000000
frequency = 0
signal = "real"
fft_size = 8388608

[input.driver]
format = "s16"

[input.defaults]
frequency = 7100000
modulation = "LSB"
```

### Beispiel 3: HackRF für Breitband-FM

```toml
[input]
sps = 10000000
frequency = 100900000
signal = "iq"

[input.driver]
format = "s8"

[input.defaults]
frequency = 100900000
modulation = "WBFM"
```

---

**Installation abgeschlossen! Sie sollten nun einen voll funktionsfähigen PhantomSDR-Plus-Server haben.**

**73 de SV1BTL & SV2AMK**
