#include "client.h"
#include "glaze/glaze.hpp"

Client::Client(connection_hdl hdl, PacketSender &sender, conn_type type)
    : type{type}, hdl{hdl}, sender{sender}, frame_num{0}, mute{false} {}

void PacketSender::send_binary_packet(connection_hdl hdl, const void *data,
                                      size_t size) {
    send_binary_packet(hdl, {{data, size}});
}

void PacketSender::send_text_packet(connection_hdl hdl,
                                    const std::string &data) {
    send_text_packet(hdl, {data});
}

/* clang-format off */
struct window_cmd {
    int l;
    int r;
    std::optional<double> m;
    std::optional<int> level;
};

template <> 
struct glz::meta<window_cmd>
{
    using T = window_cmd;
    static constexpr auto value = object(
        "l", &T::l,
        "r", &T::r,
        "m", &T::m,
        "level", &T::level
    );
};

struct demodulation_cmd {
    std::string demodulation;
};

template <>
struct glz::meta<demodulation_cmd>
{
    using T = demodulation_cmd;
    static constexpr auto value = object(
        "demodulation", &T::demodulation
    );
};

struct userid_cmd {
    std::string userid;
};

template <>
struct glz::meta<userid_cmd>
{
    using T = userid_cmd;
    static constexpr auto value = object(
        "userid", &T::userid
    );
};

// The listener's name/callsign, for /users and the waterfall labels. Sent on
// /audio, the socket a /users row is made from. "locator" is still read (and
// ignored): pages from the 5.3.0 development builds send it, and glaze refuses
// a message with an unknown key.
struct identity_cmd {
    std::string name;
    std::string locator;
};

template <>
struct glz::meta<identity_cmd>
{
    using T = identity_cmd;
    static constexpr auto value = object(
        "name", &T::name,
        "locator", &T::locator
    );
};

// The decoder the listener is running in the page (FT8, DRM, HFDL …; empty
// when none), for /users. Sent on /audio; an older server refuses the
// unknown command, which the page does not mind.
struct decoder_cmd {
    std::string name;
};

template <>
struct glz::meta<decoder_cmd>
{
    using T = decoder_cmd;
    static constexpr auto value = object(
        "name", &T::name
    );
};

// IQ width the listener asks for, in kHz (12, 24 or 48). Kept for the
// session: it takes effect whenever the listener is in IQ.
struct iq_width_cmd {
    int khz;
};

template <>
struct glz::meta<iq_width_cmd>
{
    using T = iq_width_cmd;
    static constexpr auto value = object(
        "khz", &T::khz
    );
};

// The receive-diversity partner the listener's page is combining with
// (type phantom/kiwi/uber/websdr and host[:port]; both empty when off), for
// the admin panel. Sent on /audio; an older server refuses it, harmlessly.
struct diversity_cmd {
    std::string type;
    std::string host;
};

template <>
struct glz::meta<diversity_cmd>
{
    using T = diversity_cmd;
    static constexpr auto value = object(
        "type", &T::type,
        "host", &T::host
    );
};

struct mute_cmd {
    bool mute;
};

template <>
struct glz::meta<mute_cmd>
{
    using T = mute_cmd;
    static constexpr auto value = object(
        "mute", &T::mute
    );
};

struct chat_cmd {
    std::string message;
    std::string username;
};

template <>
struct glz::meta<chat_cmd>
{
    using T = chat_cmd;
    static constexpr auto value = object(
        "message", &T::message,
        "username", &T::username
    );
};

// Noise gate enable command
struct noise_gate_enable_cmd {
    bool enabled;
};

template <>
struct glz::meta<noise_gate_enable_cmd>
{
    using T = noise_gate_enable_cmd;
    static constexpr auto value = object(
        "enabled", &T::enabled
    );
};

// Noise gate preset command
struct noise_gate_preset_cmd {
    std::string preset;
};

template <>
struct glz::meta<noise_gate_preset_cmd>
{
    using T = noise_gate_preset_cmd;
    static constexpr auto value = object(
        "preset", &T::preset
    );
};

// AGC enable command
struct agc_enable_cmd {
    bool enabled;
};

template <>
struct glz::meta<agc_enable_cmd>
{
    using T = agc_enable_cmd;
    static constexpr auto value = object(
        "enabled", &T::enabled
    );
};

// AGC speed command: 0 = Auto (legacy server AGC), 1 = Fast, 2 = Medium,
// 3 = Slow (transceiver-style hang AGC, see AGC::setTrxSpeed).
struct agc_speed_cmd {
    int speed;
};

template <>
struct glz::meta<agc_speed_cmd>
{
    using T = agc_speed_cmd;
    static constexpr auto value = object(
        "speed", &T::speed
    );
};

// Codec capability command: the client advertises which codecs it can decode.
// Currently only Opus support is negotiable; when false the server keeps this
// client on FLAC even for C-QUAM (see AudioClient::set_am_stereo).
struct codec_caps_cmd {
    bool opus;
};

template <>
struct glz::meta<codec_caps_cmd>
{
    using T = codec_caps_cmd;
    static constexpr auto value = object(
        "opus", &T::opus
    );
};

// Runtime codec request. Used by the internal autorun loopback client to ask
// for raw PCM ("pcm"); the browser never sends this, so normal clients are
// unaffected.
struct set_codec_cmd {
    std::string codec;
};

template <>
struct glz::meta<set_codec_cmd>
{
    using T = set_codec_cmd;
    static constexpr auto value = object(
        "codec", &T::codec
    );
};

using msg_variant = std::variant<window_cmd, demodulation_cmd, userid_cmd, mute_cmd, chat_cmd,
                                  noise_gate_enable_cmd, noise_gate_preset_cmd, agc_enable_cmd,
                                  codec_caps_cmd, set_codec_cmd, agc_speed_cmd, identity_cmd,
                                  decoder_cmd, diversity_cmd, iq_width_cmd>;

template <>
struct glz::meta<msg_variant>
{
    static constexpr std::string_view tag = "cmd";
    static constexpr auto ids = std::array{
        "window",
        "demodulation",
        "userid",
        "mute",
        "chat",
        "noise_gate_enable",
        "noise_gate_preset",
        "agc_enable",
        "codec_caps",
        "set_codec",
        "agc_speed",
        "identity",
        "decoder",
        "diversity",
        "iq_width"
    };
};

template<class... Ts>
struct overloaded : Ts... { using Ts::operator()...; };
/* clang-format on */

void Client::on_message(std::string &msg) {
    msg_variant msg_parsed;
    auto ec = glz::read_json(msg_parsed, msg);
    if (ec) {
        return;
    }

    std::visit(
        overloaded{
            [&](window_cmd &cmd) {
                on_window_message(cmd.l, cmd.m, cmd.r, cmd.level);
            },
            [&](demodulation_cmd &cmd) {
                on_demodulation_message(cmd.demodulation);
            },
            [&](userid_cmd &cmd) {
                on_userid_message(cmd.userid);
            },
            [&](chat_cmd &cmd) {
                on_chat_message(hdl, cmd.username, cmd.message);
            },
            [&](mute_cmd &cmd) {
                on_mute(cmd.mute);
            },
            [&](noise_gate_enable_cmd &cmd) {
                on_noise_gate_enable_message(cmd.enabled);
            },
            [&](noise_gate_preset_cmd &cmd) {
                on_noise_gate_preset_message(cmd.preset);
            },
            [&](agc_enable_cmd &cmd) {
                on_agc_enable_message(cmd.enabled);
            },
            [&](codec_caps_cmd &cmd) {
                on_codec_caps_message(cmd.opus);
            },
            [&](set_codec_cmd &cmd) {
                on_set_codec_message(cmd.codec);
            },
            [&](agc_speed_cmd &cmd) {
                on_agc_speed_message(cmd.speed);
            },
            [&](identity_cmd &cmd) {
                on_identity_message(cmd.name);
            },
            [&](decoder_cmd &cmd) {
                on_decoder_message(cmd.name);
            },
            [&](diversity_cmd &cmd) {
                on_diversity_message(cmd.type, cmd.host);
            },
            [&](iq_width_cmd &cmd) {
                on_iq_width_message(cmd.khz);
            }
        },
        msg_parsed);
}

void Client::on_window_message(int, std::optional<double> &, int,
                               std::optional<int> &) {}
void Client::on_demodulation_message(std::string &) {}
void Client::on_codec_caps_message(bool) {}
void Client::on_set_codec_message(std::string &) {}
void Client::on_chat_message(connection_hdl, std::string &, std::string &) {}
void Client::on_userid_message(std::string &userid) {
    // Used for correlating between signal and waterfall sockets
    user_id = userid.substr(0, 32);
}
void Client::on_identity_message(std::string &) {}
void Client::on_decoder_message(std::string &) {}
void Client::on_diversity_message(std::string &, std::string &) {}
void Client::on_iq_width_message(int) {}
void Client::on_mute(bool mute) { this->mute = mute; }

// Default empty implementations for noise gate and AGC (AudioClient will override)
void Client::on_noise_gate_enable_message(bool) {}
void Client::on_noise_gate_preset_message(std::string &) {}
void Client::on_agc_enable_message(bool) {}
void Client::on_agc_speed_message(int) {}