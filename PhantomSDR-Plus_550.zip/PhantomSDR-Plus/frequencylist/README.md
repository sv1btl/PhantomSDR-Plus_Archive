# How to update markers.json

- Unzip the file "frequencylist.zip" into the folder cd $HOME/PhantomSDR-Plus/frequencylist/.
- Modify the file "mymarkers.json" with your own markers.
- download from https://new.hfcc.org/data/ the newest list, at the buttom of page, current: **b26allx2.zip** - b26 Operational Schedule - **Last updated on 23-oct-2026** 
- unzip the downloaded file from the database into the folder frequencylist.
- ensure that "B26all00.TXT" and "broadcas.txt" are located in the "frequencylist" folder
- modify "update-markers.sh" line 5 to your personal full path -->  "cd $HOME/PhantomSDR-Plus/frequencylist/". Make this file executable.
- **NB** don't use '~ ' if you use the cron service e.g. use cd home/user/PhantomSDR-Plus/frequencylist/
- run update script with "update-markers.sh" manually or let it run automaticly by a cron job (for example update every 15 minutes a hour 'crontab -e' and enter: */15 * * * * /usr/bin/bash /home/$USER/PhantomSDR-Plus/frequencylist/update-markers.sh >> /home/$USER/frequencylist.log 2>&1') where $USER is the user linux account.
- The script will generate the "shortwavestations.json" based on the data given from the database and finaly will merge it with "mymarkers.json", so to create the final "markers.json" in the root PhantomSDR-Plus folder).
- **NB** Your markers in mymarkers.json will overwrite and replace the duplicate markers from shortwavestations.json in the final markers.json file which will be generated. The given mymarkers.json contains some demo markers, you can replace them with your own!
- **Decoder markers:** "decodermarkers.json" ships with PhantomSDR-Plus and is merged in after your mymarkers.json: HFDL, DRM, FAX, NAVTEX, SITOR, RTTY, PSK31, Olivia, SSTV, the WSJT modes, RADE and CW (`MORSE`) frequencies, and clicking one starts its decoder. Every update replaces it, so do not edit it — a marker of yours on the same frequency always wins.
- **EiBi window:** `update-markers.sh` also runs `update-eibi.sh`, which fetches the EiBi schedule (http://www.eibispace.de/dx/) at most once a day for the EiBi window of the receiver page, and `generate-eibi.py`, which turns it into `frontend/public/eibi.json`. It does not change your markers. To fetch it at once: `./update-eibi.sh --force`. Every HFCC entry in `markers.json` is tagged `"source": "hfcc"`, so the EiBi window can hide them (**Hide HFCC markers**).

---

# Deutsch — markers.json aktualisieren

- Entpacken Sie die Datei "frequencylist.zip" in den Ordner $HOME/PhantomSDR-Plus/frequencylist/.
- Tragen Sie Ihre eigenen Marker in die Datei "mymarkers.json" ein.
- Laden Sie von https://new.hfcc.org/data/ die neueste Liste herunter — am Ende der Seite, derzeit: **b26allx2.zip** - b26 Operational Schedule - **zuletzt aktualisiert am 23.10.2026**
- Entpacken Sie die heruntergeladene Datenbankdatei in den Ordner frequencylist.
- Stellen Sie sicher, dass "B26all00.TXT" und "broadcas.txt" im Ordner "frequencylist" liegen.
- Ändern Sie in "update-markers.sh" die Zeile 5 auf Ihren vollständigen Pfad --> "cd $HOME/PhantomSDR-Plus/frequencylist/" und machen Sie die Datei ausführbar.
- **Achtung:** Verwenden Sie kein '~', wenn Sie den cron-Dienst nutzen, sondern z. B. cd /home/user/PhantomSDR-Plus/frequencylist/
- Führen Sie "update-markers.sh" von Hand aus oder lassen Sie es per cron-Job automatisch laufen (zum Beispiel alle 15 Minuten: 'crontab -e' und dort */15 * * * * /usr/bin/bash /home/$USER/PhantomSDR-Plus/frequencylist/update-markers.sh >> /home/$USER/frequencylist.log 2>&1 eintragen), wobei $USER Ihr Linux-Benutzerkonto ist.
- Das Skript erzeugt aus den Daten der Datenbank die Datei "shortwavestations.json" und führt sie anschließend mit "mymarkers.json" zusammen, um im Stammverzeichnis von PhantomSDR-Plus die endgültige "markers.json" zu erstellen.
- **Achtung:** Ihre Marker aus mymarkers.json überschreiben in der erzeugten markers.json die doppelten Marker aus shortwavestations.json. Die mitgelieferte mymarkers.json enthält einige Beispielmarker, die Sie durch Ihre eigenen ersetzen können!
- **Decoder-Marker:** "decodermarkers.json" wird mit PhantomSDR-Plus ausgeliefert und nach Ihrer mymarkers.json eingemischt: HFDL-, DRM-, FAX-, NAVTEX-, SITOR-, RTTY-, PSK31-, Olivia-, SSTV-, WSJT-, RADE- und CW-Frequenzen (`MORSE`); ein Klick darauf startet den Decoder. Jedes Update ersetzt die Datei, bearbeiten Sie sie also nicht — ein eigener Marker auf derselben Frequenz hat immer Vorrang.
- **EiBi-Fenster:** `update-markers.sh` ruft auch `update-eibi.sh` auf, das höchstens einmal am Tag den EiBi-Sendeplan (http://www.eibispace.de/dx/) für das EiBi-Fenster der Empfängerseite holt, und `generate-eibi.py`, das daraus `frontend/public/eibi.json` macht. Ihre Marker ändert das nicht. Sofort holen: `./update-eibi.sh --force`. Jeder HFCC-Eintrag in `markers.json` trägt `"source": "hfcc"`, damit das EiBi-Fenster sie ausblenden kann (**Hide HFCC markers**).

---

# Ελληνικά — Πώς να ενημερώσετε το markers.json

- Αποσυμπιέστε το αρχείο "frequencylist.zip" στον φάκελο $HOME/PhantomSDR-Plus/frequencylist/.
- Τροποποιήστε το αρχείο "mymarkers.json" με τους δικούς σας δείκτες.
- Κατεβάστε από το https://new.hfcc.org/data/ την πιο πρόσφατη λίστα, στο κάτω μέρος της σελίδας, τρέχουσα: **b26allx2.zip** - b26 Operational Schedule - **τελευταία ενημέρωση 23-Οκτ-2026**
- Αποσυμπιέστε το αρχείο που κατεβάσατε από τη βάση δεδομένων στον φάκελο frequencylist.
- Βεβαιωθείτε ότι τα "B26all00.TXT" και "broadcas.txt" βρίσκονται στον φάκελο "frequencylist".
- Τροποποιήστε τη γραμμή 5 του "update-markers.sh" με τη δική σας πλήρη διαδρομή --> "cd $HOME/PhantomSDR-Plus/frequencylist/" και κάντε το αρχείο εκτελέσιμο.
- **ΠΡΟΣΟΧΗ:** μη χρησιμοποιείτε '~' αν χρησιμοποιείτε την υπηρεσία cron· γράψτε π.χ. cd /home/user/PhantomSDR-Plus/frequencylist/
- Εκτελέστε το "update-markers.sh" χειροκίνητα ή αφήστε το να τρέχει αυτόματα με cron (για παράδειγμα κάθε 15 λεπτά: 'crontab -e' και εισαγωγή */15 * * * * /usr/bin/bash /home/$USER/PhantomSDR-Plus/frequencylist/update-markers.sh >> /home/$USER/frequencylist.log 2>&1), όπου $USER είναι ο λογαριασμός χρήστη Linux.
- Το script δημιουργεί το "shortwavestations.json" από τα δεδομένα της βάσης και τελικά το συγχωνεύει με το "mymarkers.json", ώστε να παραχθεί το τελικό "markers.json" στον ριζικό φάκελο του PhantomSDR-Plus.
- **ΠΡΟΣΟΧΗ:** Οι δικοί σας δείκτες στο mymarkers.json αντικαθιστούν τους διπλότυπους δείκτες από το shortwavestations.json στο τελικό markers.json που θα δημιουργηθεί. Το mymarkers.json που δίνεται περιέχει μερικούς δείκτες επίδειξης — μπορείτε να τους αντικαταστήσετε με δικούς σας!
- **Δείκτες αποκωδικοποιητών:** το "decodermarkers.json" έρχεται με το PhantomSDR-Plus και συγχωνεύεται μετά το δικό σας mymarkers.json: συχνότητες HFDL, DRM, FAX, NAVTEX, SITOR, RTTY, PSK31, Olivia, SSTV, των WSJT, RADE και CW (`MORSE`), και το πάτημά τους ξεκινά τον αποκωδικοποιητή. Κάθε ενημέρωση το αντικαθιστά, οπότε μην το επεξεργάζεστε — ένας δικός σας δείκτης στην ίδια συχνότητα υπερισχύει πάντα.
- **Παράθυρο EiBi:** το `update-markers.sh` τρέχει επίσης το `update-eibi.sh`, που φέρνει το πρόγραμμα EiBi (http://www.eibispace.de/dx/) το πολύ μία φορά τη μέρα για το παράθυρο EiBi της σελίδας του δέκτη, και το `generate-eibi.py`, που το μετατρέπει σε `frontend/public/eibi.json`. Δεν αλλάζει τους δείκτες σας. Για λήψη αμέσως: `./update-eibi.sh --force`. Κάθε εγγραφή HFCC στο `markers.json` έχει `"source": "hfcc"`, ώστε το παράθυρο EiBi να μπορεί να τις κρύψει (**Hide HFCC markers**).

---

# Español — Cómo actualizar markers.json

- Descomprima el archivo "frequencylist.zip" en la carpeta $HOME/PhantomSDR-Plus/frequencylist/.
- Modifique el archivo "mymarkers.json" con sus propios marcadores.
- Descargue de https://new.hfcc.org/data/ la lista más reciente, al final de la página, actualmente: **b26allx2.zip** - b26 Operational Schedule - **última actualización 23-oct-2026**
- Descomprima en la carpeta frequencylist el archivo descargado de la base de datos.
- Asegúrese de que "B26all00.TXT" y "broadcas.txt" estén en la carpeta "frequencylist".
- Modifique la línea 5 de "update-markers.sh" con su ruta completa --> "cd $HOME/PhantomSDR-Plus/frequencylist/" y dé permisos de ejecución al archivo.
- **NOTA:** no use '~' si emplea el servicio cron; escriba por ejemplo cd /home/user/PhantomSDR-Plus/frequencylist/
- Ejecute "update-markers.sh" a mano o deje que se ejecute automáticamente mediante una tarea cron (por ejemplo cada 15 minutos: 'crontab -e' e introduzca */15 * * * * /usr/bin/bash /home/$USER/PhantomSDR-Plus/frequencylist/update-markers.sh >> /home/$USER/frequencylist.log 2>&1), donde $USER es su cuenta de usuario de Linux.
- El script genera "shortwavestations.json" a partir de los datos de la base de datos y finalmente lo combina con "mymarkers.json" para crear el "markers.json" definitivo en la carpeta raíz de PhantomSDR-Plus.
- **NOTA:** Sus marcadores de mymarkers.json sobrescriben y reemplazan los marcadores duplicados de shortwavestations.json en el markers.json final que se genera. El mymarkers.json incluido contiene algunos marcadores de ejemplo, ¡puede sustituirlos por los suyos!
- **Marcadores de decodificadores:** "decodermarkers.json" viene con PhantomSDR-Plus y se combina después de su mymarkers.json: frecuencias de HFDL, DRM, FAX, NAVTEX, SITOR, RTTY, PSK31, Olivia, SSTV, los modos WSJT, RADE y CW (`MORSE`); al pulsar uno se inicia su decodificador. Cada actualización lo reemplaza, así que no lo edite — un marcador suyo en la misma frecuencia siempre prevalece.
- **Ventana EiBi:** `update-markers.sh` también ejecuta `update-eibi.sh`, que trae el horario EiBi (http://www.eibispace.de/dx/) como mucho una vez al día para la ventana EiBi de la página del receptor, y `generate-eibi.py`, que lo convierte en `frontend/public/eibi.json`. No cambia sus marcadores. Para traerlo enseguida: `./update-eibi.sh --force`. Cada entrada HFCC de `markers.json` lleva `"source": "hfcc"`, para que la ventana EiBi pueda ocultarlas (**Hide HFCC markers**).

---

# Français — Comment mettre à jour markers.json

- Décompressez le fichier "frequencylist.zip" dans le dossier $HOME/PhantomSDR-Plus/frequencylist/.
- Modifiez le fichier "mymarkers.json" avec vos propres repères.
- Téléchargez sur https://new.hfcc.org/data/ la liste la plus récente, en bas de la page, actuellement : **b26allx2.zip** - b26 Operational Schedule - **dernière mise à jour le 23/10/2026**
- Décompressez dans le dossier frequencylist le fichier téléchargé depuis la base de données.
- Vérifiez que "B26all00.TXT" et "broadcas.txt" se trouvent bien dans le dossier "frequencylist".
- Modifiez la ligne 5 de "update-markers.sh" avec votre chemin complet --> "cd $HOME/PhantomSDR-Plus/frequencylist/" et rendez le fichier exécutable.
- **NB :** n'utilisez pas '~' si vous passez par le service cron ; écrivez par exemple cd /home/user/PhantomSDR-Plus/frequencylist/
- Lancez "update-markers.sh" à la main ou laissez-le tourner automatiquement via une tâche cron (par exemple toutes les 15 minutes : 'crontab -e' puis */15 * * * * /usr/bin/bash /home/$USER/PhantomSDR-Plus/frequencylist/update-markers.sh >> /home/$USER/frequencylist.log 2>&1), où $USER est votre compte utilisateur Linux.
- Le script génère "shortwavestations.json" à partir des données de la base, puis le fusionne avec "mymarkers.json" afin de créer le "markers.json" final à la racine du dossier PhantomSDR-Plus.
- **NB :** vos repères de mymarkers.json écrasent et remplacent les repères en double venant de shortwavestations.json dans le markers.json final qui sera généré. Le mymarkers.json fourni contient quelques repères de démonstration, que vous pouvez remplacer par les vôtres !
- **Repères des décodeurs :** « decodermarkers.json » est livré avec PhantomSDR-Plus et fusionné après votre mymarkers.json : fréquences HFDL, DRM, FAX, NAVTEX, SITOR, RTTY, PSK31, Olivia, SSTV, des modes WSJT, RADE et CW (`MORSE`) ; un clic lance le décodeur. Chaque mise à jour le remplace, ne le modifiez donc pas — un repère à vous sur la même fréquence l’emporte toujours.
- **Fenêtre EiBi :** `update-markers.sh` lance aussi `update-eibi.sh`, qui récupère la grille EiBi (http://www.eibispace.de/dx/) au plus une fois par jour pour la fenêtre EiBi de la page du récepteur, et `generate-eibi.py`, qui la transforme en `frontend/public/eibi.json`. Vos marqueurs ne changent pas. Pour la récupérer tout de suite : `./update-eibi.sh --force`. Chaque entrée HFCC de `markers.json` porte `"source": "hfcc"`, pour que la fenêtre EiBi puisse les masquer (**Hide HFCC markers**).

---

# Hrvatski — Kako ažurirati markers.json

- Raspakirajte datoteku "frequencylist.zip" u mapu $HOME/PhantomSDR-Plus/frequencylist/.
- U datoteci "mymarkers.json" upišite vlastite oznake.
- S adrese https://new.hfcc.org/data/ preuzmite najnoviji popis, na dnu stranice, trenutno: **b26allx2.zip** - b26 Operational Schedule - **posljednje ažuriranje 23.10.2026.**
- Preuzetu datoteku iz baze raspakirajte u mapu frequencylist.
- Provjerite nalaze li se "B26all00.TXT" i "broadcas.txt" u mapi "frequencylist".
- U datoteci "update-markers.sh" izmijenite 5. redak na svoju punu putanju --> "cd $HOME/PhantomSDR-Plus/frequencylist/" i učinite datoteku izvršnom.
- **NAPOMENA:** ne koristite '~' ako se služite cron uslugom; upišite npr. cd /home/user/PhantomSDR-Plus/frequencylist/
- Pokrenite "update-markers.sh" ručno ili ga pustite da se izvodi automatski cron poslom (na primjer svakih 15 minuta: 'crontab -e' pa unesite */15 * * * * /usr/bin/bash /home/$USER/PhantomSDR-Plus/frequencylist/update-markers.sh >> /home/$USER/frequencylist.log 2>&1), pri čemu je $USER vaš Linux korisnički račun.
- Skripta iz podataka baze stvara "shortwavestations.json" i naposljetku ga spaja s "mymarkers.json" kako bi u korijenskoj mapi PhantomSDR-Plusa nastao konačni "markers.json".
- **NAPOMENA:** Vaše oznake iz mymarkers.json u konačnom markers.json prepisuju i zamjenjuju dvostruke oznake iz shortwavestations.json. Priloženi mymarkers.json sadrži nekoliko oglednih oznaka koje možete zamijeniti vlastitima!
- **Oznake dekodera:** "decodermarkers.json" dolazi s PhantomSDR-Plusom i spaja se nakon vašeg mymarkers.json: frekvencije za HFDL, DRM, FAX, NAVTEX, SITOR, RTTY, PSK31, Olivia, SSTV, WSJT načine, RADE i CW (`MORSE`); klik na oznaku pokreće dekoder. Svako ažuriranje ga zamjenjuje, pa ga ne uređujte — vaša oznaka na istoj frekvenciji uvijek ima prednost.
- **EiBi prozor:** `update-markers.sh` pokreće i `update-eibi.sh`, koji najviše jednom dnevno dohvaća EiBi raspored (http://www.eibispace.de/dx/) za EiBi prozor stranice prijemnika, te `generate-eibi.py`, koji ga pretvara u `frontend/public/eibi.json`. Vaše markere ne mijenja. Za odmah: `./update-eibi.sh --force`. Svaki HFCC unos u `markers.json` nosi `"source": "hfcc"`, kako bi ih EiBi prozor mogao sakriti (**Hide HFCC markers**).

---

# Русский — Как обновить markers.json

- Распакуйте файл "frequencylist.zip" в папку $HOME/PhantomSDR-Plus/frequencylist/.
- Впишите свои метки в файл "mymarkers.json".
- Скачайте с https://new.hfcc.org/data/ самый свежий список, внизу страницы, сейчас это: **b26allx2.zip** - b26 Operational Schedule - **последнее обновление 23.10.2026**
- Распакуйте скачанный файл базы в папку frequencylist.
- Убедитесь, что "B26all00.TXT" и "broadcas.txt" находятся в папке "frequencylist".
- В файле "update-markers.sh" измените строку 5 на свой полный путь --> "cd $HOME/PhantomSDR-Plus/frequencylist/" и сделайте файл исполняемым.
- **ВНИМАНИЕ:** не используйте '~', если работаете через службу cron; пишите, например, cd /home/user/PhantomSDR-Plus/frequencylist/
- Запускайте "update-markers.sh" вручную либо оставьте его выполняться автоматически заданием cron (например, каждые 15 минут: 'crontab -e' и строка */15 * * * * /usr/bin/bash /home/$USER/PhantomSDR-Plus/frequencylist/update-markers.sh >> /home/$USER/frequencylist.log 2>&1), где $USER — ваша учётная запись Linux.
- Скрипт создаёт "shortwavestations.json" по данным из базы и затем объединяет его с "mymarkers.json", чтобы в корневой папке PhantomSDR-Plus получился итоговый "markers.json".
- **ВНИМАНИЕ:** Ваши метки из mymarkers.json перезаписывают и заменяют дублирующиеся метки из shortwavestations.json в итоговом markers.json. В поставляемом mymarkers.json есть несколько демонстрационных меток — замените их своими!
- **Метки декодеров:** "decodermarkers.json" поставляется с PhantomSDR-Plus и добавляется после вашего mymarkers.json: частоты HFDL, DRM, FAX, NAVTEX, SITOR, RTTY, PSK31, Olivia, SSTV, режимов WSJT, RADE и CW (`MORSE`); щелчок по метке запускает декодер. Каждое обновление заменяет этот файл, поэтому не редактируйте его — ваша метка на той же частоте всегда имеет приоритет.
- **Окно EiBi:** `update-markers.sh` также запускает `update-eibi.sh`, который не чаще раза в день загружает расписание EiBi (http://www.eibispace.de/dx/) для окна EiBi на странице приёмника, и `generate-eibi.py`, который превращает его в `frontend/public/eibi.json`. Ваши маркеры это не меняет. Загрузить сразу: `./update-eibi.sh --force`. Каждая запись HFCC в `markers.json` помечена `"source": "hfcc"`, чтобы окно EiBi могло их скрыть (**Hide HFCC markers**).
