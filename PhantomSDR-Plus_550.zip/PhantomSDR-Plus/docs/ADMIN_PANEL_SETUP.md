# PhantomSDR-Plus Admin Panel — Setup Guide

> ⚠️ **Security notice:** Keep this admin panel on your home network or behind a VPN. Public exposure of the admin port is not recommended without proper authentication hardening.

---

## Overview

The admin panel consists of two Python services:

| Service | File | Role |
|---|---|---|
| Admin panel | `admin_server.py` | Flask web app, binds to `127.0.0.1` (internal only) |
| Reverse proxy | `proxy.py` | Exposes both the SDR and the admin panel on a single public port |

Both services read their configuration from `admin_config.json`, which is written by `setup_admin.sh`. **Do not edit port constants directly in the Python files** — all ports and the SDR host IP are stored in `admin_config.json`.

---

## What the admin panel gives you

- **Dashboard** — live server status, CPU/RAM, top processes, recent log output, terminal
- **Config Editor** — view, edit and save any `.toml`, `.sh`, `.json`, `.h`, `.cpp` file in your installation
- **Log Viewer** — tail any log file in real time (SDR server, admin panel, RADE, crash, autorun, proxy)
- **Markers** — view and edit frequency markers
- **Chat History** — view the WebSDR chat log, clear it entirely, or delete individual messages without restarting the server
- **Waterfall Message** — broadcast a persistent banner message to all connected users, visible on the waterfall display in real time
- **Users** — live list of connected listeners with their name or callsign, location and IP address, tuned frequency, mode and duration, a ⚡ Kick button and a ⛔ Ban ▾ menu (8, 16 or 24 hours), and a map of where they are
- **Chat message deletion** — 🗑 Delete button that removes that single message from the log immediately
- **Waterfall broadcast messages** —  lets you push a persistent text banner to every connected user's waterfall
- **Spot Reporting** — start/stop the autorun FT8/FT4/JS8/WSPR decoder, pick bands/modes and the UTC hours each one runs, start it automatically after a reboot, and report spots to PSK Reporter / wsprnet (OFF by default), with two counters: per-decoder tiles for the current run and an all-time total beside each band/mode checkbox
- **Graphs** — CPU frequency, CPU load, CPU temperature and connected users plotted over the last 15 minutes / 1 hour / 4 hours / 12 hours / 24 hours
- **Thermal Guard** — stops the server if the CPU overheats and restarts it once cool, with thresholds derived from your own CPU; works with any start/stop method, and ships in log-only mode so it does nothing until you enable it
- **Settings** — change admin password, SDR base directory, process name and the spectrumserver port (with the listener port shown under it); run the default start or stop script with ▶ START / ■ STOP; an **HTTPS** card that checks https, or guides you through turning it on
- **Receivers** — every receiver of the station with the range it covers, its bandwidth, its gain and whether it is on air; change a receiver's settings and gain, stop or start, rename or delete one receiver, and prepare a new receiver for `add-receiver.sh`
- **System Health** (Dashboard) — every receiver on air or off with its uptime, free disk space and the size of each log folder, the last `crash.log` entry and the recent alerts
- **DRM** (Dashboard) — the DRM decoder: whether its helper runs, how many decoders are in use, and who is decoding which frequency (station, codec, WMER); switch DRM on or off and set the maximum number of DRM listeners (1–20), applied within 5 s without a restart. The Users page shows those listeners as DRM
- **Receive Diversity** (Dashboard) — every listener combining your receiver with another one by receive diversity: name and city, frequency and mode, the partner (PhantomSDR+, KiwiSDR, UberSDR or WebSDR) and its address. Only the admin panel sees it, never the public Users list
- **Visitors** — private visitor statistics for 1 to 31 days: visitors, sessions, listening hours, most at the same time, per day, busiest hours, countries, and the addresses with the most sessions at once, with ⛔ Ban ▾
- **Alerts** — an email and/or a Telegram message when a receiver goes off the air, comes back or is restarted, the thermal guard changes stage, or `crash.log` gets a new entry
- **Backup & restore** — one zip with the station's own settings, and a restore that copies every file it replaces to `admin-backups/` first
- **Themes** — Phosphor green, Amber display, Metal panel, Modern dark, Light, and Auto (light by day, dark at night), chosen with **THEME** in the top bar of every page

---

## Requirements

- PhantomSDR-Plus already installed and running
- Python 3.8+

> [!NOTE]
> **The installer normally does this for you.** `./install.sh` — and each of the four distro installers, both RADE installers and the stats-server installer — sets the admin panel up by default, installing `pip` first with the system's own package manager if it is missing. This page is what happens during that step, and what to do if you skipped it or want to change something afterwards.

The panel's Python libraries (`flask`, `psutil`, `aiohttp`, `tomli-w`) are installed by `setup_admin.sh`; it prints the exact command to run by hand if that ever fails.

---

## Step 1 — Run the setup script

```bash
./setup_admin.sh
```

> **Without the admin panel:** `bash setup_admin.sh --proxy-only` installs only `proxy.py` on the public port, with the ports from `station.conf`. It is what the installer does when you decline the panel, because the proxy is what listeners — and `/rade`, `/stats`, `/relay` — reach.

The script will:

1. Check that Python 3 is installed
2. Verify `admin_server.py` and `manage_admin.sh` are present
3. Record `127.0.0.1` as `sdr_host` in config (see [The `sdr_host` setting](#the-sdr_host-setting))
4. Ask for three port numbers. Each offers a default in brackets that a bare Enter
accepts, so a normal setup is three keystrokes:
   - **Spectrumserver port** — the port your SDR server listens on (default `9001`,
     which is what every `config-*.toml` in the repository ships with)
   - **Admin panel internal port** — where `admin_server.py` binds locally (default `9010`)
   - **Proxy public port** — the single external port that combines SDR + admin (default `8902`)
   On a station set up with the station questions (`configure-station.sh`), the three defaults are that station's own ports from `station.conf` — 9001, 9010 and 9000 — so Enter is right, and the start script is already preselected.

After setup, open your browser via the proxy:
```
http://YOUR_SERVER_IP:<proxy_port>/admin
```
Default password: **`admin`**

> ⚠️ **Change the password immediately** — on first login a one-step wizard asks only for a new password. The folder and the ports are already in `admin_config.json` (written by `setup_admin.sh`, which the installer runs); the wizard shows them for reference and leaves them untouched. Change them later in Settings, or with `./configure-station.sh`.

---

## Step 2 — Start / Stop / Restart

There are two ways to run the panel and the proxy. **Pick one and stay with it** — the warning at the end of this section explains what happens if you mix them.

> **Method B (systemd) is strongly recommended** wherever systemd is available. The CPU over-temperature guard runs inside the panel, so a panel that dies at 03:00 or a machine that reboots leaves the CPU unprotected until someone starts it again by hand. `setup_admin.sh` now offers the units by default. Use Method A when there is no systemd — containers, WSL1, OpenRC/sysvinit — or when you deliberately want to supervise things yourself.

### Method A — `manage_admin.sh` (no root, nothing installed)

```bash
./manage_admin.sh start      # start admin panel and proxy
./manage_admin.sh stop       # stop both
./manage_admin.sh status     # show running status and PIDs
```

One script controls **both** processes. It checks that `aiohttp` is installed before starting the proxy and prints a clear error with the fix command if it is missing.

### Method B — systemd units (starts at boot, restarts after a crash)

The repository ships two ready units, `phantomsdr-admin.service` and `phantomsdr-proxy.service`. Edit `User=` and the paths in both, then:

```bash
sudo cp phantomsdr-admin.service phantomsdr-proxy.service /etc/systemd/system/
sudo systemctl daemon-reload
./manage_admin.sh stop        # free the ports first
sudo systemctl enable --now phantomsdr-admin
sudo systemctl enable --now phantomsdr-proxy
```

Day-to-day commands then become:

```bash
sudo systemctl start   phantomsdr-admin
sudo systemctl stop    phantomsdr-admin
sudo systemctl restart phantomsdr-admin
systemctl status       phantomsdr-admin   # no sudo needed
sudo journalctl -u phantomsdr-admin -f    # live logs
```

The same four with `phantomsdr-proxy`, or both at once: `sudo systemctl restart phantomsdr-admin phantomsdr-proxy`.

One thing to do once: install the tmpfiles rule at `tmpfiles/phantomsdr-logs.conf` (edit its paths and user first). systemd creates those two logs as `root` before it drops to `User=`, and the panel's **Clear Logs** button then fails on them with `Permission denied` — see [“Clear Logs” says Permission denied](#clear-logs-says-permission-denied) below. `setup_admin.sh` installs the rule for you.

To go back to Method A:

```bash
sudo systemctl disable --now phantomsdr-admin
sudo systemctl disable --now phantomsdr-proxy
```

> ⚠️ **Do not mix the two.** With the units enabled, `./manage_admin.sh stop` is undone by systemd five seconds later, and `./manage_admin.sh start` gives you a second, unmanaged copy fighting the systemd one over the same port. (`restart` was removed from the script for exactly this reason; it now prints an error telling you to use `systemctl`.) `./manage_admin.sh status` only reads, so it stays useful either way.

### Restarting the panel

The rest of this document says "restart the panel" in a number of places. It means whichever of these matches your method:

```bash
# Method B — systemd units (the normal setup)
sudo systemctl restart phantomsdr-admin phantomsdr-proxy

# Method A — no units installed
./manage_admin.sh stop && ./manage_admin.sh start
```

---

## Step 3 — Open firewall port

Open only the **proxy public port** in your firewall. There is no need to expose the admin panel internal port externally:

```bash
sudo ufw allow <proxy_port>
```

---

## Step 4 — Kick Users feature

The Users page shows every currently connected listener. Each row shows the name or callsign the listener typed (`--` when none), the location with the IP address under it, the tuned frequency, mode and how long they have been connected. To disconnect one user, click the **⚡ Kick** button on their row — only that listener's connections are closed. All other listeners stay connected and hear nothing.

Next to the mode the Users page shows the decoder a listener is running in their page, for example `USB · FT8` (DRM listeners read `DRM`). Pages opened before the server was updated report it only after they are reloaded.

The kick is instant and surgical: the server does not restart, no audio is interrupted for anyone else, and the kicked user can reconnect immediately (the feature is for removing misbehaving or stuck connections; to keep someone out, use the ban below).

**⛔ Ban ▾** opens a small menu — **8**, **16** or **24 hours** — and the chosen length disconnects the listener from every receiver of the station and refuses that address for that long (24 hours is the most the receiver accepts) (close code 4001, which the page does not retry). The ban is kept in `admin_bans.json` next to the panel and sent to every receiver again once a minute, so a receiver restart does not lift it. While bans are in force, a **Banned** list under the table shows each one with its name, address and end time, and an **Unban** button lifts it at once. Everyone behind the same internet connection shares the address and is banned with it.

---

## Configuration — admin_config.json

All runtime configuration lives in `admin_config.json` in your PhantomSDR-Plus directory. `setup_admin.sh` writes the initial file; subsequent changes can be made via the Settings page or by editing the file directly.

Key fields written by `setup_admin.sh`:

| Key | Description |
|---|---|
| `port` | Admin panel internal port (`admin_server.py` binds here) |
| `public_port` | Spectrumserver port of the main receiver (9001 behind proxy.py) — **not** the port listeners use, that is `proxy_port`. proxy.py forwards to it; Kick, the Users page and the user count query it |
| `proxy_port` | Public port the proxy listens on |
| `sdr_host` | Host the proxy uses to reach spectrumserver — `127.0.0.1` (see below) |
| `password_hash` | SHA-256 hash of the admin password |
| `sdr_base_dir` | Path to your PhantomSDR-Plus installation |
| `sdr_process_name` | Process name to monitor (default: `spectrumserver`) |
| `start_script` / `stop_script` | Scripts the panel runs to start and stop the SDR server — also what the thermal guard acts through |

> **Several receivers on one computer?** Set `start_script` to `start-all.sh`. The stop script already stops every receiver, and Restart and the thermal guard use the start script, so with `start-all.sh` they bring back every receiver in `receivers.toml` instead of only the main one. The Users page, the user count and the kick then cover every receiver as well. See [Several Receivers](MULTI_RECEIVER.md).

---

## The `sdr_host` setting

`proxy.py` connects to `spectrumserver` over loopback — `sdr_host` is `127.0.0.1` in `admin_config.json`, written there by `setup_admin.sh`. You should not need to change it.

Set it to a real address only if `spectrumserver` runs on a **different machine** than the proxy. Then [restart the panel](#restarting-the-panel).

---

## proxy.py — what it is and when you need it

`proxy.py` puts both the SDR server and the admin panel on a **single public port**, routing by path prefix:

| Path | Routed to |
|---|---|
| `/admin*` | Admin panel (`localhost:<port>`) |
| Everything else | Spectrumserver (`<sdr_host>:<public_port>`) |

Without the proxy you must expose two ports separately. With the proxy you expose only one.

The proxy also removes the 4 MB WebSocket message-size cap (important for large FFT frames from the RX-888 at 60 MSPS), forwards real client IPs via `X-Forwarded-*` headers, and keeps long-lived connections alive through NAT with a 30-second heartbeat.

---

## Changing ports after setup

Edit `admin_config.json` directly:

```json
{
  "port":        9010,
  "public_port": 9001,
  "proxy_port":  9000,
  "sdr_host":    "127.0.0.1"
}
```

Then restart both services:

```bash
sudo systemctl restart phantomsdr-admin phantomsdr-proxy   # Method B
./manage_admin.sh stop && ./manage_admin.sh start        # Method A
```

---

## Useful manual commands

```bash
# Start admin panel manually (foreground)
python3 ~/PhantomSDR-Plus/admin_server.py

# Kill the admin panel
pkill -f admin_server.py

# Kill the proxy
pkill -f proxy.py

# Free a port that is stuck in use
sudo fuser -k 9010/tcp

# Check what is listening on a port
ss -tlnp | grep 9010
```

---

## Log files

| File | Contents |
|---|---|
| `admin.log` | Admin panel output |
| `proxy.log` | Proxy startup banner + one access-log line per proxied request |
| `logwebsdr.txt` | Launcher and watchdog log — start/stop, receiver driver, websdr.org registration |
| `spectrumserver.log` | The receiver process's own output — FFT and OpenCL setup, per-client connections, errors. The biggest of these files; it is rotated, so `spectrumserver.log.1` may sit beside it |
| `rade.log` | RADE/FreeDV sidecar log |
| `autorun.log` | Decoder daemon log — spots, SNR, drift |
| `crash.log` | Crash reports and thermal events: `[CRASH]` / `[TERMINATE]` backtraces, `[EXIT]` notes and `[THERMAL]` lines from the guard. **Normally empty** — anything in it is worth reading |

All of these are readable from the panel's **Log Viewer** tabs (LOGWEBSDR, SPECTRUMSERVER, ADMIN, RADE, CRASH, AUTORUN, PROXY). The viewer shows the last 150 lines of whichever tab is selected and refreshes every 3 seconds when auto-refresh is on; it reads only the tail, so the size of the file does not matter.

### Rotating proxy.log and admin.log

`proxy.log` records every proxied request and `admin.log` every request that reaches the panel itself. Neither is rotated by default. The dashboard's polling used to dominate both — `/admin/api/status` fires every ~3 seconds for as long as a tab is open — but those polls are now filtered out of both files (see below), so rotation is there to bound slow growth rather than a flood.

The repo ships a logrotate config at `logrotate/phantomsdr` (daily, or sooner if a log passes 10 MB; keeps 7 gzipped archives in `logproxy/`, so they do not clutter the project root). **It is site-specific — open it and change the three log paths, the `olddir` path and the `su` user to match your machine before installing**, then:

```bash
sudo cp logrotate/phantomsdr /etc/logrotate.d/phantomsdr
sudo logrotate -d /etc/logrotate.d/phantomsdr     # dry run, should list all three logs
```

The panel's **Clear Logs** button truncates **every** file in the table above, `autorun.log` and `proxy.log` included (`CLEAR_EXCLUDE` in `admin_server.py` is empty). Note what that costs on `autorun.log`: its decode history is the only record of what was heard and when, and nothing can reconstruct it — what survives a clear is whatever logrotate has already rotated into `logproxy/`, so a clear discards everything decoded since the last rotation. Clearing it under a running decoder is safe: the daemon holds it open `O_APPEND` and goes on appending to the same inode. The toast names what was cleared, and if a file could not be written — a `proxy.log` owned by a different user, say, on a split-user install — it names that file and the error instead of reporting success, and leaves that log's pane on screen rather than blanking it. The files are truncated in place, never deleted: both `manage_admin.sh` and the systemd units open them `O_APPEND`, so an unlinked file would go on filling an invisible inode until the service restarts.

Because `proxy.log` is an access log, it contains visitor IP addresses and user-agent strings — keep that in mind before sharing it when asking for help.

### "Clear Logs" says Permission denied

On a machine where the systemd units were installed on a clean tree, the button can come back with:

```
✗ Could not clear admin.log ([Errno 13] Permission denied: /home/you/PhantomSDR-Plus/admin.log),
  proxy.log ([Errno 13] Permission denied: /home/you/PhantomSDR-Plus/proxy.log)
```

It is always those two files and never the other five, because they are the only ones systemd creates itself. `StandardOutput=append:` is opened by PID 1 **before** it drops to `User=`, so a log that does not exist yet is created `root:root 0644`. The panel runs as your user and cannot truncate it. The other five logs are created by the launcher scripts, which already run as your user, so they clear normally. Where the two logs predate the units — `manage_admin.sh` created them with `>>` — they are already owned correctly and the button works, which is why the problem only shows up on a fresh systemd-first install.

Confirm with `ls -l admin.log proxy.log`: the failing ones say `root root`. Repair them:

```bash
sudo chown "$(id -un):$(id -gn)" admin.log proxy.log
sudo chmod 664 admin.log proxy.log
```

No restart is needed — systemd keeps writing through the file descriptor it already holds, and appending does not change ownership. Press **Clear Logs** again and both are emptied.

To stop it coming back, install the tmpfiles rule the repo ships at `tmpfiles/phantomsdr-logs.conf`. It re-creates both logs with the right owner at every boot, before the units start, so a removed log — manual cleanup, a reinstall, a moved installation directory — never returns root-owned. **It is site-specific: open it and change the two paths and the user:group to match your machine first**, then:

```bash
sudo cp tmpfiles/phantomsdr-logs.conf /etc/tmpfiles.d/99-phantomsdr-logs.conf
sudo systemd-tmpfiles --create /etc/tmpfiles.d/99-phantomsdr-logs.conf
```

---

## Access summary

| Setup | SDR | Admin panel |
|---|---|---|
| Without proxy | `http://YOUR_IP:<public_port>` | `http://YOUR_IP:<port>/admin` |
| With proxy | `http://YOUR_IP:<proxy_port>` | `http://YOUR_IP:<proxy_port>/admin` |

---

## Chat message deletion

The Chat History page lists every message in the current chat log. Each entry has a **🗑 Delete** button that removes that single message from the log immediately — no server restart required.

How it works:

- The admin panel rewrites the chat log file in place, stripping only the selected message line.
- The change takes effect for any user who reloads the chat; already-loaded chat history in open browser tabs is not retroactively updated.
- Clearing the entire log (the **Clear All** button) truncates the file, which also takes effect without a restart.
- A **chat reply** is stored as an ordinary message that begins with a marker naming the message it answers, for example `[RE:2026-09-25 12:00:01|SV1BTL]`, so in this list it shows with that marker in front. Deleting a reply removes only that reply. Deleting the message it answers leaves its replies in place, showing only the name and time they answer.

---

## Waterfall broadcast messages

The **Waterfall Message** panel lets you push a persistent text banner to every connected user's waterfall display without touching the server process.

### Sending a message

1. Open the admin panel and go to **Waterfall Message**.
2. Type your message text and choose a colour (hex, e.g. `#ffdd00`).
3. Click **Send** — the message appears on all active waterfall views immediately.

### Clearing the message

Click **Clear** to remove the banner from all waterfalls. The message state is held in memory by the admin panel; it is cleared automatically if the admin panel process is restarted.

---

## System Graphs

The **Graphs** page plots four measures against one shared time axis:

- **CPU frequency** — average clock across all cores, in GHz
- **CPU load** — total utilisation, in percent
- **CPU temperature** — in °C, with dashed guides at 70 °C (warm) and 80 °C (critical)
- **Users online** — listeners connected to the WebSDR at that moment

Pick a range with **15 MIN / 1 HOUR / 4 HOURS / 12 HOURS / 24 HOURS**. Hovering the plot draws a crosshair and reads out all four values at that instant. The four cards above the plot always show the newest sample.

---

## Thermal Guard

> 📖 **Full manual: [THERMAL_GUARD.md](THERMAL_GUARD.md)** — the four modes and what a sysop must do for each, running it without the panel, enabling the throttle stage without root, testing and troubleshooting. This section covers the panel side.

Stops the SDR server when the CPU gets dangerously hot, and starts it again once it has cooled. It is part of the panel — nothing extra to install — and appears as a **THERMAL GUARD** card on the Dashboard with its settings under **Settings**.

It ships **inert**: the mode starts at `log`, so out of the box it only records what it *would* have done. Nothing touches your server until you change the mode.

---

## Spot Reporting (Autorun FT8/FT4/JS8/WSPR)

The **Spot Reporting** tab controls the autorun daemon (`autorun/index.js`) — a Node.js process that decodes FT8/FT4/JS8/WSPR server-side straight off the receiver and uploads spots to the reporting networks:

- **FT8 / FT4 / JS8 → PSK Reporter** (IPFIX/UDP)
- **WSPR → wsprnet.org** (HTTP)

> **JS8 is spotted at Normal speed only** — the 15 s calling cycle, where heartbeats and CQs are. Spots come from heartbeats, compound frames and directed messages; group destinations such as `@ALLCALL` and callsigns the decoder could not resolve (`<....>`) are never reported. JS8 shares the PSK Reporter queue with FT8 and FT4 and is counted separately, exactly as they are.


**Reporting is OFF by default.** Nothing is uploaded until you enable a destination and press **Start**. Decoding and uploading are independent: the daemon can decode and log with reporting off, so you can verify activity before anything goes public.

> ⚠️ Spots are uploaded to public networks under **your callsign**. Only enable bands/modes your receiver genuinely hears, and set the correct grid square.

### Prerequisites

The autorun daemon needs Node.js 22+, the `ws` + `cbor-x` npm packages (resolved via the `autorun/node_modules` symlink → `frontend/node_modules`), and `util-linux` (`taskset`). The installers set all of this up automatically — see the [Autorun Spot Reporter section of INSTALLATION.md](INSTALLATION.md#autorun-spot-reporter-ft8ft4wspr). If **Start** fails, that symlink or `taskset` is the usual cause (see Troubleshooting below).

### Using the tab

1. **Identity** — callsign and grid. Pre-filled from `frontend/site_information.json` (`siteSysop` / `siteGridSquare`, truncated to 6 chars); override here if needed. The reporters take a 4- or 6-character locator only (KM17 or KM17VX): a longer one is cut to its 6-character square, and anything that is not a locator is refused when you save.
2. **Band × mode matrix** — tick the combinations to decode. Rows are bands, columns are FT8 / FT4 / JS8 / WSPR; unsupported cells are disabled. WSPR additionally covers the LF/MF bands (2200m, 630m) and an extra 80m EU channel.
3. **Destinations** — enable **PSK Reporter** and/or **wsprnet** (both off by default).
4. **Max slots** — a cap on how many band/mode slots run at the same time; with a [schedule](#schedule-hours-per-band-and-mode) it is checked hour by hour. **SELECT ALL** beside it ticks every band and mode.
5. **Start / Stop** — spawns/kills the daemon (pinned to the top CPU cores with `taskset`, chosen automatically for the machine — see *Resource requirements & limitations* below). **Save** / **Reload** persist and re-read the config; **Free All** clears every slot. **Start automatically after a reboot or crash** brings the daemon back by itself — see [below](#starting-automatically-after-a-reboot-or-crash).

The status card polls every 5 s and shows running state, decode/upload counts and the last upload time. A **📶 REPORTING** badge appears on the main waterfall while reporting is active.

> **"0 sent" for the first few minutes is normal.** PSK Reporter uploads batch every **5 minutes** and wsprnet every **2 minutes** — spots queue until the next flush. The status card shows the pending count and cadence.

### Changing bands or modes while it is running

A saved change reaches a running daemon by itself. The daemon looks at `autorun.json` every 5 seconds, and when **SAVE CONFIG** has changed it, it takes the new bands, modes, hours and destinations without a restart: new slots open, removed ones close, and `autorun.log` says `config reloaded` with the slots opened and closed. The counters carry on. **START** on a running daemon still answers `already running`, which is harmless: the change it saved is picked up anyway.

Two things still need **STOP** → **START**: the callsign and grid (the log says so when they change), and a hand-edited `server` or `cores` entry in `autorun.json`.

What a restart does to the counters:

- **The all-time counts beside each checkbox survive** — they live in `autorun-totals.json`, which is not deleted on shutdown.
- **The per-decoder tiles reset to zero**, being per-run by design.
- **Nothing queued is lost**: shutdown flushes pending spots before exiting.
- A **newly enabled** band starts at `0`; a band you had used **before** resumes its previous total.
- A band you **deselect keeps its number** next to the now-unchecked box; the history is not deleted.

**SELECT ALL**, beside MAX SLOTS, ticks every band and mode; when all are ticked it reads **DESELECT ALL** and unticks them.

### Schedule (hours per band and mode)

Under BANDS & MODES, the **SCHEDULE** card has a row for every ticked band and mode, with 24 boxes for the hours 00–23 **UTC**. A tick in a box means that slot decodes and spots in that hour. In the other hours it sleeps with its connection to the receiver closed, so it costs no CPU and takes none of the receiver's listener places. A slot with every hour ticked runs all day, as before there were schedules — which is how every existing configuration starts.

- Click a box to tick or untick it, or drag across several.
- **24h** and **Clear** — every hour, or none.
- **Day** and **Night** — 06–18 and 18–06 local *solar* time at the grid square under REPORTER IDENTITY (for KM17VX, Day is 04–15 UTC). Solar time rather than clock time, so it is right for any station and does not move with daylight saving.
- **→ 20m** (the row's own band) — gives the other ticked modes of that band the same hours, replacing theirs.
- **show local time** — labels the columns in your browser's time; the schedule is still kept in UTC.
- The **AT ONCE** row counts the slots running in each hour. A red number is over **MAX SLOTS**, and **SAVE CONFIG** refuses until it is fixed. MAX SLOTS limits the slots running *at the same time*, not over the day, so a schedule lets more bands share the same CPU — 10, 12 and 15 m by day and 160 and 80 m at night, for example.
- The dot before each row is green while that slot is decoding, amber while it opens for its next hour or closes, and grey while it sleeps or the daemon is stopped. The status card shows the slots scheduled now and the time of the next change.

A slot opens a little before its first hour — one decode window plus 10 seconds, so about 25 s for FT8 and JS8 and just over 2 minutes for WSPR — so that the first cycle of the hour is decoded; the cycle heard during that lead-in belongs to the hour before and is not reported. It closes a few seconds after its last hour, once the decode of that hour's last cycle has started. A tap that drops, because the receiver was restarted for example, is reopened after 30 seconds.

### Starting automatically after a reboot or crash

**Start automatically after a reboot or crash**, under the buttons, is off by default and takes effect on **SAVE CONFIG**. With it on, the admin panel — which systemd starts at boot — starts the daemon about a minute after the panel comes up, then checks every minute that it is still running and starts it again if it has died. A receiver that is not up yet does not matter: the daemon keeps retrying its taps every 30 seconds.

**STOP always wins.** After **STOP** the daemon stays off, reboots included, until you press **START**; the panel keeps that in the file `autorun-stopped`. **FREE ALL SLOTS** stops the daemon too and holds it the same way. The status card shows `Autostart: off`, `ON`, or `ON, held by STOP`.

A daemon that dies 5 times within 15 minutes is left alone for 30 minutes instead of being restarted every minute. Every automatic start, and that pause, is written to the AUTORUN log as `[admin …] autostart: …`.

### Spot counters

Two different counts are shown, and they answer different questions.

**SPOTS UPLOADED PER DECODER** — a tile per decoder (FT8 / FT4 / JS8 / WSPR) with the spots uploaded **since the daemon last started**, under it the decode count and how many are still queued. Stop/Start resets these to zero. A decoder whose destination is switched off shows its decodes and `reporting off` rather than a bare `0`, because zero uploads is a setting there, not a fault.

**The number beside each checkbox** in BANDS & MODES is that band+mode's **all-time** uploaded spots. These are kept in `autorun-totals.json` and survive restarts. **Amber with a dot in front** (`·123`) means that slot has decoded but not uploaded yet. That is normal between flushes — PSK Reporter uploads every 5 minutes and wsprnet every 2 — so FT8/FT4 counts sit amber for the first few minutes after a start. It also stays amber if that decoder's destination is switched off. A plain `0` with no dot means that slot is enabled but has decoded nothing yet — WSPR sits at zero for several minutes after a start, because it runs on a 2-minute cycle while FT8 is already counting in the hundreds. A slot the daemon has never run shows nothing at all. Hover any number for the uploads, the decodes and the time of the last upload.

**Clearing the counters.** **FREE ALL SLOTS** unticks every band/mode, turns both destinations off, stops the daemon and **erases the all-time counters** — after it, no number is shown beside any checkbox. This is the only way to reset them, and it cannot be undone. The button stops the daemon and waits for it to exit before deleting `autorun-totals.json`, because the daemon rewrites that file on shutdown; deleting it under a live daemon would simply bring the numbers back.

### Resource requirements & limitations

The daemon is deliberately lightweight and runs on low-resource hardware (a 4-core i5 is fine), but there are real limits to be aware of.

**Known limitations:**

1. **The real bottleneck is spectrumserver + SDR bandwidth, not the daemon.** An RX888 @ 30 MHz needs OpenCL/GPU; a low-core CPU without a capable GPU cannot sustain that FFT. Pair low-resource hardware with a narrower SDR (RSP1A ≈ 10 MHz, RTL-SDR ≈ 2.4 MHz).
2. **WSPR is the CPU long pole.** Its Fano decoder is a JS port (~30 s per band, single-threaded). The 4-worker pool runs 4 decodes in parallel; enabling **more than ~4 WSPR bands** at once can queue past the 120 s slot, especially while the SDR is competing for cores. FT8/FT4 decodes are cheap by comparison.
3. **Slot-count scaling.** The ~2–2.5 cores / 600–700 MB figure is for the full ~28 slots on an 8-core box. On 4 shared cores, keep it to a handful of bands (guideline: ≤ 6 FT8/FT4 + ≤ 3 WSPR) and watch the pool's `queued` stat.
4. **Pinning assumes Intel hybrid topology** (lower cores = faster P-cores). On AMD or CPUs with interleaved SMT numbering the auto split is still valid (no overlap, no crash) but "lower cores are faster" may not literally hold, and on a hyperthreaded 4C/8T part the top cores are SMT siblings — confined, not fully isolated. Where the auto range isn't ideal, use the **manual override** below.
5. **Band coverage is limited by the receiver.** The RX888 config (`sps=60000000` → 30 MHz Nyquist) cannot reach 6 m and above; the band table is 160 m–10 m. Other SDRs cover whatever their tuned window allows.
6. **Reporting cadence.** PSK Reporter flushes every 5 min, wsprnet every 2 min — "0 sent" in the first few minutes is normal, not a fault.

### Files and endpoints

| Item | Purpose |
|---|---|
| `autorun.json` | Saved config (identity, slots with their UTC `hours`, destinations, max slots, `autostart`, optional `cores` pin override). Written by the tab; git-ignored. A slot without `hours` runs all day. |
| `autorun-stopped` | Present after **STOP**: autostart leaves the daemon off, across reboots too, until **START** removes it. Git-ignored. |
| `autorun/scheduler.js` | Which slots are open at a given time: the hours, the lead-in before the first hour and the grace after the last. Tested by `node autorun/scheduler.test.mjs`. |
| `autorun-status.json` | Live status the status card reads (pid, counts, last upload). Written every 15 s; removed on stop. |
| `frontend/dist/autorun-active.json` | Public badge data served at `/autorun-active.json`. Empty when reporting is off. |
| `autorun.log` | Daemon stdout/stderr. |
| `GET/POST /admin/api/autorun/config` | Read / write `autorun.json` (validates callsign, grid, band/mode combos, slot cap). |
| `GET /admin/api/autorun/status` | Running state (`pgrep`) + `autorun-status.json`. |
| `POST /admin/api/autorun/start` / `stop` | Spawn (`taskset -c <auto> node autorun/index.js`) / `SIGTERM`. The core range is derived from the CPU (see below). |

> **Note:** after upgrading `admin_server.py` you must [restart the panel](#restarting-the-panel) to load new autorun routes or an updated band/mode matrix. The daemon runs as a separate process, so it survives admin-panel restarts.

---

## System Health

A card on the **Dashboard**, refreshed every 30 seconds (or with **↻ refresh**):

- **Receivers** — every receiver of the station (the one on `public_port` and every receiver in `receivers.toml`): a green dot and *on air, up 15h 5m* when it answers, a red **OFF THE AIR** when it does not.
- **Disk & log folders** — free space on the disk that holds the installation (amber from 80 % used, red from 90 %), and the size of `logs/`, `logproxy/` and each `instances/<id>/logs/`.
- **Recent alerts** — what the alert monitor has seen since the panel started (see [Alerts](#alerts-email--telegram)), whether or not a message was sent.
- **Last crash.log entry** — the newest non-empty `crash.log` of all receivers, with its date and its last 12 lines.

---

## Visitor statistics

The **Visitors** page in the sidebar (on a phone: **☰ MENU → Visitors**, or the **📈 VISITOR STATISTICS** button on the Users page) counts the station's listeners from the private logs `logs/users_YYYY-MM-DD.jsonl` of every receiver — the copies with the IP addresses, which the public pages no longer show. Choose **Today**, **7**, **14** or **31 days**.

- **Visitors** (distinct addresses), **sessions**, **listening hours** and the **most listening at the same time**.
- **Per day** — the same four figures for each day.
- **Busiest hours** — when sessions started, by UTC hour.
- **Countries** — visitors per country.
- **Decoders** — how many sessions ran each decoder (counted from the log lines that carry the decoder, i.e. since the server was updated).
- **Addresses** — the 20 addresses with the most sessions *at the same time* first, then the most sessions; a flood like the one of 16 September 2026 stands out at the top (**AT ONCE** turns red above 3). Each row has **BAN ▾** (8, 16 or 24 hours).

Days and hours are UTC. The station's own decoders (local connections) are left out; a session still open counts at most 12 hours. Names are not in these logs, so the page shows addresses, not names. The figures are recomputed at most once a minute.

---

## Alerts (email / Telegram)

**Settings → Alerts — Email / Telegram.** A monitor inside the admin panel looks every 30 seconds at:

| Event | When |
|---|---|
| **off the air** | a receiver has not answered for about a minute (two checks in a row) |
| **back on air** | it answers again |
| **restarted** | it answers as a new process — restarted by the watchdog, a start script or the thermal guard |
| **thermal guard** | the guard changes stage (normal / warn / throttle / stopped) |
| **crash.log** | a `crash.log` of any receiver gets a new entry; the message carries its last lines |

Each event has its own tick box. The same alert is sent at most once per 5 minutes. The first check after the panel starts only learns the current state, so restarting the panel sends nothing.

**Telegram** (the simplest):

1. In Telegram open **@BotFather**, send `/newbot` and follow the steps; it gives a **bot token** (`123456789:AA…`).
2. Open your new bot and press **Start** — a bot cannot write to you before that.
3. Open **@userinfobot**; the **Id** it answers is your **chat ID**.
4. Tick **TELEGRAM**, paste both, press **✉ SEND TEST**.

**Email:** tick **EMAIL** and fill in your provider's SMTP server, port and security (SSL on 465, STARTTLS on 587), user, password and **TO**. **FROM** may be a full address, `Name <address>`, or only a name — a name alone is shown as the sender's name over the **USER** address, so the user must then be a full address.

**✉ SEND TEST** saves the form first, then sends; the line under the buttons shows the answer of each channel, or what is still missing. The settings are kept in `admin_config.json` under `"alerts"` — the panel's private file, never part of a backup or an update. A saved password or token is shown as `********` and stays as it is unless you type a new one.

---

## Receivers

**Receivers** in the left menu (on a phone: **📡 RX** in the bottom bar) lists every receiver of the station — from `receivers.toml`, or only the main one on a single-receiver station — with its name, its `?rx=` name, the hardware and its gain, the range it covers and its centre, the bandwidth, the frequency and mode a new listener starts on, and whether it is on the air. Each receiver has its own buttons:

| Button | What it does |
|---|---|
| **✎ CHANGE SETTINGS** | the form described below |
| **■ STOP** / **▶ START** | stops only this receiver (it asks first; the others keep running), or starts it again. Starting takes about 20 seconds; the button says *STARTING …* until the receiver is on the air |
| **🏷 RENAME BUTTON** | only on a receiver without the change form: the name on its picker button, saved in `receivers.toml`; nothing restarts |
| **🗑 DELETE** | only on an extra receiver that is not the default one — see below |

**✎ CHANGE SETTINGS on an extra receiver that tunes** (one in `instances/<name>/`): give the centre frequency in MHz, pick the bandwidth from the sample rates that hardware can do, and set where a new listener starts, in which mode, its gain and the name on its button; the form shows the new range before you apply it. A frequency the hardware cannot tune, a sample rate it cannot do, or a start frequency outside the new range is refused. **✔ APPLY AND RESTART THIS RECEIVER** then:

- sets `-f`, `-s` and the gain in `instance.env`, and `frequency`, `sps`, `fft_size` and the start frequency and mode in `config.toml` — a crystal correction (a `frequency` a few Hz away from `-f`) is kept as the same error in ppm, so it stays right on the new band, and `fft_size` is scaled so the waterfall keeps its resolution
- sets `siteSDRBaseFrequency` and `siteSDRBandwidth` in `www/site_information.json` — the receiver's page reads it when it opens, so nothing is rebuilt
- sets the button name in `receivers.toml`; the receiver's directory-listing name and hardware name stay as they are
- keeps the old files in `admin-backups/retune-<name>-<date>/` and restarts **only that receiver** — its listeners are cut off for a few seconds, the others notice nothing

**✎ CHANGE SETTINGS on the main receiver and on a direct-sampling one** (RX888, Fobos HF — it covers 0 Hz to half its sample rate and has nothing to tune): the form has the name on its button, the start frequency, the mode and the gain. The start frequency and mode go into its `.toml`, the name into `receivers.toml`, and the old files into `admin-backups/settings-<name>-<date>/`. **✔ APPLY** restarts that receiver only when the start frequency, the mode or the gain changed; restarting the main receiver restarts RADE and DRM with it. The main receiver's band itself is changed with `bash configure-station.sh`: its page carries its band from the build, so it needs a page rebuild, and the wizard restarts the services with sudo. On a single-receiver station without `receivers.toml` there is no picker button, so there is no name to set.

**AT VOLUME (0 – 100 %)**, in both forms, is the volume slider position a first-time listener starts at; it goes into the receiver's `.toml` as `volume` under `[input.defaults]`. Left empty, the line is removed and the page starts at 50 %. A listener who has moved the slider once keeps their own setting on later visits. A changed volume restarts that receiver, like a changed start frequency.

**IQ FOR LISTENERS**, **WIDE IQ** and **WIDE IQ LISTENERS AT ONCE**, in both forms, are the receiver's IQ settings: `iq`, `iq_wide` and `iq_wide_listeners` under `[server]` in its `.toml` (see the wider IQ section of the User Guide). *off* hides the IQ button from listeners. Wide IQ offers 24 or 48 kHz besides the 12 kHz everyone gets, to as many listeners at once as the last field says (`0` = no limit). Only a setting you change is written, and an example line such as `# iq_wide=48` becomes the real line. The server reads these settings only when it starts, so a changed IQ setting restarts that receiver.

On every receiver, changing only the name restarts nothing.

**Gain.** For an RX888 the form has the VGA gain (0–127), the gain mode (low/high), the attenuation (0–63) and **PGA on**; for an RTL-SDR the RF gain from the steps the tuner supports, or *auto* (the stick's own AGC). They are written into the receiver's argument line — `RX888_ARGS` or `RX_ARGS` — in `instances/<name>/instance.env` for an extra receiver, and in `main.env` for the main one. `main.env` is the main receiver's `instance.env`: every start script reads it last, it is not in git and `update.sh` never replaces it. The gain cannot live in `station.conf`, because `configure-station.sh` rewrites that file. Without `main.env` the start script keeps its built-in gain (`-g 50 -a 0 -m low --pga` for the RX888). Other receiver types keep their gain in the same argument line; change it there by hand.

**🗑 DELETE** removes an extra receiver for good. Type its short name to confirm; it then stops that receiver (watchdog first) and goes no further while any of its processes is still running, takes its `[[receiver]]` block out of `receivers.toml` (the old file goes to `admin-backups/deleted-<name>-<date>/`), and moves its folder `instances/<name>/` there too — or deletes the folder if you untick *keep a copy*. Its button disappears from the pages; the driver and its log file `logwebsdr-<name>.txt` stay.

The proxy re-reads `receivers.toml` whenever it changes, so a rename, a deletion or an added receiver reaches the listeners without restarting the proxy. Open pages re-read the receiver list every 15 seconds, so a stopped receiver's button goes away and comes back on its own.

**➕ ADD NEW RECEIVER** opens a form with the questions of `add-receiver.sh`: the receiver type (with *RTL-SDR Blog V4* for an RTL stick), centre frequency, bandwidth, a short name (suggested from the band, and checked to be free), the name on its button, its antenna and the station's public address, and whether to install the driver, show the receiver picker on the main page, set this panel's start script to `start-all.sh`, start the receiver and restart the proxy. Above it, the page lists the USB receivers this computer sees, so you know the stick is plugged in. **▶ PREPARE** checks the answers, saves them in `instances/.add-rx.env`, and gives two lines to run in a terminal, each with **📋 COPY**:

```bash
cd ~/PhantomSDR-Plus
./add-receiver.sh --answers instances/.add-rx.env
```

The script takes every answer from that file and asks only for your sudo password (the driver and the proxy restart need it — the admin panel never runs anything as root), then removes the file. Reload the page afterwards and the new receiver is in the list. `--answers FILE` also works on its own: one `ADD_RX_…=value` per line; the names are listed at the top of `add-receiver.sh`.

---

## Settings — ports, start/stop and HTTPS

**PORTS**, under **🔑 UPDATE PASSWORD**, lists every port this station uses — the public port, https (443/80) when it is set up, each receiver's spectrumserver, the admin panel, statistics, RADE, DRM and the relay — read from `admin_config.json`, `station.conf` and `receivers.toml`, the same files `proxy.py` reads. A green ● means something listens on the port now, ○ that nothing does. Only the ports marked *open on the router* need forwarding; the others stay on this computer and are reached through the public port. Services that are not installed are left out.

**SPECTRUMSERVER PORT (MAIN RECEIVER)** is `public_port`: the port the main receiver's spectrumserver listens on — 9001 behind `proxy.py` on a station set up by `install.sh`. It is **not** the port listeners use; that one is shown read-only under the box as **Listener port (proxy)** (`proxy_port`), or as *none* on a station without a proxy, where the two are the same. **💾 SAVE SETTINGS** checks the number: the proxy's own port is refused, and a port that differs from the `[server] port` of the running receiver asks for confirmation first — with a wrong number `proxy.py` forwards listeners to a port where nothing answers, from its next restart on. To really move spectrumserver, set `[server] port` in the receiver's `.toml`, its line in `receivers.toml` and this box to the same number, then restart the receiver and the proxy.

**▶ START** and **■ STOP**, next to **DEFAULT START SCRIPT** and **DEFAULT STOP SCRIPT**, run the **saved** script at once, after a confirmation — both drop every listener. If you changed a selection, save first: the button refuses an unsaved one. The first seconds of the script's output appear under the buttons; the whole output of these scripts, and of the thermal guard's restarts, goes to `logs/admin-scripts.log`.

**HTTPS** shows whether the station is served over https.

- On an https station, **🔍 CHECK** runs `setup-https.sh --status`: is Caddy running, and does the certificate answer?
- On an http-only station, **🔒 SET UP HTTPS** checks what it can — `station.conf`, that your DNS name resolves (an IP address cannot get a certificate), whether ports 443 and 80 are free or already Caddy's — reminds you to forward TCP 443 and 80 on the router, and gives the two lines to run in a terminal, each with **📋 COPY**. `setup-https.sh` asks for your sudo password there: the admin panel never runs anything as root. Reload the page when it has finished, and the button becomes **CHECK**. See [Secure Access — https://](HTTPS.md).

---

## Backup & restore of the station settings

**Settings → Backup & restore of the station settings.**

**⬇ DOWNLOAD BACKUP** gives one zip, `phantomsdr-settings-<call>-<date>.zip`, with this station's own settings:

- every `*.toml` of the installation (receiver configs and `receivers.toml`) and `station.conf`
- `frontend/site_information.json`, `frontend/src/bands-config.js`, `markers.json`
- `autorun.json` (spot reporting), `websdr_relay.json`, `drm.json`, `admin_bans.json`
- for every extra receiver: `instances/<id>/config.toml`, `instance.env`, `markers.json`

and a `BACKUP-INFO.json` with the date, the computer and the file list. **Not** in it: `admin_config.json` (admin password, alert secrets), the logs, and the program itself.

**⬆ RESTORE** takes a backup zip and writes back **only** files of that same list — anything else in the zip is skipped and named. Before a file is replaced, the current one is copied to `admin-backups/restore-<date-time>/` (git-ignored, never in an update), so a wrong restore can be undone by hand. The answer says what to do next: restart the receivers after a `.toml`, `instance.env` or `station.conf`; rebuild the page (`./recompile.sh --frontend`) after site information or band settings; restart `phantomsdr-websdr-relay` after the relay settings.

---

## On a phone or tablet

Below 768 pixels wide the left menu becomes a drawer. The bottom bar has **DASH**, **RX** (Receivers), **USERS**, **GRAPHS**, **LOGS** and **☰ MENU**, which slides in the full menu with every page; it closes when you pick a page or tap beside it, and **MENU** stays lit while you are on a page that is not in the bar. On a phone the tables turn into one card per row (the Receivers list already on a tablet, up to 1100 pixels), forms drop to one column, and a card title's grey note moves under the title. Top Processes, the Markers editor and the Spot Reporting band/mode grid stay tables and scroll sideways.

---

## Themes

The **THEME** selector sits in the top bar of every page, between **ONLINE** and the clock, and again in **Settings → Appearance**; the two always show the same choice. A theme applies at once, no reload.

| Theme | Look |
|---|---|
| **Phosphor green** | the classic green terminal (default) |
| **Amber display** | the same in warm amber, like an old rig's display |
| **Metal panel** | the receiver page's grey anodised finish, lit from the upper right |
| **Modern dark** | charcoal with a blue accent, no glow |
| **Light** | white and grey, black text — for daylight |
| **Auto (day/night)** | **Light** from sunrise to sunset, **Modern dark** at night |

All themes use the same fonts and sizes; only colours and finish change. *On air* stays green and warnings amber and red in every theme, and the **Graphs** follow the theme too. **Auto** computes sunrise and sunset at the station's locator (`siteGridSquare` in Site Info) and switches by itself while the page is open; without a locator it takes 07:00–19:00 local time as day. The choice is kept per browser, so a PC and a phone can use different themes. The login page keeps the green look.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Admin panel not starting | Check `admin.log` — usually a missing Python package |
| Proxy not starting | Run `python3 -c "import aiohttp"` — if it fails: `pip3 install aiohttp --break-system-packages` |
| Fedora / openSUSE: panel or proxy does not start at boot (`status=209/STDOUT`, `avc: denied { open } … admin.log` or `proxy.log` in `sudo ausearch -m avc -ts boot`) | SELinux forbids systemd to open log files in your home folder. Run `./setup_admin.sh --selinux` (labels both logs `var_log_t`), then `sudo systemctl restart phantomsdr-admin phantomsdr-proxy`. New installs do this automatically |
| Fedora / openSUSE: everything runs, but nobody outside this machine can connect | firewalld drops the public port. Run `./setup_admin.sh --firewall` (opens the proxy port, permanent). New installs do this automatically; `setup_websdr_relay.sh` offers it for the relay port and `setup-https.sh` opens 443/80 |
| `systemctl is-active` stays `activating`, log says `address already in use` | A copy started by hand with `manage_admin.sh start` still holds the port. `./manage_admin.sh stop`, then `sudo systemctl restart phantomsdr-admin phantomsdr-proxy`. With the units installed, `manage_admin.sh start` now hands over to systemctl instead of starting a second copy |
| `proxy.log` is empty | First check the proxy is actually running (`./manage_admin.sh status`). If it is, you are on an old version: the launcher must use `python3 -u` (unbuffered — otherwise the startup banner never leaves the 8 KB buffer), and `proxy.py`'s `main()` must call `logging.basicConfig()` (otherwise aiohttp's access logger has no handler and every request line is discarded, because `web.AppRunner` — unlike `web.run_app` — does not configure logging). |
| Proxy starts but waterfall is blank | Check `sdr_host` in `admin_config.json` — normally `127.0.0.1`. If it holds an old LAN IP from a previous version, change it and [restart the panel](#restarting-the-panel) |
| Kick button says "no connections" | Run `getcap $(which ss)` — if no `cap_net_admin`, run `sudo setcap cap_net_admin+ep $(which ss)` |
| Status always shows OFFLINE | Go to Settings → SDR Process Name — set it to the exact name shown by `ps -eo comm,args \| grep -v grep` |
| Users page shows no data | Verify the endpoint works: `curl http://127.0.0.1:<public_port>/~~users` |
| External browser gets NetworkError | Check proxy is running: `./manage_admin.sh status` |
| Proxy broke after a network change | Only relevant if `sdr_host` still holds a LAN IP — set it to `127.0.0.1` and [restart the panel](#restarting-the-panel) |
| Chat delete button has no effect | Check write permission on the chat log file: `ls -l ~/PhantomSDR-Plus/chat.jsonl` |
| Waterfall message not appearing | Confirm the proxy is running (`./manage_admin.sh status`) and the frontend is on a recent build that includes the overlay renderer |
| Waterfall message lost after restart | Expected — message state is in-memory only; re-send it after restarting the admin panel |
| Spot Reporting "Start" fails / daemon exits immediately | Check `autorun.log`. Usually the missing `autorun/node_modules` symlink (`ln -sfn ../frontend/node_modules autorun/node_modules`) or `taskset` not installed (`sudo apt install -y util-linux`). |
| Spot Reporting: daemon runs but `decodes` stays 0 and `autorun.log` shows `504` / `tap closed 1006` | The audio tap can't reach spectrumserver. The daemon auto-detects the port from the **running** server's config; the `[autorun] tap backend: HOST:PORT` log line must match your `[server] port`. If it's wrong (or the server wasn't running at start), pin it in `autorun.json`: `"server": { "host": "127.0.0.1", "port": 9001 }`, then Stop→Start. |
| **SAVE CONFIG** refused: "N slots at once exceeds cap of M (UTC hour …)" | MAX SLOTS limits the slots running at the same time. Raise it, or take hours away in the SCHEDULE where the AT ONCE row is red. |
| Spot Reporting did not start after a reboot | **Start automatically after a reboot or crash** must be ticked and saved, and a **STOP** holds until **START** (the status card says `ON, held by STOP`). The AUTORUN log shows every `[admin …] autostart:` line; the panel itself must be running (`sudo systemctl status phantomsdr-admin`). |
| Spot Reporting shows "0 sent" | Normal for the first few minutes — PSK Reporter flushes every 5 min, wsprnet every 2 min. Confirm a destination is enabled and the daemon is running. |
| New bands/modes not showing in the matrix | [Restart the panel](#restarting-the-panel) — the matrix is loaded at admin start. |
| `autorun.log` shows `MODULE_TYPELESS_PACKAGE_JSON` / "Reparsing as ES module … performance overhead" | Cosmetic warning (decoding still works). `frontend/src/modules/package.json` is missing `"type": "module"`; add that line near the top, then Stop→Start. No frontend rebuild needed — the daemon imports the source file directly. |
| Spot Reporting "Start" fails with `taskset: … Invalid argument` on an old/small PC | Should not happen with the config-aware launcher — the core range is derived from the CPU count and goes unpinned on ≤ 4 cores. If seen, `admin_server.py` predates that change; update it (`_autorun_taskset_prefix`) and [restart the panel](#restarting-the-panel). |
| REPORTING badge not on the waterfall | Reporting must be ON with at least one slot; the badge reads `/autorun-active.json`. Rebuild the frontend if `dist/index.html` predates the badge. |
| **✉ SEND TEST** says "Nothing to send to: …" | The message names what is missing: tick **TELEGRAM** or **EMAIL**; Telegram needs both the bot token and the chat ID; email needs the SMTP server and **TO**. |
| Email test: `5.5.2 … Sender address rejected: need fully-qualified address` | The sender is not a full address. Put your address in **FROM**, or keep only a name there and make **USER** your full address; [restart the panel](#restarting-the-panel) if it predates that rule. |
| Telegram test fails with `Forbidden` / no message arrives | Open your bot in Telegram and press **Start** first; check the chat ID with @userinfobot (your own Id, not the bot's). |
| No alert when a receiver stopped | It takes about a minute (two checks); the same alert comes at most once per 5 minutes; a panel restart sends nothing; check the event's tick box. |
| Visitors page shows "no visitors" | The page reads `logs/users_*.jsonl` (and `instances/<id>/logs/`); those are written by the receivers' statistics logging — check they exist for the chosen days. |
| THEME selector missing, or a new theme does not apply | [Restart the panel](#restarting-the-panel), then reload the page with **Ctrl+F5** so the browser drops the old copy. |
