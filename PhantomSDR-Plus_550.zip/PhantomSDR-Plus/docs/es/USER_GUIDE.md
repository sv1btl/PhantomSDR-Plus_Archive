# Guía del usuario de PhantomSDR-Plus

¡Bienvenido a PhantomSDR-Plus! Esta guía le ayudará a sacar el máximo partido a su experiencia de escucha con WebSDR.

---

## Índice

1. [Introducción](#introducción)
2. [Primeros pasos](#primeros-pasos)
3. [Descripción de la interfaz](#descripción-de-la-interfaz)
4. [Operaciones básicas](#operaciones-básicas)
5. [Funciones avanzadas](#funciones-avanzadas)
6. [Modos de demodulación](#modos-de-demodulación)
7. [Decodificadores digitales](#decodificadores-digitales)
8. [Atajos de teclado](#atajos-de-teclado)
9. [Marcadores](#marcadores)
10. [Uso en móviles](#uso-en-móviles)
11. [Resolución de problemas](#resolución-de-problemas)

---

## Introducción

### ¿Qué es PhantomSDR-Plus?

PhantomSDR-Plus es una radio definida por software (SDR) basada en web que le permite escuchar señales de radio a través de Internet. No necesita software ni hardware especial por su parte: ¡basta con un navegador web moderno!

### ¿Qué puede escuchar?

Según la configuración del WebSDR, podrá sintonizar:

- **Radioafición**: radioaficionados de todo el mundo
- **Emisoras de radiodifusión**: radio AM/FM, emisiones en onda corta
- **Aviación**: control del tráfico aéreo, comunicaciones aeronáuticas
- **Marítimo**: comunicaciones barco-costa, meteorología marítima
- **Satélites meteorológicos**: NOAA, METEOR-M
- **Modos digitales**: FT8, RTTY, PSK31 y más
- **Estaciones de servicio**: señales horarias, militares, gubernamentales

### Requisitos del sistema

- **Navegador**: Chrome/Edge (recomendado), Firefox, Safari
- **Conexión**: Internet de banda ancha (se recomienda 1 Mbps o más)
- **Audio**: altavoces o auriculares en funcionamiento
- **Opcional**: ratón con rueda para sintonizar con mayor comodidad

---

## Primeros pasos

### 1. Acceda al WebSDR

Abra su navegador y vaya a la dirección del WebSDR que le haya facilitado el operador.

Ejemplo: `http://websdr.example.com:9000`

### 2. Carga inicial de la página

Al cargarse la página verá:
- una cascada de colores que muestra la actividad radioeléctrica
- un panel de control con el indicador de frecuencia y los botones
- un S-metro que indica la intensidad de la señal
- un indicador del número de usuarios

### 3. Empiece a escuchar

1. **Haga clic sobre una señal** en la cascada
2. **El audio comenzará automáticamente**
3. **Ajuste el volumen** con el control del navegador o el deslizador en pantalla
4. **Afine la frecuencia** haciendo clic con precisión sobre la señal

---

## Descripción de la interfaz

### Componentes principales

```
┌──────────────────────────────────────────────────────────────────────────┐
│  WebSDR <callsign>, located in <QTH>              ⚙ [ Analog S-Meter ▾ ] │
│  email · Keyboard Shortcuts · Users · Stats · Other servers 1 2 3        │
│  Frequency Search: MW SW EiBi HamDash PSK Reporter WSPRnet               │
│  Callsign Search                                                         │
│                        [ Open Additional Info ]                          │
├──────────────────────────────────────────────────────────────────────────┤
│                     Spectrum  +  Waterfall                               │
│                     band-plan strip along the bottom                     │
├───────────────────────┬────────────────────────────┬─────────────────────┤
│ Audio & Buffer        │   Frequency  │  S-Meter    │ Waterfall Controls  │
│   volume · SQ · zoom  │   7,120.00   │  dBm dBμV   │   Min · Max · zoom  │
│ AGC Auto Fast Med Slow│   band · VFO │  SNR · NF   │   colour-map strip  │
│   Compressor Equalizer├────────────────────────────┤ Zoom In Out Max Min │
│ Filters               │  Fine Tuning (kHz)         │ Waterfall Spectrum  │
│   NR NB NS AN CTCSS   │  VFO A · Modes · Bands     │ Auto Adj. Height    │
│ Modes  RADE-v2U       │           · IF Filters     │ [ profile ▾ ]       │
│   RADE-v1L RADE-v1U   │  Wheel Tuning Steps        │ [ Bookmarks ]       │
│   USB LSB CW AM QUAM  │  Decoders                  │                     │
│   FM IQ               │   FT8 FT4 FT2 JS8 CW WSPR  │                     │
│ Band selector         │   FAX SSTV NAVTEX RTTY ... │                     │
└───────────────────────┴────────────────────────────┴─────────────────────┘
```

Los tres paneles bajo la cascada se desplazan como una sola página; en una ventana estrecha se apilan en lugar de ponerse uno al lado del otro. **RADE-v2U**, **RADE-v1L** y **RADE-v1U** están en la propia línea del encabezado *Modes*, a su derecha.

### 1. Cascada (waterfall)

La cascada es una representación visual de las señales de radio:

- **Eje horizontal**: la frecuencia
- **Eje vertical**: el tiempo (se desplaza hacia abajo)
- **Colores**: la intensidad de la señal
  - **Azul oscuro/negro**: sin señal (nivel de ruido)
  - **Verde/amarillo**: señales débiles o moderadas
  - **Naranja/rojo**: señales fuertes
  - **Blanco**: señales muy fuertes

### 2. Indicador de frecuencia

Muestra la frecuencia sintonizada en distintos formatos:
- **MHz**: 7.100.000 MHz (bandas de HF)
- **kHz**: 14200 kHz
- **Hz**: 145500000 Hz (VHF/UHF)

### 3. S-metro (analógico o digital)

Muestra la intensidad de la señal:
- **S1-S9**: escala estándar de intensidad de señal
- **+dB**: señales por encima de S9 (p. ej., S9+20dB)
- **Analógico o digital**: según la configuración

### 4. Botones de modo

Seleccione el modo de demodulación:
- **AM**: modulación de amplitud
- **FM**: modulación de frecuencia
- **USB**: banda lateral superior
- **LSB**: banda lateral inferior
- **CW**: código Morse (onda continua)
- **WBFM**: FM de banda ancha (radiodifusión)
- **QUAM**: AM estéreo C-QUAM — la etiqueta se pone verde cuando se detecta un piloto estéreo
- **IQ**: I/Q en bruto — 12 kHz de la banda tal como llegan, para grabar o para otro programa (vea la sección IQ más abajo)

Junto al encabezado **Modes** están los botones **RADE-v2U**, **RADE-v1L** y **RADE-v1U**, que inician la voz digital RADE con una sola pulsación — consulte [Decodificadores digitales](#decodificadores-digitales). **RADE-v2U** inicia RADE V2 (beta), siempre en USB; **RADE-v1L** y **RADE-v1U** inician RADE v1.

### 5. Panel de control

Controles adicionales:
- **AGC**: control automático de ganancia
- **NR**: reducción de ruido (espectral)
- **NB**: supresor de impulsos
- **NS**: supresión del ruido de fondo
- **AN**: notch automático
- **CTCSS**: silenciador por subtono (FM). Al pulsarlo se abre junto al botón una pequeña ventana con *Any tone* y los 49 subtonos estándar (67,0–254,1 Hz); al elegir uno, el botón lo muestra (por ejemplo *88.5*, o *ANY*) y el audio solo pasa mientras se recibe ese subtono. La línea *Heard:* de la ventana muestra qué subtono oye el receptor en el canal en ese momento y con qué intensidad, de modo que se puede leer el subtono desconocido de un repetidor. Mientras el CTCSS está activado, el audio FM se reproduce 0,4 s por detrás del receptor, para que el silenciador ya esté abierto cuando llegan las primeras palabras de una estación; con *Any tone* el comienzo aún puede recortarse un poco, así que elija el subtono exacto siempre que pueda. Pulsar de nuevo el botón desactiva el CTCSS; Escape o un clic fuera cierra la ventana sin cambiar nada. Los marcadores guardan el tono elegido.
- **SQL**: silenciador (squelch)
- **AI**: reducción de ruido por IA (solo voz)
- **Zoom**: nivel de ampliación de la cascada
- **Wheel Tuning Steps**: paso de sintonía de la rueda del ratón, de 10 Hz a 12,5 kHz (12,5 kHz es la separación de canales en VHF/UHF)
- **Decoders**: botones que inician y detienen cada decodificador con una pulsación

### 6. Superposición del plan de bandas

Barras de color que muestran las atribuciones de frecuencia:
- colores distintos para servicios distintos
- ayuda a identificar qué está permitido en cada frecuencia

---

## Operaciones básicas

### Sintonizar una frecuencia

#### Método 1: hacer clic en la cascada

1. Haga clic directamente sobre una señal de la cascada
2. El receptor sintonizará esa frecuencia
3. Comenzará a reproducirse el audio

#### Método 2: escribir la frecuencia

1. Haga clic en cualquier punto del recuadro negro de frecuencia / S-meter, salvo sobre un dígito y salvo sobre el S-meter analógico, cuyo clic cambia su estilo
2. Se abre un teclado numérico; escriba la frecuencia con sus teclas o con el teclado (`.` o `,` como separador decimal)
3. Pulse **kHz** o **MHz** para sintonizar: la tecla que pulse fija la unidad; en el teclado, Intro equivale a kHz y `M` a MHz

**C** borra lo escrito, **⌫** borra el último dígito, y Escape o un clic fuera cierra el teclado sin sintonizar. En la vista móvil ampliada, tocar el propio campo de frecuencia abre el teclado numérico del teléfono.

Ejemplos:
- `7100` + **kHz** → 7.100 MHz
- `14.2` + **MHz** → 14.200 MHz
- `145.5` + **MHz** → 145.500 MHz

**Una frecuencia escrita trae su banda.** El receptor va a la banda en la que ha escrito igual que lo haría su botón de banda: la cascada muestra la banda completa, el brillo y el contraste toman los ajustes de esa banda y el modo sigue el plan de bandas, pero usted se queda exactamente en la frecuencia escrita. Fuera de las bandas definidas solo cambia la frecuencia. Si la estación tiene otro receptor que cubre esa frecuencia —por ejemplo `145.5` **MHz** escrito en un receptor de HF—, se abre en su lugar la página de ese receptor, ya sintonizada y encuadrada del mismo modo (vea *Elegir un receptor* más abajo).

#### Método 3: ratón sobre los dígitos

1. Sitúe el puntero sobre un dígito del indicador de frecuencia: se ilumina
2. Rueda hacia arriba o **clic izquierdo** sube ese dígito en uno; rueda hacia abajo o **clic derecho** lo baja
3. El paso es el valor posicional del dígito (1 kHz en el dígito de los kHz, 100 Hz en el primer decimal), y un dígito que pasa de 9 se lleva una unidad al dígito de su izquierda
4. En cualquier otro punto del recuadro negro de la frecuencia — nombre de banda, línea de modo, reloj — la rueda sintoniza con el paso de sintonía (**Shift** 1 kHz, **Alt** 10 kHz); solo queda fuera el S-meter analógico, donde la rueda desplaza la página

#### Método 4: botones de paso

1. Utilice los botones **▲** y **▼** junto a la frecuencia
2. El paso varía según el modo:
   - **AM/FM**: pasos de 1 kHz
   - **SSB**: pasos de 100 Hz
   - **CW**: pasos de 10 Hz

#### Método 5: botones de banda

Un botón de banda encuadra su banda —la cascada se amplía a toda la banda y el brillo y el contraste toman los ajustes de esa banda— y sintoniza la última frecuencia que usó en esa banda, sea cual sea la forma en que llegó allí (un clic en la cascada, los dígitos, un marcador, un enlace del chat…). La primera vez va a la frecuencia predeterminada de la banda. Un segundo clic en el botón de banda ya activo (resaltado) olvida la frecuencia recordada y va a la predeterminada de la banda. La memoria se guarda en su navegador, así que sobrevive a una recarga, y es solo suya.

### Escáner

El escáner recorre el receptor por un margen de canales y se detiene en el primero que lleva señal. Está en la fila **Fine Tuning (kHz)**, a la derecha del todo:

```
7 152.0   ◀  ■  ▶  ⊘   30 dB · 4 ▾
```

| Control | Qué hace |
|---------|----------|
| **◀ ▶** | Explorar hacia abajo / arriba. Detenido sobre una señal, una flecha reanuda la exploración. |
| **■** | Detener. |
| **⊘** | Excluir este canal de la exploración — para una portadora fija o un espurio. |
| **30 dB · 4 ▾** | El umbral, y a su lado el nivel que se mide en este momento. Abre los ajustes. |

El texto de la izquierda indica qué hace el escáner: `Scanner` en reposo, la frecuencia alcanzada mientras explora, `◉ 3s` mientras cuenta para reanudar,
`◉ 30·22s` mientras el canal sigue ocupado, `◉ hold` cuando se quedará ahí.

**Ajustes**

- **Range** — *Scan Band* recorre la banda donde empieza la exploración;
  *Scan Visible* recorre exactamente lo que muestra la cascada y la sigue si
hace zoom o la arrastra.
- **Scan** — *Every channel* sintoniza y escucha cada canal por turno;
  *Skip empty* lee el espectro y salta directamente a las señales.
- **Stop at** — cuánto por encima del ruido de fondo de la banda debe estar un
canal para detener la exploración, en dB. El ruido se sigue de forma continua, así que el mismo ajuste vale de día y de noche. Un canal vacío no marca 0 dB — observe un momento la cifra en el botón y ponga el umbral por encima.
- **Resume after** — cuánto tiempo debe permanecer en silencio un canal antes de
seguir. Las pausas del habla no lo reinician. *Hold* se queda hasta que pulse un botón.
- **Max stay** — sigue adelante pasado este tiempo aunque la señal continúe, para
que una portadora permanente no retenga la exploración indefinidamente.

El paso sigue al modo — 1 kHz en SSB, 0,1 kHz en CW, 5 kHz en AM, 9 o 10 kHz en onda media y 9 kHz en onda larga — y las paradas caen en la retícula de canales. La exploración se mantiene dentro de su margen y de lo que el receptor puede sintonizar; en un extremo continúa por el otro.

Los ajustes y los canales excluidos se recuerdan en su navegador.


### Seleccionar el modo de demodulación

Elija el modo adecuado para la señal:

**Para comunicaciones de voz:**
- **AM**: aviación, radiodifusión en AM, algo de radioafición
- **FM**: repetidores de VHF/UHF, radiodifusión en FM
- **USB**: radioafición en HF (20 m, 17 m, 15 m, 12 m, 10 m)
- **LSB**: radioafición en HF (160 m, 80 m, 40 m, 30 m)

**Para datos/digital:**
- **USB**: la mayoría de los modos digitales (FT8, PSK31, RTTY)
- **LSB**: algunos modos digitales en las bandas bajas de HF

**Para código Morse:**
- **CW**: señales de telegrafía/Morse

### Ajustar el volumen

- **Deslizador en pantalla**: arrastre el control de volumen. 0 % es silencio; por debajo del 50 % el nivel baja de forma suave y con pasos finos, y del 50 % hacia arriba cada paso es de 0,4 dB. La página recuerda dónde dejó el deslizador, en la página de escritorio y en /mobile; en la primera visita empieza donde lo fijó el sysop (50 % salvo otro ajuste).
- **Volumen del navegador**: use los controles multimedia del navegador
- **Volumen del sistema**: ajuste el volumen del ordenador
- **Teclado**: use las teclas + y - (si están admitidas)

### Uso del S-metro

El S-metro indica la intensidad de la señal:

- **S0-S3**: señal muy débil, difícil de copiar
- **S4-S6**: señal débil o aceptable
- **S7-S9**: señal buena o fuerte
- **S9+**: señal extremadamente fuerte

**Consejo**: para obtener el mejor audio, sintonice señales que marquen S7 o más.

**Cambiar la esfera del instrumento**: en el S-meter analógico (de aguja), haga clic sobre el propio instrumento —o enfóquelo y pulse Enter o Espacio— para recorrer tres fondos: metal cepillado oscuro, una esfera clara gris pálido y una cálida esfera ámbar de estilo vintage. Su navegador recuerda la elección, así que sigue ahí tras una recarga o un reinicio. Es por navegador y por dirección: abrir el receptor por nombre de host y por IP da dos ajustes separados, y una ventana privada siempre parte del valor por defecto del sitio.

**Por encima de 30 MHz** el S-metro sigue la norma de VHF de la IARU Región 1: allí S9 está en −93 dBm en lugar de −73 dBm en HF, igualmente con seis dB por unidad S. La aguja y la barra cambian solas con la frecuencia sintonizada; las cifras en dBm y dBµV muestran siempre el nivel medido. Algunas estaciones configuran además sus receptores de VHF/UHF para que los medidores se queden en **0 con el canal vacío**, como en un transceptor de VHF/UHF: por encima de 60 MHz la aguja y la barra solo suben entonces cuando una señal destaca sobre el ruido. Las cifras de dBm, dBµV, SNR y NF muestran siempre los valores reales.

### Gráfica de intensidad de señal

**Video** en **Recording Options** graba el espectro y la cascada junto con el audio (**Area** elige una parte de ellos). Una barra en la parte inferior de la imagen muestra la frecuencia, el modo y la hora, y la frecuencia sintonizada se marca con las mismas líneas amarillas que el sintonizador en pantalla: líneas amarillas punteadas en la frecuencia y en los bordes de la banda de paso, y el corchete sobre la cascada.

En **Recording Options**, el botón **Plotter** junto a Audio, Video y Area dibuja la lectura del S-metro como una gráfica en marcha — útil para ver el desvanecimiento, comparar dos antenas o emisoras o ver cuándo se abre una banda. Cada clic pasa por **Off → Fast → Medium → Slow**: la gráfica muestra los últimos 10, 30 o 60 segundos, con la lectura más reciente a la derecha, y su navegador recuerda la elección. Muestra la misma cifra en dBm que el S-metro digital, 20 veces por segundo; la escala izquierda va en unidades S (la escala VHF por encima de 30 MHz) y la derecha en dBm, y el rango sigue a la señal por sí solo. La línea superior muestra la lectura actual y el máximo (**pk**) del intervalo mostrado, dibujado también como una línea roja discontinua; una línea amarilla con la nueva frecuencia marca cada cambio de sintonía. Arriba a la derecha, **❚❚** detiene la gráfica (**▶** continúa) y **PNG** la guarda como imagen, `PhantomSDR_signal_<UTC>_<kHz>kHz.png`. Apagada, no cuesta nada.

### Elegir un receptor

Algunas estaciones tienen más de un receptor — por ejemplo uno para HF y otro para la banda de 2 m. Muestran en la cabecera de la página una línea *Receivers:* con un botón por receptor; aquel en el que está aparece en amarillo. Al pulsar otro botón se abre la página de ese receptor, con su propia cascada, bandas, chat y lista de oyentes. En la página /mobile los mismos botones están en la barra superior. Una estación con un solo receptor no muestra esa línea.

**Show All.** Tras los botones de receptor hay una casilla **Show All**. Al marcarla, cada uno de los demás receptores de la estación aparece bajo su cascada —su espectro y su cascada, con sus propios marcadores y su escala de frecuencias, la línea más reciente arriba—. Al pasar el ratón por encima se lee la frecuencia y el marcador más cercano; un clic abre ese receptor ahí, en la misma pestaña: sobre un marcador en el modo del marcador, en otro punto en el modo que da el plan de bandas. Su navegador recuerda la casilla, que está desmarcada hasta que usted la marque, porque cada franja es un flujo de cascada más (unos 10 KB/s).

**Se conserva la vista que dejó.** Al salir de la página de un receptor se guardan su zoom, brillo, contraste, modo y frecuencia. Su franja en la otra página muestra entonces esa misma parte de la banda, con un pequeño ▼ verde donde estaba sintonizado; el botón de la cabecera de la franja muestra ese rango y **Full span** —púlselo para ver todo el rango del receptor, y **Last view** para volver—. Un clic en una frecuencia dentro de esa vista reabre el receptor tal cual, con el mismo zoom, los mismos niveles y el mismo modo, en lugar de todo su rango.

**Elegir una banda en la franja.** Cuando el otro receptor cubre más de una banda —el receptor de HF visto desde la página de 2 m—, la cabecera de la franja tiene una lista desplegable en lugar de ese botón: **Last view**, **Full span** y cada banda de ese receptor, las mismas que muestran sus botones de banda. Elija una banda y la franja la muestra como lo hace ese botón de banda, de borde a borde con el brillo y el contraste de la banda; un clic en la franja abre entonces ese receptor encuadrado en la banda, sintonizado donde hizo clic. Su elección se guarda en su navegador, por separado para cada receptor. Un receptor con una sola banda, como 2 m, conserva el botón.

**El receptor adecuado, por sí solo.** Una frecuencia que este receptor no cubre pero sí otro receptor de la estación —escrita, desde un enlace, un marcador, un spot DX, un mensaje del chat o la etiqueta de otro oyente— abre la página de ese receptor, sintonizada ahí. La rueda del ratón y los pasos de los dígitos nunca cambian de receptor, y tampoco un transceptor conectado por CAT.

### Horario EiBi

El botón **EiBi** de la fila Frequency Search, tras **SW**, abre una ventana que busca en el horario EiBi: la lista mundial de emisiones de onda larga, media y corta y de estaciones utilitarias que mantiene Eike Bierwirth ([eibispace.de](http://www.eibispace.de/dx/)), la base de datos sobre la que está hecho shortwave.live. La estación la mantiene al día por sí sola.

**Buscar.** Ponga los filtros que quiera; la lista cambia con ellos.

- **Station**: escriba parte de un nombre; se proponen nombres mientras escribe.
- **Language**, **Target area**, **Station country**, **Transmitter in**: elija en las listas (idioma, zona de destino, país de la estación, país del transmisor).
- **Band**: onda larga, onda media, toda la onda corta, una banda de radiodifusión de 120 m a 11 m, o VLF/LF.
- **Frequency (kHz, ±2)**: todo lo que esté a menos de 2 kHz; **dial** pone la frecuencia sintonizada.
- **Time (UTC)**: *Any time* (cualquier hora), *On air now* (en el aire ahora) u *On air at* a una hora que escriba (**now** pone la hora UTC actual).
- **Today only** oculta lo que no está previsto para el día de hoy (día de la semana o fecha). **Receivable here** oculta las frecuencias que este receptor no cubre.

Las estaciones que emiten en este momento aparecen en verde. Pulse un encabezado de columna para ordenar por él, y pase el ratón sobre una fila para ver todos sus datos: lugar del transmisor, fechas de validez, cuándo se escuchó por última vez. **Reset** borra los filtros. La ventana recuerda sus filtros en su navegador.

**Sintonizar.** Pulse una fila. El receptor sintoniza la estación en el modo de la columna **Mode**: AM para radiodifusión, USB o LSB para voz utilitaria (Volmet, estaciones costeras, marinas de guerra), CW para estaciones Morse. Un modo en ámbar (FAX, HFDL, DRM, NAVTEX, RTTY-WX y CW) también arranca su decodificador, igual que un marcador de decodificador en la cascada; una fila CW abre el decodificador CW. La cascada se acerca a 100 kHz alrededor de la estación, y un marcador rojo con el nombre de la estación en amarillo indica lo que está escuchando; desaparece cuando sintoniza a más de 200 Hz de él. Una estación fuera del rango de este receptor abre el receptor que la cubre, si la estación tiene uno. La fila pulsada se pone roja en la lista mientras siga en esa estación.

**Show on waterfall** pone los resultados en la cascada como marcadores con un fino marco verde y letras verdes (con zoom, como los demás marcadores). Se quedan después de cerrar la ventana, hasta que desmarque la casilla o recargue la página. Pulsar uno sintoniza igual que una fila, y su fila se pone roja en la lista.

**Hide HFCC markers** oculta los marcadores amarillos que vienen del horario de emisiones HFCC, para que solo se vean los de EiBi. Sus propios marcadores y los marcadores de decodificador se quedan. El ajuste se mantiene al cerrar la ventana y se recuerda en su navegador; desmárquelo para que vuelvan.

La ventana se abre en el centro de la pantalla y se puede arrastrar por su título. **Esc**, **✕**, el botón **EiBi** o un clic en cualquier punto fuera de ella la cierran.

> El modo de cada fila se deduce de lo que EiBi escribe sobre la estación, así que algunos pueden ser erróneos. Los marcadores amarillos de la cascada vienen de otra lista (HFCC); esta ventana puede ocultarlos, pero nunca los cambia.

---

## Funciones avanzadas

### Control automático de ganancia (AGC)

El AGC mantiene el audio a un nivel estable. Los cuatro botones funcionan como el conmutador de AGC de un transceptor: los cuatro dan el mismo volumen y solo se diferencian en lo rápido que vuelve a subir la ganancia cuando una señal se debilita o desaparece.

- **Auto**: el AGC propio del receptor, ajustado por separado para SSB, AM y C-QUAM. Es el valor predeterminado.
- **Fast**: sin retención; la ganancia se recupera en unos 0,3 s. El ruido sube entre palabras y el desvanecimiento rápido se sigue de cerca. Bueno para CW y para distinguir una estación débil entre otras fuertes.
- **Medium**: retiene 0,25 s y luego se recupera en unos 1,2 s. Un buen ajuste de uso diario para SSB.
- **Slow**: retiene 1 s y luego se recupera en unos 3 s. El fondo se mantiene bajo entre palabras y entre pasadas; una estación débil justo después de una fuerte suena más baja durante unos segundos.

**Mientras haya un decodificador abierto**, el AGC se mantiene en Slow, sea cual sea el botón seleccionado: el decodificador oye el mismo audio que usted y necesita una ganancia estable. Junto al título AGC aparece una pequeña nota **Slow (decoder)**, y su propia elección vuelve en cuanto se cierra el último decodificador.

**Recomendación**: empiece con «Fast» para AM y «Slow» para SSB.

### Los cuatro controles de ruido

NR, NB, NS y AN son botones de encendido/apagado independientes, cada uno contra un tipo distinto de ruido. Son independientes entre sí — encender uno no enciende otro — y se pueden combinar libremente.

Ninguno llega a los decodificadores: FT8, CW, WSPR, SSTV, FAX, NAVTEX, RTTY/PSK31/Olivia/Packet/APRS y el grabber QRSS leen el audio *antes* de estos filtros, así que puede ajustarlos puramente de oído sin afectar a lo que se decodifica. Véase el [manual de decodificadores](DECODERS.md#14-consejos-generales).

### Reducción de ruido (NR)

Reducción de ruido espectral. Estima el nivel de ruido en cada parte del espectro de audio y baja esas partes, dejando en paz lo que sobresale del ruido.

**Úselo cuando**: oiga un siseo constante o ruido blanco detrás de la señal.

Los tonos constantes — una nota de CW, una portadora — se reconocen como señal y quedan protegidos, de modo que NR no se come una señal de CW como haría un filtro ingenuo. Efecto típico: 10–12 dB menos de ruido entre las palabras. La voz misma pierde bastante menos de 1 dB en señales fuertes y unos pocos dB en las muy débiles, que aun así se entienden mejor que sin NR.

### Supresor de impulsos (NB)

Elimina el ruido impulsivo: clics, chasquidos, descargas atmosféricas, encendido de motores y ruido de la red eléctrica. Vigila la envolvente del audio y silencia solo las muestras que se disparan muy por encima de ella — alrededor de un milisegundo por descarga, con entrada y salida suavizadas para que el propio recorte no produzca un clic.

**Úselo cuando**: oiga clics o chasquidos de líneas eléctricas, motores,
tormentas o encendido de vehículos.

Los notch de zumbido de red de 50 Hz y 60 Hz siguen a este botón.

### Supresión del ruido de fondo (NS)

Mide durante varios segundos el propio suelo de ruido de la banda y aplica un corte fijo a lo que se sitúa en él, más profundo en las frecuencias de audio altas que en las bajas. Donde NR reacciona instante a instante, NS es la mano lenta y firme: baja el siseo de la banda sin cambiar cómo suena la señal.

**Úselo cuando**: la banda esté tranquila pero siseante y quiera bajar el ruido
sin la calidad "submarina" de una NR agresiva.

Activo solo en USB, LSB y AM: CW, FM y los modos digitales quedan intactos. Vuelve a medir el suelo cada vez que cambia de frecuencia o de modo, y se asienta en pocos segundos.

### Notch automático (AN)

Encuentra y elimina automáticamente tonos interferentes constantes — heterodinos, portadoras, silbidos — sin que usted tenga que colocar un notch a mano. Se adapta de forma continua, así que puede quitar varios tonos a la vez y mantener notchado uno que derive.

**Úselo cuando**: oiga un silbido o tono encima de la señal que quiere.

Se desactiva en CW, donde la señal deseada *es* un tono constante.

**Nota sobre el retardo**: NR y NS añaden cada uno unos 40 ms de retardo de audio
mientras están activos (los dos juntos, unos 80 ms). NB y AN no añaden ninguno. Esto afecta solo a la escucha, nunca a los decodificadores.

### Silenciador automático (SQL)

Silencia el audio cuando no hay señal:

- **Off**: siempre suena (se oye la estática)
- **Auto**: fija el umbral automáticamente
- **Manual**: ajuste manual del umbral

**Úselo cuando**: vigile una frecuencia a la espera de actividad.

Mientras SQ está apagado, el número del umbral junto al deslizador se muestra en gris.

### Reducción de ruido por IA (AI)

El botón **AI**, con un deslizador de intensidad al lado, está en el panel Audio & Buffer, justo debajo de SQ. En la página /mobile está en la pestaña Audio, debajo de Squelch. Elimina el ruido de banda de la voz mediante RNNoise, una pequeña red neuronal entrenada con voz.

Todo ocurre en su propio navegador: no se envía nada a ningún servidor externo, no hace falta cuenta y el receptor no tiene trabajo adicional.

- **Encendido/apagado**: pulse **AI**; el botón se vuelve azul. La primera pulsación descarga el módulo (unos 1,3 MB) y el botón parpadea mientras carga.
- **Intensidad**: fija con qué intensidad actúa mientras alguien habla: los valores más bajos conservan más del sonido original. El extremo superior de la escala es a propósito más suave que un corte total, para que la voz no se dañe ni siquiera al 100 %, que aun así limpia más que el 50 %. Entre palabras actúa con más fuerza por sí sola, de modo que el soplido baja aún más ahí. El valor por defecto es 50 %. Puede ajustarlo con la IA apagada.
- **Indicador de estado**: el indicador AI bajo la frecuencia se enciende en cian mientras AI trabaja, y aparece medio atenuado cuando AI está activo pero el modo actual no es de voz.

**Úselo cuando**: escuche voz en SSB o AM en una banda ruidosa. El soplido entre palabras suele bajar unos 10 dB con el 50 % predeterminado, y más al 100 %, hasta unos 20 dB, mientras la voz conserva su nivel.

Solo modos de voz — USB, LSB, AM y SAM. En CW, FM, modos digitales y C-QUAM el audio pasa sin cambios, porque la red trata un tono de CW o la música como ruido. Como los cuatro controles de ruido, nunca llega a los decodificadores. En estaciones débiles (por debajo de unos +6 dB de SNR) mide ella misma la relación señal/ruido y suaviza más sus decisiones, para que la voz no adquiera el sonido burbujeante, «acuoso», que puede dar este tipo de filtro; las estaciones fuertes se procesan exactamente igual que antes. Si una señal muy débil aún suena procesada, baje el control. Añade unos 50 ms de retardo al audio.

### Búfer de audio y retardo

El audio llega al navegador en pequeños paquetes, de 35 ms cada uno en un receptor típico, y el navegador guarda un poco de reserva para que un paquete que llega tarde no provoque un hueco. Esa reserva es el **búfer**, y es la mayor parte del retardo entre el receptor y su altavoz.

- **Escritorio**: en el panel Audio & Buffer, el botón con el icono de red sube el búfer un paso por clic (se pone verde por encima del paso más bajo), y el control deslizante de al lado elige directamente un paso del 1 al 6. El paso más bajo va bien con una conexión por cable; los teléfonos empiezan en el paso 2.
- **/mobile**: el botón **BUF** y el control **Buffer** de la pestaña Audio hacen lo mismo.

Si el audio se corta, suba el búfer un paso. En un teléfono con Wi-Fi doméstico el retardo del receptor al altavoz suele ser de unos 100–150 ms; la red entre usted y el receptor se suma a eso.

### Su nombre o indicativo

Junto a **Open Additional Info** hay una casilla para su nombre o indicativo: hasta 10 caracteres y sin espacios, como en un WebSDR. Escríbalo y pulse **Save** (o Intro); con **Edit** lo cambia más tarde. Su navegador lo recuerda, también cuando pasa a los otros receptores de la estación. Si la deja vacía, sigue anónimo: *anonymous* más un número en el chat, y solo su ubicación en todo lo demás. En el teléfono la misma casilla está encima del indicador de frecuencia.

Su nombre aparece en la ventana **Users**, en sus líneas del chat y en la etiqueta que los demás oyentes ven bajo su cascada — su nombre y después su ubicación, por ejemplo `SV1BTL-Athens`. Su propia posición es la ★ amarilla con su nombre al lado. Pase el ratón sobre la etiqueta de otro oyente para ver la frecuencia y el modo en que está sintonizado; con un clic sintoniza allí.

Como en un WebSDR, la dirección IP de ningún oyente se muestra a los demás — ni en la ventana Users ni en las Estadísticas de usuarios, que cuentan los visitantes con un código anónimo.

La ventana Users muestra también qué decodificador usa cada oyente — FT8, CW, DRM, HFDL, etc. — como una pequeña etiqueta verde tras el modo, y las Estadísticas de usuarios tienen un panel **Decoder Popularity**: cuántas sesiones usaron cada decodificador. En la ventana Users abierta desde la página del receptor, **Tune** junto a un oyente le pone en lo que él escucha: la misma frecuencia y modo, su ancho de filtro y su decodificador — que se inicia para usted, o se detiene el suyo si él no usa ninguno. Después la banda se encuadra como con **To Band**: la cascada muestra toda la banda en la que está, con el brillo, el contraste y el paso de sintonía de esa banda.

### Propagación en las bandas

Bajo **Open Additional Info**, junto a *Current band propagation and statistics:*, el botón **🌐 Propagation** abre una página con las condiciones de las bandas para la ubicación de este receptor. Califica cada banda de 160 m a 6 m como Good, Fair, Poor o Closed, para cinco distancias (hasta 300 km, 300–1000 km, 1000–2000 km, 2000–3000 km y DX a más de 3000 km). La calificación sale de las mediciones en directo de las ionosondas más cercanas (foF2 y MUF), la posición del sol y los datos solares y geomagnéticos (flujo solar, Kp, rayos X, viento solar). El mapa es un globo centrado en la estación: arrástrelo para girarlo, arrastre con el botón derecho (o Ctrl + arrastrar) para inclinarlo, y **2D / 3D** cambia a un mapa plano. Sus anillos de **alcance por banda** muestran, para cada banda abierta, un anillo discontinuo donde termina su zona de salto y uno continuo en su alcance máximo; la leyenda bajo el mapa da el intervalo de cada banda, y un clic en una banda muestra solo su zona abierta, sombreada por Good / Fair / Poor. El globo muestra además las curvas de MUF y foF2, el día y la noche con la línea gris, y todas las ionosondas que informan ahora en el mundo — brillantes las usadas aquí. Los interruptores de capas en su esquina activan o desactivan cada una. Los anillos siguen a la ionosfera dirección por dirección — donde se refleja el trayecto, el sol allí, el óvalo auroral —, así que una banda suele llegar más lejos hacia un lado que hacia otro; la tabla de arriba es la vista justo encima de la estación. El globo necesita un navegador con WebGL2. La página se actualiza sola cada 10 minutos. Es una estimación para trayectos desde este receptor, no un registro de lo que se está oyendo.

### Chat

Cuando el operador ha habilitado el chat, tiene su propio panel en la página de escritorio y una pestaña **Chat** en /mobile. Escriba su mensaje y envíelo: sale con el nombre de su casilla de nombre (véase arriba), o como *anonymous* más un número.

Para responder a un mensaje concreto, pulse **↪ Reply** junto a su hora. Una línea sobre el cuadro de entrada muestra a quién y a qué responde; escriba y envíe como siempre, o pulse ✕ o Esc para cancelar. La respuesta aparece sangrada bajo el mensaje al que responde, con una breve línea de cita. Una respuesta a una respuesta se une al mismo hilo. El servidor guarda los últimos 20 mensajes; cuando el original ya ha salido de ese historial, la respuesta muestra solo el nombre y la hora a los que responde.

Una frecuencia en un mensaje es un enlace: un clic sintoniza allí, en el modo indicado con ella. La banda se encuadra como con **To Band** —la cascada muestra toda la banda, con el brillo y el contraste de esa banda— y el botón de la banda se ilumina.

### Función de zoom

Amplía la cascada:

El deslizador **Zoom** tiene 20 pasos, mostrados como ×1 a ×20 (el paso, no una ampliación). ×1 muestra todo el receptor; cada paso estrecha la vista alrededor de la sintonía en el mismo factor, de modo que el zoom crece de forma uniforme, hasta unos pocos kHz en ×20. El botón junto al deslizador avanza un paso en cada clic y vuelve a ×1 después de ×20.

**Úsela cuando**: necesite ver las señales con más claridad o sintonizar con precisión.

**To Band** muestra la banda entera de la frecuencia sintonizada, con 5 kHz de margen en cada extremo.

### Auto Adj. (cascada)

El interruptor **Auto Adj.** de los controles de la cascada ajusta por usted el brillo y el contraste de la cascada. Mide el ruido de fondo en todo el tramo visible y lo convierte en un fondo oscuro y uniforme —también donde el ruido difiere de una parte del tramo a otra— y estira todo lo que queda por encima, de modo que las señales débiles destacan y las más fuertes llegan a los colores superiores. Funciona igual con cualquier mapa de color, y solo cambia la cascada: la traza del espectro conserva su escala real en dB. Mientras está activo, los controles Min y Max quedan bloqueados y muestran el ruido de fondo y el pico medidos; al desactivarlo vuelven a los ajustes de la banda.

### Espectro 3D

El botón **3D**, junto a **Reverse** en los controles de la cascada, convierte el espectro en un relieve de los últimos segundos: la frecuencia a lo ancho, el tiempo hacia el fondo de la pantalla y la intensidad de la señal como altura. Usa los mismos colores, el mismo brillo (Min), el mismo contraste (Max) y el mismo Auto Adj. que la cascada, y sigue el zoom y el arrastre como el espectro plano. Un clic sintoniza, arrastrar recorre la banda y la rueda del ratón hace zoom, exactamente como en el espectro plano. El relieve se estrecha hacia el fondo como una mesa vista en ángulo, y cuanto más atrás está una fila, más bajos son sus picos. Un clic en una fila más antigua sintoniza la frecuencia de esa fila, y la frecuencia que se muestra bajo el ratón indica entonces también la edad de la fila (por ejemplo 7.074.000 · −6 s). El botón **⚙** abre dos deslizadores: **Angle** (cuánto sube el suelo hacia el fondo) y **Depth** (cuánto se estrecha el relieve y bajan sus filas hacia el fondo); **Reset** vuelve a los valores por defecto, y su ajuste se recuerda en el navegador. Las marcas de la izquierda indican cuántos segundos atrás está una fila; las de la derecha, cuántos dB por encima del nivel Min llega un pico (se ocultan mientras Auto Adj. está activo). **✕ 2D**, o el botón 3D de nuevo, vuelve al espectro plano, y su elección se recuerda en el navegador. La vista necesita WebGL2, que ofrece cualquier navegador actual; sin él el botón no aparece. Una grabación de vídeo hecha con la vista 3D abierta graba la vista 3D en lugar del espectro plano. La vista 3D está adaptada de PhantomSDR-ORSAT, de F1NSK.

**Línea del cursor.** Dondequiera que esté el ratón sobre el espectro, la cascada o la vista 3D, una línea amarilla discontinua marca esa frecuencia en el espectro y en la cascada, y el espectro la muestra en MHz.

### Analizador de audio

El botón **📊 Show** de la sección Spectrogram abre el analizador de audio bajo la cascada; **📊 Hide** lo cierra. Muestra el audio que oye, tras la demodulación, como un espectro con rejilla en dB y una línea amarilla de picos. **Gain** sube o baja la traza y **Color** elige sus colores. El espectro se dibuja en relieve, iluminado desde arriba a la derecha. En los colores Rainbow cada barra se colorea según cuánto sobresale del ruido en su frecuencia —azul oscuro para el ruido, también en las pausas de la voz cuando el AGC lo eleva, y luego azul, cian, amarillo, naranja y rojo para señales cada vez más fuertes—, mientras su altura se sigue leyendo en la escala de dB. Como el espectro principal, el analizador y sus informes se dibujan sobre fondo negro, con líneas de cuadrícula grises.

- **Eje de frecuencias.** Sigue el modo: 0–4,5 kHz en SSB, 0–2 kHz en CW, 0–5,5 kHz en AM y FM. En LSB está invertido (los tonos agudos a la izquierda), de modo que se lee en la misma dirección que el espectro de RF. Una línea cian marca la frecuencia sintonizada (en CW, la nota de 600 Hz), y bajo el ratón el analizador muestra la frecuencia de audio y la frecuencia de RF en kHz.
- **Marcas de ancho de banda.** Marcas de colores indican los anchos recomendados para el modo — SSB estándar 300–2700 Hz y ESSB 50–4000 Hz, CW 500 Hz y 250 Hz, AM de radiodifusión y AM de radioaficionado — y un recuadro blanco discontinuo muestra su filtro actual. El ancho estándar se dibuja con una línea cian continua y el alternativo (ESSB, CW 250 Hz, AM de radioaficionado) con una línea azul claro discontinua.
- **Vista RF en AM y FM.** El audio demodulado no tiene portadora, así que en estos modos el analizador muestra la estación tal como está en la cascada: la portadora en el centro y las bandas laterales a cada lado. Su escala está en dB sobre el ruido.
- **Ancho ocupado.** La línea bajo el espectro da el ancho que ocupa la estación sintonizada (método de −26 dB, medido en la cascada) con un veredicto para SSB, AM y CW: verde dentro de la norma, ámbar ancho (una estación ESSB sale en ámbar), rojo para un splatter probable, que además se sombrea en el espectro. Necesita unos 2 s de medidas; los chasquidos de estática se ignoran.
- **Sin necesidad de zoom.** Mientras el analizador está abierto, la página mantiene una segunda conexión de cascada, invisible, centrada en la estación y con la resolución fina que necesitan las medidas; así la vista RF y todas las medidas de RF funcionan con cualquier zoom de la cascada. Se cierra con el analizador. Cuesta unos 12–14 KB/s (unos 45 MB por hora) de datos adicionales mientras el analizador está abierto; con una conexión de datos limitada, ciérrelo cuando no lo necesite.
- **Sintonizar desde el analizador.** La frecuencia de la cabecera del analizador sintoniza como el dial principal: pase el ratón sobre un dígito y gire la rueda, o clic izquierdo para subir un paso y clic derecho para bajar; un clic junto a los dígitos abre el teclado numérico. Un clic en la etiqueta del modo abre un menú con los modos.
- **Mute.** El botón Mute de la cabecera del analizador silencia el receptor mientras el análisis continúa — para comprobar su propia emisión sin devolverla al micrófono. El sonido silenciado desde ahí vuelve al cerrar el analizador.

**Informe de audio SSB.** En USB y LSB se abre bajo el analizador un panel de informe. Sobre una ventana deslizante de 20 s, y solo mientras la estación habla, juzga el equilibrio tonal — graves (100–300 Hz) y presencia (1,5–2,7 kHz) frente a los medios, comparados con la referencia que elija: **Standard SSB**, **DX / punch** o **ESSB / hi-fi** — y después la compresión, el zumbido de red (rayas en 50/100/150 o 60/120/180 Hz), la portadora residual y la banda lateral opuesta (ambas medidas en la cascada) y el ancho ocupado. Cada fila recibe un punto verde, ámbar o rojo; una fila que no se puede medir dice por qué, normalmente por el filtro de recepción (para los graves su borde inferior debe estar en unos 120 Hz o menos). Por encima de 2,7 kHz no se juzga nada, aunque el analizador lo sigue mostrando. La forma media de la voz se dibuja en el analizador como una curva azul. **Store A** la guarda como la curva discontinua A, para comparar después de que el corresponsal cambie un ajuste; **Clear A** la borra y **↺ Restart** empieza de nuevo los 20 s. **Generate a listening report** descarga un archivo HTML para enviar al corresponsal, con los veredictos, una imagen del espectro y los últimos 20 segundos de audio. Las medidas son orientativas: el fading y el filtro y el AGC del receptor influyen, así que prefiera el AGC lento (Slow). El analizador y el informe están adaptados de PhantomSDR-ORSAT, de F1NSK.

**Informe de AM y FM.** En AM, C-QUAM y FM se abre en su lugar, bajo el analizador, un panel de informe para estos modos. Aquí el audio del receptor dice poco del transmisor —la portadora de AM se elimina del audio y el AGC fija el nivel—, así que el informe juzga la estación sobre todo en el espectro de RF, en una ventana deslizante de 20 s. En **AM**: la profundidad de modulación (media y pico, a partir de la potencia de las bandas laterales frente a la portadora), el equilibrio de las dos bandas laterales, el desplazamiento de la portadora respecto a la frecuencia sintonizada, el ancho del audio, el zumbido de red y el ancho ocupado. En **FM**: la desviación (aproximada, a partir del ancho del 99 % por la regla de Carson), el ancho del 99 % con el canal en que cabe (12,5 o 25 kHz), el desplazamiento de frecuencia, el ancho del audio, el tono CTCSS si lo hay y el zumbido de red. La cascada promedia cada línea durante unos 0,1 s, por lo que la profundidad de pico sale más baja que en un osciloscopio; una portadora que llega al tope de la escala de la cascada es demasiado fuerte para medirla, y el informe lo indica. El desplazamiento de la portadora incluye también el error de frecuencia del propio receptor. **↺ Restart** y **Generate a listening report** funcionan como en el informe de SSB.

### Control del transceptor (CAT)

Su propio transceptor y la página del receptor pueden mantenerse en la misma frecuencia: gire el dial del equipo y la cascada lo sigue, o haga clic en una señal de la cascada y el equipo se sintoniza en ella. Solo afecta a *su* sesión de escucha; nadie más en el receptor lo nota.

**Con Desktop PhantomSDR+ (4.0 o posterior).** La aplicación de escritorio tiene un menú **Rig**. *Rig → Rig control...* abre una ventana donde elige su equipo y la forma de conectarlo, y el propio menú activa y desactiva la sincronización. Sincroniza frecuencia, modo y ancho de filtro, en un sentido o en ambos, y puede silenciar el receptor mientras transmite. Además de PhantomSDR-Plus maneja del mismo modo receptores **KiwiSDR, PA3FWM WebSDR y UberSDR**. Llega al equipo de una de estas cuatro formas:

- **Integrado** — sin otro software: Icom (CI-V), Yaesu (CAT nuevo y FT-817/857/897), Kenwood, Elecraft, FlexRadio SmartSDR CAT, QRP Labs y otros equipos compatibles con Kenwood.
- **Hamlib** — cualquier equipo que conozca Hamlib, más de 300, elegido de una lista con búsqueda. Los instaladores de Windows incluyen Hamlib; en Linux instale `libhamlib-utils`.
- **rigctld en la red** — un `rigctld` que ya está en marcha.
- **flrig** — para un equipo que flrig ya comparte con fldigi, WSJT-X o un programa de registro.

La aplicación, sus instaladores y su manual completo están en [Desktop PhantomSDR+ (Dropbox)](https://www.dropbox.com/scl/fo/kjwj96zg3kj7dgq4fjef9/APnA3c9hhv4hk3YMGIGjH7s?rlkey=jfiwklly63kv73poalx631pk3&st=m37uvaym&dl=0).

**Con un navegador web.** La [CATsync Tool for WebSDRs](https://catsyncsdr.wordpress.com/) (Windows) acopla un equipo a la página del receptor abierta en su navegador. Sincroniza frecuencia y modo.

**El ancho de filtro y el silencio al transmitir** funcionan en receptores KiwiSDR, WebSDR y UberSDR, y en un receptor PhantomSDR-Plus con la 4.1.0 o posterior. En un PhantomSDR-Plus más antiguo la frecuencia y el modo siguen sincronizándose; el filtro no.

El manual completo — cada ajuste, los equipos admitidos, cómo se evita que los dos lados se peleen y la solución de problemas — es **[Control del transceptor](RIG_CONTROL.md)**.

---

## Modos de demodulación

### AM (modulación de amplitud)

**Se usa para:**
- comunicaciones aeronáuticas
- radiodifusión en AM
- parte de la radioafición
- comunicaciones marítimas

### QUAM (AM estéreo C-QUAM)

**Se usa para:**
- Emisoras de onda media que transmiten AM estéreo

**Características:**
- 10 kHz de ancho, se decodifica como par estéreo en lugar de AM mono
- La etiqueta del botón se pone **verde** por sí sola cuando está presente el piloto estéreo de 25 Hz, así se ve qué emisoras están realmente en estéreo antes de seleccionarlo
- Desde AM, pulsar de nuevo el botón pasa a detección síncrona sobre la portadora; la etiqueta se pone **amarilla** y muestra `SAM`. Una tercera pulsación vuelve al AM normal
- Mientras SAM funciona, bajo los indicadores de estado aparece una línea como `SAM +3.2 Hz · 97%` (con el S-meter digital, bajo VFO | modo | ancho de banda): cuánto se aparta la portadora de la emisora del dial (+ = por encima) y lo bien enganchado que está el detector — amarilla desde el 85 %, gris de nuevo por debajo del 60 %. El amarillo solo indica que hay una portadora estable, no qué modo es: una portadora AM corriente en una frecuencia marcada como DRM también la pone amarilla
- El audio C-QUAM viaja con Opus; el resto de modos usa FLAC

**Buenas prácticas:**
- Busque la etiqueta verde en señales fuertes de onda media por la noche
- Si el estéreo suena inestable, `SAM` es más firme con portadora débil

### FM (modulación de frecuencia)

**Se usa para:**
- repetidores de radioafición de VHF/UHF
- servicios públicos (policía, bomberos, emergencias)
- radio comercial bidireccional
- algunas comunicaciones por satélite

### USB (banda lateral superior)

**Se usa para:**
- radioafición en HF (por encima de 10 MHz)
- la mayoría de los modos digitales de HF
- comunicaciones marítimas (por encima de 8 MHz)

### LSB (banda lateral inferior)

**Se usa para:**
- radioafición en HF (por debajo de 10 MHz)
- algunos modos digitales de HF
- comunicaciones marítimas (por debajo de 8 MHz)

### CW (onda continua / código Morse)

**Se usa para:**
- telegrafía de radioaficionados
- radiobalizas de navegación
- estaciones de señales horarias

### CW-L (CW, banda lateral inferior)

El mismo filtro Morse de ±250 Hz que **CW**, pero el tono se toma por debajo de la portadora en lugar de por encima. Úselo cuando una señal se copie mejor por el lado bajo, o cuando una portadora interferente quede justo por encima de la deseada.

**No hay botón CW-L en la página de escritorio.** Su fila de modos es `USB · LSB · CW · AM · QUAM · FM · IQ`. CW-L se ofrece en la página simplificada `/mobile`, y en escritorio todavía puede fijarse mediante un enlace o un marcador que lo nombre.

También funcionan los enlaces escritos para KiwiSDR o UberSDR: `modulation=CWU` (o `CW-U`) abre en CW y `modulation=CWL` en CW-L.

### WBFM (FM de banda ancha)

**Se usa para:**
- radiodifusión en FM (88-108 MHz)
- algunos enlaces descendentes de satélite

### IQ (I/Q en bruto)

**Se usa para:**
- grabar un trozo de la banda para reproducirlo después en HDSDR, SDR#, SDR++ o SDRuno
- escuchar con otro programa — también un cliente KiwiSDR puede pedirlo

**Características:**
- 12 kHz de la banda centrados en el dial, como I y Q — se oye en estéreo, I a la izquierda y Q a la derecha, como lo reproduce un KiwiSDR. Suena a soplido: es la señal antes de cualquier demodulación
- se envía sin pérdidas (FLAC), nunca con Opus, que destruiría el I/Q
- el nivel sigue a la banda: el ruido queda bajo (unos −45 dBFS) y una emisora fuerte se lleva a unos −20 dBFS. NR, NB, NS, AN, AI y el silenciador no se aplican, y elegir IQ apaga cualquier decodificador en marcha
- **Audio** en *Recording Options* graba el I/Q; al detenerlo, **Download IQ** lo guarda como archivo WAV (16 bits estéreo, 12 kHz) con un nombre como `PhantomSDR_20261026_031500Z_6030000Hz_IQ.wav`. HDSDR, SDR# y SDRuno leen la frecuencia y la hora del archivo, SDR++ del nombre, así que la grabación se abre ya sintonizada
- decide la estación: el botón aparece solo donde `[server] iq` está activado (el valor por defecto)

**Buenas prácticas:**
- ponga la emisora que quiere en el centro — la grabación cubre ±6 kHz alrededor del dial (±12 o ±24 kHz en un IQ más ancho, abajo)
- para oír una emisora, un modo normal es más sencillo; IQ es para grabar, para otros programas y para oír varias emisoras a la vez (abajo)

#### IQ más ancho: 24 y 48 kHz

Donde la estación lo ofrece, el panel IQ Demodulators tiene **Width: 12 kHz · 24 kHz · 48 kHz**. 24 kHz abarca los modos anchos de DRM o una emisora con sus dos vecinas, 48 kHz todo un grupo de emisoras de radiodifusión o un segmento de CW/digitales. La banda de paso en la cascada y la imagen del panel siguen el ancho, la grabación se hace con él (un WAV a 24 o 48 kHz) y su navegador recuerda la elección. Un IQ más ancho cuesta a la estación más subida — unos 0,7 Mbit/s por oyente a 24 kHz y 1,4 Mbit/s a 48 kHz, frente a 0,35 a 12 kHz —, así que la estación decide cuántos oyentes pueden tenerlo a la vez; cuando todas las plazas están ocupadas sigue en 12 kHz (el panel lo indica) y la página vuelve a pedirlo cada 30 segundos. Para Dream u otro programa en un cable virtual a 48 kHz, ponga también el cable a 48 kHz. Los clientes KiwiSDR reciben siempre 12 kHz.

#### Demoduladores IQ

Mientras el receptor está en IQ, bajo los decodificadores se abre un panel **IQ Demodulators**. Ejecuta hasta seis receptores sobre el I/Q en su navegador — el receptor no se resintoniza y el ordenador de la estación no trabaja más:

- La imagen muestra todo el ancho del IQ (12, 24 o 48 kHz) alrededor del dial con las frecuencias reales; cada demodulador es una franja de color y su propio dial una línea dentro de ella. Un clic en la imagen lleva allí el demodulador seleccionado; la rueda del ratón encima lo mueve 10 Hz (Mayús 100 Hz)
- Cada fila tiene el modo (USB, LSB, CW, AM, DSB, FM), la frecuencia con los botones « ‹ › » (100 y 10 Hz), una barra de nivel, **M** para silenciar y **✕** para quitar. La fila seleccionada tiene además **Width**, **Volume** y **Pan**
- **DSB** sigue la portadora por sí sola (un lazo de seguimiento de portadora): colocada a unas decenas de Hz de la portadora, el audio se mantiene limpio y estable, tanto en DSB con portadora suprimida como en AM, donde funciona como AM síncrona
- **+ Add** añade un demodulador en el dial, hasta seis. **Demodulators** / **Raw I/Q** elige si oye estos o el I/Q sin más
- Se fijan respecto al dial, así que sintonizar el receptor los mueve todos juntos; una emisora a más de 6 kHz del dial no está en el flujo
- Ejemplo: una estación DX trabajando en split — un demodulador LSB en el DX, a la izquierda, y otro en los que llaman unos kHz más arriba, a la derecha
- Su navegador recuerda sus demoduladores. Los filtros de ruido (NR, NB, NS, AN, AI) no actúan en IQ: estreche **Width** en su lugar

---

## Decodificadores digitales

PhantomSDR-Plus incluye decodificadores integrados para modos digitales. Para una guía completa, consulte [Decodificadores](DECODERS.md).

La vía más rápida es la fila de botones **Decoders** del panel principal, justo debajo de **Wheel Tuning Steps**: diez botones — **FT8, FT4, FT2, JS8, CW, WSPR, FAX, SSTV, NAVTX, FLDIGI** — que, con una sola pulsación, activan su decodificador, ponen en ON el interruptor principal Decoder y desplazan la ventana del decodificador hasta hacerla visible. El botón permanece azul mientras el decodificador funciona; púlselo de nuevo para detenerlo y cerrar su ventana. El desplegable **Decoder Options** sigue funcionando igual que antes y se mantiene sincronizado con los botones.

**RADE-v2U**, **RADE-v1L** y **RADE-v1U** (voz digital RADE) tienen sus propios botones junto al encabezado **Modes** y dentro de las ventanas emergentes **Modes** y **Bands**, y funcionan del mismo modo: pulsar para iniciar, volver a pulsar para detener. **RADE-v2U** inicia RADE V2 (beta), siempre en USB; **RADE-v1L** y **RADE-v1U** inician RADE v1.

---

## Atajos de teclado

Atajos de teclado para trabajar más rápido.

---

### Control de frecuencia

Las **teclas de flecha** sintonizan desde cualquier punto de la página:

- **Flecha arriba / abajo**: ±10 Hz; con **Shift** ±1 kHz, con **Ctrl** (o **Cmd**) ±100 kHz, con **Shift + Ctrl** ±1 MHz
- **Flecha izquierda / derecha**: ±100 Hz; con **Shift** ±10 kHz, con **Ctrl** (o **Cmd**) ±500 kHz, con **Shift + Ctrl** ±10 MHz
- **Ctrl derecho**: descarta los decimales y sintoniza el kHz entero igual o inferior a la frecuencia actual

En el cuadro del chat, y siempre que un deslizador, una lista o un campo de texto tenga el foco del teclado, las flechas actúan sobre ese control en lugar de sintonizar.

**Ratón sobre el indicador de frecuencia**: sitúe el puntero sobre un dígito; rueda hacia arriba o clic izquierdo lo sube, rueda hacia abajo o clic derecho lo baja, cada vez según el valor posicional del dígito (nueve dígitos, de 100 MHz a 1 Hz). Entre los dígitos, la rueda avanza con el paso de sintonía de la banda (1 kHz salvo que el plan de bandas indique otro); mantenga **Shift** para 1 kHz y **Alt** para 10 kHz. Un clic en cualquier otro punto del recuadro negro de frecuencia / S-meter abre el teclado numérico (Método 2 en *Sintonizar una frecuencia*).

**Rueda del ratón sobre la cascada**: hace zoom. Mantenga **Ctrl** (o **Cmd**) o **Shift** para sintonizar en lugar de ampliar, y **Shift + Ctrl** juntos para ajustar al kHz entero más cercano.

> No hay atajos de Página arriba / Página abajo.

### Lectores de pantalla

Los oyentes ciegos o con baja visión pueden usar PhantomSDR-Plus con un lector de pantalla: NVDA, JAWS o Narrador en Windows, VoiceOver en el Mac y en iPhone/iPad, TalkBack en Android, Orca en Linux, ChromeVox en ChromeOS. Cada botón, deslizador y lista tiene un nombre hablado, y las ventanas emergentes abiertas desde el teclado toman el foco y lo devuelven al cerrarse. Para los oyentes que ven, nada cambia en la pantalla.

Estos atajos funcionan en cualquier parte de la página, también mientras se escribe en un campo:

- **Alt + Shift + F**: decir la frecuencia, el modo y el ancho de banda
- **Alt + Ctrl**: abrir el teclado numérico de frecuencia (pulse las dos teclas a la vez y suéltelas)
- **Alt + Shift + S**: decir la intensidad de la señal (unidades S y dBm) y la SNR
- **Alt + Shift + R**: leer en voz alta el texto de los decodificadores, sí / no (FT8, FT4, FT2, JS8, WSPR, CW, NAVTEX, la ventana FLDIGI, HFDL, DSC, HF Selcall y ALE)
- **Alt + Shift + C**: leer en voz alta los mensajes nuevos del chat, sí / no
- **Alt + Shift + H**: decir estos atajos

En el Mac, Alt es la tecla **Opción**. Los dos interruptores de lectura siguen apagados hasta que los active, y el navegador los recuerda. Tras sintonizar con las flechas, o cambiar de modo con **l**, **u**, **a**, **q** o **f**, se dicen la nueva frecuencia y el modo en cuanto se dejan de pulsar las teclas. Con NVDA o JAWS, las letras sueltas de modo necesitan el modo foco (NVDA + Espacio), porque en el modo exploración el lector de pantalla usa esas letras; los atajos Alt + Shift funcionan en ambos.

En el teléfono, use la página /mobile: la frecuencia, los pasos, los modos y las pestañas tienen nombre y dicen cuál está seleccionado, el S-meter se puede leer, los botones **+** y **−** dicen la nueva frecuencia, y los mensajes nuevos del chat se leen en voz alta mientras la pestaña Chat está abierta.

---

## Marcadores

Guarde sus frecuencias favoritas para acceder a ellas rápidamente. También puede exportar la lista de marcadores y guardarla localmente, y después importarla en cualquier otro PhantomSDR.

Cuando los marcadores propios y los del plan de bandas se solapan:

🔵 Los marcadores propios (marco cian fino, letras amarillas) aparecen encima <br /> 🟡 Los marcadores amarillos, debajo <br />
✅ Los clics en los marcadores azules tienen prioridad <br />


### Añadir un marcador

1. Sintonice la frecuencia deseada
2. Haga clic en el botón «Bookmarks»
3. Haga clic en «Add Bookmark»
4. Escriba una descripción
5. Haga clic en «Save»

┌──────────────┬────────────────┬────────┐ │ Bookmark name│Label (optional)│ [Add]  │ └──────────────┴────────────────┴────────┘

### Cómo se usa:

**Añadir un marcador:**
- Nombre: «Local News Station»
- Etiqueta: «NEWS»
- Haga clic en Add

**Verlo en la cascada:**
- amplíe hasta que aparezcan los marcadores
- verá un recuadro azul marino con «NEWS» en amarillo y negrita

**Hacer clic en el marcador:**
- sintoniza la frecuencia
- fija el modo de demodulación
- funciona igual que hacer clic en un marcador del plan de bandas

### Gestionar los marcadores
- **Editar**: haga clic en el icono del lápiz junto al marcador
- **Eliminar**: haga clic en el icono de la papelera junto al marcador
- **Exportar**: descargue los marcadores como archivo JSON
- **Importar**: cargue marcadores desde un archivo JSON

### Compartir marcadores

1. Haga clic en «Export Bookmarks»
2. Comparta el archivo JSON con otras personas
3. Los destinatarios hacen clic en «Import Bookmarks»
4. Seleccionan su archivo
---

## Uso en móviles

¡PhantomSDR-Plus funciona de maravilla en dispositivos móviles!

### Dos vistas móviles

Hay dos formas de usar el receptor desde el teléfono:

- **`http://su_servidor:PUERTO/mobile`**: la página simplificada. Sin cascada, por lo que consume aproximadamente la mitad de datos. Entrada de frecuencia, pasos de sintonía, modos, S-meter, bandas, marcadores, usuarios y chat.
- **La vista ampliada**: la disposición para teléfono de la interfaz principal, con la cascada y todos los controles.

Se cambia con los botones de la parte inferior de `/mobile` (**Mobile extended view**, **Full desktop view**) y con **Simplified mobile** en la vista ampliada.

**Su frecuencia le acompaña.** Cambiar de vista le mantiene en la misma señal: la frecuencia y el modo viajan en el enlace, así que ya no acaba en la frecuencia predeterminada del receptor. La barra de direcciones también sigue su sintonía, de modo que recargar la página, guardarla como marcador o enviar el enlace a alguien devuelven exactamente a esa frecuencia.

**El modo sigue el plan de bandas en ambas páginas.** Sintonice un segmento marcado como AM, LSB, USB o CW —escribiendo una frecuencia, avanzando a pasos o pulsando un botón de banda— y el receptor cambia a ese modo, tanto en la página simplificada como en la interfaz completa. Un modo elegido a mano se mantiene mientras se mueve dentro del mismo segmento, y fuera de las bandas definidas su modo no se toca. Mientras **RADE** (RADEL/RADEU) está en marcha conserva el receptor, de modo que sintonizar no lo interrumpe.

Al cambiar entre las dos vistas su modo actual viaja con usted, pero si la vista a la que pasa no tiene un equivalente, el plan de bandas decide para esa frecuencia: una frecuencia de radiodifusión llega en AM, 40 m en LSB, un segmento de CW en CW. `SAM` en la página simplificada se convierte en AM con el detector síncrono en la vista ampliada, y a la inversa. `RADEL` y `RADEU` solo existen en la página simplificada: al salir de uno de ellos se conserva la frecuencia y el plan de bandas elige el modo.

Una frecuencia fuera de la cobertura del receptor se ajusta al extremo más cercano, de manera que un enlace antiguo nunca puede dejarle fuera de banda.

## Resolución de problemas

### No hay audio

**Posibles causas:**
1. Navegador silenciado → compruebe los controles de volumen del navegador
2. Sistema silenciado → compruebe el volumen del ordenador
3. Señal débil → sintonice una señal más fuerte (S7+)
4. Modo incorrecto → pruebe otros modos de demodulación

**Soluciones:**
1. Haga clic en una señal fuerte (naranja/roja en la cascada)
2. Compruebe que el navegador no esté silenciado (icono de silencio en la pestaña)
3. Pruebe otra frecuencia
4. Recargue la página (F5)

### Audio distorsionado

**Posibles causas:**
1. Señal saturada → señal demasiado fuerte
2. Modo incorrecto → señal de AM escuchada en SSB, etc.
3. Interferencias → señales adyacentes que se cuelan

**Soluciones:**
1. Baje el volumen
2. Pruebe otro modo de demodulación
3. Use un filtro más estrecho
4. Aléjese de las señales interferentes

### El audio se corta o va con retraso

**Posibles causas:**
1. Conexión irregular → los paquetes llegan tarde y el búfer se vacía
2. Teléfono u ordenador ocupado → el navegador no da abasto

**Soluciones:**
1. Suba el búfer un paso (vea *Búfer de audio y retardo*)
2. Prefiera Wi-Fi o cable a los datos móviles
3. Cierre otras pestañas y aplicaciones

Para verlo con detalle, abra la página añadiendo `?diag=1` a su dirección (por ejemplo `http://your_server:PORT/mobile?diag=1`). La página /mobile muestra entonces bajo sus controles el retardo, lo irregular que es la conexión y el estado del búfer; la página de escritorio escribe la misma línea en la consola del navegador (F12) cada diez segundos. Útil al comunicar un problema al operador de la estación.

### La cascada no se actualiza

**Posibles causas:**
1. Problema de red → conexión lenta o interrumpida
2. Rendimiento del navegador → demasiadas pestañas abiertas
3. Sobrecarga del servidor → demasiados usuarios

**Soluciones:**
1. Compruebe la conexión a Internet
2. Cierre las pestañas innecesarias
3. Recargue la página (F5)
4. Inténtelo más tarde, cuando haya menos usuarios conectados

### No se puede sintonizar una frecuencia

**Posibles causas:**
1. Frecuencia fuera de rango → el SDR no cubre esa frecuencia
2. Formato de escritura incorrecto → use el formato correcto (p. ej., «14200» y no «14.200.000»)

**Soluciones:**
1. Compruebe la cobertura de frecuencias del SDR (indicada en la página)
2. Use los ejemplos de formato de frecuencia facilitados
3. Haga clic en la cascada en su lugar

---

**¡Disfrute explorando el espectro radioeléctrico con PhantomSDR-Plus!**

**73 (saludos cordiales) de SV1BTL, 9A7AOF, F1NSK & SV2AMK**

Para las instrucciones de instalación, consulte [INSTALLATION.md](INSTALLATION.md). Para los detalles técnicos, consulte [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md).
