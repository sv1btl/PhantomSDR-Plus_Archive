# Mehrere Empfänger — Sysop-Handbuch

> **Portnummern.** Die Beispiele unten verwenden die Ports, die `install.sh` vorschlägt: `proxy.py` auf dem öffentlichen Port 9000, der Hauptempfänger auf 9001, weitere Empfänger auf 9002, 9003 und so weiter. Die Stationsfragen halten `receivers.toml` aktuell: Ändert sich ein Port oder die Adresse, setzt `configure-station.sh` den Hauptempfänger auf seinen neuen Port und schreibt jeden Link als `<Adresse>/?rx=<id>` — ein Link ohne `?rx=` würde einen Besucher auf dem Empfänger halten, den sich das `rx`-Cookie merkt. Einem Empfänger nie den öffentlichen Port selbst geben: Der Proxy würde an sich selbst weiterleiten, deshalb lehnt er das jetzt ab.

**Zwei oder mehr Empfänger auf einem Rechner, mit einer Empfängerauswahl auf der Seite.**

Seit v5.0.0 kann ein PhantomSDR-Plus-Rechner mehrere Empfänger gleichzeitig betreiben — zum Beispiel einen RX-888 für Kurzwelle und einen RTL-SDR für 2 m — und die Hörer wechseln mit Schaltflächen im Seitenkopf zwischen ihnen, so wie OpenWebRX seine Profile anbietet. Jeder Empfänger behält seinen eigenen Wasserfall, Chat, seine Markierungen, Hörerliste und Stationsangaben; niemand auf einem Empfänger wird je von jemandem auf einem anderen gestört.

> **Eilig?** Eine Station mit einem Empfänger braucht nichts davon und merkt keinen Unterschied. Für einen zweiten Empfänger: `instances/<name>/` mit eigener `config.toml` anlegen, mit `INSTANCE=<name> ./start-<radio>.sh` starten, beide Empfänger in `receivers.toml` eintragen und den Proxy neu starten. Das Beispiel in [Abschnitt 3](#3-einen-zweiten-empfänger-hinzufügen) geht es Zeile für Zeile durch.

> **Am einfachsten:** Führen Sie `./add-receiver.sh` aus (die Installer bieten es am Ende an). Das Skript fragt, welcher Empfänger und was er abdecken soll, installiert seinen Treiber, schreibt alles, was in [Abschnitt 3](#3-einen-zweiten-empfänger-hinzufügen) und [Abschnitt 4](#4-receiverstoml) beschrieben ist, und bietet an, den Empfänger zu starten und den Proxy neu zu starten. Der Rest dieses Handbuchs erklärt, was es tut — für den Fall, dass Sie etwas von Hand ändern möchten.

> **Aus dem Admin-Panel:** die Seite **Receivers** listet jeden Empfänger mit dem, was er abdeckt. **✎ CHANGE SETTINGS** ändert Frequenz und Bandbreite eines zusätzlichen Empfängers (und startet nur diesen neu) und bei jedem Empfänger Startfrequenz, Betriebsart, Verstärkung und Knopfnamen — ein zusätzlicher Empfänger hat seine Verstärkung in `instances/<id>/instance.env`, der Hauptempfänger in `main.env`, das jedes start-*.sh zuletzt liest. **■ STOP** / **▶ START** stoppt oder startet einen Empfänger, während die anderen weiterlaufen, und **🗑 DELETE** entfernt einen zusätzlichen Empfänger (stoppt ihn, nimmt ihn aus `receivers.toml`, verschiebt seinen Ordner `instances/<id>/` nach `admin-backups/`). Außerdem bereitet sie einen neuen Empfänger vor: sie speichert Ihre Antworten und gibt `./add-receiver.sh --answers instances/.add-rx.env` zum Ausführen in einem Terminal aus. Siehe [Admin-Panel](ADMIN_PANEL_SETUP.md).

---

## Inhalt

1. [Wie es funktioniert](#1-wie-es-funktioniert)
2. [Zwei Arten, die Empfänger zu veröffentlichen](#2-zwei-arten-die-empfänger-zu-veröffentlichen)
3. [Einen zweiten Empfänger hinzufügen](#3-einen-zweiten-empfänger-hinzufügen)
4. [receivers.toml](#4-receiverstoml)
5. [Starten und Stoppen](#5-starten-und-stoppen)
6. [Was die Hörer sehen](#6-was-die-hörer-sehen)
7. [Das S-Meter oberhalb von 30 MHz](#7-das-s-meter-oberhalb-von-30-mhz)
8. [Sicherheit](#8-sicherheit)
9. [Wie viele Empfänger passen](#9-wie-viele-empfänger-passen)
10. [Fallen, die man kennen sollte](#10-fallen-die-man-kennen-sollte)

---

## 1. Wie es funktioniert

Jeder Empfänger ist ein vollständiger eigener spectrumserver mit eigenem SDR-Frontend, eigener Konfiguration und eigenem internen Port. Sie teilen niemals Abtastwerte, Einstellungen oder Hörer. Verbunden werden sie durch `proxy.py`, den Reverse-Proxy, der bereits das Admin-Panel ausliefert: Er liest `receivers.toml` und schickt jede Anfrage an einen Empfänger.

```
                     ┌──► :9001  spectrumserver  RX-888   (KW, der Hauptempfänger)
Hörer ──► proxy.py ──┤
                     └──► 127.0.0.1:9002  spectrumserver  RTL-SDR  (2 m, Instanz "vhf")
```

Der Proxy entscheidet anhand dieser Merkmale, in dieser Reihenfolge:

1. `?rx=<id>` in der Adresse — `http://ihr.host:9000/?rx=vhf`. Die Seite hängt es an jeden Socket, jede Abfrage und jeden Link an, den sie öffnet, damit ein Tab bei seinem Empfänger bleibt.
2. Das Cookie `rx`, das der Proxy setzt, sobald eine Anfrage ein gültiges `?rx=` trägt.
3. Der Host-Header, wenn ein Empfänger diesen Namen unter `hostnames` führt.
4. Sonst der Standardempfänger.

Der **Hauptempfänger** ist der wie gewohnt gestartete (`./start-rx888mk2.sh`). Jeder weitere Empfänger ist eine **benannte Instanz**: mit `INSTANCE=<name>` gestartet, in `instances/<name>/` konfiguriert und mit eigenem Log (`logwebsdr-<name>.txt`), Server-Log, Watchdog-Sperre und FIFO. Die Prozesse werden an einer Kennung `PHANTOMSDR_INSTANCE` in ihrer Umgebung unterschieden, nicht an ihrem Namen; zwei Empfänger dürfen also dasselbe Programm ausführen — zweimal `rtl_sdr`, oder `rx_sdr` für einen RSP1A und einen Airspy — und ein Neustart des einen berührt den anderen nie.

---

## 2. Zwei Arten, die Empfänger zu veröffentlichen

**A — der Hauptempfänger behält seinen eigenen Port.** Der Hauptempfänger bleibt genau, wo er war (etwa `:9001`), seine Hörer merken nichts, und die anderen Empfänger erreicht man über den Port des Proxys (`proxy_port` in `admin_config.json`, etwa `:9000`) mit `?rx=`. Nichts muss umziehen, nichts geht vom Netz; dafür gibt es zwei öffentliche Ports.

```
KW:  http://ihr.host:9001/
2 m: http://ihr.host:9000/?rx=vhf
```

**B — ein öffentlicher Port für alles.** Der Proxy übernimmt den öffentlichen Port, und der Hauptempfänger zieht auf einen internen um. Setzen Sie `[front] port` in `receivers.toml`, verlegen Sie `[server] port` des Hauptempfängers und setzen Sie dort `host = "127.0.0.1"`, stellen Sie `public_port` in `admin_config.json` auf den neuen internen Port und tragen Sie `public_port = <der öffentliche Port>` unter `[websdr]` ein, damit das Verzeichnis weiterhin den richtigen meldet. Danach liegt alles hinter einem Port; der Preis ist eine kurze Unterbrechung beim Umzug.

```
KW:  http://ihr.host:9000/
2 m: http://ihr.host:9000/?rx=vhf
```

Die Empfängerauswahl funktioniert in beiden Fällen gleich. Variante A ist der sicherere Anfang; B kann später folgen, ohne am zweiten Empfänger etwas zu ändern.

---

## 3. Einen zweiten Empfänger hinzufügen

**`add-receiver.sh` fügt einen Empfänger hinzu** — führen Sie es aus und beantworten Sie seine Fragen; es installiert den Treiber (`setup-rtlsdr.sh` für einen RTL-SDR, das passende `setup-*.sh` für die anderen), wählt einen freien internen Port, legt den Instanzordner, seine Konfiguration und seine Zeile in `receivers.toml` an und benennt den Empfänger nach dem, was er abdeckt. Die Seite **Receivers** des Admin-Panels macht dasselbe mit ➕ ADD NEW RECEIVER.

---

## 4. receivers.toml

Kopieren Sie `receivers.toml.example` nach `receivers.toml`. Ohne diese Datei bedient der Proxy genau wie bisher einen einzigen Empfänger.

```toml
# [front]
# port = 9000        # nur Variante B: der Proxy hört zusätzlich auf diesem öffentlichen Port

[[receiver]]
id       = "hf"
name     = "HF 0-30 MHz (RX-888 MkII)"
port     = 9001
default  = true
launcher = "start-rx888mk2.sh"
url      = "http://ihr.host:9000/"

[[receiver]]
id       = "vhf"
name     = "2 m (RTL-SDR Blog V4)"
port     = 9002
launcher = "start-rtl.sh"
instance = "vhf"
url      = "http://ihr.host:9000/?rx=vhf"
```

| Schlüssel | Bedeutung |
|---|---|
| `id` | Kurzname für `?rx=`; Buchstaben, Ziffern, `-` und `_` |
| `name` | Die Beschriftung der Schaltfläche des Empfängers |
| `port` | `[server] port` seines spectrumservers |
| `host` | Optional; wo dieser spectrumserver läuft (Standard `127.0.0.1`) |
| `default` | Der Empfänger für Anfragen, die keinen nennen; höchstens einer |
| `launcher` | Sein `start-*.sh`, für `start-all.sh`; weglassen bei einem Empfänger, den dieser Rechner nicht startet |
| `instance` | Sein Instanzname; beim Hauptempfänger weglassen |
| `url` | Wohin seine Schaltfläche den Hörer schickt; ohne Angabe `/?rx=<id>` auf dem Proxy |
| `hostnames` | Optionale DNS-Namen, die direkt zu diesem Empfänger führen |

Der Proxy liefert die Liste auch als `/receivers.json` aus (IDs, Namen und Links — nie die internen Ports); diese Datei liest die Auswahl.

---

## 5. Starten und Stoppen

| Befehl | Wirkung |
|---|---|
| `./start-rx888mk2.sh` | Startet oder startet den Hauptempfänger neu |
| `INSTANCE=vhf ./start-rtl.sh` | Startet oder startet den Empfänger `vhf` neu |
| `./start-all.sh` | Startet jeden Empfänger in `receivers.toml`, der einen `launcher` hat |
| `./stop-websdr.sh vhf` | Stoppt nur `vhf` |
| `./stop-websdr.sh main` | Stoppt nur den Hauptempfänger |
| `./stop-websdr.sh` | Stoppt jeden Empfänger, wie schon immer |

**Solange ein Empfänger gestoppt ist**, verschwindet seine Schaltfläche aus der Auswahl — der Proxy listet nur die Empfänger, die antworten, und offene Seiten lesen die Liste alle 15 Sekunden neu — und kommt wieder, wenn der Empfänger wieder startet; läuft nur noch ein Empfänger, verschwindet die Zeile *Receivers:* ganz. Ein gestoppter Empfänger kommt von selbst wieder, sobald alle Empfänger gestartet werden: `./start-all.sh`, **Restart** im Admin-Panel und ein Neustart durch den Thermal Guard starten alles, was in `receivers.toml` steht. Um einen dauerhaft abzuschalten, löschen Sie ihn auf der Seite **Receivers** des Admin-Panels, oder entfernen Sie seinen `[[receiver]]`-Block von Hand (oder kommentieren Sie ihn aus) — der Proxy liest `receivers.toml` neu, sobald sie sich ändert, also wirken eine Umbenennung, eine Entfernung oder ein neuer Block ohne Neustart des Proxys (nur die erste `receivers.toml` einer Station oder eine Änderung von `[front] port` braucht noch einen).

Stellen Sie im Admin-Panel das **Default start script** auf `start-all.sh`. Sein Stop hält bereits jeden Empfänger an, und Restart sowie der Temperaturschutz verwenden das Startskript; mit `start-all.sh` kehren deshalb alle Empfänger zurück statt nur des Hauptempfängers.

Der RADE-Helfer gehört nur zum Hauptempfänger. Eine benannte Instanz startet oder stoppt ihn nie.

---

## 6. Was die Hörer sehen

**Die Empfängerauswahl.** Auf einer Station mit mehr als einem Empfänger bekommt der Seitenkopf eine eigene Zeile, *Receivers:*, mit einer Schaltfläche pro Empfänger; der aktuelle erscheint gelb. Die Seite /mobile hat dieselben Schaltflächen als zweite Reihe in ihrer oberen Leiste, und sie öffnen die /mobile-Seite des anderen Empfängers.

**Show-All-Streifen.** Ein Kästchen *Show All* hinter den Empfänger-Tasten zeigt jeden anderen Empfänger als Live-Streifen unter dem Wasserfall des Hörers. Ein Klick dort öffnet jenen Empfänger auf der angeklickten Frequenz, und eine Seite, die der Hörer verlassen hat, öffnet sich wieder mit der Ansicht, mit der er sie verlassen hat. Jeder Streifen ist ein reiner Wasserfall-Socket zum anderen Empfänger (`/waterfall?rx=<id>`): Er ist dort kein Hörer — die Hörerzahl und das Hörerlimit pro IP sehen ihn nicht, `per_ip_sockets` schon — und kostet etwa 10 KB/s Upload für jeden Hörer, der das Kästchen anhakt. Er ist standardmäßig aus und braucht auf dem Server nichts. Deckt der andere Empfänger mehr als ein Band ab, bietet der Kopf des Streifens dessen Bänder in einer Auswahlliste an (dieselben wie seine Bandschaltflächen); ein Band rahmt den Streifen wie seine Bandschaltfläche, und ein Klick öffnet den Empfänger dann auf dieses Band gerahmt. Die Wahl wird je Empfänger im Browser des Hörers gespeichert.

**Wechsel nach Frequenz.** Eine Frequenz außerhalb des Bereichs dieses Empfängers, die ein anderer Empfänger abdeckt — eingetippt, aus einem Link, einem Lesezeichen oder einem Spot —, öffnet den Empfänger, der sie abdeckt. Den Bereich jedes Empfängers erfährt die Seite, indem sie kurz dessen `/waterfall`-Socket öffnet, und merkt ihn sich einen Tag lang.

**Hörer und Statistik je Empfänger.** Die Fenster *Connected Users* und *User Statistics* zeigen den Empfänger, auf dessen Seite sie liegen, auch wenn mehrere Empfänger nebeneinander im selben Browser offen sind. Die Statistik stammt aus den eigenen Logs jenes Empfängers — `logs/` beim Hauptempfänger, `instances/<id>/logs/` bei den anderen.

**Die eigenen Angaben jedes Empfängers.** Eine Seite, die auf einem zweiten Empfänger geöffnet wird, lädt vor dem Start dessen `site_information.json`; Bandschaltflächen, Startfrequenz, Hörerliste, Stationsangaben sowie die Links bei Receiver und Antenna gehören damit zu ihm. Ein normaler Besuch beim Hauptempfänger stellt keine zusätzliche Anfrage.

Die Schlüssel in `site_information.json` dafür:

| Schlüssel | Bedeutung |
|---|---|
| `siteReceiverId` | Der Empfänger, zu dem diese Seite gehört (seine `id`); beim Hauptempfänger weglassen |
| `siteReceiversList` | Wo die Auswahl die Liste liest, z. B. `http://ihr.host:9000/receivers.json`; nötig bei einem Empfänger, dessen Seite nicht über den Proxy ausgeliefert wird |
| `siteReceiverURL` | Wohin der Name bei *Receiver* in *Open Additional Info* verlinkt |
| `siteAntennaURL` | Wohin der Name bei *Antenna* verlinkt; `""` zeigt den Namen ohne Link |

**Wann die Auswahl verborgen bleibt.** Die Auswahl zeigt nur eine Liste, die den Host nennt, unter dem die Seite geöffnet wurde. Über die LAN-Adresse geöffnet (`http://192.168.1.10:9000/`) bleibt sie verborgen; als `http://ihr.host:9000/` erscheint sie. Das ist Absicht: Eine Station, die die `site_information.json` einer anderen unverändert übernommen hat, zeigt deren Empfänger nie als ihre eigenen.

---

## 7. Das S-Meter oberhalb von 30 MHz

Nach dem Standard der IARU Region 1 liegt S9 unterhalb von 30 MHz bei −73 dBm und **oberhalb bei −93 dBm**, in beiden Fällen sechs dB je S-Stufe. Die S-Meter (Zeigerinstrument, digitaler Balken und der Balken auf /mobile) folgen der eingestellten Frequenz: Oberhalb von 30 MHz zeigen sie VHF-S-Stufen, darunter wie bisher. Die Werte in dBm und dBµV werden nie verändert. Sollen die Instrumente auf einem leeren Kanal auf 0 ruhen wie bei einem VHF/UHF-Funkgerät, tragen Sie `"siteSMeterGateDb": 6` in die `site_information.json` des Empfängers ein (kein Neubau nötig): Oberhalb von **60 MHz** schlagen Zeiger und Balken dann erst aus, wenn ein Signal so viele dB über dem Rauschen in seiner eigenen Umgebung liegt (der stärkste Punkt im Durchlassbereich gegen das Spektrum ±100 kHz darum herum). Das ist **standardmäßig aus** — ein kalibriertes Instrument, das das echte Bandrauschen zeigt, ist die ehrlichere Anzeige. Die Seite /mobile, die keinen Wasserfall hat, schätzt das Rauschen aus dem empfangenen Pegel selbst.

Kalibrieren Sie die dBm-Anzeige eines VHF-Empfängers mit `analog_smeter_offset` (Zeiger und Zahlen) und `smeter_offset` (digitaler Balken) unter `[input]` in seiner `config.toml` und starten Sie diesen Empfänger danach neu. Stellen Sie zuerst die Verstärkung ein: Ein RTL-SDR meldet Pegel relativ zu seinem eigenen Vollausschlag, jede Änderung der Verstärkung verschiebt also die Anzeige. Ohne Messsender sollte ein 50-Ω-Abschluss statt der Antenne, in USB mit 2,7-kHz-Filter, etwa −136 dBm anzeigen (thermisches Rauschen in 2,7 kHz ist −139,7 dBm, plus die Rauschzahl des Sticks).

Für einen RTL-SDR schreibt `add-receiver.sh` eine Startkalibrierung: eine feste Verstärkung `-g 29.7` in `instance.env` (die automatische Verstärkung des Tuners lässt sich nicht kalibrieren) sowie `analog_smeter_offset=-55` und `smeter_offset=-38`, gemessen an einem RTL-SDR Blog V4 bei dieser Verstärkung mit einem Signal von −71 dBm (63 µV). Ein anderer Stick desselben Modells liegt meist nur wenige dB daneben; prüfen Sie ihn mit einem bekannten Signal und kalibrieren Sie neu, wenn Sie die Verstärkung ändern.

---

## 8. Sicherheit

Binden Sie jeden Empfänger, der über den Proxy erreicht wird, an `127.0.0.1` (`[server] host`), damit sein Port nicht am Proxy vorbei genutzt werden kann. Die Limits pro Adresse aus [Verbindungslimits](CONNECTION_LIMITS.md) gelten je Empfänger.

---

## 9. Wie viele Empfänger passen

Die Software setzt keine Grenze; die Hardware tut es. Schmalbandige Empfänger sind genügsam: Ein RTL-SDR mit 2,4 Msps braucht etwa 5–10 % eines Kerns, einige Dutzend MB Speicher und etwa 38 Mbit/s auf dem USB.

- **USB 2.0 ist die übliche Grenze.** Alle USB-2-Geräte teilen sich einen Bus mit 480 Mbit/s, auch in einer blauen USB-3-Buchse. Drei bis vier RTL-SDR je Bus sind ein sicherer Wert; fügen Sie sie einzeln hinzu und beobachten Sie jeden Wasserfall auf Lücken.
- **Strom:** Ab mehr als zwei Sticks einen aktiven Hub verwenden.
- **Ein zweiter Breitbandempfänger** (ein weiterer RX-888 oder ein HackRF mit 20 Msps) ist etwas anderes: Er konkurriert mit dem ersten um USB 3, CPU und GPU.
- **Hörer kosten mehr als Empfänger.** Jeder Hörer kostet CPU auf seinem Empfänger und Upload-Bandbreite; die Gesamtzahl der Hörer zählt deshalb mehr als die Zahl der Empfänger.

---

## 10. Fallen, die man kennen sollte

- **Zwei Sticks desselben Modells haben dieselbe Seriennummer.** Jeder RTL-SDR Blog V4 meldet `00000001`. Geben Sie jedem eine eigene mit `rtl_eeprom -s <seriennummer>` (immer nur ein Stick eingesteckt) und nennen Sie sie in `instance.env` (`RX_ARGS="-d <seriennummer> …"`), sonst können die Sticks nach einem Neustart die Empfänger tauschen.
- **Kiwi-Clients können keinen Empfänger wählen.** Ein KiwiSDR-Client wählt eine nackte Adresse und einen Port; über den Proxy landet er immer beim Standardempfänger. Lassen Sie `[kiwi_emulation]` bei den anderen ausgeschaltet.
- **Cookies gelten pro Host, nicht pro Port.** Ein Besucher, der den zweiten Empfänger auf `:9000` benutzt hat, trägt `rx=vhf` auch zu `:9001`. Deshalb entscheidet eine Seite anhand von `siteReceiverId`, welcher Empfänger sie ist, nie anhand des Cookies.
- **Verzeichniseinträge.** Geben Sie jedem Empfänger in `[websdr]` einen eigenen Namen und setzen Sie bei einem Empfänger hinter dem Proxy `[websdr] public_port` auf den Port, den die Hörer benutzen, sonst wirbt der Eintrag mit dem internen.
- **Ein Frontend-Build zeigt kurz „Not Found".** `frontend/dist` wird an Ort und Stelle neu gebaut; einige Sekunden lang fehlt die Seite während eines Builds bei jedem Empfänger.
- **Nichts startet die Empfänger beim Hochfahren**, außer Sie richten es ein. Nach einem Neustart bringt `./start-all.sh` alle zurück.
