# Korisnički vodič za PhantomSDR-Plus

Dobrodošli u PhantomSDR-Plus! Ovaj će vam vodič pomoći da izvučete najviše iz slušanja putem WebSDR-a.

---

## Sadržaj

1. [Uvod](#uvod)
2. [Početak rada](#početak-rada)
3. [Pregled sučelja](#pregled-sučelja)
4. [Osnovne radnje](#osnovne-radnje)
5. [Napredne značajke](#napredne-značajke)
6. [Načini demodulacije](#načini-demodulacije)
7. [Digitalni dekoderi](#digitalni-dekoderi)
8. [Tipkovni prečaci](#tipkovni-prečaci)
9. [Oznake](#oznake)
10. [Upotreba na mobilnim uređajima](#upotreba-na-mobilnim-uređajima)
11. [Savjeti i dobre prakse](#savjeti-i-dobre-prakse)
12. [Rješavanje problema](#rješavanje-problema)
13. [Često postavljana pitanja](#često-postavljana-pitanja)

---

## Uvod

### Što je PhantomSDR-Plus?

PhantomSDR-Plus je softverski definirani radio (SDR) koji radi u web-pregledniku i omogućuje vam slušanje radijskih signala preko interneta. S vaše strane nisu potrebni ni poseban softver ni hardver — dovoljan je moderan web-preglednik!

### Što možete slušati?

Ovisno o konfiguraciji WebSDR-a, možete se ugoditi na:

- **Amaterski radio**: radioamatere diljem svijeta
- **Radiodifuzijske postaje**: AM/FM radio, kratkovalne emisije
- **Zrakoplovstvo**: kontrolu zračnog prometa, komunikacije zrakoplova
- **Pomorstvo**: veze brod-obala, pomorsku meteorologiju
- **Meteorološke satelite**: NOAA, METEOR-M
- **Digitalne načine rada**: FT8, RTTY, PSK31 i druge
- **Uslužne postaje**: signale točnog vremena, vojne, državne

### Sistemski zahtjevi

- **Preglednik**: Chrome/Edge (preporučeno), Firefox, Safari
- **Veza**: širokopojasni internet (preporučuje se 1 Mbit/s ili više)
- **Zvuk**: ispravni zvučnici ili slušalice
- **Neobavezno**: miš s kotačićem za lakše ugađanje

---

## Početak rada

### 1. Pristupite WebSDR-u

Otvorite preglednik i idite na adresu WebSDR-a koju vam je dao operater.

Primjer: `http://websdr.example.com:9002`

### 2. Prvo učitavanje stranice

Kada se stranica učita, vidjet ćete:
- šareni prikaz slapa koji pokazuje radijsku aktivnost
- upravljačku ploču s prikazom frekvencije i gumbima
- S-metar koji pokazuje jakost signala
- brojač korisnika

### 3. Počnite slušati

1. **Kliknite na signal** u prikazu slapa
2. **Zvuk će se automatski pokrenuti**
3. **Podesite glasnoću** pomoću regulatora glasnoće preglednika ili klizača na zaslonu
4. **Fino ugodite frekvenciju** klikom točno na signal

---

## Pregled sučelja

### Glavni dijelovi

```
┌──────────────────────────────────────────────────────────────────────────┐
│  WebSDR <callsign>, located in <QTH>              ⚙ [ Analog S-Meter ▾ ] │
│  email · Keyboard Shortcuts · Users · Stats · Other servers 1 2 3        │
│  Frequency Search: MW SW HamDash PSK Reporter WSPRnet · Callsign Search  │
│                        [ Open Additional Info ]                          │
├──────────────────────────────────────────────────────────────────────────┤
│                     Spectrum  +  Waterfall                               │
│                     band-plan strip along the bottom                     │
├───────────────────────┬────────────────────────────┬─────────────────────┤
│ Audio & Buffer        │   Frequency  │  S-Meter    │ Waterfall Controls  │
│   volume · SQ · zoom  │   7,120.00   │  dBm dBμV   │   Min · Max · zoom  │
│ AGC Auto Fast Med Slow│   band · VFO │  SNR · NF   │   colour-map strip  │
│   Compressor Equalizer├────────────────────────────┤ Zoom In Out Max Min │
│ Filters               │  Fine Tuning (kHz)         │ Waterfall Spectrum  │
│   NR NB NS AN CTCSS   │  VFO A · Modes · Bands     │ Auto Adj. Height    │
│ Modes  RADE-v2U       │           · IF Filters     │ [ profile ▾ ]       │
│   RADE-v1L RADE-v1U   │  Wheel Tuning Steps        │ [ Bookmarks ]       │
│   USB LSB CW AM QUAM  │  Decoders                  │                     │
│   FM IQ               │   FT8 FT4 FT2 JS8 CW WSPR  │                     │
│ Band selector         │   FAX SSTV NAVTEX RTTY ... │                     │
└───────────────────────┴────────────────────────────┴─────────────────────┘
```

Tri ploče ispod slapa pomiču se kao jedna stranica; u uskom se prozoru slažu jedna ispod druge umjesto jedna uz drugu. **RADE-v2U**, **RADE-v1L** i **RADE-v1U** stoje na samom retku naslova *Modes*, njemu zdesna.

### 1. Prikaz slapa

Slap je vizualni prikaz radijskih signala:

- **Vodoravna os**: frekvencija
- **Okomita os**: vrijeme (pomiče se prema dolje)
- **Boje**: jakost signala
  - **Tamnoplava/crna**: nema signala (razina šuma)
  - **Zelena/žuta**: slabi do umjereni signali
  - **Narančasta/crvena**: jaki signali
  - **Bijela**: vrlo jaki signali

### 2. Prikaz frekvencije

Prikazuje trenutačno ugođenu frekvenciju u raznim formatima:
- **MHz**: 7.100.000 MHz (KV pojasevi)
- **kHz**: 14200 kHz
- **Hz**: 145500000 Hz (VHF/UHF)

### 3. S-metar (analogni ili digitalni)

Prikazuje jakost signala:
- **S1-S9**: standardna ljestvica jakosti signala
- **+dB**: signali iznad S9 (npr. S9+20dB)
- **Analogni ili digitalni**: ovisno o konfiguraciji

### 4. Gumbi načina rada

Odaberite način demodulacije:
- **AM**: amplitudna modulacija
- **FM**: frekvencijska modulacija
- **USB**: gornji bočni pojas
- **LSB**: donji bočni pojas
- **CW**: Morseov kod (neprekinuti val)
- **WBFM**: širokopojasni FM (radiodifuzija)
- **QUAM**: C-QUAM AM stereo — natpis postaje zelen kada se otkrije stereo pilot
- **IQ**: sirovi I/Q — 12 kHz pojasa kako stižu, za snimanje ili za drugi program (vidi odjeljak IQ niže)

Uz naslov **Modes** nalaze se gumbi **RADE-v2U**, **RADE-v1L** i **RADE-v1U**, koji jednim pritiskom pokreću RADE digitalni glas — pogledajte [Digitalni dekoderi](#digitalni-dekoderi). **RADE-v2U** pokreće RADE V2 (beta), uvijek u USB-u; **RADE-v1L** i **RADE-v1U** pokreću RADE v1.

### 5. Upravljačka ploča

Dodatne kontrole:
- **AGC**: automatska regulacija pojačanja
- **NR**: smanjenje šuma (spektralno)
- **NB**: prigušivač impulsnog šuma
- **NS**: potiskivanje pozadinskog šuma
- **AN**: automatski notch
- **CTCSS**: squelch podtonom (FM). Pritisak otvara pokraj gumba mali prozor s *Any tone* i 49 standardnih podtonova (67,0–254,1 Hz); nakon odabira gumb prikazuje ton (na primjer *88.5* ili *ANY*), a zvuk prolazi samo dok se taj podton prima. Redak *Heard:* u prozoru pokazuje koji podton prijemnik upravo čuje na kanalu i koliko je jak, pa se nepoznati podton repetitora može očitati. Dok je CTCSS uključen, FM zvuk kasni 0,4 s za prijemnikom, tako da je squelch već otvoren kad stignu prve riječi stanice; s *Any tone* početak se još može malo odrezati, pa gdje god možete odaberite točan podton. Ponovni pritisak isključuje CTCSS; Escape ili klik izvan prozora zatvara ga bez promjene. Oznake pamte odabrani ton.
- **SQL**: squelch
- **AI**: smanjenje šuma umjetnom inteligencijom (samo govor)
- **Zoom**: razina uvećanja slapa
- **Wheel Tuning Steps**: korak ugađanja kotačićem miša, od 10 Hz do 12,5 kHz (12,5 kHz je razmak kanala na VHF/UHF)
- **Decoders**: gumbi koji jednim pritiskom pokreću i zaustavljaju svaki dekoder

### 6. Preklop plana pojaseva

Obojene trake koje prikazuju dodjelu frekvencija:
- različite boje za različite službe
- pomažu prepoznati što je dopušteno na kojoj frekvenciji

---

## Osnovne radnje

### Ugađanje na frekvenciju

#### Način 1: klik na slap

1. Kliknite izravno na signal u slapu
2. Prijamnik će se ugoditi na tu frekvenciju
3. Zvuk će se početi reproducirati

#### Način 2: upis frekvencije

1. Kliknite bilo gdje u crni okvir frekvencije / S-metra — svugdje osim na znamenku i osim na analogni S-metar, čiji klik mijenja njegov izgled
2. Otvara se numerička tipkovnica; upišite frekvenciju njezinim tipkama ili tipkovnicom računala (`.` ili `,` za decimalni zarez)
3. Pritisnite **kHz** ili **MHz** za ugađanje — tipka koju pritisnete određuje jedinicu; na tipkovnici Enter znači kHz, a `M` znači MHz

**C** briše upis, **⌫** briše zadnju znamenku, a Escape ili klik izvan zatvara tipkovnicu bez ugađanja. U proširenom mobilnom prikazu dodir samog polja frekvencije otvara numeričku tipkovnicu telefona.

Primjeri:
- `7100` + **kHz** → 7.100 MHz
- `14.2` + **MHz** → 14.200 MHz
- `145.5` + **MHz** → 145.500 MHz

**Upisana frekvencija donosi i svoj pojas.** Prijemnik ide u pojas u koji ste upisali onako kako bi to učinila tipka tog pojasa: vodopad prikazuje cijeli pojas, svjetlina i kontrast preuzimaju postavke tog pojasa, a način rada slijedi plan pojasa — ali ostajete točno na upisanoj frekvenciji. Izvan definiranih pojaseva mijenja se samo frekvencija. Ima li stanica još jedan prijemnik koji pokriva tu frekvenciju — recimo `145.5` **MHz** upisano na KV prijemniku — umjesto toga otvara se stranica tog prijemnika, već ugođena i uokvirena na isti način (vidi *Odabir prijemnika* niže).

#### Način 3: miš na znamenkama

1. Postavite pokazivač iznad znamenke prikaza frekvencije — ona zasvijetli
2. Kotačić prema gore ili **lijevi klik** povećava tu znamenku za jedan; kotačić prema dolje ili **desni klik** je smanjuje
3. Korak je mjesna vrijednost znamenke — 1 kHz na znamenki kHz, 100 Hz na prvoj decimali — a znamenka koja prijeđe 9 prenosi jedinicu na znamenku lijevo od sebe
4. Bilo gdje drugdje u crnom okviru frekvencije — naziv pojasa, redak načina rada, sat — kotačić ugađa korakom ugađanja (**Shift** 1 kHz, **Alt** 10 kHz); izuzet je samo analogni S-metar, gdje kotačić pomiče stranicu

#### Način 4: gumbi koraka

1. Koristite gumbe **▲** i **▼** pokraj frekvencije
2. Veličina koraka ovisi o načinu rada:
   - **AM/FM**: koraci od 1 kHz
   - **SSB**: koraci od 100 Hz
   - **CW**: koraci od 10 Hz

#### Način 5: gumbi pojasa

Gumb pojasa uokviruje svoj pojas — slap se zumira na cijeli pojas, a svjetlina i kontrast preuzimaju postavke tog pojasa — i ugađa na frekvenciju koju ste posljednju koristili u tom pojasu, bez obzira na to kako ste onamo došli (klik na slap, znamenke, oznaka, poveznica u chatu…). Prvi put ide na zadanu frekvenciju pojasa. Drugi klik na gumb pojasa koji je već aktivan (istaknut) zaboravlja zapamćenu frekvenciju i ide na zadanu frekvenciju pojasa. Pamćenje se čuva u vašem pregledniku, pa preživi ponovno učitavanje, i samo je vaše.

### Skener

Skener vodi prijemnik preko raspona kanala i zaustavlja se na prvom na kojem ima signala. Nalazi se u retku **Fine Tuning (kHz)**, skroz desno:

```
7 152.0   ◀  ■  ▶  ⊘   30 dB · 4 ▾
```

| Kontrola | Što radi |
|----------|-----------|
| **◀ ▶** | Pretraga dolje / gore. Dok stoji na signalu, strelica nastavlja pretragu. |
| **■** | Zaustavljanje. |
| **⊘** | Isključi ovaj kanal iz pretrage — za trajni nosilac ili smetnju. |
| **30 dB · 4 ▾** | Prag, a pokraj njega razina koja se upravo mjeri. Otvara postavke. |

Tekst lijevo pokazuje što skener radi: `Scanner` u mirovanju, frekvenciju do koje je došao tijekom pretrage, `◉ 3s` dok odbrojava do nastavka, `◉ 30·22s` dok je kanal još zauzet, `◉ hold` kad ostaje na mjestu.

**Postavke**

- **Range** — *Scan Band* pretražuje pojas u kojem pretraga počinje;
  *Scan Visible* pretražuje točno ono što slap prikazuje i prati ga ako
zumirate ili ga pomaknete.
- **Scan** — *Every channel* ugađa i sluša svaki kanal redom;
  *Skip empty* čita spektar i skoči ravno na signale.
- **Stop at** — koliko iznad šuma pojasa kanal mora biti da bi zaustavio
pretragu, u dB. Šum se prati neprekidno pa ista postavka vrijedi danju i noću. Prazan kanal ne pokazuje 0 dB — pogledajte na trenutak vrijednost na gumbu i postavite prag iznad nje.
- **Resume after** — koliko dugo kanal mora biti tih prije nego što pretraga
krene dalje. Stanke u govoru je ne pokreću ponovno. *Hold* ostaje dok ne pritisnete gumb.
- **Max stay** — kreće dalje nakon ovog vremena i ako je signal još tu, da
trajni nosilac ne bi zadržao pretragu zauvijek.

Korak prati način rada — 1 kHz u SSB, 0,1 kHz u CW, 5 kHz u AM, 9 ili 10 kHz na srednjim valovima i 9 kHz na dugim — a zaustavljanja padaju na mrežu kanala. Pretraga ostaje unutar svojeg raspona i unutar onoga što prijemnik može ugoditi; na rubu se vraća na drugi kraj i nastavlja.

Postavke i isključeni kanali pamte se u vašem pregledniku.


### Odabir načina demodulacije

Odaberite način prikladan signalu:

**Za govorne komunikacije:**
- **AM**: zrakoplovstvo, AM radiodifuzija, dio amaterskog prometa
- **FM**: VHF/UHF repetitori, FM radiodifuzija
- **USB**: KV amaterski radio (20 m, 17 m, 15 m, 12 m, 10 m)
- **LSB**: KV amaterski radio (160 m, 80 m, 40 m, 30 m)

**Za podatke/digitalne načine:**
- **USB**: većina digitalnih načina (FT8, PSK31, RTTY)
- **LSB**: neki digitalni načini na nižim KV pojasevima

**Za Morseov kod:**
- **CW**: telegrafski/Morseovi signali

### Podešavanje glasnoće

- **Klizač na zaslonu**: povucite klizač glasnoće. 0 % je tišina; ispod 50 % razina pada glatko u finim koracima, a od 50 % naviše svaki je korak 0,4 dB. Stranica pamti gdje ste ostavili klizač, na stranici za računalo i na /mobile; pri prvom posjetu počinje ondje gdje ga je postavio sysop (50 %, ako nije drukčije postavljeno).
- **Glasnoća preglednika**: koristite medijske kontrole preglednika
- **Glasnoća sustava**: podesite glasnoću računala
- **Tipkovnica**: koristite tipke + i - (ako su podržane)

### Upotreba S-metra

S-metar prikazuje jakost signala:

- **S0-S3**: vrlo slab signal, teško ga je pratiti
- **S4-S6**: slab do osrednji signal
- **S7-S9**: dobar do jak signal
- **S9+**: iznimno jak signal

**Savjet**: za najbolji zvuk ugodite se na signale koji pokazuju S7 ili više.

**Promjena izgleda instrumenta**: na analognom (kazaljčnom) S-metru kliknite na sam instrument — ili ga fokusirajte i pritisnite Enter ili Razmaknicu — da biste prošli kroz tri pozadine: tamni brušeni metal, svijetlu blijedosivu skalu i toplu jantarnu skalu u vintage stilu. Vaš preglednik pamti izbor, pa ostaje i nakon osvježavanja ili ponovnog pokretanja. Vrijedi po pregledniku i po adresi: otvaranje prijamnika preko imena računala i preko IP-a daje dvije odvojene postavke, a privatni prozor uvijek kreće od zadane vrijednosti stranice.

**Iznad 30 MHz** S-metar slijedi VHF standard IARU Regije 1: ondje je S9 na −93 dBm umjesto −73 dBm na kratkom valu, i dalje sa šest dB po S-jedinici. Kazaljka i traka same se prebacuju prema ugođenoj frekvenciji; vrijednosti u dBm i dBµV uvijek pokazuju izmjerenu razinu. Neke stanice svoje VHF/UHF prijemnike podese i tako da instrumenti **miruju na 0 dok je kanal prazan**, kao na VHF/UHF primopredajniku: iznad 60 MHz kazaljka i traka tada se dižu tek kad signal izađe iz šuma. Vrijednosti dBm, dBµV, SNR i NF uvijek pokazuju stvarne vrijednosti.

### Graf jačine signala

**Video** pod **Recording Options** snima spektar i slap zajedno sa zvukom (**Area** bira njihov dio). Traka na dnu slike prikazuje frekvenciju, način rada i vrijeme, a ugođena frekvencija označena je istim žutim crtama kao ugađač na zaslonu: žute točkaste crte na frekvenciji i na rubovima propusnog pojasa te zagrada iznad slapa.

Pod **Recording Options** gumb **Plotter** pokraj Audio, Video i Area crta očitanje S-metra kao pokretni graf — korisno za praćenje fadinga, usporedbu dviju antena ili stanica ili da vidite kad se opseg otvara. Svaki klik ide **Off → Fast → Medium → Slow**: graf prikazuje posljednjih 10, 30 ili 60 sekundi, s najnovijim očitanjem desno, a preglednik pamti izbor. Prikazuje istu vrijednost u dBm kao digitalni S-metar, 20 puta u sekundi; lijeva ljestvica je u S-jedinicama (VHF ljestvica iznad 30 MHz), desna u dBm, a raspon sam prati signal. Gornji redak prikazuje trenutno očitanje i vršnu vrijednost (**pk**) prikazanog razdoblja, nacrtanu i kao crvenu isprekidanu liniju; žuta linija s novom frekvencijom označava svako preugađanje. Gore desno **❚❚** zaustavlja graf (**▶** nastavlja), a **PNG** ga sprema kao sliku, `PhantomSDR_signal_<UTC>_<kHz>kHz.png`. Isključen ne troši ništa.

### Odabir prijemnika

Neke stanice imaju više od jednog prijemnika — na primjer jedan za kratki val i jedan za opseg od 2 m. U zaglavlju stranice prikazuju redak *Receivers:* s jednim gumbom po prijemniku; onaj na kojem ste prikazan je žuto. Pritiskom na drugi gumb otvara se stranica tog prijemnika, s vlastitim vodopadom, opsezima, chatom i popisom slušatelja. Na stranici /mobile isti gumbi nalaze se u gornjoj traci. Stanica s jednim prijemnikom ne prikazuje takav redak.

**Show All.** Iza tipki prijemnika nalazi se kućica **Show All**. Kad je označena, svaki drugi prijemnik stanice pojavljuje se ispod vašeg vodopada — njegov spektar i vodopad, s vlastitim oznakama i vlastitom ljestvicom frekvencija, najnoviji redak na vrhu. Prelaskom miša očitavate frekvenciju i najbližu oznaku; klik otvara taj prijemnik na tom mjestu, u istoj kartici: na oznaci u načinu rada oznake, drugdje u načinu koji daje plan pojasa. Preglednik pamti kućicu; isključena je dok je ne označite, jer je svaka traka još jedan tok vodopada (oko 10 KB/s).

**Prikaz koji ste ostavili ostaje.** Kad napustite stranicu prijemnika, pamte se njegov zoom, svjetlina, kontrast, način rada i frekvencija. Njegova traka na drugoj stranici tada prikazuje isti dio pojasa, s malim zelenim ▼ ondje gdje ste bili ugođeni; tipka u zaglavlju trake prikazuje taj raspon i **Full span** — pritisnite je za cijeli raspon prijemnika, a **Last view** za povratak. Klik na frekvenciju unutar tog prikaza ponovno otvara prijemnik upravo tako, s istim zoomom, razinama i načinom rada, umjesto cijelog raspona.

**Odabir pojasa na traci.** Kad drugi prijemnik pokriva više od jednog pojasa — KV prijemnik gledan sa stranice za 2 m — zaglavlje trake umjesto te tipke ima padajući popis: **Last view**, **Full span** i svaki pojas tog prijemnika, iste pojaseve koje prikazuju njegovi gumbi pojasa. Odaberite pojas i traka ga prikazuje kao taj gumb pojasa, od ruba do ruba sa svjetlinom i kontrastom pojasa; klik na traku tada otvara taj prijemnik uokviren na pojas, ugođen ondje gdje ste kliknuli. Vaš se izbor pamti u pregledniku, zasebno za svaki prijemnik. Prijemnik sa samo jednim pojasom, poput 2 m, zadržava tipku.

**Pravi prijemnik sam od sebe.** Frekvencija koju ovaj prijemnik ne pokriva, a drugi prijemnik stanice pokriva — upisana, iz poveznice, oznake, DX spota, poruke u chatu ili oznake drugog slušatelja — otvara stranicu tog prijemnika, ugođenu na nju. Kotačić miša i koraci po znamenkama nikad ne mijenjaju prijemnik, kao ni primopredajnik spojen preko CAT-a.

---

## Napredne značajke

### Automatska regulacija pojačanja (AGC)

AGC drži zvuk na ujednačenoj razini. Četiri tipke rade kao preklopnik AGC-a na primopredajniku: sve četiri daju istu glasnoću i razlikuju se samo po tome koliko se brzo pojačanje ponovno podiže kad signal oslabi ili prestane.

- **Auto**: vlastiti AGC prijamnika, zasebno podešen za SSB, AM i C-QUAM. To je zadana postavka.
- **Fast**: bez zadržavanja; pojačanje se oporavlja za oko 0,3 s. Šum se podiže između riječi, a brzi feding prati se izbliza. Dobro za CW i za izdvajanje slabe stanice između jakih.
- **Medium**: zadržava 0,25 s, zatim se oporavlja za oko 1,2 s. Dobra svakodnevna postavka za SSB.
- **Slow**: zadržava 1 s, zatim se oporavlja za oko 3 s. Pozadina ostaje niska između riječi i između javljanja; slaba stanica odmah nakon jake nekoliko sekundi zvuči tiše.

**Dok je dekoder otvoren**, AGC se drži na Slow, bez obzira na odabranu tipku: dekoder čuje isti zvuk kao i vi i treba mu ujednačeno pojačanje. Pokraj naslova AGC pojavljuje se mala napomena **Slow (decoder)**, a vaš se izbor vraća čim se zatvori posljednji dekoder.

**Preporuka**: počnite s „Fast" za AM i „Slow" za SSB.

### Četiri regulatora šuma

NR, NB, NS i AN zasebni su prekidači, svaki protiv druge vrste šuma. Neovisni su — uključivanje jednoga ne uključuje drugi — i mogu se slobodno kombinirati.

Nijedan ne doseže dekodere: FT8, CW, WSPR, SSTV, FAX, NAVTEX, RTTY/PSK31/Olivia/Packet/APRS i QRSS grabber čitaju zvuk *prije* ovih filtara, pa ih možete namještati isključivo po sluhu bez utjecaja na dekodiranje. Vidjeti
[priručnik za dekodere](DECODERS.md#14-opći-savjeti).

### Smanjenje šuma (NR)

Spektralno smanjenje šuma. Procjenjuje razinu šuma u svakom dijelu zvučnog spektra i te dijelove stišava, a ono što se izdiže iznad šuma ostavlja na miru.

**Koristite kada**: čujete ravnomjerno siktanje ili bijeli šum iza signala.

Postojani tonovi — CW nota, nosilac — prepoznaju se kao signal i štite, pa NR ne pojede CW signal kako bi to učinio naivan filtar. Tipičan učinak: 10–12 dB manje šuma između riječi. Sam govor gubi znatno manje od 1 dB na jakim signalima i nekoliko dB na vrlo slabima, koji se ipak razumiju bolje nego bez NR-a.

### Prigušivač impulsnog šuma (NB)

Uklanja impulsni šum: klikove, praskove, atmosferske izboje, paljenje motora i smetnje s dalekovoda. Prati ovojnicu zvuka i utišava samo uzorke koji daleko iskaču iznad nje — oko jedne milisekunde po prasku, s mekim ulazom i izlazom kako samo prigušivanje ne bi kliknulo.

**Koristite kada**: čujete klikove ili praskove s dalekovoda, motora, grmljavine
ili paljenja vozila.

Notch filtri mrežnog bruma na 50 Hz i 60 Hz slijede ovu tipku.

### Potiskivanje pozadinskog šuma (NS)

Kroz nekoliko sekundi mjeri vlastiti prag šuma pojasa i stalnim iznosom stišava sve što leži na njemu, dublje na visokim nego na niskim zvučnim frekvencijama. Dok NR reagira iz trenutka u trenutak, NS je spora, mirna ruka: spušta šum pojasa ne mijenjajući kako signal zvuči.

**Koristite kada**: pojas je miran ali šuman, a želite spustiti šum bez
„podvodnog" prizvuka agresivnog NR-a.

Djeluje samo u USB, LSB i AM — CW, FM i digitalni načini ostaju netaknuti. Prag mjeri iznova pri svakoj promjeni frekvencije ili načina rada i smiri se unutar nekoliko sekundi.

### Automatski notch (AN)

Sam pronalazi i uklanja postojane ometajuće tonove — heterodine, nosioce, zvižduke — bez ručnog postavljanja notcha. Neprekidno se prilagođava, pa istodobno uklanja više tonova i drži prigušenim ton koji klizi.

**Koristite kada**: čujete zvižduk ili ton preko željenog signala.

Zaobiđen u CW-u, gdje je željeni signal *upravo* postojan ton.

**Napomena o kašnjenju**: NR i NS dok su uključeni dodaju svaki oko 40 ms
kašnjenja zvuka (oba zajedno oko 80 ms). NB i AN ne dodaju ništa. To se tiče samo slušanja, nikada dekodera.

### Automatski squelch (SQL)

Utišava zvuk kada nema signala:

- **Off**: uvijek se čuje (uz šum)
- **Auto**: automatski postavlja prag
- **Manual**: prag se podešava ručno

**Koristite kada**: nadzirete frekvenciju u očekivanju prometa.

Dok je SQ isključen, broj praga pokraj klizača prikazan je sivo.

### Smanjenje šuma umjetnom inteligencijom (AI)

Tipka **AI**, s klizačem jačine pokraj nje, nalazi se na ploči Audio & Buffer odmah ispod SQ. Na stranici /mobile nalazi se na kartici Audio, ispod Squelch. Uklanja šum pojasa iz govora pomoću RNNoise, male neuronske mreže naučene na govoru.

Sve se odvija u vašem pregledniku: ništa se ne šalje na vanjski poslužitelj, nije potreban račun, a prijamnik nema nikakav dodatni posao.

- **Uključivanje**: kliknite **AI**; tipka postaje plava. Prvi klik preuzima modul (oko 1,3 MB), a tipka pulsira dok se učitava.
- **Jačina**: određuje koliko snažno djeluje dok netko govori — niže vrijednosti zadržavaju više izvornog zvuka. Gornji kraj ljestvice namjerno je blaži od punog rezanja, kako govor ne bi bio oštećen ni na 100 %, što i dalje čisti više nego 50 %. Između riječi sama djeluje jače, pa šum ondje pada još više. Zadana vrijednost je 50 %. Možete je postaviti i dok je AI isključen.
- **Oznaka stanja**: oznaka AI ispod prikaza frekvencije svijetli cijan dok AI radi, a prikazuje se napola prigušena kad je AI uključen, ali trenutni način nije govorni.

**Koristite kad**: slušate SSB ili AM govor na pojasu s puno šuma. Šum između riječi obično padne za oko 10 dB uz zadanih 50 %, a na 100 % više, do oko 20 dB, dok govor zadržava svoju razinu.

Samo govorni načini — USB, LSB, AM i SAM. U CW, FM, digitalnim načinima i C-QUAM zvuk prolazi nepromijenjen, jer mreža CW ton ili glazbu smatra šumom. Kao ni četiri regulatora šuma, nikad ne dolazi do dekodera. Kod slabih stanica (ispod oko +6 dB SNR-a) sama mjeri omjer signala i šuma i jače izglađuje svoje odluke, kako govor ne bi poprimio žuboreći, „vodenasti“ zvuk koji takav filtar može dati; jake stanice obrađuju se točno kao prije. Ako vrlo slab signal i dalje zvuči obrađeno, smanjite klizač. Dodaje oko 50 ms kašnjenja zvuka.

### Zvučni spremnik i kašnjenje

Zvuk stiže u preglednik u malim paketima, kod tipičnog prijamnika po 35 ms, a preglednik zadržava malu zalihu kako paket koji kasni ne bi izazvao prekid. Ta zaliha je **spremnik** (buffer) i čini najveći dio kašnjenja između prijamnika i vašeg zvučnika.

- **Desktop**: u panelu Audio & Buffer tipka s ikonom mreže povećava spremnik za jedan korak po kliku (postaje zelena iznad najnižeg koraka), a klizač pokraj nje izravno bira korak od 1 do 6. Najniži korak odgovara žičanoj vezi; telefoni počinju na koraku 2.
- **/mobile**: tipka **BUF** i klizač **Buffer** u kartici Audio rade isto.

Spremnik se sam prilagođava. Stranica mjeri koliko nepravilno vaša veza isporučuje zvuk i drži samo onoliko zalihe koliko je posljednja minuta pokazala da treba, plus sigurnosnu rezervu odabranog koraka: 20 ms na koraku 1, 50 ms na koraku 2, više na višim koracima. Nakon trenutnog problema s mrežom dodatno kašnjenje ponovno nestaje za minutu-dvije, a mala razlika između takta vaše zvučne kartice i takta prijamnika više ne izaziva prekid svakih nekoliko minuta. Prilagodbe su po nekoliko milisekundi, rade se ondje gdje se zvuk ponavlja i ne čuju se. Dekoderi i vaše snimke nikad nisu pogođeni: dobivaju svaki uzorak.

Ako se zvuk prekida, povećajte spremnik za jedan korak. Na telefonu preko kućnog Wi-Fija kašnjenje od prijamnika do zvučnika obično je oko 100–150 ms; mreža između vas i prijamnika dodaje se na to.

### Vaše ime ili pozivni znak

Pokraj **Open Additional Info** nalazi se polje za vaše ime ili pozivni znak: najviše 10 znakova i bez razmaka, kao na WebSDR-u. Upišite ga i pritisnite **Save** (ili Enter); s **Edit** ga kasnije mijenjate. Preglednik ga pamti, i kad prijeđete na druge prijemnike postaje. Ostavite li polje prazno, ostajete anonimni: *anonymous* i broj u chatu, a svugdje drugdje samo vaša lokacija. Na mobitelu je isto polje iznad prikaza frekvencije.

Vaše ime pojavljuje se u prozoru **Users**, u vašim redcima chata i na oznaci koju drugi slušatelji vide ispod svog waterfalla — vaše ime, a zatim vaša lokacija, na primjer `SV1BTL-Athens`. Vaš vlastiti položaj je žuta ★ s vašim imenom pokraj. Prijeđite mišem preko oznake drugog slušatelja da vidite frekvenciju i način na koji je ugođen; klikom se ugađate onamo.

Kao na WebSDR-u, IP adresa nijednog slušatelja ne prikazuje se drugima — ni u prozoru Users ni u Statistici korisnika, koja posjetitelje broji po anonimnom kodu.

Prozor Users prikazuje i koji dekoder pojedini slušatelj koristi — FT8, CW, DRM, HFDL itd. — kao malu zelenu oznaku iza načina rada, a Statistika korisnika ima ploču **Decoder Popularity**: koliko je sesija koristilo koji dekoder. U prozoru Users otvorenom sa stranice prijemnika, **Tune** pokraj slušatelja postavlja vas na ono što on sluša: istu frekvenciju i način rada, širinu njegova filtra i njegov dekoder — pokrenut za vas, ili se vaš zaustavlja kad on ne koristi nijedan. Zatim se pojas uokviruje kao s **To Band**: slap prikazuje cijeli pojas u kojem je, sa svjetlinom, kontrastom i korakom ugađanja tog pojasa.

### Propagacija na opsezima

Ispod **Open Additional Info**, pokraj *Current band propagation and statistics:*, gumb **🌐 Propagation** otvara stranicu s uvjetima na opsezima za lokaciju ovog prijemnika. Svaki opseg od 160 m do 6 m ocjenjuje kao Good, Fair, Poor ili Closed, za pet udaljenosti (do 300 km, 300–1000 km, 1000–2000 km, 2000–3000 km i DX iznad 3000 km). Ocjene se temelje na trenutnim mjerenjima najbližih ionosondi (foF2 i MUF), položaju sunca te sunčevim i geomagnetskim podacima (sunčev tok, Kp, X-zrake, sunčev vjetar). Karta je globus sa stanicom u središtu: povucite da ga zavrtite, povucite desnom tipkom (ili Ctrl + povlačenje) da ga nagnete, a **2D / 3D** prebacuje na ravnu kartu. Njegovi prstenovi **dometa opsega** za svaki otvoreni opseg pokazuju isprekidani prsten gdje završava njegova mrtva zona i puni prsten na najvećem dometu; legenda ispod karte daje raspon svakog opsega, a klik na opseg prikazuje samo njegovo otvoreno područje, zasjenjeno prema Good / Fair / Poor. Globus prikazuje i krivulje MUF i foF2, dan i noć sa sivom linijom te svaku ionosondu koja sada javlja, u cijelom svijetu — svijetle one korištene ovdje. Prekidači slojeva u njegovu kutu uključuju ili isključuju svaki od njih. Prstenovi prate ionosferu smjer po smjer — gdje se put reflektira, sunce ondje, auroralni oval — pa opseg obično seže dalje u jednom smjeru nego u drugom; tablica iznad je pogled ravno iznad postaje. Globus treba preglednik s WebGL2. Stranica se sama osvježava svakih 10 minuta. To je procjena za veze s ovog prijemnika, a ne zapis onoga što se čuje.

### Chat

Kad je operater uključio chat, on ima vlastitu ploču na desktop stranici i karticu **Chat** na /mobile. Upišite poruku i pošaljite je: odlazi pod imenom iz vašeg polja za ime (vidi gore) ili kao *anonymous* i broj.

Da biste odgovorili na određenu poruku, kliknite **↪ Reply** pokraj njezina vremena. Redak iznad polja za unos pokazuje kome i na što odgovarate; pišite i šaljite kao i obično, ili pritisnite ✕ ili Esc za odustajanje. Odgovor se pojavljuje uvučen ispod poruke na koju odgovara, s kratkim retkom citata. Odgovor na odgovor ide u istu nit. Poslužitelj čuva zadnjih 20 poruka; kad je izvorna poruka već ispala iz te povijesti, odgovor prikazuje samo ime i vrijeme na koje odgovara.

Frekvencija u poruci je poveznica: klik ugađa onamo, u načinu rada navedenom uz nju. Pojas se uokviruje kao s **To Band** — slap prikazuje cijeli pojas, sa svjetlinom i kontrastom tog pojasa — i gumb pojasa zasvijetli.

### Funkcija uvećanja

Uvećava prikaz slapa:

Klizač **Zoom** ima 20 koraka, prikazanih kao ×1 do ×20 (korak, a ne uvećanje). ×1 prikazuje cijeli prijemnik; svaki korak sužava prikaz oko ugođene frekvencije za isti faktor, pa uvećanje raste ravnomjerno, sve do nekoliko kHz na ×20. Gumb uz klizač svakim klikom ide korak dalje i nakon ×20 vraća se na ×1.

**Koristite kada**: trebate jasnije vidjeti signale ili se precizno ugoditi.

**To Band** prikazuje cijeli pojas frekvencije na kojoj ste, s 5 kHz rezerve na svakom rubu.

### Auto Adj. (slap)

Prekidač **Auto Adj.** među kontrolama slapa sam podešava svjetlinu i kontrast slapa. Mjeri razinu šuma preko cijelog vidljivog raspona i pretvara je u jednoliku, tamnu pozadinu — i ondje gdje se šum razlikuje od jednog dijela raspona do drugog — a sve iznad nje razvlači, tako da se slabi signali ističu, a najjači dosežu gornje boje. Radi jednako sa svakom paletom boja, a mijenja se samo slap: krivulja spektra zadržava svoju stvarnu dB ljestvicu. Dok je uključen, klizači Min i Max su zaključani i prikazuju izmjerenu razinu šuma i vrh; isključivanjem se vraćaju na postavke opsega.

### 3D spektar

Gumb **3D** pokraj **Reverse**, među kontrolama slapa, prikazuje spektar kao reljef posljednjih nekoliko sekundi: frekvencija u širinu, vrijeme u dubinu zaslona, jakost signala kao visina. Koristi iste boje, istu svjetlinu (Min), isti kontrast (Max) i isti Auto Adj. kao slap, a zumiranje i povlačenje prati kao ravni spektar. Klik ugađa, povlačenje pomiče po opsegu, a kotačić miša zumira, točno kao na ravnom spektru. Reljef se prema natrag sužava kao stol gledan pod kutom, a što je red dalje, to su mu vrhovi niži. Klik na stariji red ugađa na frekvenciju tog reda, a frekvencija prikazana ispod miša tada pokazuje i starost reda (na primjer 7.074.000 · −6 s). Gumb **⚙** otvara dva klizača: **Angle** (koliko strmo se dno penje prema natrag) i **Depth** (koliko se reljef sužava i redovi snižavaju prema natrag); **Reset** vraća zadane vrijednosti, a postavka se pamti u pregledniku. Oznake lijevo pokazuju koliko je sekundi neki red star, a desno koliko dB iznad razine Min doseže vrh (skrivene su dok je Auto Adj. uključen). **✕ 2D**, ili ponovno gumb 3D, vraća ravni spektar, a izbor se pamti u pregledniku. Prikaz traži WebGL2, koji nudi svaki današnji preglednik; bez njega se gumb ne pojavljuje. Video snimka napravljena dok je 3D prikaz otvoren snima 3D prikaz umjesto ravnog spektra. 3D prikaz preuzet je iz PhantomSDR-ORSAT autora F1NSK.

**Linija pokazivača.** Gdje god se miš nalazi iznad spektra, slapa ili 3D prikaza, isprekidana žuta linija označava tu frekvenciju i na spektru i na slapu, a spektar je ispisuje u MHz.

### Audio analizator

Gumb **📊 Show** u odjeljku Spectrogram otvara audio analizator ispod slapa; **📊 Hide** ga zatvara. Prikazuje zvuk koji slušate, nakon demodulacije, kao spektar s mrežom u dB i žutom linijom vršnih vrijednosti. **Gain** podiže ili spušta krivulju, a **Color** bira njezine boje. Spektar se crta reljefno, osvijetljen odozgo zdesna. U bojama Rainbow svaki se stupac boji prema tome koliko se na svojoj frekvenciji izdiže iznad šuma — tamnoplavo za šum, i u stankama govora kad ga AGC podigne, zatim plavo, cijan, žuto, narančasto i crveno za sve jače signale — dok se njegova visina i dalje očitava na ljestvici u dB. Kao i glavni spektar, analizator i njegova izvješća crtaju se na crnoj podlozi, sa sivim linijama mreže.

- **Frekvencijska os.** Prati način rada: 0–4,5 kHz u SSB-u, 0–2 kHz u CW-u, 0–5,5 kHz u AM-u i FM-u. U LSB-u je obrnuta (visoki tonovi lijevo), pa se čita u istom smjeru kao RF spektar. Cijan linija označava ugođenu frekvenciju (u CW-u ton od 600 Hz), a ispod miša analizator prikazuje audio frekvenciju i RF frekvenciju u kHz.
- **Oznake širine pojasa.** Obojene oznake pokazuju preporučene širine za način rada — SSB standard 300–2700 Hz i ESSB 50–4000 Hz, CW 500 Hz i 250 Hz, AM radiodifuzija i AM radioamateri — a isprekidani bijeli okvir pokazuje vaš trenutni filtar. Standardna širina crta se punom cijan linijom, alternativna (ESSB, CW 250 Hz, AM radioamateri) isprekidanom svijetloplavom.
- **RF prikaz u AM-u i FM-u.** Demodulirani zvuk nema nosilac, pa u tim načinima analizator prikazuje stanicu onakvu kakva je na slapu: nosilac u sredini, bočni pojasevi s obje strane. Njegova ljestvica je u dB iznad šuma.
- **Zauzeta širina.** Redak ispod spektra daje širinu koju zauzima ugođena stanica (metoda −26 dB, mjereno na slapu) s ocjenom za SSB, AM i CW: zeleno unutar norme, narančasto široko (ESSB stanica je narančasta), crveno za vjerojatan splatter, koji je i osjenčan na spektru. Potrebno je oko 2 s mjerenja; statičke smetnje se zanemaruju.
- **Zumiranje nije potrebno.** Dok je analizator otvoren, stranica drži drugu, nevidljivu vezu slapa, centriranu na stanicu i s finom rezolucijom koju mjerenja trebaju — tako RF prikaz i sva RF mjerenja rade pri bilo kojem zumu slapa. Zatvara se s analizatorom. Troši oko 12–14 KB/s (oko 45 MB na sat) dodatnih podataka dok je analizator otvoren; na vezi s ograničenim prometom zatvorite ga kad vam ne treba.
- **Ugađanje iz analizatora.** Frekvencija u zaglavlju analizatora ugađa se kao glavni prikaz: postavite miš na znamenku i okrenite kotačić, ili lijevi klik za korak gore i desni klik za korak dolje; klik pokraj znamenki otvara brojčanu tipkovnicu. Klik na oznaku načina rada otvara izbornik načina.
- **Mute.** Gumb Mute u zaglavlju analizatora utišava prijemnik dok analiza teče dalje — za provjeru vlastite emisije bez vraćanja zvuka u mikrofon. Zvuk utišan ondje vraća se kad se analizator zatvori.

**SSB audio izvještaj.** U USB-u i LSB-u ispod analizatora otvara se ploča izvještaja. Na pomičnom prozoru od 20 s, i samo dok stanica govori, ocjenjuje tonsku ravnotežu — bas (100–300 Hz) i prisutnost (1,5–2,7 kHz) prema srednjem pojasu, u usporedbi s referencom koju odaberete: **Standard SSB**, **DX / punch** ili **ESSB / hi-fi** — zatim kompresiju, mrežno brujanje (linije na 50/100/150 ili 60/120/180 Hz), preostali nosilac i suprotni bočni pojas (oboje mjereno na slapu) te zauzetu širinu. Svaki redak dobiva zelenu, narančastu ili crvenu točku; redak koji se ne može izmjeriti kaže zašto, obično zbog prijamnog filtra (za bas njegov donji rub mora biti na oko 120 Hz ili niže). Iznad 2,7 kHz ništa se ne ocjenjuje, iako ga analizator i dalje prikazuje. Prosječni oblik glasa crta se na analizatoru kao plava krivulja. **Store A** je čuva kao isprekidanu krivulju A, za usporedbu nakon što druga stanica promijeni postavku; **Clear A** je briše, a **↺ Restart** počinje 20 s ispočetka. **Generate a listening report** preuzima HTML datoteku za slanje drugoj stanici, s ocjenama, slikom spektra i posljednjih 20 sekundi zvuka. Mjerenja su orijentacijska: fading te filtar i AGC prijemnika utječu na njih, pa odaberite sporu AGC (Slow). Analizator i izvještaj preuzeti su iz PhantomSDR-ORSAT autora F1NSK.

**AM i FM izvještaj.** U AM-u, C-QUAM-u i FM-u ispod analizatora umjesto toga otvara se ploča izvještaja za te načine rada. Ovdje zvuk prijemnika malo govori o odašiljaču — AM nosilac uklanja se iz zvuka, a AGC određuje razinu — pa izvještaj ocjenjuje stanicu uglavnom na RF spektru, na pomičnom prozoru od 20 s. U **AM-u**: dubinu modulacije (prosjek i vrh, iz snage bočnih pojaseva prema nosiocu), ravnotežu dvaju bočnih pojaseva, odmak nosioca od ugođene frekvencije, širinu zvuka, mrežno brujanje i zauzetu širinu. U **FM-u**: devijaciju (približno, iz širine 99 % po Carsonovu pravilu), širinu 99 % s kanalom u koji stane (12,5 ili 25 kHz), odmak frekvencije, širinu zvuka, CTCSS ton ako postoji i mrežno brujanje. Slap svaki redak usrednjava kroz oko 0,1 s, pa vršna dubina izgleda niža nego na osciloskopu; nosilac koji dosegne vrh ljestvice slapa prejak je za mjerenje, i izvještaj to kaže. Odmak nosioca uključuje i pogrešku frekvencije samog prijemnika. **↺ Restart** i **Generate a listening report** rade kao u SSB izvještaju.

### Upravljanje primopredajnikom (CAT)

Vaš primopredajnik i stranica prijemnika mogu ostati na istoj frekvenciji: okrenite gumb za ugađanje na uređaju i slap ga slijedi, ili kliknite signal na slapu i uređaj se ugodi na njega. To se odnosi samo na *vašu* sesiju slušanja; nitko drugi na prijemniku to ne primjećuje.

**S aplikacijom Desktop PhantomSDR+ (4.0 ili novija).** Desktop aplikacija ima izbornik **Rig**. *Rig → Rig control...* otvara prozor u kojem birate svoj uređaj i način povezivanja, a sam izbornik uključuje i isključuje sinkronizaciju. Sinkronizira frekvenciju, način rada i širinu filtra, u jednom ili oba smjera, i može utišati prijemnik dok odašiljete. Osim PhantomSDR-Plusa na isti način upravlja i prijemnicima **KiwiSDR, PA3FWM WebSDR i UberSDR**. Do uređaja dolazi na jedan od četiri načina:

- **Ugrađeni upravljači** — bez drugog softvera: Icom (CI-V), Yaesu (novi CAT i FT-817/857/897), Kenwood, Elecraft, FlexRadio SmartSDR CAT, QRP Labs i ostali uređaji kompatibilni s Kenwoodom.
- **Hamlib** — svaki uređaj koji Hamlib poznaje, više od 300, odabran s popisa s pretraživanjem. Instalacijski programi za Windows sadrže Hamlib; na Linuxu instalirajte `libhamlib-utils`.
- **rigctld na mreži** — `rigctld` koji je već pokrenut.
- **flrig** — za uređaj koji flrig već dijeli s fldigijem, WSJT-X-om ili dnevnikom veza.

Aplikacija, njezini instalacijski programi i cijeli priručnik nalaze se na [Desktop PhantomSDR+ (Dropbox)](https://www.dropbox.com/scl/fo/kjwj96zg3kj7dgq4fjef9/APnA3c9hhv4hk3YMGIGjH7s?rlkey=jfiwklly63kv73poalx631pk3&st=m37uvaym&dl=0).

**S web preglednikom.** [CATsync Tool for WebSDRs](https://catsyncsdr.wordpress.com/) (Windows) povezuje uređaj sa stranicom prijemnika otvorenom u vašem pregledniku. Sinkronizira frekvenciju i način rada.

**Širina filtra i utišavanje pri odašiljanju** rade na prijemnicima KiwiSDR, WebSDR i UberSDR te na PhantomSDR-Plus prijemniku s inačicom 4.1.0 ili novijom. Na starijem PhantomSDR-Plusu frekvencija i način rada i dalje se sinkroniziraju; filtar ne.

Cijeli priručnik — svaka postavka, podržani uređaji, kako se sprječava da se strane „svađaju” i rješavanje problema — nalazi se u **[Upravljanje primopredajnikom](RIG_CONTROL.md)**.

**Za programere.** Svaka stranica prijemnika nudi ove funkcije na `window`, a njih koriste oba alata:

| Funkcija | Što radi |
|---|---|
| `catsync_getFrequency()` / `catsync_setFrequency(hz)` | Ugođena frekvencija, u Hz |
| `catsync_getMode()` / `catsync_setMode(mode)` | `USB`, `LSB`, `CW`, `CW-L`, `AM`, `FM`, `WBFM` … |
| `catsync_getBandwidth()` / `catsync_setBandwidth(hz)` | Ukupna širina propusnog pojasa, u Hz. Postavite je nakon načina rada: promjena načina vraća propusni pojas na zadano |
| `catsync_getMute()` / `catsync_setMute(on)` | Utišavanje, preko gumba za utišavanje na stranici |
| `catsync_ready` | `true` čim su funkcije postavljene |

Posljednja tri retka nova su u inačici 4.1.0; prije poziva provjerite postoji li funkcija.

---

## Načini demodulacije

### AM (amplitudna modulacija)

**Koristi se za:**
- zrakoplovne komunikacije
- AM radiodifuziju
- dio amaterskog radija
- pomorske komunikacije

**Značajke:**
- široki pojas (obično 10 kHz)
- osjetljiva na šum
- lako se ugađa (dovoljno je kliknuti na signal)

**Dobre prakse:**
- koristite brzi AGC
- uključite prigušivač impulsnog šuma ako čujete klikove
- ugodite se na vrh signala u slapu

### QUAM (C-QUAM AM stereo)

**Koristi se za:**
- Srednjovalne postaje koje emitiraju AM stereo

**Značajke:**
- Širina 10 kHz, dekodira se kao stereo par umjesto mono AM-a
- Natpis na gumbu sam postaje **zelen** kada je prisutan stereo pilot od 25 Hz, pa vidite koje postaje doista emitiraju u stereu prije nego što ga odaberete
- Iz AM-a novi pritisak prebacuje na sinkronu detekciju na nosiocu; natpis postaje **žut** i prikazuje `SAM`. Treći pritisak vraća na obični AM
- Dok SAM radi, ispod pokazivača stanja pojavljuje se redak poput `SAM +3.2 Hz · 97%` (kod digitalnog S-metra ispod VFO | način rada | širina pojasa): koliko je nosilac stanice udaljen od ugođene frekvencije (+ = iznad nje) i koliko je dobro detektor zaključan — žut od 85 %, ispod 60 % opet siv. Žuto znači samo da postoji stabilan nosilac, ne i koji je način rada: i obični AM nosilac na frekvenciji označenoj kao DRM boji ga žuto
- C-QUAM zvuk prenosi se Opusom; svi ostali načini koriste FLAC

**Preporuke:**
- Noću tražite zeleni natpis na jakim srednjovalnim signalima
- Ako stereo zvuči nestabilno, `SAM` je mirniji izbor uz slab nosilac

### FM (frekvencijska modulacija)

**Koristi se za:**
- VHF/UHF amaterske repetitore
- javne službe (policija, vatrogasci, hitna pomoć)
- komercijalni dvosmjerni radio
- neke satelitske komunikacije

**Značajke:**
- uski pojas (obično 12,5 ili 25 kHz)
- izvrsna otpornost na šum
- „efekt zahvata" (pobjeđuje najjači signal)

**Dobre prakse:**
- ugodite se precizno na sredinu signala
- koristite squelch za utišavanje u mirovanju
- isključite smanjenje šuma (nije potrebno)

### USB (gornji bočni pojas)

**Koristi se za:**
- KV amaterski radio (iznad 10 MHz)
- većinu digitalnih KV načina rada
- pomorske komunikacije (iznad 8 MHz)

**Značajke:**
- uski pojas (obično 2.4 kHz)
- učinkovito iskorištenje spektra
- zahtijeva precizno ugađanje

**Dobre prakse:**
- koristite spori AGC
- ugodite se na donji rub signala u slapu
- po potrebi uključite smanjenje šuma

### LSB (donji bočni pojas)

**Koristi se za:**
- KV amaterski radio (ispod 10 MHz)
- neke digitalne KV načine rada
- pomorske komunikacije (ispod 8 MHz)

**Značajke:**
- isto kao USB, ali zrcalno
- konvencija: LSB na nižim KV pojasevima

**Dobre prakse:**
- koristite spori AGC
- ugodite se na gornji rub signala u slapu
- po potrebi uključite smanjenje šuma

### CW (neprekinuti val / Morseov kod)

**Koristi se za:**
- amatersku telegrafiju
- navigacijske svjetionike
- postaje signala točnog vremena

**Značajke:**
- vrlo uski pojas (100-500 Hz)
- velika učinkovitost
- za razumijevanje je potrebno poznavanje Morseova koda

**Dobre prakse:**
- koristite uski filtar (400-500 Hz)
- ugodite se precizno na sredinu tona
- uključite audiofiltar za bolji ton

### CW-L (CW, donji bočni pojas)

Isti Morseov filtar od ±250 Hz kao **CW**, ali se ton uzima ispod nosioca umjesto iznad njega. Korisno kada se signal bolje prima s donje strane ili kada smetajući nosilac leži tik iznad željenoga.

**Na stolnoj stranici nema gumba CW-L.** Njezin red načina rada je `USB · LSB · CW · AM · QUAM · FM · IQ`. CW-L se nudi na pojednostavljenoj stranici `/mobile`, a na stolnoj se i dalje može postaviti poveznicom ili knjižnom oznakom koja ga imenuje.

Rade i poveznice pisane za KiwiSDR ili UberSDR: `modulation=CWU` (ili `CW-U`) otvara u CW-u, a `modulation=CWL` u CW-L-u.

### WBFM (širokopojasni FM)

**Koristi se za:**
- FM radiodifuziju (88-108 MHz)
- neke satelitske silazne veze

**Značajke:**
- vrlo široki pojas (200 kHz)
- izvrsna kvaliteta zvuka
- visoka vjernost

**Dobre prakse:**
- ugodite se točno na središnju frekvenciju
- za radiodifuziju squelch nije potreban
- uživajte u zvuku visoke kvalitete!

### IQ (sirovi I/Q)

**Koristi se za:**
- snimanje dijela pojasa za kasnije reproduciranje u HDSDR-u, SDR#-u, SDR++-u ili SDRuno-u
- slušanje drugim programom — može ga zatražiti i KiwiSDR klijent

**Značajke:**
- 12 kHz pojasa oko ugođene frekvencije, kao I i Q — čuje se stereo, I lijevo i Q desno, kako ga reproducira KiwiSDR. Zvuči kao šum: to je signal prije ikakve demodulacije
- šalje se bez gubitaka (FLAC), nikad Opusom, koji bi uništio I/Q
- razina prati pojas: šum ostaje tih (oko −45 dBFS), a jaka stanica dovodi se na oko −20 dBFS. NR, NB, NS, AN, AI i squelch ne primjenjuju se, a odabir IQ-a isključuje dekoder koji radi
- **Audio** pod *Recording Options* snima I/Q; kad zaustavite, **Download IQ** sprema ga kao WAV datoteku (16-bitni stereo, 12 kHz) s imenom na primjer `PhantomSDR_20261026_031500Z_6030000Hz_IQ.wav`. HDSDR, SDR# i SDRuno čitaju frekvenciju i vrijeme iz datoteke, SDR++ iz imena, pa se snimka otvara već ugođena
- odlučuje stanica: gumb se pojavljuje samo gdje je `[server] iq` uključen (zadano)

**Dobre prakse:**
- stanicu koju želite stavite u sredinu — snimka obuhvaća ±6 kHz oko ugođene frekvencije (±12 ili ±24 kHz kod šireg IQ-a, niže)
- za slušanje jedne stanice jednostavniji je normalan način rada; IQ je za snimanje, za druge programe i za slušanje više stanica odjednom (niže)

#### Širi IQ: 24 i 48 kHz

Gdje ga postaja nudi, ploča IQ Demodulators ima **Width: 12 kHz · 24 kHz · 48 kHz**. 24 kHz obuhvaća široke DRM načine ili stanicu s oba susjeda, 48 kHz cijelu skupinu radiodifuznih stanica ili CW/digitalni dio opsega. Propusni pojas na vodopadu i slika na ploči prate širinu, snimka se radi u njoj (WAV na 24 ili 48 kHz), a preglednik pamti izbor. Širi IQ postaju stoji više uploada — oko 0,7 Mbit/s po slušatelju na 24 kHz i 1,4 Mbit/s na 48 kHz, prema 0,35 na 12 kHz — pa postaja određuje koliko ga slušatelja smije imati istodobno; kad su sva mjesta zauzeta, ostajete na 12 kHz (ploča to kaže), a stranica ponovno pita svakih 30 sekundi. Za Dream ili drugi program na virtualnom kabelu na 48 kHz postavite i kabel na 48 kHz. KiwiSDR klijenti uvijek dobivaju 12 kHz.

**Za sysopa:** dva retka pod `[server]` u konfiguraciji prijemnika uključuju ga, za bilo koji prijemnik; zatim ponovno pokrenite taj prijemnik. Iste postavke nalaze se u administratorskoj ploči pod **Receivers → ✎ CHANGE SETTINGS**, koja ujedno ponovno pokreće prijemnik.

```
iq_wide=48            # 12 (isključeno, zadano), 24 ili 48 kHz
iq_wide_listeners=4   # slušatelji sa širokim IQ-om istodobno, 0 = bez ograničenja
```

#### IQ demodulatori

Dok je prijemnik u IQ-u, ispod dekodera otvara se ploča **IQ Demodulators**. Pokreće do šest prijemnika na I/Q-u u vašem pregledniku — prijemnik se ne preugađa, a računalo stanice nema dodatnog posla:

- Slika prikazuje cijelu širinu IQ-a (12, 24 ili 48 kHz) oko ugođene frekvencije sa stvarnim frekvencijama; svaki demodulator je obojena traka, a njegova vlastita frekvencija crta u njoj. Klik na sliku premješta onamo odabrani demodulator; kotačić miša iznad nje pomiče ga za 10 Hz (Shift 100 Hz)
- Svaki redak ima način rada (USB, LSB, CW, AM, DSB, FM), frekvenciju s gumbima « ‹ › » (100 i 10 Hz), pokazivač razine, **M** za utišavanje i **✕** za uklanjanje. Odabrani redak ima još **Width**, **Volume** i **Pan**
- **DSB** sama prati nosilac (petlja za praćenje nosioca): postavljena unutar nekoliko desetaka Hz od nosioca, zvuk ostaje čist i stabilan, kod DSB-a s potisnutim nosiocem kao i kod AM-a, gdje radi kao sinkroni AM
- **+ Add** dodaje demodulator na ugođenoj frekvenciji, do šest. **Demodulators** / **Raw I/Q** bira slušate li njih ili čisti I/Q
- Postavljeni su u odnosu na ugođenu frekvenciju, pa ugađanje prijemnika pomiče sve zajedno; stanica više od 6 kHz od ugođene frekvencije nije u toku
- Primjer: DX stanica koja radi split — jedan LSB demodulator na DX-u, lijevo, i jedan na pozivateljima nekoliko kHz više, desno
- Vaš preglednik pamti vaše demodulatore. Filtri šuma (NR, NB, NS, AN, AI) ne djeluju u IQ-u: umjesto toga suzite **Width**

---

## Digitalni dekoderi

PhantomSDR-Plus uključuje ugrađene dekodere za digitalne načine rada. Za potpuni vodič pogledajte [Dekoderi](DECODERS.md).

Najbrži je put red gumba **Decoders** na glavnoj ploči, odmah ispod **Wheel Tuning Steps**: deset gumba — **FT8, FT4, FT2, JS8, CW, WSPR, FAX, SSTV, NAVTX, FLDIGI** — od kojih svaki jednim pritiskom pokreće svoj dekoder, uključuje glavni prekidač Decoder i dovodi prozor dekodera na zaslon. Gumb ostaje plav dok dekoder radi; pritisnite ga ponovno da zaustavite dekoder i zatvorite njegov prozor. Padajući izbornik **Decoder Options** radi točno kao i prije te ostaje usklađen s gumbima.

**RADE-v2U**, **RADE-v1L** i **RADE-v1U** (RADE digitalni glas) imaju vlastite gumbe uz naslov **Modes** te u skočnim prozorima **Modes** i **Bands**, i rade na isti način: pritisak za pokretanje, ponovni pritisak za zaustavljanje. **RADE-v2U** pokreće RADE V2 (beta), uvijek u USB-u; **RADE-v1L** i **RADE-v1U** pokreću RADE v1.

Dekoderi za SSTV, HF FAX, NAVTEX, FSK/RTTY i CW rade svaki u vlastitoj pozadinskoj dretvi, pa uključivanje ili isključivanje dekodera nikada ne prekida zvuk, a slap ostaje gladak tijekom dekodiranja. Dobivaju zvuk uzet prije smanjenja šuma i utišavanja u vašem pregledniku — možete utišati prijamnik, a dekodiranje se nastavlja bez smetnji. Dok je dekoder otvoren, AGC se drži na Slow, kako bi pojačanje za njega ostalo ujednačeno.

**Dok dekoder radi, drži način rada i propusni pojas.** Uobičajeno način rada slijedi plan opsega — ugodite u odsječak označen kao LSB ili AM i prijamnik se prebaci. Dekoder koji radi nadjačava to i zadržava način rada i uski propusni pojas koji mu treba, čak i ako odete na drugi opseg. Vlastiti način rada opsega vraća se čim isključite dekoder, a gumbi načina rada rade u svakom trenutku ako želite preuzeti upravljanje. CW dekoder je iznimka: dekodira u načinu rada u kojem slušate.

### FT8 i FT4 dekoder

**Što su FT8 i FT4?**
- popularni digitalni načini rada u amaterskom radiju
- komunikacija slabim signalima
- emisije od 15 sekundi za FT8 i 7,5 sekundi za FT4

**Kako se koristi:**
1. Ugodite se na FT8 ili FT4 frekvencije
2. Odaberite način USB
3. Uključite FT8 dekoder — pritisnite gumb **FT8** ili ga odaberite iz izbornika
4. Promatrajte kako se pojavljuju dekodirane poruke

**Uobičajene FT8 frekvencije (USB):**
- 160 metara: 1.840 MHz
- 80 metara: 3.573 MHz
- 60 metara: 5.357 MHz
- 40 metara: 7.074 MHz
- 30 metara: 10.136 MHz
- 20 metara: 14.074 MHz
- 17 metara: 18.100 MHz
- 15 metara: 21.074 MHz
- 12 metara: 24.915 MHz
- 10 metara: 28.074 MHz
- 6 metara: 50.313 MHz (50.323 MHz za DX)

**Uobičajene FT4 frekvencije (USB):**

- 80 m: 3.575 MHz
- 40 m: 7.0475 MHz
- 30 m: 10.140 MHz
- 20 m: 14.080 MHz
- 17 m: 18.104 MHz
- 15 m: 21.140 MHz
- 12 m: 24.919 MHz
- 10 m: 28.180 MHz
- 6 m: 50.318 MHz

---

### JS8 dekoder

**Što je JS8?**
- FT8-ov mehanizam za slabe signale, korišten za razgovor s tipkovnice na tipkovnicu
- Slobodan tekst umjesto fiksnih poruka: duge poruke stižu kroz nekoliko ciklusa
- Pet brzina; **Normal** (15 s) je pozivna brzina i nosi gotovo sav promet

**Kako se koristi:**
1. Ugodite se na JS8 frekvenciju
2. Odaberite način **USB**
3. Uključite JS8 dekoder — tipka **JS8** ili iz izbornika
4. Ostavite **Speed** na *Normal*, a sync offset na **Auto**

**Kako čitati ploču:**
- Poruke koje još pristižu prikazuju se na vrhu zeleno, s trepćućim pokazivačem — na Normal poruka može trajati punu minutu
- Dovršene se navode ispod kao `Mode | Hz | dB | Message`, s **pozivnim znakovima u zelenom**
- Blijed, kurzivni redak istekao je prije posljednjeg okvira: tekst je stvaran, ali može biti skraćen

**Uobičajene JS8 frekvencije (USB):**

- 160m: 1.842 MHz
- 80m: 3.578 MHz
- 40m: 7.078 MHz
- 30m: 10.130 MHz
- 20m: 14.078 MHz
- 17m: 18.104 MHz
- 15m: 21.078 MHz
- 12m: 24.922 MHz
- 10m: 28.078 MHz

JS8 je mnogo tiši od FT8 — jedna emisija svakih nekoliko minuta je normalna, a tišina nije kvar. Potpuni vodič: [Dekoderi](DECODERS.md).

---

### CW dekoder
Samo pritisnite gumb CW i pojavit će se dekodirani tekst. Pritisnite gumb CW još jednom da očistite prozor i ponovno pokrenete dekoder.

---

### WSPR

WSPR (Weak Signal Propagation Reporter, izgovara se „whisper") način je rada svjetionika s iznimno slabim signalima koji kartira putove KV prostiranja diljem svijeta. Svaka emisija traje otprilike 110 sekundi i stane u kanal širine 200 Hz. Dekoder čeka potpuni dvominutni interval usklađen s UTC-om prije dekodiranja. Uključite dekoder i s padajućeg popisa odaberite **WSPR**. Ili jednostavno pritisnite gumb **WSPR**.

---

### HF FAX / WEFAX

HF radiofaks (poznat i kao WEFAX) koriste obalne straže i meteorološke službe diljem svijeta za emitiranje vremenskih karata, karata stanja mora i prizemnih analiza na kratkim valovima. Dekoder rekonstruira sliku redak po redak kako je prima.

---

### NAVTEX

NAVTEX je međunarodni pomorski sustav emitiranja obavijesti o sigurnosti u priobalju — navigacijskih upozorenja, vremenskih prognoza te obavijesti o traganju i spašavanju.

---

### FLDIGI — ALE 2G, RTTY, PSK31, Olivia, FST4W, MFSK, MSK144, DominoEX, THOR, THROB, Hellschreiber, MT63, Packet i APRS

Jedan prozor za uskopojasne tipkovničke načine rada koje je proslavio fldigi, s četrnaest inačica: amaterski RTTY, **PSK31/63/125** (fazno ključanje, BPSK/QPSK, 31,25–125 bauda), **Olivia**, **Contestia** i **MFSK16/32/64** (višetonski s korekcijom pogrešaka), **DominoEX** i **THOR** (inkrementalno frekvencijsko ključanje, THOR s korekcijom pogrešaka), **THROB**, **Hellschreiber** (iscrtan kao slika), **MT63** (64 nosioca), **Packet (AX.25)** i **APRS**. Otvara se gumbom **FLDIGI** ili stavkom **FLDIGI** u izborniku dekodera; sam fldigi nije potreban. Ploča se prilagođava inačici — kontrole za shift, baud i okvir nestaju za sve osim amaterskog RTTY-a, a ostali načini dodaju birač Mode i, osim Hellschreibera, klizač squelcha. Tri inačice ispisuju ono što dekodiraju redak po redak umjesto teksta: **ALE 2G HAM**, neposredno prije Packet na popisu (uspostava KV veze, MIL-STD-188-141, na HFLINK amaterskim kanalima), te **FST4W** i **MSK144**, WSJT-X načini rada za LF/MF svjetionike i za meteor scatter. **PSK Browser**, prekidač **Browser — all signals** ispod popisa **Mode** za PSK31, istodobno dekodira sve BPSK31 signale u propusnom pojasu, jedan redak po signalu; klik na redak prati taj signal. Vidi [priručnik za dekodere](DECODERS.md). **Browser — all signals** ispod popisa **Mode** za Oliviju čini isto za Oliviju i Contestiju, za ondje odabranu konfiguraciju. Pomorski FSK (SITOR), meteorološki RTTY i ALE mreže državnih službi, vojske i službi (**ALE 2G**) nalaze se u prozoru **SERVICES**, s istim dekoderima.

**CW Browser:** uključite prekidač **Browser — all signals** u CW prozoru da se istodobno dekodiraju svi CW signali u 200–3000 Hz, jedan redak po signalu, s pozivnim znakom postaje i označenim CQ pozivima; prijemnik dok radi prelazi na USB 200–3000 Hz.

Amaterski i meteorološki RTTY imaju klizač **Squelch (SNR)** koji sprječava da se šum ispisuje kao nasumična slova, a sve varijante osim Olivije prikazuju pravi SNR na istoj ljestvici od 3 kHz. Dvije stvari treba znati: PSK31 sam ispravlja pogrešku ugađanja u rasponu od otprilike ±25 Hz, pa se dovoljno samo približiti; Olivia traži da **Mode** (tonovi / širina pojasa) točno odgovara emisiji, ne šalje preambulu i stoga joj treba nekoliko sekundi za sinkronizaciju prije nego što se pojavi tekst. Ploča se otvara na Olivia **8 / 250**. Za ostale fldigi načine postavite signal na središnju frekvenciju ili pritisnite **⟳ Auto-tune Center** i odaberite odgovarajući **Mode**: THROB traži ugađanje unutar ±3 Hz, DominoEX, THOR i MT63 opraštaju mnogo više, a MFSK, THOR i MT63 ispisuju tekst nekoliko sekundi iza signala. Hellschreiber prikazuje sliku, a ne tekst.

**Packet** ispisuje svaki AX.25 okvir koji čuje, kao TNC monitor; **APRS** pretvara APRS pakete u običan tekst — položaj s lokatorom, brzinu, visinu, vrijeme, poruke, objekte i stanje. Odaberite **Speed**: **1200 Bd** za VHF/UHF, čime se prijemnik prebacuje na **FM** na kanalu (europskih 144,800 MHz nalazi se na popisu frekvencija), ili **300 Bd** za KV, u USB-u. Ispisuju se samo paketi s ispravnim kontrolnim zbrojem, pa se na mirnom kanalu ništa ne pojavljuje. Ispod teksta karta prikazuje svaku čutu postaju s položajem, s putanjama za one u pokretu i vašim prijemnikom u jantarnoj boji; može se smanjiti, a klik na dekodirani redak približi kartu toj postaji. Vidi [priručnik za dekodere](DECODERS.md#napomene-o-packetu-i-aprs-u).

---

### QRSS grabber

QRSS je CW poslan tako sporo da jedna točka traje sekundama, i gleda se umjesto da se sluša — grabber crta trag na vlastitom prikazu. Nije u izborniku dekodera; ima vlastiti odjeljak **QRSS** i može raditi istodobno s dekoderom.

Pritisnite **🐌 Show**, zatim odaberite prozor s popisa **Band** i pritisnite **Tune**: prijamnik odlazi na tu frekvenciju u **CW**-u s propusnim pojasom skrojenim za taj način rada, a trag pada na središnju crtu prikaza. Najprometniji je prozor na 30 m (10.140,00 kHz). Postavite **Speed** prema svjetioniku — **QRSS 10** ako ne znate — i budite strpljivi: pozivnom znaku može trebati deset minuta da prijeđe zaslon. Sve pojedinosti u [Dekoderi](DECODERS.md).

---

### SSTV

Televizija sporog raščlanjivanja šalje nepomične slike običnim SSB kanalom, redak po redak. Uključite dekoder, odaberite **SSTV** i ugodite se na SSTV frekvenciju — 14.230 MHz glavna je međunarodna pozivna frekvencija. Ostavite **Mode** na **Auto**: dekoder čita VIS zaglavlje emisije, a ako ste se ugodili nakon zaglavlja, način rada prepoznaje prema vremenskim odnosima sinkronizacije. Podržani su načini Martin, Scottie i Robot, a slika se gradi redak po redak kako pristiže. Ili jednostavno pritisnite gumb **SSTV**.

### Automatska prijava spotova i grafikoni poslužitelja

Dekodiranja FT8, FT4 i WSPR može slati i sam poslužitelj — FT8/FT4 na PSK Reporter, WSPR na WSPRnet — pomoću autorun daemona koji sysop pokreće s administratorske ploče. Neovisan je o dekoderima u vašem pregledniku: radi bez obzira sluša li tko ili ne, a ništa što dekodirate u pregledniku ne prijavljuje se.

Sysop ga prati preko dva brojača koja je lako zamijeniti: pločice po dekoderu broje spotove poslane od zadnjeg pokretanja daemona, dok je broj uz svaki potvrdni okvir pojasa/načina rada ukupan zbroj tog mjesta od početka i preživljava ponovna pokretanja. Ista ploča ima stranicu **Grafikoni** koja crta frekvenciju procesora, opterećenje, temperaturu i broj korisnika kroz zadnjih 15 minuta do 24 sata. Oboje je opisano u [vodiču za administratorsku ploču](ADMIN_PANEL_SETUP.md).


---

## Tipkovni prečaci

Tipkovni prečaci za brži rad.

---

### Upravljanje frekvencijom

**Tipke sa strelicama** ugađaju s bilo kojeg mjesta na stranici:

- **Strelica gore / dolje**: ±10 Hz; uz **Shift** ±1 kHz, uz **Ctrl** (ili **Cmd**) ±100 kHz, uz **Shift + Ctrl** ±1 MHz
- **Strelica lijevo / desno**: ±100 Hz; uz **Shift** ±10 kHz, uz **Ctrl** (ili **Cmd**) ±500 kHz, uz **Shift + Ctrl** ±10 MHz
- **Desni Ctrl**: odbacuje decimale i ugađa na cijeli kHz jednak trenutnoj frekvenciji ili ispod nje

U polju chata lijevo / desno umjesto toga pomiču kursor.

**Miš na prikazu frekvencije**: postavite pokazivač iznad znamenke; kotačić prema gore ili lijevi klik je povećava, kotačić prema dolje ili desni klik je smanjuje, svaki put za mjesnu vrijednost znamenke (devet znamenki, od 100 MHz do 1 Hz). Između znamenki kotačić se pomiče korakom ugađanja pojasa (1 kHz osim ako plan pojasa kaže drukčije); držite **Shift** za 1 kHz, **Alt** za 10 kHz. Klik bilo gdje drugdje u crnom okviru frekvencije / S-metra otvara numeričku tipkovnicu (Način 2 u *Ugađanje na frekvenciju*).

**Kotačić miša iznad slapa**: zumira. Držite **Ctrl** (ili **Cmd**) odnosno **Shift** za ugađanje umjesto zumiranja, a **Shift + Ctrl** zajedno za poravnanje na najbliži cijeli kHz.

> Prečaca Page Up / Page Down nema.

---

## Oznake

Spremite omiljene frekvencije za brzi pristup. Popis oznaka možete i izvesti te spremiti lokalno, a zatim ga uvesti u bilo koji drugi PhantomSDR.

Kada se oznake i markeri preklapaju:

🔵 Plave se oznake prikazuju iznad <br /> 🟡 Žuti se markeri prikazuju ispod <br />
✅ Klikovi na oznake imaju prednost <br />


### Dodavanje oznake

1. Ugodite se na željenu frekvenciju
2. Kliknite gumb „Bookmarks"
3. Kliknite „Add Bookmark"
4. Unesite opis
5. Kliknite „Save"

┌──────────────┬────────────────┬────────┐ │ Bookmark name│Label (optional)│ [Add]  │ └──────────────┴────────────────┴────────┘

### Kako se koristi:

**Dodavanje oznake:**
- Naziv: „Local News Station"
- Oznaka: „NEWS"
- Kliknite Add

**Prikaz u slapu:**
- uvećavajte dok se markeri ne pojave
- vidjet ćete tamnoplavi okvir s natpisom „NEWS" podebljano žutim

**Klik na oznaku:**
- ugađa na frekvenciju
- postavlja način demodulacije
- radi jednako kao klik na marker

### Upravljanje oznakama
- **Uređivanje**: kliknite ikonu olovke pokraj oznake
- **Brisanje**: kliknite ikonu koša pokraj oznake
- **Izvoz**: preuzmite oznake kao JSON datoteku
- **Uvoz**: učitajte oznake iz JSON datoteke

### Dijeljenje oznaka

1. Kliknite „Export Bookmarks"
2. Podijelite JSON datoteku s drugima
3. Primatelji kliknu „Import Bookmarks"
4. Odaberu vašu datoteku
---

## Upotreba na mobilnim uređajima

PhantomSDR-Plus izvrsno radi na mobilnim uređajima!

### Dva mobilna prikaza

Prijamnik se na telefonu može koristiti na dva načina:

- **`http://vaš_poslužitelj:PORT/mobile`** — pojednostavljena stranica. Bez slapa, pa troši otprilike upola manje podataka. Unos frekvencije, koraci ugađanja, načini rada, S-metar, pojasevi, oznake, korisnici i čavrljanje.
- **Prošireni prikaz** — telefonski raspored glavnog sučelja, sa slapom i svim kontrolama.

Prebacuje se gumbima na dnu `/mobile` (**Mobile extended view**, **Full desktop view**) i gumbom **Simplified mobile** u proširenom prikazu.

**Vaša frekvencija ide s vama.** Promjena prikaza ostavlja vas na istom signalu — frekvencija i način rada putuju u poveznici, pa više ne završavate na zadanoj frekvenciji prijamnika. I adresna traka prati vaše ugađanje, pa ponovno učitavanje stranice, oznaka ili poveznica poslana nekome vraćaju točno na tu frekvenciju.

**Način rada slijedi plan pojaseva na obje stranice.** Ugodite se na segment označen kao AM, LSB, USB ili CW — upisivanjem frekvencije, koracima ili gumbom pojasa — i prijamnik prelazi na taj način rada, na pojednostavljenoj stranici jednako kao i u punom sučelju. Način koji odaberete ručno ostaje dok se krećete unutar istog segmenta, a izvan definiranih pojaseva vaš se način ne dira. Dok **RADE** (RADEL/RADEU) radi, on zadržava prijamnik, pa ga ugađanje ne prekida.

Pri prebacivanju između dva prikaza trenutačni način rada ide s vama; ako prikaz u koji prelazite nema odgovarajući, o njemu odlučuje plan pojaseva za tu frekvenciju — radiodifuzijska frekvencija stiže u AM, 40 m u LSB, CW segment u CW. `SAM` s pojednostavljene stranice postaje AM sa sinkronim detektorom u proširenom prikazu, i obratno. `RADEL` i `RADEU` postoje samo na pojednostavljenoj stranici: napuštanjem jednog od njih frekvencija se čuva, a način rada bira plan pojaseva.

Frekvencija izvan pokrivenosti prijamnika povlači se na najbliži rub, pa vas stara poveznica nikada ne može ostaviti izvan pojasa.

### Značajke posebno za mobilne uređaje

- **Kontrole prilagođene dodiru**: veliki gumbi i klizači
- **Povlačenje za ugađanje**: povucite lijevo/desno po slapu
- **Stiskanje za uvećanje**: stisnite slap za približavanje/udaljavanje
- **Vodoravni način**: okrenite uređaj za bolji pregled
- **Spektar i vodopad po mjeri telefona**: u proširenom prikazu oba su viša nego što bi ih učinile proporcije stolne stranice

### Savjeti za mobilne uređaje

1. **Koristite Wi-Fi**: prijenos zvuka troši podatkovni promet
2. **Vodoravna orijentacija**: bolji pogled na slap
3. **Slušalice**: bolja kvaliteta zvuka
4. **Spremite omiljene postaje kao oznake**: lakše im se vraćate
5. **Zatvorite druge aplikacije**: osigurava gladak rad

### Preporučeni mobilni preglednici

- **Android**: Chrome ili Samsung Internet
- **iOS**: Mozilla
- **Oba**: pobrinite se da je preglednik ažuriran

---

## Savjeti i dobre prakse

### Za najbolji prijam

1. **Birajte jake signale**: tražite narančastu/crvenu boju u slapu
2. **Ugodite se precizno**: kliknite točno na sredinu signala
3. **Odaberite ispravan način rada**: uskladite ga s vrstom signala
4. **Podesite AGC**: brzi za AM, spori za SSB
5. **Koristite NR/NB**: pomažu u uvjetima s puno šuma

### Pronalaženje aktivnosti

1. **Promatrajte slap**: boje pokazuju jakost signala
2. **Slušajte popularne frekvencije**:
   - 40 m: 7.100-7.300 MHz (LSB)
   - 20 m: 14.200-14.350 MHz (USB)
   - 2 m: 145.200-145.600 MHz (FM)
3. **Provjerite preklop plana pojaseva**: prikazuje dodjelu frekvencija
4. **Koristite oznake**: brz pristup aktivnim frekvencijama

### Razumijevanje uvjeta prostiranja

**KV danju:**
- viši pojasevi rade bolje (20 m, 15 m, 10 m)
- moguća je veza na velike udaljenosti (DX)
- čuju se radiodifuzijske postaje

**KV noću:**
- niži pojasevi rade bolje (80 m, 40 m)
- drukčiji obrasci prostiranja
- čuju se druge postaje

**VHF/UHF:**
- uglavnom optička vidljivost
- lokalne komunikacije
- ujednačeniji uvjeti

### Bonton

1. **Nemojte dugo zauzimati prijamnik**: i drugi žele slušati
2. **Koristite razgovor s poštovanjem**: budite pristojni prema drugim korisnicima
3. **Prijavite probleme**: pomozite operateru u održavanju postaje
4. **Nemojte tražiti tehničku podršku**: ovo je platforma za slušanje. Za pomoć pošaljite poruku SysOpu.

---

## Rješavanje problema

### Nema zvuka

**Mogući uzroci:**
1. Preglednik je utišan → provjerite regulaciju glasnoće u pregledniku
2. Sustav je utišan → provjerite glasnoću računala
3. Slab signal → ugodite se na jači signal (S7+)
4. Pogrešan način rada → isprobajte druge načine demodulacije

**Rješenja:**
1. Kliknite na jak signal (narančast/crven u slapu)
2. Provjerite da preglednik nije utišan (ikona utišavanja na kartici)
3. Isprobajte drugu frekvenciju
4. Ponovno učitajte stranicu (F5)

### Izobličen zvuk

**Mogući uzroci:**
1. Preupravljan signal → signal je prejak
2. Pogrešan način rada → AM signal slušan u SSB načinu itd.
3. Smetnje → prelijevanje susjednih signala

**Rješenja:**
1. Smanjite glasnoću
2. Isprobajte drugi način demodulacije
3. Upotrijebite uži pojas filtra
4. Odmaknite se od ometajućih signala

### Zvuk se prekida ili kasni

**Mogući uzroci:**
1. Nepravilna veza → paketi stižu kasno i spremnik se isprazni
2. Zauzet telefon ili računalo → preglednik ne stiže

**Rješenja:**
1. Povećajte spremnik za jedan korak (vidi *Zvučni spremnik i kašnjenje*)
2. Radije koristite Wi-Fi ili kabel nego mobilne podatke
3. Zatvorite ostale kartice i aplikacije

Za detaljniji uvid otvorite stranicu s dodanim `?diag=1` na adresi (na primjer `http://your_server:PORT/mobile?diag=1`). Stranica /mobile tada ispod svojih kontrola prikazuje kašnjenje, koliko je veza nepravilna i kako stoji spremnik; desktop stranica isti redak upisuje u konzolu preglednika (F12) svakih deset sekundi. Korisno kad operateru stanice prijavljujete problem.

### Slap se ne osvježava

**Mogući uzroci:**
1. Problem s mrežom → spora ili prekinuta veza
2. Performanse preglednika → previše otvorenih kartica
3. Preopterećenje poslužitelja → previše korisnika

**Rješenja:**
1. Provjerite internetsku vezu
2. Zatvorite nepotrebne kartice preglednika
3. Ponovno učitajte stranicu (F5)
4. Pokušajte kasnije, kada je manje korisnika na vezi

### Nije moguće ugoditi se na frekvenciju

**Mogući uzroci:**
1. Frekvencija izvan raspona → SDR ne pokriva tu frekvenciju
2. Pogrešan format upisa → koristite ispravan format (npr. „14200", a ne „14.200.000")

**Rješenja:**
1. Provjerite frekvencijsku pokrivenost SDR-a (prikazana na stranici)
2. Koristite navedene primjere formata frekvencije
3. Umjesto toga kliknite na slap

### Isprekidan zvuk

**Mogući uzroci:**
1. spora internetska veza
2. veliko opterećenje poslužitelja
3. problemi s performansama preglednika

**Rješenja:**
1. Zatvorite druge aplikacije koje troše propusnost
2. Pokušajte izvan vršnih sati
3. Zatvorite nepotrebne kartice preglednika
4. Koristite žičanu vezu umjesto Wi-Fija

---

## Često postavljana pitanja

### Opća pitanja

**P: Trebam li posebnu opremu za korištenje WebSDR-a?**
O: Ne! Samo računalo ili mobilni uređaj s pristupom internetu.

**P: Je li korištenje WebSDR-a besplatno?**
O: Da, većina WebSDR-ova je besplatna. Vode ih volonteri.

**P: Mogu li odašiljati putem WebSDR-a?**
O: Ne, WebSDR služi samo za prijam. Odašiljanje nije moguće.

**P: Koje frekvencije mogu slušati?**
O: Ovisi o konfiguraciji WebSDR-a. Pogledajte podatke o postaji.

**P: Mogu li snimati zvuk?**
O: Neki preglednici omogućuju snimanje. Provjerite mogućnosti svojeg preglednika.

### Tehnička pitanja

**P: Koju frekvenciju uzorkovanja koristi SDR?**
O: Razlikuje se od postaje do postaje. Pogledajte stranicu s podacima o postaji.

**P: Kolika je latencija?**
O: Obično nekoliko desetinki sekunde između radijskog signala i vaših zvučnika: obrada u prijamniku, mreža i spremnik reprodukcije preglednika, koji se prilagođava vašoj vezi (oko 100–150 ms na telefonu preko kućnog Wi-Fija). Vidi *Zvučni spremnik i kašnjenje*.

**P: Mogu li koristiti više instanci?**
O: Obično da, ali to može opteretiti poslužitelj. Budite obzirni.

**P: Radi li izvan mreže?**
O: Ne, WebSDR zahtijeva internetsku vezu.

**P: Koji su preglednici podržani?**
O: Chrome, Firefox, Edge, Safari (sve novije verzije)

### Pitanja o korištenju

**P: Koliko ljudi može slušati istodobno?**
O: Ovisi o kapacitetu poslužitelja. Često 50-200+ korisnika.

**P: Mogu li vidjeti što drugi slušaju?**
O: Ako je omogućeno, da. Potražite oznake „drugi korisnici".

**P: Mogu li razgovarati s drugim slušateljima?**
O: Ako ga je operater uključio. Potražite okvir za chat; **↪ Reply** odgovara na određenu poruku (vidi *Chat* gore).

**P: Zašto se na nekim frekvencijama ništa ne vidi?**
O: Na toj frekvenciji trenutačno nema signala. Isprobajte druge!

**P: Što su obojene trake u slapu?**
O: Preklop plana pojaseva koji prikazuje dodjelu frekvencija.

---

## Izvori

### Saznajte više o radiju

- **Planovi pojaseva**: potražite „amateur radio band plan" + svoju regiju
- **Prostiranje**: naučite o prostiranju KV radiovalova
- **Digitalni načini rada**: istražite FT8, PSK31, RTTY
- **Amaterski radio**: razmislite o polaganju za amatersku dozvolu!

### Pronalaženje drugih WebSDR-ova

- **WebSDR imenik**: http://sdr-list.xyz
- **WebSDR.org**: http://websdr.org
- **KiwiSDR**: http://kiwisdr.com/public/

### Kako doći do pomoći

1. **Operater postaje**: pogledajte kontaktne podatke na stranici
2. **Razgovor korisnika**: pitajte druge slušatelje (ako je dostupan)
3. **Mrežni forumi**: potražite zajednice WebSDR-a
4. **Dokumentacija**: pogledajte ovaj vodič!

---

## Dodatak: uobičajene frekvencije

### KV amaterski pojasevi

| Pojas | Frekvencijski raspon | Način rada | Aktivnost |
|-------|----------------------|------------|-----------|
| 160 m | 1.800-2.000 MHz | LSB | Noć/lokalno |
| 80 m | 3.500-4.000 MHz | LSB | Noć/regionalno |
| 40 m | 7.000-7.300 MHz | LSB | Dan/noć/DX |
| 30 m | 10.100-10.150 MHz | USB | Samo podaci/CW |
| 20 m | 14.000-14.350 MHz | USB | Danju/DX |
| 17 m | 18.068-18.168 MHz | USB | Danju/DX |
| 15 m | 21.000-21.450 MHz | USB | Danju/DX |
| 12 m | 24.890-24.990 MHz | USB | Danju/DX |
| 10 m | 28.000-29.700 MHz | USB | Sporadično/DX |

### VHF/UHF amaterski pojasevi

| Pojas | Frekvencijski raspon | Način rada | Aktivnost |
|-------|----------------------|------------|-----------|
| 6 m | 50.000-54.000 MHz | USB/FM | Sporadično |
| 2 m | 144.000-148.000 MHz | FM | Vrlo aktivno |
| 70 cm | 420.000-450.000 MHz | FM | Aktivno |

### Radiodifuzijski pojasevi

| Služba | Frekvencijski raspon | Način rada |
|--------|----------------------|------------|
| AM radio | 530-1710 kHz | AM |
| Kratki valovi | 2.3-26.1 MHz | AM |
| FM radio | 88-108 MHz | WBFM |

### Zrakoplovstvo

| Služba | Frekvencijski raspon | Način rada |
|--------|----------------------|------------|
| Kontrola zračnog prometa | 118-137 MHz | AM |
| ACARS (podaci) | 130-136 MHz | Podaci |

### Pomorstvo

| Služba | Frekvencijski raspon | Način rada |
|--------|----------------------|------------|
| Pomorski VHF | 156-162 MHz | FM |
| Pomorski KV | 2-22 MHz | USB |

---

## Pojmovnik

**AGC**: automatska regulacija pojačanja – automatski podešava razine zvuka

**AM**: amplitudna modulacija – govorni način rada u zrakoplovstvu i radiodifuziji

**Širina pojasa**: frekvencijski raspon signala

**CW**: neprekinuti val – signali Morseova koda

**DX**: veza na veliku udaljenost

**FFT**: brza Fourierova transformacija – pretvara vremensku domenu u frekvencijsku

**FLDIGI**: prozor dekodera za ALE 2G, RTTY, PSK31, Oliviju, FST4W, MFSK, MSK144, DominoEX, THOR, THROB, Hellschreiber, MT63, Packet i APRS, nazvan po programu fldigi koji je proslavio te načine rada

**FM**: frekvencijska modulacija – govorni način rada za VHF/UHF

**HF**: kratki valovi (3-30 MHz) – pojasevi za velike udaljenosti

**kHz**: kilohertz (1.000 Hz)

**LSB**: donji bočni pojas – govorni način rada za niže KV pojaseve

**MHz**: megahertz (1.000.000 Hz)

**NB**: prigušivač impulsnog šuma – uklanja impulsni šum

**NR**: smanjenje šuma – smanjuje pozadinski šum

**PSK**: fazno pomično ključanje – digitalni način rada

**RTTY**: radioteleprinter – digitalni tekstualni način rada

**S-metar**: mjerač jakosti signala

**SDR**: softverski definirani radio

**SQL**: squelch – utišava zvuk kada nema signala

**SSB**: jednobočni pojas (USB ili LSB)

**USB**: gornji bočni pojas – govorni način rada za više KV pojaseve

**VHF**: vrlo visoke frekvencije (30-300 MHz) – optička vidljivost

**UHF**: ultravisoke frekvencije (300-3000 MHz) – optička vidljivost

**Slap (waterfall)**: vizualni prikaz radijskog spektra kroz vrijeme

---

**Uživajte u istraživanju radijskog spektra uz PhantomSDR-Plus!**

**73 (srdačni pozdravi) de SV1BTL, 9A7AOF, F1NSK & SV2AMK**

Za upute o instalaciji pogledajte [INSTALLATION.md](INSTALLATION.md). Za tehničke pojedinosti pogledajte [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md).
