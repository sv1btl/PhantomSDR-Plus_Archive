# Plusieurs récepteurs — Manuel du sysop

> **Numéros de port.** Les exemples ci-dessous utilisent les ports que propose `install.sh` : `proxy.py` sur le port public 9000, le récepteur principal sur 9001, les récepteurs suivants sur 9002, 9003, etc. Les questions de la station tiennent `receivers.toml` à jour : quand un port ou l'adresse change, `configure-station.sh` déplace le récepteur principal sur son nouveau port et écrit chaque lien sous la forme `<adresse>/?rx=<id>` — un lien sans `?rx=` garderait le visiteur sur le récepteur que retient le cookie `rx`. Ne donnez jamais à un récepteur le port public lui-même : le proxy se renverrait vers lui-même, il le refuse donc désormais.

**Deux récepteurs ou plus sur un même ordinateur, avec un sélecteur de récepteur sur la page.**

Depuis la v5.0.0, un ordinateur PhantomSDR-Plus peut faire tourner plusieurs récepteurs en même temps — par exemple un RX-888 pour les ondes courtes et un RTL-SDR pour le 2 m — et les auditeurs passent de l'un à l'autre par des boutons dans l'en-tête de la page, comme OpenWebRX propose ses profils. Chaque récepteur garde sa propre cascade, son chat, ses repères, sa liste d'auditeurs et ses informations de station ; personne sur un récepteur n'est jamais gêné par quelqu'un sur un autre.

> **Pressé ?** Une station à un seul récepteur n'a besoin de rien de tout cela et ne voit aucun changement. Pour un second récepteur : créez `instances/<nom>/` avec son propre `config.toml`, démarrez-le avec `INSTANCE=<nom> ./start-<radio>.sh`, inscrivez les deux récepteurs dans `receivers.toml` et redémarrez le proxy. L'exemple de la [section 3](#3-ajouter-un-second-récepteur) le détaille ligne par ligne.

> **Le plus simple :** lancez `./add-receiver.sh` (les installeurs le proposent à la fin). Il demande quel récepteur et ce qu'il doit couvrir, installe son pilote, écrit tout ce que décrivent la [section 3](#3-ajouter-un-second-récepteur) et la [section 4](#4-receiverstoml), et propose de démarrer le récepteur et de redémarrer le proxy. Le reste de ce manuel explique ce qu'il fait, pour le jour où vous voulez modifier quelque chose à la main.

> **Depuis le panneau d'administration :** la page **Receivers** liste chaque récepteur avec ce qu'il couvre. **✎ CHANGE SETTINGS** change la fréquence et la largeur de bande d'un récepteur supplémentaire (et redémarre seulement celui-là), et sur chaque récepteur la fréquence de départ, le mode, le gain et le nom du bouton — un récepteur supplémentaire garde son gain dans `instances/<id>/instance.env`, le principal dans `main.env`, que chaque start-*.sh lit en dernier. **■ STOP** / **▶ START** arrête ou démarre un récepteur pendant que les autres continuent, et **🗑 DELETE** supprime un récepteur supplémentaire (l'arrête, le retire de `receivers.toml`, déplace son dossier `instances/<id>/` dans `admin-backups/`). Elle prépare aussi un nouveau récepteur : elle enregistre vos réponses et donne `./add-receiver.sh --answers instances/.add-rx.env` à lancer dans un terminal. Voir [Panneau d'administration](ADMIN_PANEL_SETUP.md).

---

## Sommaire

1. [Comment cela fonctionne](#1-comment-cela-fonctionne)
2. [Deux façons de publier les récepteurs](#2-deux-façons-de-publier-les-récepteurs)
3. [Ajouter un second récepteur](#3-ajouter-un-second-récepteur)
4. [receivers.toml](#4-receiverstoml)
5. [Démarrer et arrêter](#5-démarrer-et-arrêter)
6. [Ce que voient les auditeurs](#6-ce-que-voient-les-auditeurs)
7. [Le S-mètre au-dessus de 30 MHz](#7-le-s-mètre-au-dessus-de-30-mhz)
8. [Sécurité](#8-sécurité)
9. [Combien de récepteurs tiennent](#9-combien-de-récepteurs-tiennent)
10. [Pièges à connaître](#10-pièges-à-connaître)

---

## 1. Comment cela fonctionne

Chaque récepteur est un spectrumserver complet et indépendant, avec son propre SDR, sa propre configuration et son propre port interne. Ils ne partagent jamais d'échantillons, de réglages ni d'auditeurs. Ce qui les relie, c'est `proxy.py`, le proxy inverse qui sert déjà le panneau d'administration : il lit `receivers.toml` et envoie chaque requête à un récepteur.

```
                         ┌──► :9001  spectrumserver  RX-888   (HF, le récepteur principal)
auditeurs ──► proxy.py ──┤
                         └──► 127.0.0.1:9002  spectrumserver  RTL-SDR  (2 m, instance "vhf")
```

Le proxy décide d'après ces éléments, dans cet ordre :

1. `?rx=<id>` dans l'adresse — `http://votre.hote:9000/?rx=vhf`. La page l'ajoute à chaque socket, requête et lien qu'elle ouvre, si bien qu'un onglet reste sur son récepteur.
2. Le cookie `rx`, que le proxy pose chaque fois qu'une requête porte un `?rx=` valide.
3. L'en-tête Host, si un récepteur cite ce nom dans `hostnames`.
4. Sinon le récepteur par défaut.

Le **récepteur principal** est celui que l'on démarre comme d'habitude (`./start-rx888mk2.sh`). Tout autre récepteur est une **instance nommée** : démarrée avec `INSTANCE=<nom>`, configurée dans `instances/<nom>/`, avec son propre journal (`logwebsdr-<nom>.txt`), journal du serveur, verrou du watchdog et FIFO. Les processus se distinguent par une étiquette `PHANTOMSDR_INSTANCE` dans leur environnement, pas par leur nom ; deux récepteurs peuvent donc exécuter exactement le même programme — deux `rtl_sdr`, ou `rx_sdr` pour un RSP1A et un Airspy — et le redémarrage de l'un ne touche jamais l'autre.

---

## 2. Deux façons de publier les récepteurs

**A — le récepteur principal garde son propre port.** Le récepteur principal reste exactement où il était (par exemple `:9001`), ses auditeurs ne remarquent rien, et l'on atteint les autres récepteurs par le port du proxy (`proxy_port` dans `admin_config.json`, par exemple `:9000`) avec `?rx=`. Rien ne bouge et rien ne quitte l'antenne ; en contrepartie il y a deux ports publics.

```
HF :  http://votre.hote:9001/
2 m : http://votre.hote:9000/?rx=vhf
```

**B — un seul port public pour tout.** Le proxy prend le port public et le récepteur principal passe sur un port interne. Définissez `[front] port` dans `receivers.toml`, déplacez le `[server] port` du récepteur principal et mettez-y `host = "127.0.0.1"`, mettez le nouveau port interne dans `public_port` de `admin_config.json` et ajoutez `public_port = <le port public>` sous `[websdr]`, pour que l'annuaire continue d'annoncer le bon. Tout se trouve alors derrière un seul port ; le prix est une courte coupure pendant le déplacement.

```
HF :  http://votre.hote:9000/
2 m : http://votre.hote:9000/?rx=vhf
```

Le sélecteur de récepteur fonctionne de la même façon dans les deux cas. La disposition A est le début le plus sûr ; B peut suivre plus tard sans rien changer au second récepteur.

---

## 3. Ajouter un second récepteur

**`add-receiver.sh` ajoute un récepteur** — lancez-le et répondez à ses questions ; il installe le pilote (`setup-rtlsdr.sh` pour un RTL-SDR, le `setup-*.sh` correspondant pour les autres), choisit un port interne libre, écrit le dossier de l'instance, sa configuration et sa ligne dans `receivers.toml`, et nomme le récepteur d'après ce qu'il couvre. La page **Receivers** du panneau d'administration fait la même chose avec ➕ ADD NEW RECEIVER.

---

## 4. receivers.toml

Copiez `receivers.toml.example` en `receivers.toml`. Sans ce fichier, le proxy sert un seul récepteur, comme toujours.

```toml
# [front]
# port = 9000        # disposition B seulement : le proxy écoute aussi sur ce port public

[[receiver]]
id       = "hf"
name     = "HF 0-30 MHz (RX-888 MkII)"
port     = 9001
default  = true
launcher = "start-rx888mk2.sh"
url      = "http://votre.hote:9000/"

[[receiver]]
id       = "vhf"
name     = "2 m (RTL-SDR Blog V4)"
port     = 9002
launcher = "start-rtl.sh"
instance = "vhf"
url      = "http://votre.hote:9000/?rx=vhf"
```

| Clé | Signification |
|---|---|
| `id` | Nom court utilisé dans `?rx=` ; lettres, chiffres, `-` et `_` |
| `name` | Le texte du bouton du récepteur |
| `port` | Le `[server] port` de son spectrumserver |
| `host` | Facultatif ; où tourne ce spectrumserver (par défaut `127.0.0.1`) |
| `default` | Le récepteur des requêtes qui n'en nomment aucun ; un seul au plus |
| `launcher` | Son `start-*.sh`, pour `start-all.sh` ; à omettre pour un récepteur que cet ordinateur ne démarre pas |
| `instance` | Le nom de son instance ; à omettre pour le récepteur principal |
| `url` | Où son bouton envoie l'auditeur ; sans elle, `/?rx=<id>` sur le proxy |
| `hostnames` | Noms DNS facultatifs qui mènent directement à ce récepteur |

Le proxy sert aussi la liste sous `/receivers.json` (identifiants, noms et liens — jamais les ports internes) ; c'est ce que lit le sélecteur.

---

## 5. Démarrer et arrêter

| Commande | Effet |
|---|---|
| `./start-rx888mk2.sh` | Démarre ou redémarre le récepteur principal |
| `INSTANCE=vhf ./start-rtl.sh` | Démarre ou redémarre le récepteur `vhf` |
| `./start-all.sh` | Démarre chaque récepteur de `receivers.toml` qui a un `launcher` |
| `./stop-websdr.sh vhf` | Arrête seulement `vhf` |
| `./stop-websdr.sh main` | Arrête seulement le récepteur principal |
| `./stop-websdr.sh` | Arrête tous les récepteurs, comme toujours |

**Tant qu'un récepteur est arrêté**, son bouton disparaît du sélecteur — le proxy ne liste que les récepteurs qui répondent, et les pages ouvertes relisent la liste toutes les 15 secondes — et revient quand le récepteur redémarre ; s'il ne reste qu'un récepteur en marche, la ligne *Receivers:* disparaît complètement. Un récepteur arrêté revient de lui-même chaque fois que tous les récepteurs sont démarrés : `./start-all.sh`, le **Restart** du panneau d'administration et un redémarrage par le thermal guard démarrent tout ce qui figure dans `receivers.toml`. Pour en garder un éteint pour de bon, supprimez-le sur la page **Receivers** du panneau d'administration, ou retirez (ou commentez) son bloc `[[receiver]]` à la main — le proxy relit `receivers.toml` dès qu'il change, donc un renommage, une suppression ou un nouveau bloc prennent effet sans redémarrer le proxy (seuls le premier `receivers.toml` d'une station, ou un changement de `[front] port`, en demandent encore un).

Réglez le **Default start script** du panneau d'administration sur `start-all.sh`. Son Stop arrête déjà tous les récepteurs, et son Restart ainsi que la protection thermique utilisent le script de démarrage ; avec `start-all.sh`, ils ramènent tous les récepteurs au lieu du seul principal.

L'auxiliaire RADE n'appartient qu'au récepteur principal. Une instance nommée ne le démarre ni ne l'arrête jamais.

---

## 6. Ce que voient les auditeurs

**Le sélecteur de récepteur.** Sur une station à plusieurs récepteurs, l'en-tête de la page reçoit une ligne à lui, *Receivers:*, avec un bouton par récepteur ; le récepteur actuel apparaît en jaune. La page /mobile a les mêmes boutons en deuxième rangée de sa barre supérieure, et ils ouvrent la page /mobile de l'autre récepteur.

**Bandes Show All.** Une case *Show All* après les boutons de récepteur affiche chaque autre récepteur sous la cascade de l'auditeur, en bande en direct. Un clic sur elle ouvre ce récepteur accordé sur la fréquence cliquée, et une page que l'auditeur a quittée se rouvre avec la vue dans laquelle il l'a laissée. Chaque bande est un socket de cascade seule vers l'autre récepteur (`/waterfall?rx=<id>`) : ce n'est pas un auditeur là-bas — le décompte des utilisateurs et la limite d'auditeurs par IP ne le voient pas, `per_ip_sockets` si — et elle coûte environ 10 Ko/s d'envoi pour chaque auditeur qui coche la case. Elle est désactivée par défaut et ne demande rien au serveur. Quand l'autre récepteur couvre plus d'une bande, l'en-tête de sa bande Show All propose ses bandes dans une liste déroulante (les mêmes que ses boutons de bande) ; une bande cadre l'aperçu comme son bouton de bande, et un clic ouvre alors le récepteur cadré sur cette bande. Le choix est conservé par récepteur dans le navigateur de l'auditeur.

**Changement par la fréquence.** Une fréquence hors de la couverture de ce récepteur mais couverte par un autre — tapée, issue d'un lien, d'un signet ou d'un spot — ouvre le récepteur qui la couvre. La page apprend la plage de chaque récepteur en ouvrant un instant son socket `/waterfall`, et la retient pendant un jour.

**Utilisateurs et statistiques par récepteur.** Les fenêtres *Connected Users* et *User Statistics* montrent le récepteur dont elles occupent la page, même avec plusieurs récepteurs ouverts côte à côte dans le même navigateur. Les statistiques viennent des journaux de ce récepteur — `logs/` pour le récepteur principal, `instances/<id>/logs/` pour les autres.

**Les informations propres à chaque récepteur.** Une page ouverte sur un second récepteur charge le `site_information.json` de ce récepteur avant de démarrer ; les boutons de bande, la fréquence de départ, la liste des auditeurs, les informations de station et les liens Receiver et Antenna sont donc tous les siens. Une visite ordinaire du récepteur principal ne fait aucune requête supplémentaire.

Les clés de `site_information.json` concernées :

| Clé | Signification |
|---|---|
| `siteReceiverId` | Le récepteur auquel appartient cette page (son `id`) ; à omettre sur le récepteur principal |
| `siteReceiversList` | Où le sélecteur lit la liste, p. ex. `http://votre.hote:9000/receivers.json` ; nécessaire sur un récepteur dont la page n'est pas servie par le proxy |
| `siteReceiverURL` | Vers où pointe le nom de *Receiver* dans *Open Additional Info* |
| `siteAntennaURL` | Vers où pointe le nom de *Antenna* ; `""` affiche le nom sans lien |

**Quand le sélecteur reste caché.** Le sélecteur n'affiche qu'une liste qui cite l'hôte sous lequel la page a été ouverte. Ouverte par l'adresse du réseau local (`http://192.168.1.10:9000/`), il reste caché ; ouverte en `http://votre.hote:9000/`, il apparaît. C'est voulu : une station qui a copié le `site_information.json` d'une autre sans le modifier n'affiche jamais les récepteurs de celle-ci comme les siens.

---

## 7. Le S-mètre au-dessus de 30 MHz

La norme de l'IARU Région 1 place S9 à −73 dBm sous 30 MHz et à **−93 dBm au-dessus**, avec six dB par point S dans les deux cas. Les S-mètres (l'aiguille analogique, la barre numérique et la barre de /mobile) suivent la fréquence accordée : au-dessus de 30 MHz ils indiquent des points S VHF, en dessous comme avant. Les valeurs en dBm et dBµV ne changent jamais. Si vous préférez que les instruments restent à 0 sur un canal vide, comme ceux d'un transceiver VHF/UHF, ajoutez `"siteSMeterGateDb": 6` au `site_information.json` du récepteur (sans recompilation) : au-dessus de **60 MHz**, l'aiguille et la barre ne montent alors que lorsqu'un signal dépasse de ce nombre de dB le bruit de son propre voisinage (le point le plus fort de la bande passante face au spectre ±100 kHz autour). C'est **désactivé par défaut** — un instrument étalonné qui montre le vrai bruit de bande est la lecture la plus honnête. La page /mobile, qui n'a pas de cascade, estime le bruit à partir du niveau reçu lui-même.

Étalonnez les dBm d'un récepteur VHF avec `analog_smeter_offset` (aiguille et valeurs) et `smeter_offset` (barre numérique) sous `[input]` dans son `config.toml`, puis redémarrez ce récepteur. Fixez d'abord le gain : un RTL-SDR donne ses niveaux par rapport à sa propre pleine échelle, donc chaque changement de gain déplace les lectures. Sans générateur, une charge de 50 Ω à la place de l'antenne, en USB avec un filtre de 2,7 kHz, doit indiquer environ −136 dBm (le bruit thermique dans 2,7 kHz vaut −139,7 dBm, plus le facteur de bruit de la clé).

Pour un RTL-SDR, `add-receiver.sh` écrit un étalonnage de départ : un gain fixe `-g 29.7` dans `instance.env` (le gain automatique du tuner ne s'étalonne pas) ainsi que `analog_smeter_offset=-55` et `smeter_offset=-38`, mesurés sur un RTL-SDR Blog V4 à ce gain avec un signal de −71 dBm (63 µV). Une autre clé du même modèle s'en écarte en général de quelques dB seulement ; vérifiez-la avec un signal connu et réétalonnez si vous changez le gain.

---

## 8. Sécurité

Liez chaque récepteur joint par le proxy à `127.0.0.1` (`[server] host`), afin que son port ne puisse pas servir à contourner le proxy. Les limites par adresse de [Limites de connexion](CONNECTION_LIMITS.md) s'appliquent par récepteur.

---

## 9. Combien de récepteurs tiennent

Le logiciel ne fixe aucune limite ; le matériel, si. Les récepteurs à bande étroite coûtent peu : un RTL-SDR à 2,4 Msps utilise environ 5 à 10 % d'un cœur, quelques dizaines de Mo de mémoire et environ 38 Mbit/s d'USB.

- **L'USB 2.0 est le plafond habituel.** Tous les périphériques USB 2 partagent un bus de 480 Mbit/s, même dans une prise USB 3 bleue. Trois à quatre RTL-SDR par bus est un chiffre sûr ; ajoutez-les un par un et surveillez chaque cascade pour repérer des trous.
- **Alimentation :** au-delà de deux clés, utilisez un hub alimenté.
- **Un second récepteur large bande** (un autre RX-888, ou un HackRF à 20 Msps) est une autre affaire : il dispute au premier l'USB 3, le CPU et le GPU.
- **Les auditeurs coûtent plus que les récepteurs.** Chaque auditeur coûte du CPU sur son récepteur et de la bande passante montante ; le nombre total d'auditeurs compte donc plus que le nombre de récepteurs.

---

## 10. Pièges à connaître

- **Deux clés du même modèle ont le même numéro de série.** Chaque RTL-SDR Blog V4 indique `00000001`. Donnez à chacune le sien avec `rtl_eeprom -s <série>` (une seule clé branchée à la fois) et nommez-le dans `instance.env` (`RX_ARGS="-d <série> …"`), sinon après un redémarrage les clés peuvent échanger leurs récepteurs.
- **Les clients Kiwi ne peuvent pas choisir de récepteur.** Un client KiwiSDR appelle une simple adresse et un port ; à travers le proxy il aboutit toujours au récepteur par défaut. Laissez `[kiwi_emulation]` désactivé sur les autres.
- **Les cookies valent par hôte, pas par port.** Un visiteur qui a utilisé le second récepteur sur `:9000` emporte aussi `rx=vhf` vers `:9001`. C'est pourquoi une page décide quel récepteur elle est d'après `siteReceiverId`, jamais d'après le cookie.
- **Les entrées d'annuaire.** Donnez à chaque récepteur son propre nom dans `[websdr]`, et sur un récepteur derrière le proxy mettez `[websdr] public_port` au port qu'utilisent les auditeurs, sinon l'entrée annonce le port interne.
- **Une compilation du frontend affiche brièvement « Not Found ».** `frontend/dist` est recompilé sur place ; pendant quelques secondes de compilation, la page manque sur chaque récepteur.
- **Rien ne démarre les récepteurs au démarrage de l'ordinateur**, à moins que vous ne le prévoyiez. Après un redémarrage, `./start-all.sh` les ramène tous.
