# Structure du projet PhantomSDR-Plus

Ce document offre une vue d'ensemble complète de la structure de répertoires de PhantomSDR-Plus, de l'organisation des fichiers et des relations entre composants.

---

## Table des matières

1. [Arborescence des répertoires](#arborescence-des-répertoires)
2. [Répertoire racine](#répertoire-racine)
3. [Code source (`src/`)](#code-source-src)
4. [Frontend (`frontend/`)](#frontend-frontend)
5. [Listes de fréquences (`frequencylist/`)](#listes-de-fréquences-frequencylist)
6. [Fichiers de configuration](#fichiers-de-configuration)
7. [Système de compilation](#système-de-compilation)

---

## Arborescence des répertoires

*Seulement les dossiers principaux et les fichiers qu'un sysop utilise ; la liste complète se trouve dans le dépôt lui-même.*

```
PhantomSDR-Plus
├── add-receiver.sh            # ajoute un récepteur de plus : pilote, instances/<nom>/, receivers.toml — voir docs/MULTI_RECEIVER.md
├── admin_server.py
├── autorun
├── config-rtl.toml
├── config.toml
├── configure-station.sh       # l'assistant de station : demande une fois, écrit station.conf, le .toml et site_information.json
├── docs
├── drm                        # créé par setup-drm.sh : src/ et bin/ (pas dans git)
├── frequencylist
├── frontend
├── install.sh
├── instances                  # récepteurs supplémentaires, un dossier chacun (hors git) — voir docs/MULTI_RECEIVER.md
├── jsdsp
├── proxy.py                   # l'unique port public : la page, /admin, /rade, /stats, /relay et récepteurs ?rx=
├── rade_helper.py             # le sidecar RADE : V1 via ~/radae, V2 (beta) via ~/rade_c
├── recompile.sh               # recompilation ; --backend / --frontend / --both ne demandent rien
├── receivers.toml.example     # liste des récepteurs pour proxy.py — à copier en receivers.toml
├── setup-https.sh             # https:// devant : Caddy sur 443 avec un certificat Let's Encrypt — voir docs/HTTPS.md
├── src
├── start-rtl.sh
├── start-rx888mk2.sh
├── station.conf               # les réponses de la station à l'assistant (pas dans git, jamais touché par update.sh)
├── stop-websdr.sh
├── subprojects
├── tci-bridge
├── thermal_guard.py           # Protection contre la surchauffe du processeur pour le panneau (fonctionne aussi seule)
├── update.sh                  # mise à jour : rapport, puis « update now? » ; --check, --from, --make-known
└── websdr_relay.py            # le relais lui-même — voir docs/RECEIVE_DIVERSITY.md
```
---

## Répertoire racine

### Fichiers de configuration

| Fichier | Rôle | Quand le modifier |
|---------|------|-------------------|
| `config.toml` | Configuration par défaut | Installation initiale, tests |
| `config-rtl.toml` | Configuration propre au RTL-SDR | Utilisation d'un RTL-SDR |
| `config-rsp1a.toml` | Configuration SDRplay RSP1A | Utilisation d'un RSP1A |
| `config-airspyhf.toml` | Configuration Airspy HF+ | Utilisation d'un Airspy |
| `config-fobos-hf.toml` | RigExpert Fobos SDR, HF1/HF2 en échantillonnage direct (0-25 MHz) | Utilisation d'un Fobos en HF |
| `config-fobos.toml` | RigExpert Fobos SDR, voie RF (25-6000 MHz) | Utilisation d'un Fobos au-dessus de 25 MHz |
| `config-hackrf.toml` | Configuration HackRF One | Utilisation d'un HackRF |
| `config-rx888mk2.toml` | Configuration RX888 MK2 | Utilisation d'un RX888 |
| `config.example.hackrf.toml` | Exemple HackRF One | Utilisation d'un HackRF |
| `station.conf` | Les réponses à l'assistant de station — récepteur, bande, station, ports, compléments. Écrit par `configure-station.sh` ; lu par les scripts de démarrage et `proxy.py`. Jamais dans git, jamais touché par `update.sh` | Via `bash configure-station.sh` |
| `main.env` | Le `instance.env` propre au récepteur principal : sa ligne d'arguments (`RX888_ARGS` / `RX_ARGS`) avec le gain réglé dans Admin → Receivers → ✎ CHANGE SETTINGS. Lu en dernier par chaque script de démarrage ; absent tant qu'aucun gain n'est enregistré. Jamais dans git, jamais touché par `update.sh` | Admin → Receivers, ou à la main |

### Scripts de démarrage/arrêt et de maintenance

Chaque `start-*.sh` ci-dessous est un **lanceur autonome + chien de garde + journaliseur** : il arrête toute instance en cours, lance le récepteur + `spectrumserver`, se détache en arrière-plan, relance automatiquement la chaîne si elle s'arrête, et journalise dans `logwebsdr.txt`. Ils partagent un même script d'arrêt et un unique verrou `flock` (un seul récepteur à la fois). Ne modifiez que le bloc **RECEIVER CONFIGURATION** en tête de chacun (arguments du récepteur / configuration / nom du processus). Les six scripts de lancement issus du même modèle (`start-airspyhf.sh`, `start-rtl.sh`, `start-rsp1a.sh`, `start-fobos.sh`, `start-fobos-hf.sh`, `start-hackrf.sh`) sont identiques sous ce bloc ; `start-rx888mk2.sh` est un script à part. Depuis la v5.0.0, plusieurs récepteurs peuvent tourner côte à côte : un script de démarrage lancé avec `INSTANCE=<nom>` donne à ce récepteur son propre dossier `instances/<nom>/`, son propre journal, son verrou et son FIFO — voir [Plusieurs récepteurs](MULTI_RECEIVER.md).

| Script | Rôle |
|--------|------|
| `install.sh` | Installation et compilation automatiques — d'abord les questions de la station, puis tout sans surveillance (aussi `install_fedora.sh`, `install_arch.sh`, `install_opensuse.sh`) |
| `configure-station.sh` | L'assistant de station : récepteur, bande, station, internet, ports et compléments, demandés une fois et enregistrés dans `station.conf` ; il en tire le `.toml` du récepteur, `site_information.json` et les réglages du relais, en ne changeant que ses propres clés et en sauvegardant chaque fichier d'abord. `--show` affiche les réponses, `--apply` réécrit les fichiers à partir d'elles — voir le [Guide d'installation](INSTALLATION.md) |
| `setup-autostart.sh` | Démarrage au boot : installe `phantomsdr-receiver.service`, qui lance au boot le script de démarrage de `station.conf` (ou celui indiqué) et `stop-websdr.sh` à l'arrêt, avec le groupe `plugdev` ; `--remove` l'annule |
| `setup-https.sh` | Sert le récepteur en https:// en plus de http:// : installe Caddy sur le port 443 avec un certificat Let's Encrypt pour le nom DNS de la station (renouvelé tout seul) et le dirige vers le port loopback `PORT_TLS` de `proxy.py`, où le proxy prend auprès de Caddy l'adresse réelle de chaque visiteur. `--lan` pour le réseau local avec le certificat propre de Caddy, `--status`, `--remove` ; les questions de la station le lancent quand https est choisi — voir [Accès sécurisé](HTTPS.md) |
| `add-receiver.sh` | Ajoute un récepteur de plus à cet ordinateur : demande quel récepteur et ce qu'il couvre, installe son pilote, crée `instances/<nom>/` et l'entrée de `receivers.toml`, et propose de le démarrer et de redémarrer le proxy. Les installeurs le proposent à la fin — voir [Plusieurs récepteurs](MULTI_RECEIVER.md) |
| `start-rtl.sh` | Lancement + chien de garde du serveur avec RTL-SDR (`rtl_sdr`) |
| `start-rsp1a.sh` | Lancement + chien de garde du serveur avec SDRplay RSP1A (`rx_sdr`) ; utilise libmirisdr-5, ou l'API SDRplay quand elle est installée (`RX_DRIVER` en impose un) |
| `start-airspyhf.sh` | Lancement + chien de garde du serveur avec Airspy HF+ (`rx_sdr`) |
| `start-fobos-hf.sh` | Lancement + chien de garde du serveur avec RigExpert Fobos SDR, HF1/HF2 en échantillonnage direct (`rx_sdr \| cf32_to_real`) |
| `start-fobos.sh` | Lancement + chien de garde du serveur avec RigExpert Fobos SDR, voie RF (`rx_sdr`) |
| `start-hackrf.sh` | Lancement + chien de garde du serveur avec HackRF One (`hackrf_transfer`) |
| `start-rx888mk2.sh` | Lancement + chien de garde du serveur avec RX888 MK2 (`rx888_stream`) |
| `start-all.sh` | Démarre chaque récepteur de `receivers.toml` par son propre script — à choisir comme script de démarrage du panneau d'administration sur une station à plusieurs récepteurs ; voir [Plusieurs récepteurs](MULTI_RECEIVER.md) |
| `stop-websdr.sh` | Arrêt du serveur et de son chien de garde — partagé par tous les récepteurs |
| `stop-websdr.sh <instance>` | Arrête un seul récepteur (`main` pour le principal) ; sans argument, tous s'arrêtent, comme avant |
| `setup-rx888-udev.sh` | Installe les règles udev pour que `rx888_stream` du RX-888 tourne sans sudo |
| `setup-rsp1a.sh` / `setup-fobos.sh` / `setup-airspyhf.sh` | Installent la chaîne de pilote SoapySDR du RSP1A, du Fobos ou de l'Airspy HF+ — SoapySDR depuis la distribution, pilote et rx_tools compilés dans `sdr_drivers/`, une règle udev — sur l'une des quatre distributions prises en charge. Les options 3, 5 et 6 de l'installateur les lancent ; ils fonctionnent aussi seuls. Code commun dans `setup-sdr-common.sh` — voir le [Guide d'installation](INSTALLATION.md#récepteurs-sur-soapysdr-rsp1a-fobos-airspy-hf) |
| `setup-hackrf.sh` | Installe le paquet `hackrf` de la distribution et une règle udev pour le HackRF One, sur l'une des quatre distributions prises en charge ; l'option 7 de l'installateur le lance |
| `setup-rtlsdr.sh` | Installe le pilote RTL-SDR sur l'une des quatre distributions prises en charge — le paquet `rtl-sdr` de la distribution ou, avec `RTL_V4=y`, le pilote du RTL-SDR Blog V4 compilé depuis les sources —, bloque le pilote DVB-T et ajoute une règle udev ; `add-receiver.sh` le lance |
| `setup-firewall.sh` | Garde anti-afflux optionnelle au niveau du noyau : charge une table nftables avec un plafond de connexions simultanées et un débit par adresse source sur les ports du récepteur, un frein contre la force brute SSH et le partage de fichiers Windows fermé hors des plages privées. Nécessite root, ne peut pas vous enfermer dehors (policy accept, les connexions établies acceptées en premier) et `--apply` se retire de lui-même s'il n'est pas confirmé en 60 s — voir [Limites de connexion](CONNECTION_LIMITS.md) |
| `setup-cpufreq-perms.sh` | Donne à un groupe `cpufreq` le droit d'écriture sur la limite de fréquence du processeur, afin que l'étage throttle du garde fonctionne sans root. Installe une règle `tmpfiles.d` pour survivre à un redémarrage ; `--revoke` annule tout |
| `update.sh` | Met à jour l'installation depuis l'arborescence publiée sans toucher à votre configuration, vos marqueurs, la liste de fréquences ni vos modifications : rapport, question « Update these files now? » (ENTRÉE = non), sauvegarde, application et recompilation de ce qui a changé seulement. `--check` pour cron, `--from` depuis un ZIP, une archive ou un dossier sans réseau — voir le [Guide d'installation](INSTALLATION.md) |
| `update-known.txt` | Le SHA-256 de chaque version de chaque fichier jamais publiée, livré avec chaque version, pour que `update.sh` mette à jour sans question un fichier simplement ancien. Écrit par `bash update.sh --make-known` dans l'arborescence source |
| `recompile.sh` | Recompile le backend et/ou le frontend et choisit la variante servie à `/`. Avec `--backend`, `--frontend` ou `--both` il ne demande rien et garde la variante actuelle — c'est ainsi que `install.sh` et `update.sh` l'appellent |
| `smeter_theme.sh` | Définir le cadran par défaut du S-mètre analogique (dark / amber / vintage) pour tous les utilisateurs, et proposer la reconstruction du frontend — voir [Modifier les variantes](https://github.com/sv1btl/PhantomSDR-Plus/blob/main/docs/fr/EDITING_VARIANTS.md) |
| `waterfall.sh` | Modifie le niveau minimal de cascade par défaut (dB) dans `waterfall.js` + `App.svelte` — voir [README](README.md) |
| `kiwi_install.sh` | Installe l'émulation des clients KiwiSDR sur une arborescence qui ne l'a pas : corrige les sources du backend, copie `src/kiwi_bridge.h` et ajoute un bloc `[kiwi_emulation]` documenté aux fichiers de configuration de la racine. Idempotent, et sauvegarde chaque fichier qu'il touche — voir [Émulation des clients KiwiSDR](Aether_config.md) |
| `tci-bridge/tci-rigctld.mjs` | Non utilisé par le récepteur. Un petit programme Node.js que l'auditeur lance à côté de son propre transceiver : il lit la fréquence, le mode et l'état d'émission dans `rigctld` de Hamlib et les sert en TCI sur le port 50001, pour que le bouton **TCI-CAT** de la page pilote un poste sans TCI, comme l'IC-7300 — voir [Pilotage du transceiver](RIG_CONTROL.md) |

### Fichiers de données

| Fichier | Rôle | Format |
|---------|------|--------|
| `markers.json` | Favoris et marqueurs de fréquence | JSON |
| `chat_history.txt` | Messages de chat des utilisateurs | Texte brut |
| `favicon.ico` | Icône du site | Image ICO |
| `fftw_wisdom` | Données d'optimisation FFT | Binaire FFTW |
| `phantom_fftw_wisdom` | Optimisation FFT supplémentaire | Binaire FFTW |

### Panneau d'administration et report de spots

| Fichier | Rôle |
|---------|------|
| `admin_server.py` | Le panneau d'administration lui-même. Outre les pages de gestion, il fait tourner l'échantillonneur de la page **Graphiques** : un thread d'arrière-plan relève toutes les 2 secondes la fréquence du processeur, la charge, la température et les utilisateurs connectés, et les conserve uniquement en mémoire — 1 heure en pleine résolution plus 24 heures de moyennes sur 30 secondes. Rien n'est écrit sur le disque : l'historique est perdu au redémarrage. |
| `admin_config.json` | Réglages du panneau d'administration (empreinte du mot de passe, ports, options, seuils de la protection thermique) |
| `proxy.py` | Le port public. Sert la page et transmet `/admin` au panneau et — sur une station configurée avec l'assistant — `/rade`, `/stats` et `/relay` aux services derrière lui, de sorte qu'un seul port est redirigé. Lit ses ports dans `admin_config.json`, ou dans `station.conf` en l'absence de panneau (`setup_admin.sh --proxy-only`) |
| `thermal_guard.py` | Protection contre la surchauffe du processeur. Arrête le serveur lorsque le processeur devient trop chaud et le relance une fois refroidi, en déduisant ses seuils du seuil critique que publie votre propre processeur plutôt que d'un nombre fixe. Elle ne cherche jamais à identifier ce qui supervise le serveur : tant qu'il fait trop chaud, elle réémet l'arrêt toutes les 2 s, si bien qu'un watchdog, une unité systemd ou une tâche cron qui le relance est défait jusqu'au refroidissement de la machine. Bibliothèque standard uniquement ; importée par `admin_server.py` (cadencée par l'échantillonneur des Graphiques) et exécutable seule pour les installations sans panneau. Par défaut en journalisation seule, elle n'agit donc sur rien tant qu'elle n'est pas activée — voir [Panneau d'administration]voir le [manuel du Thermal Guard](THERMAL_GUARD.md) |
| `autorun/` | Le démon de report de spots — voir [Rapporteur de spots autorun](INSTALLATION.md#rapporteur-de-spots-autorun-ft8ft4wspr) |
| `autorun.json` | Quelles bandes/quels modes décoder et à quelles heures UTC, identité, destinations et démarrage automatique |
| `autorun-stopped` | Présent après STOP dans le panneau : le démarrage automatique laisse le démon arrêté, redémarrages compris, jusqu'à START |
| `autorun-status.json` | État courant du démon : alimente les compteurs **de l'exécution en cours** (les tuiles par décodeur), remis à zéro par Stop/Start |
| `autorun-totals.json` | Spots téléversés **depuis toujours** par bande et mode : le nombre à côté de chaque case ; écrit par le démon afin de survivre aux redémarrages |

### Fichiers du système de compilation

| Fichier | Rôle |
|---------|------|
| `meson.build` | Configuration principale de compilation |
| `meson_options.txt` | Options de compilation configurables |
| `.gitattributes` | Attributs du dépôt Git |

---

## Code source (`src/`)

Le répertoire `src/` contient l'implémentation du backend en C++.

### Composants clés

#### 1. Application principale (`main.cpp`)
- Analyse les arguments de la ligne de commande
- Charge le fichier de configuration
- Initialise les composants du serveur
- Démarre la boucle d'événements

#### 2. Serveur de spectre (`spectrumserver.cpp`)
- Coordonne tous les composants
- Gère les connexions des utilisateurs
- Distribue les données de spectre
- Traite les requêtes des utilisateurs

#### 3. Pilotes SDR (`drivers/`)
- Interface abstraite pour le matériel SDR
- Lecture et mise en forme des données d'échantillons
- Gestion des fonctions propres à chaque appareil

#### 4. Moteur DSP (`dsp/`)
- Calcul de FFT (accéléré par CPU/GPU)
- Démodulation (AM, FM, BLU, CW, etc.)
- Filtrage et rééchantillonnage audio
- AGC par auditeur — Auto (réglée par mode) ou Fast / Medium / Slow comme sur un transceiver, choisie par la commande `agc_speed` (`utils/audioprocessing.cpp`) — et réduction de bruit

#### 5. Serveur web (`server/`)
- Communication WebSocket
- Service de fichiers statiques HTTP
- Gestion des sessions utilisateur
- Diffusion de données en temps réel

#### 6. Encodage audio (`audio/`)
- Compression FLAC
- Compression Opus
- Optimisation de la diffusion

---

## Frontend (`frontend/`)

L'interface utilisateur web construite avec Svelte et Vite.


#### 1. Application principale (`App.svelte`)
- Composant de plus haut niveau
- Structure de la mise en page
- Orchestration des composants
- **Rangée de boutons de décodeur** — un bouton par décodeur sur le panneau principal, juste sous le sélecteur de modes ; une pression démarre le décodeur et ouvre sa fenêtre, une seconde l'arrête. Elle a remplacé l'ancienne rangée de largeur de bande. RADE-v2U/RADE-v1L/RADE-v1U se trouvent dans `lib/ModesSelector.svelte`, à côté du sélecteur de modes et dans les fenêtres **Modes** et **Bands**.
- **Ligne de version** — « PhantomSDR+ | v5.5.0 original from github.com/sv1btl/PhantomSDR-Plus », l'adresse servant de lien ; la même ligne figure sur la page /mobile. Le numéro de version et l'adresse se trouvent dans `lib/version.js` ; la ligne est une attribution d'auteur couverte par `ADDITIONAL_TERMS.md`.

#### 2. Affichage en cascade (`waterfall.js` + `lib/`)
- Rendu du spectre et de la cascade sur canevas et palettes de couleurs dans `waterfall.js` (JS pur, pas un composant) ; le remappage luminosité/contraste de **Auto Adj.** est `lib/wfAutoLevel.js`
- Accord interactif via `lib/PassbandTuner.svelte`
- Superpositions du plan de bandes et des marqueurs via `lib/FrequencyMarkers.svelte`
- L'analyseur audio est `lib/Spectrogram.svelte`, le bilan audio SSB `lib/SsbReport.svelte` et le bilan AM/FM `lib/AmFmReport.svelte` ; leurs mesures RF (largeur occupée, porteuse et bande opposée en SSB, taux de modulation AM et excursion FM, la vue RF en AM/FM) viennent de `measureOccupied`, `measureSsb`, `measureAmFm` et `getRfSlice` dans `waterfall.js`, qui, analyseur ouvert, garde une connexion de cascade invisible à résolution fine autour de la fréquence d'accord (`detailFollow`), si bien qu'elles fonctionnent à tout zoom ; adapté de PhantomSDR-ORSAT de F1NSK
- Le spectre 3D est `lib/Waterfall3D.svelte` (WebGL2) : tant qu'il est ouvert, `waterfall.js` lui transmet par `waterfall.view3d` chaque ligne avec les niveaux de la cascade (Min/Max et Auto Adj. appliqués), la plage de zoom et la palette ; adapté de PhantomSDR-ORSAT de F1NSK

#### 3. Commandes (`App.svelte` + `lib/`)
- Saisie et affichage de la fréquence — `lib/FrequencyInput.svelte`
- Pavé numérique pour saisir une fréquence — `lib/FreqKeypad.svelte` ; la fréquence tapée est accordée avec le zoom, les Min/Max et le mode de sa bande (`tuneTypedFrequency()` dans `App.svelte`), et une fréquence couverte par un autre récepteur ouvre ce récepteur
- Bandes **Show All** des autres récepteurs — `lib/RxStrip.svelte` : un socket `/waterfall?rx=<id>` chacune, chaque trame décodée et dessinée, avec la palette et les niveaux de l'autre récepteur, la ligne la plus récente en haut ; les plages des récepteurs et les liens entre eux viennent de `lib/receivers.js` ; avec deux bandes ou plus dans la plage de l'autre récepteur, une liste déroulante de bandes dans son en-tête (choix dans `localStorage` `rxStripView:<id>`, le clic arrive avec `&band=1`)
- Choix du mode (AM/FM/BLU/CW) — `lib/ModesSelector.svelte`, changement de bande — `lib/BandSelector.svelte`
- Fenêtre EiBi — `lib/SwSchedule.svelte` : cherche dans `/eibi.json` avec les critères de shortwave.live ; une ligne accorde par le chemin du clic sur un marqueur (`handleFrequencyMarkerClick()` dans `App.svelte`, d'où le démarrage du décodeur pour les modes de décodeur), et ses résultats verts ainsi que le marqueur rouge « en écoute » sont dessinés par `lib/FrequencyMarkers.svelte`, et **Hide HFCC markers** masque les entrées de `markers.json` que `update-markers.sh` marque `"source": "hfcc"` ; les lignes CW sont accordées avec le mode de marqueur `MORSE`, elles ouvrent donc le décodeur CW
- L'AGC, le NR, le NB et les autres commandes se trouvent dans `App.svelte` lui-même ; il n'existe pas de `Controls.svelte` distinct

#### 3a. Scanner (`scanner.js`)
- Balayage de canaux : promène le récepteur sur une plage et s'arrête au premier canal portant un signal. Du JS pur, pas un composant — `App.svelte` fournit le VFO, le mode, le plan de bandes et l'appel d'accord, et reçoit en retour l'état de l'interface par un seul rappel
- Le seuil est exprimé en dB au-dessus du bruit de fond de la bande plutôt qu'en niveau absolu, en réutilisant le bruit que `waterfall.js` suit déjà (`snrNoiseDb`) : aucun étalonnage propre n'est nécessaire
- Deux façons de parcourir la bande : accorder et écouter chaque canal, ou examiner d'abord le spectre et n'accorder que ce qu'il ne peut pas écarter. Le spectre peut sauter un canal mais jamais s'arrêter sur un — tout arrêt provient d'une écoute réelle
- La plage est soit la bande du plan de bandes, soit exactement ce que montre la cascade ; la reprise automatique, la durée de séjour maximale et la liste d'exclusion sont ici également, conservées dans `localStorage`

#### 4. Système audio (`audio.js`)
- Flux audio WebSocket
- Décodage FLAC/Opus
- Contrôle de la lecture audio
- Distribue le PCM brut (prélevé avant la réduction de bruit et la coupure du son du navigateur ; l'AGC du serveur est maintenue sur Slow tant qu'un décodeur est ouvert) aux décodeurs de modes
- Réduction de bruit par IA : `lib/rnnoise.js` charge le module WebAssembly RNNoise (`@jitsi/rnnoise-wasm`) à la première utilisation ; `audio.js` ne l'applique qu'aux modes phonie, après la prise des décodeurs, qui ne l'entendent donc jamais
- Le FLAC passe par `flacLowLatency.js`, qui décode chaque paquet dès qu'il arrive et ramène la fréquence réelle du flux (par exemple 12016,3 Hz) à 12000 Hz avec un rééchantillonneur à 64 coefficients (2,7 ms de retard). Le décodeur WASM de `modules/` livrait le son par blocs fixes de 1024 échantillons et retenait environ 160 ms ; il sert encore pour Opus, pour les sources de diversité et pour le FLAC quand la page est ouverte avec `?flac=wasm`
- Contrôle du tampon de lecture (`playoutControl.js`) : `ArrivalMeter` mesure l'irrégularité d'arrivée des paquets par rapport à la chronologie propre du flux, ainsi que la dérive entre l'horloge d'échantillonnage du récepteur et la carte son de l'auditeur ; `CushionController` maintient le plus petit tampon de la dernière minute près de la marge du cran de tampon choisi, en coupant ou en répétant une période accordée à la hauteur du son (`spliceOut` / `spliceIn`) dans l'audio envoyé au haut-parleur. Les décodeurs et les enregistrements reçoivent le flux intact. S'applique au chemin à tampons planifiés qu'utilise tout auditeur d'une station en http simple ; `?drain=0` le désactive, `?diag=1` affiche ses valeurs

#### 4a. Décodeurs de modes et leurs workers

Chacun des décodeurs de modes lourds s'exécute dans son propre Web Worker, de sorte que le décodage ne bloque jamais la lecture audio ni la cascade. Ils suivent un schéma commun — trois fichiers par décodeur :

| Décodeur | Moteur | Worker | Proxy sur le thread principal |
|----------|--------|--------|-------------------------------|
| SSTV | `sstv.js` | `sstv.worker.js` | `sstvWorkerProxy.js` |
| FAX HF | `fax.js` | `fax.worker.js` | `faxWorkerProxy.js` |
| NAVTEX + FLDIGI (ALE 2G HAM, FSK/RTTY, PSK31/63/125, QPSK, Olivia, Contestia, PSK Browser, Olivia Browser, RTTY Browser, MFSK Browser, FST4W, MFSK, MSK144, DominoEX, THOR, THROB, Hellschreiber, MT63, Packet/APRS) + SERVICES (Maritime FSK / SITOR, Weather RTTY, ALE 2G) | `fsk.js`, `psk31.js`, `olivia.js`, `mfsk.js`, `ifk.js`, `throb.js`, `hell.js`, `mt63.js`, `fldigiFec.js`, `ax25.js`, `ale.js`, `fst4w.js`, `msk144.js`, `pskBrowser.js`, `oliviaBrowser.js`, `rttyBrowser.js`, `mfskBrowser.js` | `fsk.worker.js` | `fskWorkerProxy.js` |
| SERVICES (DSC, Time Signals, HF Selcall) | `dsc.js`, `timesig.js` | `services.worker.js` | `servicesWorkerProxy.js` |
| CW, CW Browser | `cwDecoder.js`, `cwBrowser.js` | `cw.worker.js` | `cwWorkerProxy.js` |

#### 4b. Diversité de réception (`diversity.js`)
- Associe le récepteur local à un second situé ailleurs et suit le site qui a, à cet instant, le meilleur signal. Du JS simple, pas un composant — il s'insère à un seul endroit de `audio.js`, qui lui passe le PCM local et restitue ce qu'il renvoie
- **Sélection, pas addition.** Deux sites entendent la même émission par des trajets ionosphériques différents, donc leurs formes d'onde ont des phases sans rapport ; les additionner donne un filtrage en peigne. Une combinaison cohérente exigerait une horloge commune, que deux récepteurs reliés par internet ne partagent pas. Le mélange n'a lieu que pendant un fondu de 30 ms
- L'alignement corrèle les deux **enveloppes audio** (puissance logarithmique à 100 Hz), jamais les formes d'onde — l'enveloppe survit au trajet comme à n'importe quel codec. Un verrouillage n'est retenu que si une seconde recherche indépendante concorde, ce qui écarte le décalage assuré mais faux que produiraient deux sites s'évanouissant en opposition
- Le flux distant est d'abord **verrouillé en cadence** sur le local. Deux récepteurs, ce sont deux horloges et deux chaînes de décimation : leur audio arrive jusqu'à 2% décalé même quand tous deux annoncent 12 kHz — 240 échantillons par seconde de dérive, qu'aucune corrélation ne retient. Le rapport est mesuré d'après le nombre d'échantillons réellement livré de chaque côté et appliqué par un rééchantillonneur qui conserve sa phase fractionnaire d'un bloc à l'autre, si bien qu'un rapport quelconque tient indéfiniment
- Le choix du site s'appuie sur un SNR par centiles mesuré sur des échantillons **alignés en contenu**, avec hystérésis, temporisation de maintien et une sortie rapide si le site actif s'effondre. Les niveaux sont appariés bruit à bruit, pour qu'un changement ne modifie pas le souffle de fond
- Les décodeurs conservent le flux **local** : FT8, JS8, WSPR et RADE intègrent de façon cohérente sur un intervalle, et un changement en cours d'intervalle est une discontinuité de phase qui peut coûter le décodage

#### 4c. Sources de diversité (`remoteSource.js`, `kiwiSource.js`, `uberSource.js`, `webSdrSource.js`)
- Un seul contrat — `onPcm` / `onState` / `tune` / `canReceive` — si bien que `diversity.js` ignore toujours ce qui se trouve en face. Ajouter un type de récepteur revient à ajouter un fichier
- `remoteSource.js` — un autre PhantomSDR-Plus via `/audio` (cbor + FLAC), réutilisant `createDecoder()` de `lib/wrappers.js`
- `kiwiSource.js` — un KiwiSDR : trames `SND`, PCM gros-boutiste, avec l'horodatage GPS de 10 octets qu'un paquet stéréo insère avant l'audio
- `uberSource.js` — un UberSDR via son `/ws` natif : Opus derrière un en-tête de 21 octets, réaccord sur la connexion ouverte. L'identifiant de session doit d'abord être déclaré par `POST /connection` et doit être un UUID
- `webSdrSource.js` — un WebSDR, via `websdr_relay.py` sur ce serveur : le navigateur ne peut pas se connecter directement, car WebSDR vérifie l'en-tête `Origin` et aucun script n'a le droit de le modifier. L'accord passe en trame texte sur la même connexion ; la couverture des bandes vient du relais
- `webSdrCodec.js` — le format audio de WebSDR : un flux étiqueté octet par octet dont les blocs compressés alimentent un prédicteur leaky-LMS à 20 prises. Porté depuis le client WebSDR et vérifié échantillon par échantillon
- `diversityList.js` — la liste des récepteurs enregistrés et les règles d'adresse des quatre types, partagées par le panneau de bureau et la page mobile pour qu'un seul format serve aux deux. Ainsi que le transfert — un blob compact, son code QR et un analyseur qui accepte toutes les formes que les deux pages ont jamais écrites — et `browseUrl()`, qui retransforme une adresse appelée en une adresse qu'un navigateur peut ouvrir
- `lib/DiversityPanel.svelte` — l'interface : adresse, type de source, correction de SNR et état en direct, ainsi que les récepteurs enregistrés — nommés, réordonnables, exportés et importés sous forme de fichier JSON, par type de source dans `localStorage`. Tout s'édite à l'intérieur du panneau : `prompt()` et `confirm()` bloquent le thread principal, celui-là même par lequel l'audio est poussé vers le worklet de lecture. Un bouton **▦ QR** dessine la liste en code scannable, car `localStorage` appartient à un navigateur et un téléphone démarre vide. `mobile/Mobile.svelte` reprend la même fonction dans un onglet **Div**, dans le CSS simple propre à cette page. Voir [Diversité de réception](RECEIVE_DIVERSITY.md)

#### 4d. Identificateur de mode (`modeId.js`, `modePriors.js`)
- Répond à « qu'est-ce que j'écoute ? ». Il lit la même prise PCM brute que les décodeurs et classe les modes probables, pour que l'opérateur choisisse le bon décodeur au lieu de les essayer tous les dix. Il ne décode jamais : il mesure des propriétés physiques du signal et les note face à une table de modes connus
- La largeur occupée est la largeur contiguë à −15 dB autour du pic, délibérément pas une valeur à 99 % de puissance : les clics de manipulation laissent de longues traînes sur l'intégrale de puissance et faisaient paraître tout mode étroit plusieurs fois trop large. La rapidité de modulation vient de la **fréquence instantanée** et non des énergies des tonalités, car aucune durée d'intégration ne résout à la fois un décalage de 170 Hz et un symbole de 100 Bd. La cadence de manipulation vient de l'enveloppe on/off et sert aussi d'indicateur de vitesse en CW
- `modePriors.js` apporte le seul indice que l'audio ne peut pas porter : l'endroit où vous êtes accordé. Un signal 100 Bd / 170 Hz sur 518 kHz est du NAVTEX ; le même signal sur 14,070 MHz ne l'est pas. Il ne fait que repondérer ce que le signal soutenait déjà, et n'invente jamais un candidat
- FT8, JS8 et FT2 sont annoncés comme un seul groupe à dessein : ils ne se séparent pas sur la seule largeur et le seul espacement des tonalités, et prétendre le contraire serait une réponse fausse énoncée avec assurance
- En dessous d'environ 10 dB de SNR, il se tait plutôt que de deviner
- Il tourne dans son propre Web Worker (`modeId.worker.js` + `modeIdWorkerProxy.js`), selon le même schéma moteur/worker/proxy que les décodeurs ci-dessus ; le résultat est la pastille de `lib/ModeIdChip.svelte`

#### 4e. Connexions refusées (`refused.js`, `clientVersion.js`)

- `refused.js` est le vocabulaire commun d'une connexion que le serveur éconduit : code de fermeture **4003** (au-delà d'une limite par adresse, ou page plus ancienne que `[server] min_client_version`) et **4001** (une exclusion par le sysop). Les deux sont définitifs. `audio.js`, `waterfall.js` et `events.js` importent tous `isRefusal()` de là, car tous trois ouvrent une connexion qui peut être refusée et tous trois doivent alors régler leur promesse d'initialisation — sinon la page attend indéfiniment une connexion qui ne viendra jamais
- Rien ne réessaie. Une connexion `/audio` tombée met fin à la session, délibérément : `/waterfall` et `/events` ne revenaient jamais avec une reconnexion, une session réessayée était donc de l'audio vivant sur une cascade figée, et face à une limite de débit chaque tentative prolongerait justement le refus qu'elle cherchait à contourner. La page de bureau explique un refus survenu au chargement et s'arrête simplement quand il survient en cours de session ; `/mobile` affiche une ligne invitant l'auditeur à recharger
- `clientVersion.js` contient un seul entier, `CLIENT_VERSION`, que la page ajoute à sa connexion audio sous la forme `/audio?v=N`. Le serveur éconduit tout ce qui est inférieur à `[server] min_client_version` : c'est ainsi qu'une station force les onglets exécutant encore une version antérieure à recharger — le seul levier existant, puisque le serveur n'atteint pas le JavaScript déjà en cours dans un navigateur. Incrémentez-le quand une modification du frontend ne doit plus être ignorée par les onglets ouverts
- Référence complète : [Limites de connexion](CONNECTION_LIMITS.md)

#### 4f. Réponses dans le chat (`lib/chatReply.js`)
- Une réponse est un message de chat ordinaire qui commence par un marqueur nommant le message auquel il répond, `[RE:<horodatage>|<nom>]` ; le serveur le stocke et le relaie comme toute autre ligne et n'a besoin d'aucune modification
- `chatReply.js` crée et lit ce marqueur et regroupe les réponses sous leur original, sur un niveau. `App.svelte` et `mobile/Mobile.svelte` l'utilisent tous deux, si bien que les deux pages organisent le chat de la même façon
- Quand l'original a déjà quitté l'historique de 20 messages du serveur, la réponse reste là où elle est arrivée et n'affiche que le nom et l'heure auxquels elle répond

#### 4g. Noms des auditeurs et confidentialité (`lib/identity.js`)
- La case de nom à côté de **Open Additional Info** garde le nom ou l'indicatif dans `localStorage` (`chatusername`) et l'envoie sur `/audio` sous la forme `{"cmd":"identity","name":…}` ; `audio.js` le renvoie à chaque ouverture de son socket. Un lien vers un récepteur à une autre adresse le transporte en `?idname=`, lu une fois puis retiré de la barre d'adresse
- Le serveur le nettoie (`clean_listener_name` dans `utils.cpp`) : 10 caractères au plus et sans espace comme sur un WebSDR, au moins une lettre ou un chiffre ; les noms réservés du chat et les `anonymous1234` valent aucun nom. `/users` le donne en `name` ; les étiquettes du waterfall l'affichent suivi de la ville
- Le `/users` public, `users.json` et les `/logs/users_*.jsonl` que lit `stats.html` ne contiennent aucune adresse IP : la copie du journal porte à la place un code opaque `visitor` (hachage à clé, clé dans `logs/.visitor_salt`) ; les fichiers sur disque gardent les adresses. Le panneau d'administration lit `/~~users`, qui ne répond qu'à un pair loopback sans `X-Forwarded-For`
- Le décodeur en cours suit le même chemin : `App.svelte` envoie `{"cmd":"decoder","name":"FT8"}` (vide quand aucun ne tourne) à chaque changement, et `audio.js` le renvoie sur un nouveau socket. Le serveur garde une étiquette courte (lettres, chiffres, espace, `-+/`, 12 au plus) et la donne comme `decoder` dans `/users` et dans chaque ligne de `users_*.jsonl` ; un changement est journalisé comme un changement de fréquence, pour que `stats.html` (Decoder Popularity) et la page Visitors du panneau puissent le compter
- Les bannissements de 8/16/24 heures du panneau sont conservés dans `admin_bans.json` (jamais distribué) et renvoyés à chaque récepteur une fois par minute ; `/~~unban` en lève un

#### 5. Gestion d'état (`stores/`)
- Magasins de données réactifs
- État applicatif partagé
- Gestion des événements

---

## Listes de fréquences (`frequencylist/`)

Les repères de fréquence sur la cascade. `mymarkers.json` est la liste que le récepteur affiche réellement ; le reste est la matière première que `update-markers.sh` transforme en elle, actualisée depuis les grilles en ligne. Le `README.md` de ce dossier explique la mise à jour dans les sept langues.

```
frequencylist/
├── mymarkers.json            # les repères affichés par le récepteur — édités à la main, survivent à une mise à jour
├── shortwavestations.json    # stations en ondes courtes, généré par generate-current-shortwave.py
├── 0.TXT                     # la grille HF mondiale A26, décompressée et analysée par update-markers.sh
├── a26allx2.zip              # archive source téléchargée par update-markers.sh
├── admin.txt · antenna.txt · broadcas.txt · fmorg.txt · language.txt · site.txt
│                             # listes annexes de la même source (sites, langues, administrateurs, antennes)
├── generate-current-shortwave.py
├── update-eibi.sh            # récupère la grille EiBi pour la fenêtre EiBi, au plus une fois par jour
├── generate-eibi.py          # la transforme en frontend/public/eibi.json et frontend/dist/eibi.json
├── update-markers.sh         # actualise tout ce qui précède depuis les grilles en ligne
└── README.md
```

La fenêtre EiBi (le bouton **EiBi**) utilise une seconde liste, distincte. `update-markers.sh` lance d'abord `update-eibi.sh`, qui vérifie la grille EiBi (http://www.eibispace.de/dx/) au plus une fois par jour et ne la télécharge que si EiBi en a publié une nouvelle, en passant de lui-même à la liste de la saison suivante (été A, hiver B) ; `generate-eibi.py` la transforme en `eibi.json` pour la page et déduit le mode de chaque station. Lancez `./frequencylist/update-eibi.sh --force` pour la récupérer tout de suite. Un téléchargement raté n'arrête jamais la mise à jour des marqueurs. `update.sh` met à jour les deux scripts et demande d'abord si vous les avez modifiés. `update-markers.sh` marque aussi chaque entrée HFCC qu'il écrit dans `markers.json` avec `"source": "hfcc"` ; **Hide HFCC markers** de la fenêtre EiBi masque exactement celles-là.

### Format (`mymarkers.json`, `shortwavestations.json`)

```json
[
    { "frequency": 77500,   "name": "DCF77", "mode": "CW" },
    { "frequency": 2485000, "name": "Vanuatu Broadcasting", "mode": "AM" }
]
```

`mode` est un mode du récepteur (`USB`, `LSB`, `AM`, `FM`, `CW`, …) ou le nom d'un mode numérique — `FT8`, `FT4`, `FT2`, `JS8`, `WSPR`, `SSTV`, `NAVTEX`, `FAX`, `RTTY`, `RTTY-WX`, `RTTY-NAV`, `SITOR`, `PSK31`, `PSK63`, `PSK125`, `BPSK31`/`63`/`125`, `QPSK31`/`63`/`125`, `OLIVIA`, `CONTESTIA`, `MFSK`, `MFSK16`, `MFSK32`, `MFSK64`, `DOMINOEX`, `THOR`, `THROB`, `HELL`, `FELDHELL`, `MT63`, `PACKET`, `APRS`, `RADEU`, `RADEL`, `RADE` ou `FREEDV` — auquel cas un clic sur le marqueur démarre ce décodeur ([détails](DECODERS.md#démarrer-un-décodeur-depuis-un-marqueur-de-fréquence)).

---

## Fichiers de configuration

### Configuration du serveur (fichiers `.toml`)

Structure des fichiers de configuration :

```toml
[server]
# Web server settings
port = 9001
html_root = "frontend/dist/"
threads = 2
otherusers = 1
iq = true

[limits]
# Limites par adresse — toutes désactivées ou à une valeur raisonnable par défaut,
# une configuration sans elles se comporte comme avant. Voir CONNECTION_LIMITS.md.
per_ip = 3              # auditeurs simultanés depuis une adresse
per_ip_rate = 40        # nouvelles connexions par minute depuis une adresse

[websdr]
# Online registration
register_online = true
name = "WebSDR Name"
antenna = "Antenna Type"
grid_locator = "AB12cd"
hostname = "domain.com"

[input]
# SDR input settings
sps = 2048000           # Sample rate
fft_size = 131072       # FFT size
frequency = 145000000   # Base frequency
signal = "iq"           # Signal type: "iq" or "real"
audio_sps = 12000       # Audio sample rate
audio_compression = "opus"  # "flac" or "opus"
accelerator = "opencl"  # "none", "cuda", "opencl"

[input.driver]
# Driver settings
name = "stdin"
format = "u8"           # Sample format

[input.defaults]
# User interface defaults
frequency = 145500000
modulation = "FM"
```

### Informations du site (`site_information.json`)

```json
{
  "siteSysop": "Operator Callsign",
  "siteSysopEmailAddress": "email@example.com",
  "siteGridSquare": "AB12cd",
  "siteCity": "City, Country",
  "siteInformation": "https://github.com/sv1btl/PhantomSDR-Plus",
  "siteHardware": "Hardware specs",
  "siteSoftware": "Software version",
  "siteReceiver": "SDR model",
  "siteAntenna": "Antenna description",
  "siteNote": "Additional notes",
  "siteIP": "http://domain.com:9000",
  "siteSDRBaseFrequency": 0,
  "siteSDRBandwidth": 2048000,
  "siteRegion": 1,
  "siteChatEnabled": true
}
```

---

## Système de compilation

### Configuration de compilation Meson

#### `meson.build` (racine)

Définit :
- Les métadonnées du projet
- Les dépendances
- Les options du compilateur
- Les listes de fichiers sources
- Les cibles de compilation

#### `meson_options.txt`

Options disponibles :
```
option('opencl', type: 'boolean', value: false, description: 'Enable OpenCL support')
option('cuda', type: 'boolean', value: false, description: 'Enable CUDA support')
option('optimization', type: 'string', value: '3', description: 'Optimization level')
```

---

## Flux de données

### Flux de fonctionnement du serveur

```
1. SDR Hardware → rtl_sdr/hackrf_transfer/etc.
                ↓
2. Sample Stream → stdin → spectrumserver
                ↓
3. spectrumserver:
   - FFT calculation (waterfall)
   - Demodulation (audio)
   - Compression (FLAC/Opus)
                ↓
4. WebSocket → Browser Client
                ↓
5. Browser:
   - Render waterfall
   - Decode and play audio
   - Display controls
```

### Flux d'interaction utilisateur

```
1. User clicks on waterfall
                ↓
2. JavaScript sends frequency change request
                ↓
3. WebSocket → spectrumserver
                ↓
4. spectrumserver:
   - Updates demodulator frequency
   - Sends new audio stream
                ↓
5. Browser receives and plays new audio
```

---

## Guide de modification des fichiers

### Lorsque vous modifiez le code du backend (`src/**`) :

```bash
./recompile.sh --backend
```

### Lorsque vous modifiez le code du frontend (`frontend/src/**`) :

```bash
./recompile.sh --frontend
```

### Lorsque vous modifiez la configuration (`.toml`, `.json`) :

```bash
# Restart server
./stop-websdr.sh
./start-rtl.sh  # (or appropriate start script)
```

### Lorsque vous modifiez les marqueurs (`markers.json`) :

```bash
# Reload page in browser
# No server restart needed
```

---

## Opérations courantes sur les fichiers

### Personnaliser le frontend

1. Modifiez la source : `nano frontend/src/App.svelte`
2. Recompilez : `./recompile.sh --frontend`
3. Redémarrez le serveur : `./stop-websdr.sh && ./start-rtl.sh`

### Ajouter des marqueurs personnalisés

1. Modifiez le fichier de marqueurs : `nano markers.json`
2. Format :
   ```json
   {
     "markers": [
       {
         "frequency": 145500000,
         "label": "2m Calling",
         "mode": "FM"
       }
     ]
   }
   ```
3. Rechargez le navigateur (aucun redémarrage du serveur nécessaire)

---

## Gestion de versions

### Publier une version (mainteneur)

Avant d'envoyer les fichiers, renouvelez la liste d'empreintes, afin que `update.sh` reconnaisse sur chaque station les versions qu'elle possède comme publiées :

```bash
# 1. copiez les fichiers modifiés dans la copie à envoyer, puis :
bash update.sh --make-known /path/to/the/upload/copy
# 2. committez update-known.txt et copiez-le aussi dans la copie à envoyer
```

La liste ne fait que grandir : les entrées des versions précédentes sont conservées, si bien qu'une copie publique publiée une fois reste reconnaissable dans toutes les versions suivantes.

---

Pour les instructions d'installation, voir [INSTALLATION.md](INSTALLATION.md). Pour les informations d'utilisation, voir [USER_GUIDE.md](USER_GUIDE.md).

**73 de SV1BTL, 9A7AOF, F1NSK & SV2AMK**
